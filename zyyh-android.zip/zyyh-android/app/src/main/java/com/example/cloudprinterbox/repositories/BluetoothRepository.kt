package com.example.cloudprinterbox.repositories

import android.annotation.SuppressLint
import com.example.ble.model.BleDevice
import com.example.cloudprinterbox.model.BluetoothConnectResult
import com.example.cloudprinterbox.model.BluetoothNotifyResult
import com.example.cloudprinterbox.utils.bluetooth.BluetoothManagement

class BluetoothRepository {

    fun startScan(block: (BleDevice?) -> Unit) = BluetoothManagement.startScan(block)

    @SuppressLint("MissingPermission")
    fun startConnect(device: BleDevice, block: (BluetoothConnectResult) -> Unit) = BluetoothManagement.startConnect(device, block)

    fun enableNotify(device: BleDevice, block: (BluetoothNotifyResult) -> Unit) = BluetoothManagement.enableNotify(device, block)

    fun writeData(device: BleDevice, data: ByteArray, block: (Boolean) -> Unit) = BluetoothManagement.writeData(device, data, block)

    fun readData(device: BleDevice) = BluetoothManagement.readData(device)

}