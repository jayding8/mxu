package com.example.cloudprinterbox

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.ViewModelProvider
import com.example.ble.model.BleDevice
import com.example.cloudprinterbox.utils.share.SharedFlowUtil
import com.example.cloudprinterbox.utils.sp.SharedPreferenceUtil
import com.example.cloudprinterbox.view.LoadingDialog
import com.example.cloudprinterbox.viewmodel.ConnectAndBindDeviceViewModel
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class ConnectAndBindDeviceActivity : ComponentActivity() {

    private val viewModel by lazy { ViewModelProvider(this)[ConnectAndBindDeviceViewModel::class.java] }

    private lateinit var loadingDialog: LoadingDialog

    private var device: BleDevice? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connect_and_bind)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            device = intent.getParcelableExtra("KEY_BLE_DEVICE", BleDevice::class.java)
        } else {
            device = intent.getParcelableExtra<BleDevice>("KEY_BLE_DEVICE")
        }
        initView()
        initData()
    }

    private fun initView() {
        val etWifiName = findViewById<EditText>(R.id.et_wifi_name)
        val etWifiPassword = findViewById<EditText>(R.id.et_wifi_password)
        val btnConnectDevice = findViewById<Button>(R.id.btn_connect_device)
        btnConnectDevice.setOnClickListener {
            val wifiName = etWifiName.text.toString()
            if (wifiName.isEmpty()) {
                Toast.makeText(this, "wifi名称不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val wifiPassword = etWifiPassword.text.toString()
            if (wifiPassword.isEmpty()) {
                Toast.makeText(this, "wifi密码不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            loadingDialog.showLoading()
            viewModel.writeData(device!!, wifiName, wifiPassword) { }
        }
        loadingDialog = LoadingDialog(this)
    }

    private fun initData() {
        viewModel.flowScope.launch {
            SharedFlowUtil.collect(SharedFlowUtil.bluetoothNotifyDataFlow) {
                // bind to server
                if (it.state == 1) {
                    viewModel.bindDeviceWithUser("${it.specific}_${it.id}", SharedPreferenceUtil.getUserId(), SharedPreferenceUtil.getUserToken())
                } else {
                    MainScope().launch {
                        SharedPreferenceUtil.setBindDeviceState(false)
                        Toast.makeText(this@ConnectAndBindDeviceActivity, "设备连接失败", Toast.LENGTH_SHORT).show()
                        loadingDialog.dismissLoading()
                    }
                }
            }
        }

        viewModel.flowScope.launch {
            viewModel.bindDeviceResultFlow.collect {success ->
                MainScope().launch {
                    loadingDialog.dismissLoading()
                    if (success) {
                        //TODO 跳转页面
                        SharedPreferenceUtil.setBindDeviceState(true)
                        Toast.makeText(this@ConnectAndBindDeviceActivity, "设备绑定成功", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@ConnectAndBindDeviceActivity, BindSuccessActivity::class.java))
                    } else {
                        SharedPreferenceUtil.setBindDeviceState(false)
                        Toast.makeText(this@ConnectAndBindDeviceActivity, "设备绑定失败", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}