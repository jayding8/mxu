package com.example.cloudprinterbox.repositories

import com.example.cloudprinterbox.model.BindDeviceResult
import com.example.cloudprinterbox.model.LoginResult
import com.example.cloudprinterbox.model.Responses
import com.example.cloudprinterbox.repositories.Api.KEY_BIND_DEVICE_SPECIFIC_ID
import com.example.cloudprinterbox.repositories.Api.KEY_BIND_DEVICE_USER_ID
import com.example.cloudprinterbox.repositories.Api.KEY_BIND_DEVICE_USER_TOKEN
import com.example.cloudprinterbox.repositories.Api.KEY_LOGIN_PASSWORD
import com.example.cloudprinterbox.repositories.Api.KEY_LOGIN_PHONE_NUMBER
import com.example.cloudprinterbox.repositories.Api.URL_BIND_DEVICE
import com.example.cloudprinterbox.repositories.Api.URL_LOGIN
import com.example.cloudprinterbox.utils.network.Network
import com.google.gson.Gson
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume

class UserRepository {

    suspend fun login(userName: String, password: String): Responses<LoginResult>? {
        return withTimeout(TIMEOUT) {
            suspendCancellableCoroutine { continuation ->
                Network.post(URL_LOGIN, hashMapOf(
                    KEY_LOGIN_PHONE_NUMBER to userName,
                    KEY_LOGIN_PASSWORD to password
                ), object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        continuation.resume(Responses(false, null))
                    }

                    override fun onResponse(call: Call, response: Response) {
                        val loginResult = Gson().fromJson(response.body?.string(), LoginResult::class.java)
                        if (loginResult.code == RESPONSE_OK_CODE) {
                            continuation.resume(Responses(true, loginResult))
                        } else {
                            continuation.resume(Responses(false, null))
                        }
                    }
                })
                continuation.invokeOnCancellation {
                    continuation.resume(Responses(false, null))
                }
            }
        }
    }

    suspend fun bindDeviceToUser(deviceId: String, userId: String, token: String): Responses<BindDeviceResult>? {
        return withTimeout(TIMEOUT) {
            suspendCancellableCoroutine { continuation ->
                Network.postWithHeader(
                    URL_BIND_DEVICE, hashMapOf(
                        KEY_BIND_DEVICE_SPECIFIC_ID to deviceId,
                        KEY_BIND_DEVICE_USER_ID to userId
                ), hashMapOf(KEY_BIND_DEVICE_USER_TOKEN to token), object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        continuation.resume(Responses(false, null))
                    }

                    override fun onResponse(call: Call, response: Response) {
                        val bindDeviceResult = Gson().fromJson(response.body?.string(), BindDeviceResult::class.java)
                        if (bindDeviceResult.code == RESPONSE_OK_CODE) {
                            continuation.resume(Responses(true, bindDeviceResult))
                        } else {
                            continuation.resume(Responses(false, null))
                        }
                    }
                })
                continuation.invokeOnCancellation {
                    continuation.resume(Responses(false, null))
                }
            }
        }
    }

    companion object {
        const val TIMEOUT = 15000L
        const val RESPONSE_OK_CODE = 200
    }
}