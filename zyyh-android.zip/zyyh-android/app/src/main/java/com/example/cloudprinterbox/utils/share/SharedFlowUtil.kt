package com.example.cloudprinterbox.utils.share

import com.example.cloudprinterbox.model.NotifyResultDetail
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object SharedFlowUtil {

    val _bluetoothNotifyDataFlow = MutableSharedFlow<NotifyResultDetail>()
    val bluetoothNotifyDataFlow = _bluetoothNotifyDataFlow.asSharedFlow()

    suspend fun <T> emit(flow: MutableSharedFlow<T>, data: T) {
        flow.emit(data)
    }

    suspend fun <T> collect(flow: SharedFlow<T>, block: (T) -> Unit) {
        flow.collect {
            block.invoke(it)
        }
    }

}