package com.example.cloudprinterbox.adapters

import android.view.View

interface OnItemClickListener<T> {

    fun onItemClick(view: View, data: T)

}