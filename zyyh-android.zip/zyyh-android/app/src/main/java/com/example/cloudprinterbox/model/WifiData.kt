package com.example.cloudprinterbox.model

data class WifiData(val ssid: String, val passwd: String)
