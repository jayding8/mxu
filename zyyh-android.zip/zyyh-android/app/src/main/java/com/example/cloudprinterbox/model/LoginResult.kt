package com.example.cloudprinterbox.model

import com.google.gson.annotations.SerializedName

data class LoginResult(val code: Int, val data: LoginResultDetail? = null)


data class LoginResultDetail(
    val userId: String,
    @SerializedName("phone_number") val phone: String,
    val refresh: String
)