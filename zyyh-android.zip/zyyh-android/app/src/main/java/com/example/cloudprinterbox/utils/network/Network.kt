package com.example.cloudprinterbox.utils.network

import okhttp3.Callback
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request

object Network {

    fun getOrCreateOkhttpClient(): OkHttpClient {
        return OkHttpClient.Builder().build()
    }

    fun post(url: String, map: HashMap<String, String>, callback: Callback) {
        val formBody = FormBody.Builder()
        map.forEach {
            formBody.add(it.key, it.value)
        }
        val requestBody = formBody.build()
        val request = Request.Builder().url(url).post(requestBody).build()
        getOrCreateOkhttpClient().newCall(request).enqueue(callback)
    }

    fun postWithHeader(url: String, map: HashMap<String, String>, headerMap: HashMap<String, String>, callback: Callback) {
        val formBody = FormBody.Builder()
        map.forEach {
            formBody.add(it.key, it.value)
        }
        val requestBody = formBody.build()
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .addHeaderFromMap(headerMap)
            .build()
        getOrCreateOkhttpClient().newCall(request).enqueue(callback)
    }

    private fun Request.Builder.addHeaderFromMap(hashMap: HashMap<String, String>) = apply {
        hashMap.forEach {
            addHeader(it.key, it.value)
        }
    }
}
