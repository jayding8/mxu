package com.example.cloudprinterbox

import android.app.Application
import com.example.cloudprinterbox.utils.bluetooth.BluetoothManagement
import com.example.cloudprinterbox.utils.sp.SharedPreferenceUtil


class CloudPrinterBoxApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        SharedPreferenceUtil.init(applicationContext)
        BluetoothManagement.initBle(this)
    }
}