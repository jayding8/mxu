package com.example.cloudprinterbox


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ble.model.BleDevice
import com.example.cloudprinterbox.adapters.OnItemClickListener
import com.example.cloudprinterbox.adapters.ScanResultAdapter
import com.example.cloudprinterbox.utils.share.SharedFlowUtil
import com.example.cloudprinterbox.viewmodel.BluetoothScanViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class BluetoothScanActivity : ComponentActivity() {

    private val viewModel by lazy { ViewModelProvider(this)[BluetoothScanViewModel::class.java] }

    private var recyclerView: RecyclerView? = null

    private var mAdapter: ScanResultAdapter? = null

    private var deviceInfos: ArrayList<BleDevice> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth_scan)
        initView()
        initData()
    }

    private fun initData() {
        viewModel.startScan()
        viewModel.flowScope.launch {
            viewModel.bluetoothScanResultFlow.collect {
                MainScope().launch {
                    mAdapter?.refresh(it)
                }
            }
        }
    }

    private fun initView() {
        recyclerView = findViewById(R.id.rv_bluetooth_devices)
        mAdapter = ScanResultAdapter(deviceInfos).also {
            it.setOnItemClickListener(object : OnItemClickListener<BleDevice> {
                override fun onItemClick(view: View, data: BleDevice) {
                    viewModel.startConnect(data) { connectResult ->
                        if (connectResult.state) {
                            viewModel.enableNotify(data) {
                                val result = it.data
                                CoroutineScope(Dispatchers.IO).launch {
                                    result?.let {detail ->
                                        SharedFlowUtil.emit(SharedFlowUtil._bluetoothNotifyDataFlow, detail)
                                    }
                                }
                                Log.i("BluetoothScanActivity", "notify data: $result")
                            }
                            startActivity(
                                Intent(
                                    this@BluetoothScanActivity,
                                    ConnectAndBindDeviceActivity::class.java
                                ).apply {
                                    putExtra("KEY_BLE_DEVICE", data)
                                }
                            )
                        } else {
                            Toast.makeText(this@BluetoothScanActivity, "连接失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            })
        }
        recyclerView?.run {
            layoutManager = LinearLayoutManager(this@BluetoothScanActivity)
            adapter = mAdapter

        }
    }
}