package com.example.cloudprinterbox.model

data class BluetoothConnectResult(var state: Boolean)