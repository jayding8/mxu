package com.example.cloudprinterbox.model

data class Responses<T>(val success: Boolean, val data: T?)