package com.example.cloudprinterbox.adapters

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.ble.model.BleDevice
import com.example.cloudprinterbox.R


class ScanResultAdapter(private var dataList: ArrayList<BleDevice>) :
    RecyclerView.Adapter<ScanResultAdapter.ScanResultViewHolder>() {

    private var onItemClickListener: OnItemClickListener<BleDevice>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScanResultViewHolder {
        val view: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_scan_result, parent, false)
        return ScanResultViewHolder(view)
    }

    @SuppressLint("MissingPermission")
    override fun onBindViewHolder(holder: ScanResultViewHolder, position: Int) {
        val deviceInfo = dataList[position]
        holder.tvName.text = deviceInfo?.bleName ?: ""
        holder.btnConnect.setOnClickListener {
            this.onItemClickListener?.onItemClick(holder.itemView, deviceInfo)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    fun refresh(newDataList: ArrayList<BleDevice>) {
        this.dataList = newDataList
        notifyDataSetChanged()
    }

    fun setOnItemClickListener(listener: OnItemClickListener<BleDevice>) {
        this.onItemClickListener = listener
    }

    inner class ScanResultViewHolder(view: View) : ViewHolder(view) {
        var tvName: TextView
        var btnConnect: Button

        init {
            tvName = view.findViewById(R.id.tv_name)
            btnConnect = view.findViewById(R.id.btn_connect)
        }
    }
}

