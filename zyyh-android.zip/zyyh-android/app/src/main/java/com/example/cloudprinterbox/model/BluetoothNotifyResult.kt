package com.example.cloudprinterbox.model

data class BluetoothNotifyResult(var state: Boolean, var data: NotifyResultDetail?)

data class NotifyResultDetail(val specific: String, val id: String, val state: Int)