package com.example.cloudprinterbox.viewmodel

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import androidx.lifecycle.ViewModel
import com.example.ble.model.BleDevice
import com.example.cloudprinterbox.model.BluetoothConnectResult
import com.example.cloudprinterbox.model.BluetoothNotifyResult
import com.example.cloudprinterbox.repositories.BluetoothRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

class BluetoothScanViewModel : ViewModel() {

    val flowScope = CoroutineScope(Dispatchers.IO)

    private val _bluetoothScanResultFlow = MutableSharedFlow<ArrayList<BleDevice>>()
    val bluetoothScanResultFlow = _bluetoothScanResultFlow.asSharedFlow()

    val deviceInfos: ArrayList<BleDevice> = arrayListOf()

    val bluetoothRepo = BluetoothRepository()

    @SuppressLint("MissingPermission")
    fun startScan() {
        bluetoothRepo.startScan { scanResult ->
            CoroutineScope(Dispatchers.IO).launch {
                scanResult?.let { device ->
                    if (device?.bleName != null && device.bleName.startsWith("A100")) {
                        if (deviceInfos.find { it.bleName == device.bleName } == null) {
                            deviceInfos.add(device)
                            _bluetoothScanResultFlow.emit(deviceInfos)
                        }
                    }
                }

            }
        }
    }

    fun startConnect(device: BleDevice, block: (BluetoothConnectResult) -> Unit) {
        bluetoothRepo.startConnect(device, block)
    }

    fun enableNotify(device: BleDevice, block: (BluetoothNotifyResult) -> Unit) = bluetoothRepo.enableNotify(device, block)
}