package com.example.cloudprinterbox.model

data class BindDeviceResult(val code: Int, val msg: String)
