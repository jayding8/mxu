package com.example.cloudprinterbox.viewmodel

import androidx.lifecycle.ViewModel
import com.example.ble.model.BleDevice
import com.example.cloudprinterbox.model.WifiData
import com.example.cloudprinterbox.repositories.BluetoothRepository
import com.example.cloudprinterbox.repositories.UserRepository
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

class ConnectAndBindDeviceViewModel : ViewModel() {

    val flowScope = CoroutineScope(Dispatchers.IO)

    private val bluetoothRepo = BluetoothRepository()

    private val userRepo = UserRepository()

    private val _bindDeviceResultFlow = MutableSharedFlow<Boolean>()
    val bindDeviceResultFlow = _bindDeviceResultFlow.asSharedFlow()

    fun writeData(device: BleDevice, wifiName: String, wifiPassword: String, block: (Boolean) -> Unit) {
        val wifiByteData = Gson().toJson(WifiData(wifiName, wifiPassword)).toByteArray()
        val sendByteArray = ByteArray(wifiByteData.size + 2)
        sendByteArray[0] = (170 and 0xFF).toByte()
        wifiByteData.forEachIndexed { index, byte ->
            sendByteArray[index + 1] = byte
        }
        sendByteArray[wifiByteData.size + 1] = (255 and 0xFF).toByte()
        bluetoothRepo.writeData(device, sendByteArray) {
            block.invoke(it)
        }
    }

    fun bindDeviceWithUser(deviceId: String, userId: String?, userToken: String?) {
        CoroutineScope(Dispatchers.IO).launch {
            val result = userRepo.bindDeviceToUser(deviceId, userId ?: "", userToken ?: "")
            result?.let {
                _bindDeviceResultFlow.emit(it.success)
            }
        }
    }

}