package com.example.cloudprinterbox

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.ViewModelProvider
import com.example.cloudprinterbox.utils.sp.SharedPreferenceUtil
import com.example.cloudprinterbox.view.LoadingDialog
import com.example.cloudprinterbox.viewmodel.LoginViewModel
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class LoginActivity : ComponentActivity() {

    private val viewModel by lazy { ViewModelProvider(this)[LoginViewModel::class.java] }

    private lateinit var loadingDialog: LoadingDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        initView()
        initData(intent)
        onLoginDataChanged()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        initData(intent)
    }

    private fun initView() {
        val etPhone = findViewById<EditText>(R.id.et_phone)
        val etPassword = findViewById<EditText>(R.id.et_password)
        val btnLogin = findViewById<Button>(R.id.btn_login)
        btnLogin.setOnClickListener {
            val phone = etPhone.text.toString()
            if (phone.isEmpty()) {
                Toast.makeText(this, "手机号不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val password = etPassword.text.toString()
            if (password.isEmpty()) {
                Toast.makeText(this, "密码不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            loadingDialog.showLoading()
            viewModel.login(phone, password)
        }
        loadingDialog = LoadingDialog(this)
    }

    private fun initData(intent: Intent?) {
        val forceLogin = intent?.getBooleanExtra("forceLogin", false)
        if (forceLogin == true) {

        } else {
            if (SharedPreferenceUtil.getBindDeviceState() && SharedPreferenceUtil.getUserId()?.isNotEmpty() == true) {
                startActivity(Intent(this@LoginActivity, BindSuccessActivity::class.java))
            }
        }
    }

    private fun onLoginDataChanged() {
        viewModel.flowScope.launch {
            viewModel.loginResultFlow.collect { result ->
                MainScope().launch {
                    loadingDialog.dismissLoading()
                    if (result.success) {
                        Toast.makeText(this@LoginActivity, "登录成功", Toast.LENGTH_SHORT).show()
                        SharedPreferenceUtil.setUserId(result.data?.data?.userId ?: "")
                        SharedPreferenceUtil.setUserToken(result.data?.data?.refresh ?: "")
                        // jump activity to search ble
                        startActivity(Intent(this@LoginActivity, BluetoothPermissionCheckActivity::class.java))
                    } else {
                        Toast.makeText(this@LoginActivity, "登录失败", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}