package com.example.cloudprinterbox.view

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import com.example.cloudprinterbox.R

class LoadingDialog(private val context: Context) {

    private var dialog: AlertDialog? = null

    fun showLoading() {
        // 使用布局加载器加载自定义的加载布局
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_loading, null)

        // 创建 AlertDialog 并设置不可取消（用户无法点击外部关闭）
        dialog = AlertDialog.Builder(context)
            .setView(view)
            .setCancelable(false) // 禁止点击外部取消
            .create()

        // 显示 Dialog
        dialog?.show()
    }

    fun dismissLoading() {
        // 关闭 Dialog
        dialog?.dismiss()
    }
}
