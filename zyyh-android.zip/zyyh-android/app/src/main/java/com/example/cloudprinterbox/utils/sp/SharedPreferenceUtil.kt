package com.example.cloudprinterbox.utils.sp

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences


@SuppressLint("StaticFieldLeak")
object SharedPreferenceUtil {

    private const val PREF_NAME = "cloud_printer_box"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_BIND_DEVICE_STATE = "bind_device_state"
    private const val KEY_USER_TOKEN = "user_token"

    private var sharedPreferences: SharedPreferences? = null
    private var context: Context? = null

    fun init(context: Context) {
        this.context = context
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun setUserId(userId: String) {
        sharedPreferences?.edit()?.putString(KEY_USER_ID, userId)?.apply()
    }

    fun getUserId(): String? {
        return sharedPreferences!!.getString(KEY_USER_ID, "")
    }

    fun setBindDeviceState(success: Boolean) {
        sharedPreferences?.edit()?.putBoolean(KEY_BIND_DEVICE_STATE, success)?.apply()
    }

    fun getBindDeviceState(): Boolean {
        return sharedPreferences!!.getBoolean(KEY_BIND_DEVICE_STATE, false)
    }

    fun setUserToken(token: String) {
        sharedPreferences?.edit()?.putString(KEY_USER_TOKEN, token)?.apply()
    }

    fun getUserToken(): String? {
        return sharedPreferences!!.getString(KEY_USER_TOKEN, "")
    }
}