package com.example.cloudprinterbox.utils.bluetooth

import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.content.Context
import android.util.Log
import com.example.ble.Ble
import com.example.ble.BleLog
import com.example.ble.callback.BleConnectCallback
import com.example.ble.callback.BleNotifyCallback
import com.example.ble.callback.BleReadCallback
import com.example.ble.callback.BleScanCallback
import com.example.ble.callback.BleWriteCallback
import com.example.ble.model.BleDevice
import com.example.ble.utils.ByteUtils
import com.example.ble.utils.UuidUtils
import com.example.cloudprinterbox.model.BluetoothConnectResult
import com.example.cloudprinterbox.model.BluetoothNotifyResult
import com.example.cloudprinterbox.model.NotifyResultDetail
import java.lang.Exception
import java.util.UUID

object BluetoothManagement {

//    private var bluetoothManager: BluetoothManager? = null
//
//    private var bluetoothGatt: BluetoothGatt? = null
//
//    private var currentDevice: BluetoothDevice? = null
//
//    private var currentService: BluetoothGattService? = null
//
//    private var currentCharacteristic: BluetoothGattCharacteristic? = null
//
//    fun setBluetoothManager(bluetoothManager: BluetoothManager?) {
//        this.bluetoothManager = bluetoothManager
//    }
//
//    @SuppressLint("MissingPermission")
//    fun startScan(block: (BluetoothDevice?) -> Unit) {
//        bluetoothManager?.run {
//            if (!adapter.isEnabled) {
//                return
//            }
//            adapter.bluetoothLeScanner?.startScan(object: ScanCallback() {
//
//                override fun onScanResult(callbackType: Int, result: ScanResult?) {
//                    super.onScanResult(callbackType, result)
//                    currentDevice = result?.device
//                    block.invoke(currentDevice)
//                }
//
//                override fun onScanFailed(errorCode: Int) {
//                    super.onScanFailed(errorCode)
//                    currentDevice = null
//
//                }
//            })
//        }
//    }
//
//    @SuppressLint("MissingPermission")
//    fun stopScan() {
//        bluetoothManager?.run {
//            if (!adapter.isEnabled) {
//                return
//            }
//            adapter.bluetoothLeScanner?.stopScan(object: ScanCallback() {})
//        }
//    }
//
//    @SuppressLint("MissingPermission")
//    fun startConnect(context: Context, wifiName: String, wifiPassword: String, block: (String?) -> Unit) {
//        var gattCallback = object : BluetoothGattCallback() {
//
//            @SuppressLint("MissingPermission")
//            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
//                super.onConnectionStateChange(gatt, status, newState)
//                if (newState == BluetoothProfile.STATE_CONNECTED) {
//                    Log.i("BluetoothRepository", "connect to GATT server")
//                    bluetoothGatt?.discoverServices()
//                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
//                    Log.i("BluetoothRepository", "disconnect to GATT server")
//                }
//            }
//
//            override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
//                super.onServicesDiscovered(gatt, status)
//                if (status == BluetoothGatt.GATT_SUCCESS) {
//                    gatt?.services?.get(0)?.let {
//                        currentService = it
//                        currentCharacteristic = it.characteristics?.get(0)
//                        val notifySuccess = gatt.setCharacteristicNotification(currentCharacteristic, true)
//                        if (notifySuccess) {
//
//                        }
//                    }
//                }
//            }
//
//            override fun onCharacteristicWrite(
//                gatt: BluetoothGatt?,
//                characteristic: BluetoothGattCharacteristic?,
//                status: Int
//            ) {
//                super.onCharacteristicWrite(gatt, characteristic, status)
//            }
//
//            override fun onCharacteristicChanged(
//                gatt: BluetoothGatt?,
//                characteristic: BluetoothGattCharacteristic?
//            ) {
//                super.onCharacteristicChanged(gatt, characteristic)
//            }
//        }
//        bluetoothGatt = currentDevice?.connectGatt(context, false, gattCallback)
//    }

    private var ble: Ble<BleDevice>? = null

    private const val TAG = "BluetoothManagement"

    private var serviceUUID: UUID? = null

    private var characteristicUUID: UUID? = null

    fun initBle(context: Context) {
        ble = Ble.options() //开启配置
            .setLogBleEnable(true) //设置是否输出打印蓝牙日志（非正式打包请设置为true，以便于调试）
            .setThrowBleException(true) //设置是否抛出蓝牙异常 （默认true）
            .setAutoConnect(false) //设置是否自动连接 （默认false）
            .setIgnoreRepeat(false) //设置是否过滤扫描到的设备(已扫描到的不会再次扫描)
            .setConnectTimeout((10 * 1000).toLong()) //设置连接超时时长（默认10*1000 ms）
            .setMaxConnectNum(7) //最大连接数量
            .setScanPeriod((12 * 1000).toLong()) //设置扫描时长（默认10*1000 ms）
            .setUuidService(UUID.fromString(UuidUtils.uuid16To128("fd00"))) //设置主服务的uuid（必填）
            .setUuidWriteCha(UUID.fromString(UuidUtils.uuid16To128("fd01"))) //设置可写特征的uuid （必填,否则写入失败）
            .setUuidReadCha(UUID.fromString(UuidUtils.uuid16To128("fd02"))) //设置可读特征的uuid （选填）
            .setUuidNotifyCha(UUID.fromString(UuidUtils.uuid16To128("fd03"))) //设置可通知特征的uuid （选填，库中默认已匹配可通知特征的uuid）
            .create(context, object : Ble.InitCallback {
                override fun success() {
                    BleLog.e(TAG, "初始化成功")
                }

                override fun failed(failedCode: Int) {
                    BleLog.e(TAG, "初始化失败：$failedCode")
                }
            })
    }

    fun startScan(block: (BleDevice?) -> Unit) {
        ble?.startScan(object: BleScanCallback<BleDevice>() {
            override fun onLeScan(device: BleDevice?, rssi: Int, scanRecord: ByteArray?) {
               block.invoke(device)
            }

            override fun onStart() {
                super.onStart()
            }

            override fun onStop() {
                super.onStop()
            }

            override fun onScanFailed(errorCode: Int) {
                super.onScanFailed(errorCode)
            }
        })
    }

    fun startConnect(device: BleDevice, block: (BluetoothConnectResult) -> Unit) {
        ble?.connect(device, object: BleConnectCallback<BleDevice>() {

            override fun onConnectionChanged(device: BleDevice?) {
            }

            override fun onConnectCancel(device: BleDevice?) {
                super.onConnectCancel(device)
                block.invoke(BluetoothConnectResult(false))
            }

            override fun onReady(device: BleDevice?) {
                super.onReady(device)
                block.invoke(BluetoothConnectResult(true))
            }

            override fun onServicesDiscovered(device: BleDevice?, gatt: BluetoothGatt?) {
                super.onServicesDiscovered(device, gatt)
                gatt?.services?.forEach { service ->
                    if (service.uuid.toString().startsWith("00001800") ||
                        service.uuid.toString().startsWith("00001801")){
                    } else {
                        serviceUUID = service.uuid
                        Ble.options().setUuidServicesExtra(arrayOf(service.uuid))
                        service.characteristics.forEach {
                            characteristicUUID = it.uuid
                        }
                    }
                }
            }

            override fun onConnectFailed(device: BleDevice?, errorCode: Int) {
                super.onConnectFailed(device, errorCode)
                block.invoke(BluetoothConnectResult(false))
            }
        })
    }

    fun enableNotify(device: BleDevice, block: (BluetoothNotifyResult) -> Unit) {
        ble?.enableNotify(device, true, object : BleNotifyCallback<BleDevice>() {

            override fun onChanged(device: BleDevice?, characteristic: BluetoothGattCharacteristic?) {
                val uuid = characteristic?.uuid
                val data = characteristic?.value
                Log.i(TAG, "data: $data")
                data?.let {
                    val notifyResultDetail = try {
                        val dataArray = String(it).split(",")
                        NotifyResultDetail(dataArray[0], dataArray[1], dataArray[2].toInt())
                    } catch (e: Exception) {
                        null
                    }
                    block.invoke(BluetoothNotifyResult(true, notifyResultDetail))
                }
            }

            override fun onNotifySuccess(device: BleDevice?) {
                super.onNotifySuccess(device)
                block.invoke(BluetoothNotifyResult(true, null))
            }

            override fun onNotifyFailed(device: BleDevice?, failedCode: Int) {
                super.onNotifyFailed(device, failedCode)
                block.invoke(BluetoothNotifyResult(false, null))

            }

            override fun onNotifyCanceled(device: BleDevice?) {
                super.onNotifyCanceled(device)
                block.invoke(BluetoothNotifyResult(false, null))

            }
        })
    }

    fun writeData(device: BleDevice, data: ByteArray, block: (Boolean) -> Unit) {
        ble?.writeByUuid(device, data, serviceUUID, characteristicUUID, object: BleWriteCallback<BleDevice>() {
            override fun onWriteSuccess(p0: BleDevice?, p1: BluetoothGattCharacteristic?) {
                Log.i(TAG, "write data success")
                block.invoke(true)
            }

            override fun onWriteFailed(device: BleDevice?, failedCode: Int) {
                super.onWriteFailed(device, failedCode)
                block.invoke(false)
            }
        })
    }

    fun readData(device: BleDevice) {
        ble?.readByUuid(device, serviceUUID, characteristicUUID, object: BleReadCallback<BleDevice>() {
            override fun onReadSuccess(
                dedvice: BleDevice?,
                characteristic: BluetoothGattCharacteristic?
            ) {
                super.onReadSuccess(dedvice, characteristic)
                val result = ByteUtils.toString(characteristic?.value)
                val a= 0
            }

            override fun onReadFailed(device: BleDevice?, failedCode: Int) {
                super.onReadFailed(device, failedCode)
            }
        })
    }

}