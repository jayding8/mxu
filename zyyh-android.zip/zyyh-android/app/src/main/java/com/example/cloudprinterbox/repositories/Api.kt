package com.example.cloudprinterbox.repositories

object Api {
    const val URL_LOGIN = "https://wtcloudbox.cn/login/api/v1/passwordLogin/"
    const val KEY_LOGIN_PHONE_NUMBER = "phone_number"
    const val KEY_LOGIN_PASSWORD = "password"

    const val URL_BIND_DEVICE = "https://wtcloudbox.cn/app/api/v1/dev_bind/"
    const val KEY_BIND_DEVICE_SPECIFIC_ID = "device_id"
    const val KEY_BIND_DEVICE_USER_ID = "user_id"
    const val KEY_BIND_DEVICE_USER_TOKEN = "x-token"
}