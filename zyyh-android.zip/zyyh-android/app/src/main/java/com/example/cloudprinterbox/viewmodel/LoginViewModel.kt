package com.example.cloudprinterbox.viewmodel

import androidx.lifecycle.ViewModel
import com.example.cloudprinterbox.model.LoginResult
import com.example.cloudprinterbox.model.Responses
import com.example.cloudprinterbox.repositories.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {

    val flowScope = CoroutineScope(Dispatchers.IO)

    private val _loginResultFlow = MutableSharedFlow<Responses<LoginResult>>()
    val loginResultFlow = _loginResultFlow.asSharedFlow()

    private val userRepo = UserRepository()

    fun login(userName: String, password: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val result = userRepo.login(userName, password)
            result?.let {
                _loginResultFlow.emit(it)
            }
        }
    }
}