package com.example.ble.exception;

/**
 *
 * Created by LiuLei on 2017/10/19.
 */

public class BleNotSupportException extends BleException {
    private static final long serialVersionUID = 5704181388624724795L;

    public BleNotSupportException() {
    }

    public BleNotSupportException(String message) {
        super(message);
    }

}
