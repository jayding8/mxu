<template>
  <div>
    <span v-if="theme.showTheme" @click="handleOpenTheme">
      说明指引
      <vab-icon icon="brush-2-line" />
    </span>

    <el-drawer
      append-to-body
      custom-class="vab-drawer"
      direction="rtl"
      size="280px"
      :title="translateTitle('说明指引')"
      :visible.sync="drawerVisible"
    >
      <el-scrollbar />
    </el-drawer>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { translateTitle } from '@/utils/i18n'

  export default {
    name: 'VabTheme',
    data() {
      return {
        drawerVisible: false,
      }
    },
    computed: {
      ...mapGetters({
        theme: 'settings/theme',
      }),
    },
    methods: {
      translateTitle,
      handleOpenTheme() {
        this.drawerVisible = true
      },
    },
  }
</script>
