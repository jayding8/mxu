<template>
  <div class="label-wrapper">
    <div class="list-box">
      <div class="label-box" v-for="(item, index) in labelList" :key="index" v-if="isStore">
        <div class="title mb-10" v-if="item.children && item.children.length">{{ item.label_name }}</div>
        <div class="list" v-if="item.children && item.children.length">
          <div v-for="(label, j) in item.children" :key="j" class="relative" @click="selectLabel(label)">
            <div class="label-item"
              :style="{ backgroundColor: label.bg_color, color: label.color, border: label.border_color ? '1px solid ' + label.border_color : 'none' }"
              v-if="!label.icon">{{ label.label_name }}
            </div>
            <img :src="label.icon" class="img-tag" v-else />
            <span class="active mobiconfont"
              :class="label.disabled ? 'icon-a-ic_CompleteSelect' : 'icon-ic_unselect'"></span>
          </div>

        </div>
      </div>
      <div v-if="!isStore">暂无标签</div>
    </div>
    <div class="footer">
      <el-button type="primary" class="btns" @click="subBtn">确定</el-button>
      <el-button type="primary" class="btns" ghost @click="cancel">取消</el-button>
    </div>
  </div>
</template>

<script>
import { productStoreLabel } from '@/api/product'

export default {
  name: "storeLabelList",
  props: {},
  data() {
    return {
      labelList: [],
      dataLabel: [],
      isStore: false
    }
  },
  mounted() {
  },
  methods: {
    inArray: function (search, array) {
      for (let i in array) {
        if (array[i].id == search) {
          return true;
        }
      }
      return false;
    },
    // 用户标签
    storeLabel(data) {
      this.dataLabel = data;
      productStoreLabel()
        .then((res) => {
          console.log('productStoreLabel', res);
          res.data.map(el => {
            if (el.children && el.children.length) {
              this.isStore = true;
              el.children.map(label => {
                if (this.inArray(label.id, this.dataLabel)) {
                  label.disabled = true;
                } else {
                  label.disabled = false;
                }
              })
            }
          })
          this.labelList = res.data
        })
        .catch((res) => {
          this.$message.error(res.msg);
        });
    },
    selectLabel(label) {
      if (label.disabled) {
        let index = this.dataLabel.indexOf(this.dataLabel.filter(d => d.id == label.id)[0]);
        this.dataLabel.splice(index, 1);
        label.disabled = false
      } else {
        this.dataLabel.push({ 'label_name': label.label_name, 'id': label.id });
        label.disabled = true
      }
    },
    // 确定
    subBtn() {
      this.$emit('activeData', JSON.parse(JSON.stringify(this.dataLabel)))
    },
    cancel() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="stylus" scoped>
.label-wrapper
  .list
    display flex
    flex-wrap wrap

    .label-item
      margin 0 8px 10px 0
      padding: 3px 8px;
      background #EEEEEE
      color #333333
      border-radius 2px
      cursor pointer
      font-size 12px
      cursor pointer

    .active {
      color #ffffff;
      font-size 12px
      position absolute;
      top -2px
      right 9px
    }

  .footer
    display flex
    justify-content flex-end
    margin-top 40px

    button
      margin-left 10px

.btn
  width 60px
  height 24px

.title
  font-size 13px

.list-box
  overflow-y auto
  overflow-x hidden
  max-height 340px

  &::-webkit-scrollbar {
    width: 0;
  }

.img-tag {
  height: 22px;
  border-radius 2px
  margin-right 10px
  cursor pointer
}

.relative {
  position relative
}
</style>
