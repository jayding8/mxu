<template>
  <div class="linkage">
    <el-select v-model="currentProvince" @change="choseProvince" placeholder="省级地区">
      <el-option v-for="(item, key) in province" :key="key" :label="item.name" :value="item.name">
      </el-option>
    </el-select>
    <el-select v-model="currentCity" @change="choseCity" placeholder="市级地区" style="margin: 0 10px;">
      <el-option v-for="(item, key) in city" :key="key" :label="item.name" :value="item.name">
      </el-option>
    </el-select>
    <el-select v-model="currentArea" @change="choseArea" placeholder="区级地区">
      <el-option v-for="(item, key) in area" :key="key" :label="item" :value="item">
      </el-option>
    </el-select>
  </div>
</template>

<script>
import { linkage } from "@/mockData/linkage.js";

export default {
  name: 'linkage',
  data() {
    return {
      province: [],
      city: [],
      area: [],
      currentProvince: '',
      currentCity: '',
      currentArea: '',
    }
  },
  created() {
    this.initData();
  },
  methods: {
    // 加载china地点数据，三级
    initData() {
      this.province = linkage;
      this.city = this.province[0].children;
      this.area = this.city[0].children;
      this.currentProvince = this.province[0].name;
      this.currentCity = this.city[0].name;
      this.currentArea = this.area[0];
      this.callback();
    },
    // 选省
    choseProvince(provinceName) {
      const target = this.province.find(v => v.name == provinceName);
      this.city = target.children;
      this.area = this.city[0].children;
      this.currentProvince = provinceName;
      this.currentCity = this.city[0].name;
      this.currentArea = this.area[0];
      this.callback();
    },
    // 选市
    choseCity(cityName) {
      const target = this.city.find(v => v.name == cityName);
      this.area = target.children;
      this.currentCity = cityName;
      this.currentArea = this.area[0];
      this.callback();
    },
    // 选区
    choseArea(areaName) {
      this.currentArea = areaName;
      this.callback();
    },
    callback() {
      this.$emit('linkageCallback', { province: this.currentProvince, city: this.currentCity, area: this.currentArea });
    },
  },

}
</script>

<style scoped></style>