import request from '@/utils/request'
//消费明细
export function Payorder(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Payorder/index',
      ...params,
    },
  })
}
//余额明细

export function Moneylog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Money/moneylog',
      ...params,
    },
  })
}

//充值记录

export function Rechargelog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Money/rechargelog',
      ...params,
    },
  })
}

//余额提现

export function Withdrawlog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Money/withdrawlog',
      ...params,
    },
  })
}

//佣金记录

export function Cmmrecord(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Commission/record',
      ...params,
    },
  })
}
//佣金明细

export function Commissionlog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Commission/commissionlog',
      ...params,
    },
  })
}
//佣金提现

export function Cmmwithdrawlog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Commission/withdrawlog',
      ...params,
    },
  })
}
//佣金统计

export function Cmmtongji(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Commission/tongji',
      ...params,
    },
  })
}
//积分明细

export function Scorelog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Score/scorelog',
      ...params,
    },
  })
}
//分红记录

export function Fenhonglog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Commission/fenhonglog',
      ...params,
    },
  })
}
//门店明细

export function Menmoneylog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MendianMoney/moneylog',
      ...params,
    },
  })
}
//门店提现

export function Menwithdrawlog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MendianMoney/withdrawlog',
      ...params,
    },
  })
}
//核销记录

export function Hexiao(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Hexiao/index',
      ...params,
    },
  })
}
//扶持金记录

export function fuchiRecord(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Commission/fuchiRecord',
      ...params,
    },
  })
}

//扶持金明细

export function fuchiLog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Commission/fuchiLog',
      ...params,
    },
  })
}
//发票管理

export function Invoice(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Invoice/index',
      ...params,
    },
  })
}
//奖金池

export function BonusPool(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/BonusPool/index',
      ...params,
    },
  })
}
//奖金池-贡献值记录

export function BonusPoolrecord(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/BonusPool/record',
      ...params,
    },
  })
}
//奖金池-贡献值明细

export function BonusPoolcommissionlog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/BonusPool/commissionlog',
      ...params,
    },
  })
}
//奖金池-贡献值提现记录

export function BonusPoolwithdrawlog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/BonusPool/withdrawlog',
      ...params,
    },
  })
}
//信用额度明细

export function OverdraftMoney(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/OverdraftMoney/moneylog',
      ...params,
    },
  })
}
