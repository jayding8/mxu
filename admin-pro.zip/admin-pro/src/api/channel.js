import request from '@/utils/request'
//公众号绑定
export function Binding() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Binding/index',
    },
  })
}

//小程序支付
export function Wxpay() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Wxpay/set',
    },
  })
}

//小程序订阅模板消息
export function Wxtmpl() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Wxtmpl/tmplset',
    },
  })
}

//小程序服务类目

export function Wxleimu(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/Wxleimu/index',
      ...params,
    },
  })
}

//小程序外部链接
export function Wxurl(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Wxurl/index',
      ...params,
    },
  })
}

//支付宝小程序
export function Alipay() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Binding/alipay',
    },
  })
}

//百度小程序
export function Baidu() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Binding/baidu',
    },
  })
}

//头条小程序
export function Toutiao() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Binding/toutiao',
    },
  })
}

//手机H5
export function H5() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Binding/h5',
    },
  })
}

//QQ小程序
export function QQ() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Binding/qq',
    },
  })
}

//手机 APP
export function App() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Binding/app',
    },
  })
}
