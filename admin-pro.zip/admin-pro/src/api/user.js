import request from '@/utils/request'

export async function login(data) {
  return request({
    url: '?s=/login/index',
    method: 'post',
    data,
  })
}

export function getUserInfo() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Backstage/index',
    },
  })
}

export function welcome() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Backstage/welcome',
    },
  })
}

export function shopProduct(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopProduct/index',
      ...params,
    },
  })
}

export function productDelete(data) {
  return request({
    url: '?s=/ShopProduct/del',
    method: 'post',
    data,
  })
}

export function productCopy(data) {
  return request({
    url: '?s=/ShopProduct/procopy',
    method: 'post',
    data,
  })
}

export function productStatus(data) {
  return request({
    url: '?s=/ShopProduct/setst',
    method: 'post',
    data,
  })
}

export function shopOrder(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/index',
      ...params,
    },
  })
}

export function getDetail(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/getdetail',
    },
    data
  })
}

export function getExpress(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/getExpress',
    },
    data
  })
}

export function sendExpress(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/sendExpress',
    },
    data
  })
}

export function refundInit(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/refundinit',
    },
    data
  })
}

export function refund(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/refund',
    },
    data
  })
}

export function shopOrderStatus(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/index/status/' + params.status +'/showtype/',
      ...params,
    },
  })
}

export function shopOrderEdit(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopOrder/edit/id/' + params,
    },
  })
}

export function doEdit(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/edit/id/' + data.info.id,
    },
    data
  })
}

export function doPrint(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/wifiprint',
    },
    data
  })
}

export function getShd(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopOrder/shd/id/'+ params,
    },
  })
}

export function doReceive(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/orderCollect',
    },
    data
  })
}

export function doDelete(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/del',
    },
    data
  })
}

export function logout() {
  return request({
    url: '/logout',
    method: 'get',
  })
}

export function register(data) {
  return request({
    url: '/register',
    method: 'post',
    data,
  })
}
