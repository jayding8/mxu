import request from '@/utils/request'

export async function login(data) {
  return request({
    url: '?s=/login/index',
    method: 'post',
    data,
  })
}

export function getUserInfo() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Backstage/index',
    },
  })
}

export function welcome() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Backstage/welcome',
    },
  })
}

export function shopProduct(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopProduct/index',
      ...params,
    },
  })
}
export function shopOrder(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/index',
      ...params,
    },
  })
}

export function logout() {
  return request({
    url: '/logout',
    method: 'get',
  })
}

export function register(data) {
  return request({
    url: '/register',
    method: 'post',
    data,
  })
}
