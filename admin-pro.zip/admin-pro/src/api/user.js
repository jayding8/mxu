import request from '@/utils/request'

export async function login(data) {
  return request({
    url: '?s=/login/index',
    method: 'post',
    data,
  })
}

export function getUserInfo() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Backstage/index',
    },
  })
}

export function welcome() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Backstage/welcome',
    },
  })
}

export function shopProduct(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopProduct/index',
      ...params,
    },
  })
}

export function productDelete(data) {
  return request({
    url: '?s=/ShopProduct/del',
    method: 'post',
    data,
  })
}

export function productCopy(data) {
  return request({
    url: '?s=/ShopProduct/procopy',
    method: 'post',
    data,
  })
}

export function productStatus(data) {
  return request({
    url: '?s=/ShopProduct/setst',
    method: 'post',
    data,
  })
}

export function shopOrder(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/index',
      ...params,
    },
  })
}
export function shopOrderStatus(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/index/status/' + params.status,
      ...params,
    },
  })
}

export function logout() {
  return request({
    url: '/logout',
    method: 'get',
  })
}

export function register(data) {
  return request({
    url: '/register',
    method: 'post',
    data,
  })
}
