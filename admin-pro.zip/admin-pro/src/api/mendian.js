import request from '@/utils/request'
//门店列表
export function mendianlist(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/Mendian/index2',
      ...params,
    },
  })
}
//门店分组

export function MendianGroup(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MendianGroup/index',
      ...params,
    },
  })
}

//门店等级

export function MendianLevel(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MendianLevel/index',
      ...params,
    },
  })
}

//门店设置

export function MendianSet() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MendianSet/index',
    },
  })
}

//门店管理

export function mendian(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Mendian/index',
      ...params,
    },
  })
}
