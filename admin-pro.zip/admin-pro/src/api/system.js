import request from '@/utils/request'

export function WebUser(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/WebUser/index/type/1',
      ...params,
    },
  })
}
