import request from '@/utils/request'

export function webUser(params) {
  return request({
    url: '/',
    method: 'post',
    s: '/WebUser/index',
    ...params,
  })
}
