import request from '@/utils/request'

export function getCategory(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopCategory/edit',
      ...params,
    },
  })
}

export function getEdit(id) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopCategory/edit/id/' + id,
    },
  })
}

export function getSonCate(id) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopCategory/edit/pid/' + id,
    },
  })
}

export function saveCate(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopCategory/save',
    },
    data: {
      ...data,
    },
  })
}

export function doDelete(data) {
  return request({
    url: '/table/doDelete',
    method: 'post',
    data,
  })
}
