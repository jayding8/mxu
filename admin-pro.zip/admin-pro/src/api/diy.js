import request from '@/utils/request'
// 装修页面列表
export function getList(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/DesignerPage/index',
      ...params,
    },
  })
}
// 页面分类
export function Category(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/DesignerCategory/index',
      ...params,
    },
  })
}
// 底部导航
export function Menu() {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/DesignerMenu/index',
    },
  })
}
// 内页导航
export function Menu2(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/DesignerMenu/menu2',
      ...params,
    },
  })
}
// 商品详情
export function Shopdetail() {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/DesignerMenuShopdetail/shopdetail',
    },
  })
}
// 登录页面
export function Login() {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/DesignerLogin/index',
    },
  })
}
// 移动端后台
export function Mobile() {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/DesignerMobile/index',
    },
  })
}
// 分享设置
export function Share(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/DesignerShare/index',
      ...params,
    },
  })
}
// 分享链接-分类/分组
export function Chooseurl() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/DesignerPage/chooseurl/type/geturl',
    },
  })
}

// 分享链接-商品
export function shop_product(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/shop_product/index',
      ...params,
    },
  })
}
// 分享链接-拼团商品
export function collage_product(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/collage_product/index',
      ...params,
    },
  })
}

// 分享链接-拼团商品
export function cycle_product(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/cycle_product/index',
      ...params,
    },
  })
}
