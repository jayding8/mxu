import request from '@/utils/request'
//系统设置
export function GetSysset(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Backstage/sysset',
      ...params,
    },
  })
}

export function sysset(data) {
  return request({
    url: '?s=/Backstage/sysset',
    method: 'post',
    data,
  })
}
//管理员列表

export function User(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/User/index',
      ...params,
    },
  })
}

//配送方式

export function Freight(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Freight/index',
      ...params,
    },
  })
}

//快递设置

export function ExpressData() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ExpressData/index',
    },
  })
}

//送货单

export function ShdSet(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShdSet/index',
      ...params,
    },
  })
}
//小票打印机

export function Wifiprint(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Wifiprint/index',
      ...params,
    },
  })
}
//短信设置

export function Sms() {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Sms/set',
    },
  })
}

//配置短信设置

export function SetSms(info) {
  return request({
    url: '?s=/Sms/set',
    method: 'post',
    data: {
      info,
    },
  })
}
//发送记录

export function Sendlog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Sms/sendlog',
      ...params,
    },
  })
}
//操作日志

export function Plog(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/Backstage/plog',
      ...params,
    },
  })
}
