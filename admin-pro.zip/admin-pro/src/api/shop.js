import request from '@/utils/request'

// 数据概况
export function welcome() {
  return request({
    url: '/Backstage/welcome',
    method: 'get',
  })
}
// 商品管理
// export function shopProduct() {
//   return request({
//     url: '/ShopProduct/index',
//     method: 'get',
//   })
// }
export function shopProduct(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopProduct/index',
      ...params,
    },
  })
}

//获取商品编辑
export function getProductEdit(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopProduct/edit/id/' + params,
    },
  })
}

//保存编辑商品
export function productSave(data) {
  return request({
    url: '?s=/ShopProduct/save',
    method: 'post',
    data,
  })
}

// 订单管理
// export function shopOrder() {
//   return request({
//     url: '/ShopOrder/index',
//     method: 'get',
//   })
// }
export function shopOrder(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopOrder/index',
      ...params,
    },
  })
}
//退款申请
// export function shopRefundOrder() {
//   return request({
//     url: '/ShopRefundOrder/index',
//     method: 'get',
//   })
// }
export function ShopRefundOrder(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopRefundOrder/index',
      ...params,
    },
  })
}
//评价管理
// export function shopComment() {
//   return request({
//     url: '/ShopComment/index',
//     method: 'get',
//   })
// }
export function shopComment(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopComment/index',
      ...params,
    },
  })
}
//商品分类
// export function shopCategory() {
//   return request({
//     url: '/ShopCategory/index',
//     method: 'get',
//   })
// }
export function shopCategory(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopCategory/index',
      ...params,
    },
  })
}

//商品分组
// export function shopGroup() {
//   return request({
//     url: '/ShopGroup/index',
//     method: 'get',
//   })
// }
export function shopGroup(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopGroup/index',
      ...params,
    },
  })
}
//商品参数
// export function shopParam() {
//   return request({
//     url: '/ShopParam/index',
//     method: 'get',
//   })
// }
export function shopParam(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopParam/index',
      ...params,
    },
  })
}
//商品服务
// export function shopService() {
//   return request({
//     url: '/ShopService/index',
//     method: 'get',
//   })
// }
export function ShopFuwu(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopFuwu/index',
      ...params,
    },
  })
}
//商品海报
// export function shopPoster() {
//   return request({
//     url: '/ShopPoster/index',
//     method: 'get',
//   })
// }
export function shopPoster(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopPoster/index',
      ...params,
    },
  })
}
//录入订单
// export function shopOrderlr() {
//   return request({
//     url: '/ShopOrderlr/index',
//     method: 'get',
//   })
// }
export function shopOrderlr(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopOrderlr/index',
      ...params,
    },
  })
}
//录入库存
// export function shopStock() {
//   return request({
//     url: '/ShopStock/index',
//     method: 'get',
//   })
// }
export function shopStock(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopStock/index',
      ...params,
    },
  })
}
//商品采集
// export function shopTaobao() {
//   return request({
//     url: '/ShopTaobao/index',
//     method: 'get',
//   })
// }
export function shopTaobao(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/ShopTaobao/index',
      ...params,
    },
  })
}
//销售统计
// export function shopSale() {
//   return request({
//     url: '/ShopOrder/tongji',
//     method: 'get',
//   })
// }
export function shopSale(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/tongji',
      ...params,
    },
  })
}
export function shopSale2(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopOrder/tongji/type/2',
      ...params,
    },
  })
}
//商城设置
// export function shopSet() {
//   return request({
//     url: '/ShopSet/index',
//     method: 'get',
//   })
// }
export function shopSet(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/ShopSet/index',
      ...params,
    },
  })
}
