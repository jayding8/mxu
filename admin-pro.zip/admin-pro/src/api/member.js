import request from '@/utils/request'
//会员列表
export function member(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/Member/index',
      ...params,
    },
  })
}
//会员等级

export function MemberLevel(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MemberLevel/index',
      ...params,
    },
  })
}

//会员等级编辑

export function getMemberLevelEdit(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MemberLevel/edit/id/' + params,
    },
  })
}

export function saveMemberLevelEdit(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/MemberLevel/edit/id/' + params,
    },
    data,
  })
}

//升级记录

export function memberUpgrade(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/MemberLevel/applyorder',
      ...params,
    },
  })
}

//脱离记录

export function changePidLog(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: '/MemberLevel/changePidLog',
      ...params,
    },
  })
}
//大区设置

export function Largearea(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/Largearea/index',
      ...params,
    },
  })
}

//一客一价

export function MemberProduct(params) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: '/MemberProduct/index',
      ...params,
    },
  })
}

// 会员关系网
export function memberCharts({ mid }) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: `/Member/charts/mid/${mid}`,
    },
  })
}
