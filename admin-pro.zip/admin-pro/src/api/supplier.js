import request from '@/utils/request'

/******** 车辆信息 start *********/

// 获取车辆信息列表
export function getCarList(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.car/getList',
      ...params,
    },
  })
}

// 删除车辆信息
export function delCar(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.car/delete',
      ...params,
    },
  })
}

// 获取车辆信息详情
export function getCarDetail(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.car/detail',
      ...params,
    },
  })
}

// 新增、修改车辆信息
export function addOrEditCar(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: 'deliveryAdmin.car/edit',
    },
    data: {
      ...data,
    },
  })
}

// 修改车辆信息状态
export function updateCarStatus(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.car/status',
      ...params,
    },
  })
}
/******** 车辆信息 end *********/

/******** 区域信息 start *********/

// 获取区域列表
export function getAreaList(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.area/getList',
      ...params,
    },
  })
}

// 新增、修改区域记录
export function addOrEditArea(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: 'deliveryAdmin.area/edit',
    },
    data: {
      ...data,
    },
  })
}

// 删除区域记录
export function delArea(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.area/delete',
      ...params,
    },
  })
}

// 修改区域记录状态
export function updateAreaStatus(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.area/status',
      ...params,
    },
  })
}
/******** 区域信息 end *********/

/******** 线路管理 start *********/

// 获取线路列表
export function getLineList(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.line/getList',
      ...params,
    },
  })
}

// 新增、修改区域记录
export function addOrEditLine(data) {
  return request({
    url: '/',
    method: 'post',
    params: {
      s: 'deliveryAdmin.line/edit',
    },
    data: {
      ...data,
    },
  })
}

// 删除区域记录
export function delLine(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.line/delete',
      ...params,
    },
  })
}

// 修改区域记录状态
// export function updateAreaStatus(params) {
//   return request({
//     url: '/',
//     method: 'get',
//     params: {
//       s: 'deliveryAdmin.area/status',
//       ...params,
//     },
//   })
// }
/******** 线路管理 end *********/

/******** 商家管理 start *********/
// 获取商家列表
export function getShopList(params) {
  return request({
    url: '/',
    method: 'get',
    params: {
      s: 'deliveryAdmin.shop/getList',
      ...params,
    },
  })
}
/******** 商家管理 end *********/
