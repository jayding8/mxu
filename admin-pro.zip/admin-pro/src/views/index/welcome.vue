<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col :span="16">
        <div class="col">
          <div class="shopinfo">
            <div class="head">
              <div class="logo">
                <h1 class="title">欢迎登录系统</h1>
                <p class="goal">一个能够升起月亮的身体，必然驮住了无数次日落</p>
              </div>
              <p class="date">上次登录：{{ lastLoginInfo }}</p>
            </div>
            <div class="detail noNotice">
              <el-row align="middle" class="top" justify="center" type="flex">
                <el-col :span="6">
                  <div class="avator">
                    <img
                      alt="avator"
                      class="img"
                      height="72"
                      :src="avatorSrc"
                      width="72"
                    />
                    <p class="menu">合作版本</p>
                  </div>
                </el-col>
                <el-col class="flex1" :span="18">
                  <p class="shop-name">头号美妆</p>
                  <p class="date">到期时间：{{ expireDate }}</p>
                  <div class="channel flex-center">
                    <vab-icon class="icon" icon="mini-program-fill" />
                    <vab-icon class="icon" icon="wechat-2-fill" />
                    <vab-icon class="icon" icon="qq-fill" />
                    <vab-icon class="icon" icon="alipay-fill" />
                    <vab-icon class="icon" icon="html5-fill" />
                    <vab-icon class="icon" icon="baidu-fill" />
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>

          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                实时收入概况
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="dataItems">
                <el-col
                  v-for="(item, index) in dataItems"
                  :key="item + index"
                  class="grid"
                  :span="8"
                >
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                      <p class="yesterday">昨日</p>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                      <p class="p2">{{ item.yesterday }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>
        <div class="col" style="margin-top: 20px">
          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                支出概况
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="datarightItems">
                <el-col
                  v-for="(item, index) in datarightItems"
                  :key="item + index"
                  class="grid"
                  :span="4"
                >
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>

        <div class="col2" style="margin-top: 20px">
          <trend />
        </div>
      </el-col>

      <el-col :span="5">
        <el-card shadow="hover">主.题</el-card>
      </el-col>
      <el-col :span="3">
        <el-card shadow="hover">主题</el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  // import Trend from './components/Trend'
  import { welcome } from '@/api/user'
  // import VabDraggable from 'vuedraggable'
  export default {
    name: 'Welcome',
    // components: {
    //   VabDraggable,
    //   Trend,
    // },
    data() {
      return {
        avatorSrc:
          'https://yw.yftsm.com/static/dist/shop/image/shopdefault.png',
        lastLoginInfo: '2024-04-28 00:11:21 IP: 183.213.83.84',
        expireDate: '2024-12-01 00:00:00',
        updateTimestamp: '2024-04-28 12:07:01',
        headStyle: {
          backgroundImage: 'url(/static/dist/shop/image/homepage/day-bg.png)',
          backgroundSize: '100% 100%',
        },
        dataItems: [
          {
            title: '支付订单数',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-持平',
          },
          {
            title: '支付人数',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '支付商品数',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '余额支付',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '微信支付',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '支付总金额',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
        ],
        datarightItems: [
          {
            title: '今日佣金',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-持平',
          },
          {
            title: '已提现佣金',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '已提现余额',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '已提现积分',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '已退款金额',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
          {
            title: '其他支出',
            unit: '笔',
            today: '0',
            yesterday: '0',
            difference: '-',
          },
        ],
        order0Count: '',
        operateItems: [
          {
            href: 'ShopProduct/edit',
            icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
            text: '添加商品',
          },
          {
            href: 'DesignerPage/index',
            icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
            text: '店铺装修',
          },
          {
            href: 'ShopOrder/index',
            icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
            text: '订单管理',
          },
          {
            href: 'Member/index',
            icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
            text: '会员管理',
          },
          {
            href: 'Member/index',
            icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
            text: '代客下单',
          },
          {
            href: 'Coupon/index',
            icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
            text: '优惠券',
          },
        ],
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
      dragOptions() {
        return {
          animation: 600,
          group: 'description',
        }
      },
    },
    created() {
      welcome().then((res) => {
        this.welcome = res

        console.log(res)
      })
    },
    methods: {
      welcome,
    },
  }
</script>

<style lang="scss" scoped>
  .echarts,
  .trend-echart {
    width: 900px !important;
    height: 300px !important;
  }
  .index-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .card {
    border: none;
  }
  .col {
    display: flex;
    background: #fff;
    padding: 20px 10px 10px 20px;
    border-radius: 10px;
    box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
  }
  .col1 {
    background: #fff;
    padding: 20px 10px 10px 20px;
    border-radius: 10px;
    box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
  }
  .col2 {
    background: #fff;
    padding: 20px 10px 10px 20px;
    border-radius: 10px;
    box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
    margin-bottom: 20px;
  }

  .el-card {
    margin-bottom: 0 !important;
  }

  .flex-center {
    display: flex;
    align-items: center;
  }

  .flex-between {
    display: flex;
    justify-content: space-between;
  }
  .shopinfo {
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    overflow: hidden;
    max-width: 346px; /* 最大宽度 */
    min-width: 313px; /* 最小宽度 */

    .head {
      background-image: url(https://yw.yftsm.com/static/dist/shop/image/homepage/day-bg.png);
      background-size: 100% 100%;
      padding: 17px 17px 29px;
      height: 137px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      font-size: 12px;
      color: hsla(0, 0%, 98%, 0.9);
      line-height: 17px;
      box-sizing: border-box;
      .date {
        color: hsla(0, 0%, 100%, 0.63);
      }
      .logo {
        padding-right: 55px;
      }
      .title {
        padding-bottom: 4px;
        font-weight: 600;
        font-size: 19px;
        color: #fff;
        line-height: 28px;
        margin: 0;
      }
      .goal {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        margin: 0;
      }
    }

    .detail {
      margin-top: -15px;
      height: 170px;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      background: linear-gradient(180deg, #d6e6ff, #fdfdff);
      .img {
        border-radius: 50%;
        border: 2px solid #ebf4ff;
      }
      .top {
        padding: 45px 15px 10px;
        .avatar {
          position: relative;
          width: 74px;
        }
        .menu {
          position: absolute;
          bottom: 0;
          padding: 0 7px;
          font-size: 12px;
          line-height: 20px;
          color: #eed8a0;
          background: #2d2e31;
          border-radius: 4px;
          width: 72px;
          text-align: center;
          overflow: hidden;
          -ms-text-overflow: ellipsis;
          text-overflow: ellipsis;
          white-space: nowrap;
          box-sizing: border-box;
        }
        .flex1 {
          flex: 1;
          min-height: 0;
          min-width: 0;
          width: 0px;
          margin-left: 17px;
          .date {
            font-size: 12px;
            line-height: 20px;
            color: rgba(0, 0, 0, 0.4);
            margin: 0;
          }
          .shop-name {
            margin-bottom: 2px;
            font-size: 18px;
            font-weight: 600;
            color: rgba(0, 0, 0, 0.8);
            line-height: 20px;
            width: 100%;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            margin: 0;
          }
        }
      }
      .icon {
        color: rgb(97, 92, 175);
        display: inline-block;
        margin-right: 8px;
        font-size: 20px;
      }
    }
  }
  .overview {
    width: 100%;
    margin-left: 10px;
    // border: #fb6638 1px solid;
    .tip-title {
      position: relative;
      padding-left: 10px;
      font-weight: 600;
      font-size: 16px;
      line-height: 22px;
      color: rgba(0, 0, 0, 0.8);
      margin: 0;

      span {
        padding-left: 10px;
        font-weight: 400;
        font-size: 12px;
        line-height: 17px;
        color: rgba(0, 0, 0, 0.4);
      }
    }
    .yesterday {
      margin: 0;
    }
    .tip-title::after {
      content: '';
      width: 3px;
      height: 13px;
      border-radius: 10px;
      background: var(--primary, #fb6638);
      position: absolute;
      top: 5px;
      left: 5px;
      bottom: 0;
      margin-left: -5px;
    }
  }
  .grid {
    // margin: -10px;
    padding: 10px !important;
  }
  .data-block-item {
    // padding: 10px 20px;
    padding: 0 !important;
    font-size: 14px;
    background: #f7f9fe;
    border-radius: 10px;
    // margin: 20px;

    .middle {
      margin: 0;
      font-size: 14px;
      line-height: 20px;
      color: #666;
    }

    .middle .p1 {
      font-weight: 600;
      font-size: 30px;
      line-height: 20px;
      color: #000;
      margin: 0px;
    }
    .p2 {
      margin: 0px;
    }

    .top {
      font-size: 14px;
      line-height: 10px;
      color: rgba(0, 0, 0, 0.4);
      margin-bottom: 10px;
    }

    .top p:first-child {
      font-size: 14px;
      line-height: 20px;
      color: rgba(0, 0, 0, 0.8);
      margin: 0px;
    }

    .bottom {
      font-size: 12px;
      margin-top: 14px;
      p {
        margin: 0 0 0 0;
      }
    }
  }

  .col2 {
  }
</style>
