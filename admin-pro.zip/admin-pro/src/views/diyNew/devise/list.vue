<template>
  <div>
    8888888888888888888
  </div>
</template>

<script>
import {
  diyList,
  diyDel,
  setStatus,
  recovery,
  getRoutineCode,
} from "@/api/diyNew";


export default {
  name: "devise_list",
  computed: {
  },
  components: {

  },
  data() {
    return {

    };
  },
  created() {
    this.getList();
  },
  methods: {
    // 获取列表
    getList() {
      let storage = window.localStorage;
      this.imgUrl = storage.getItem("imgUrl");
      let that = this;
      this.loading = true;
      diyList(this.diyFrom).then((res) => {
        this.loading = false;
        let data = res.data;
        this.list = data.list;
        this.total = data.count;
        data.list.forEach(function (e) {
          if (e.status == 1) {
            that.isDiy = e.is_diy;
            let imgUrl = `${that.BaseURL}pages/annex/special/index?id=${e.id}`;
            storage.setItem("imgUrl", imgUrl);
            that.imgUrl = imgUrl;
            // let imgUrl = JSON.parse(storage.getItem('menuList'));
            // that.imgUrl = `http://192.168.1.12:8080/pages/annex/special/index?id=${e.id}`;
          }
        });
      });
    },
  },
};
</script>

<style scoped lang="scss"></style>
