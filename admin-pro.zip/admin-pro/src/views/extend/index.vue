<template>
  <div class="index-container">
    用户列表
    <vab-theme />

    <div class="block">
      <el-pagination
        :current-page="info.data.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="info.data.limit"
        :page-sizes="[10, 20, 50, 100]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { member } from '@/api/member'
  export default {
    name: 'Index',
    data() {
      return {
        info: {
          count: 0,
          data: {
            current: 1,
            limit: 10,
          },
        },
        userList: [],
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.member({
        page: this.info.data.current,
        limit: this.info.data.limit,
      }).then((res) => {
        this.userList = res
        this.info.count = res.count
      })
    },
    methods: {
      member,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.member({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.member({
          page: val,
          limit: this.info.page.limit,
        })
      },
    },
  }
</script>

<style lang="scss" scoped></style>
