<template>
  <div>
    <span @click="handleOpenTheme">
      股东分红配置弹窗
    </span>

    <el-drawer append-to-body custom-class="vab-drawer" direction="rtl" size="1200px" :title="translateTitle('股东分红设置')"
      :visible.sync="drawerVisible">
      <div class="container">
        <div style="margin-top: 10px;">
          <el-button v-for="(strategy, index) in data" :key="index" :type="strategy.apply_check == 1 ? 'primary' : ''"
            @click="toggle(strategy, index)">
            {{ strategy.name }}
          </el-button>
        </div>
        <div style="margin-top: 40px;">
          <div v-for="(strategy, index) in data" :key="index" style="margin-bottom: 10px;">

            <div v-if="strategy.apply_check == 1" style="display: flex; ">
              <div class="t1"> {{ strategy.name }}</div>
              <div>
                <div class="nav_box">
                  <div class="t2">
                    <div>分红级数</div>
                    <el-input placeholder="0" class="t3"></el-input>
                  </div>
                  <div class="t2">
                    <div>分红比例</div>
                    <el-input placeholder="0.00" class="t3"></el-input>
                  </div>
                  <div class="t2">
                    <div>分红金额</div>
                    <el-input placeholder="0.00" class="t3"></el-input>
                  </div>
                  <div class="t2">
                    <div>积分比例</div>
                    <el-input placeholder="0.00" class="t3"></el-input>
                  </div>
                  <div class="t2">
                    <div>上月业绩达标</div>
                    <el-input placeholder="0" class="t3"></el-input>
                  </div>
                  <div class="t2">
                    <div>业绩累积</div>
                    <el-input placeholder="0.00" class="t3"></el-input>
                  </div>
                </div>
                <div class="nav_box">
                  <div class="t2">
                    <div>只给最近上级</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>
                  </div>
                  <div class="t2">
                    <div>包含自己</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>
                  </div>
                  <div class="t2">
                    <div>去掉最高</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>
                  </div>
                  <div class="t2">
                    <div>扣除分销佣金</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>
                  </div>
                  <div class="t2">
                    <div>商品单独设置</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>
                  </div>
                  <div class="t2">
                    <div>业绩包含自己</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>
                  </div>
                  <div class="t2">
                    <div>业绩含运费</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>
                  </div>
                  <div class="t2">
                    <div>业绩累积</div>
                    <div class="t3">
                      <el-switch v-model="scorebdkyf" />
                    </div>

                  </div>
                </div>
              </div>
              <div class="t5" @click="remove(index)">删除</div>
            </div>
          </div>
          <!-- {{ data }} -->
        </div>
        <div>
          <el-button type="primary" size="default" style="position: fixed; bottom: 80px; right: 80px;"
            @click="">保存</el-button>

        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script>
import { translateTitle } from '@/utils/i18n'
export default {
  name: 'Gdfenhong',
  props: {
    data: {
      type: Array,
      default: () => { }
    }
  },
  data() {
    return {
      drawerVisible: false,
      scorebdkyf: false,
    }
  },

  created() {
    console.log('Received data:', this.data); // 检查props是否接收到了数据
  },
  methods: {
    translateTitle,
    handleOpenTheme() {
      this.drawerVisible = true
    },
    toggle(strategy, index) {
      if (strategy.apply_check == 0) {
        this.data[index].apply_check = 1
      }
    },
    remove(index) {
      this.data[index].apply_check = 0
    }
  },
}
</script>
<style>
.container {
  padding: 10px 50px;
}

.t1 {
  width: 34px;
  text-align: center;
  /* 水平居中文本 */
  background-color: #1890ff;
  margin: 1px 0;
  color: #fff;
  padding: 10px;
  writing-mode: vertical-rl;
  /* 文本竖排，从右到左 */
  transform: rotate(360deg);
  /* 旋转文本，使其从上到下排列 */
  display: flex;
  /* 使用flex布局来垂直居中文本 */
  justify-content: center;
  /* 水平居中文本 */
  align-items: center;
  /* 垂直居中文本 */
  user-select: none;
  cursor: default;
}

.t2 {
  min-width: 100px;
  max-width: 200px;
  text-align: center;
  /* border: 1px solid #ccc; */
  /* background-color: #f5f5f5; */
  padding: 10px 10px;
  margin: 1px 0;
  line-height: 32px;
}

.t3 {
  min-width: 80px;
  max-width: 150px;
  /* border: 1px solid #ccc; */
}

.t4 {
  width: 50px;
  height: 50px;
  border-radius: 100%;
  background-color: #ff4d4f;
  color: #fff;
  text-align: center;
  line-height: 50px;
  margin: 63px 16px;
  cursor: pointer
}

.t5 {
  width: 34px;
  text-align: center;
  /* 水平居中文本 */
  background-color: #ff7678;
  margin: 1px 0;
  color: #fff;
  padding: 10px;
  writing-mode: vertical-rl;
  /* 文本竖排，从右到左 */
  transform: rotate(360deg);
  /* 旋转文本，使其从上到下排列 */
  display: flex;
  /* 使用flex布局来垂直居中文本 */
  justify-content: center;
  /* 水平居中文本 */
  align-items: center;
  /* 垂直居中文本 */
  user-select: none;
  cursor: default;
}

.nav_box {
  display: flex;
  background-color: #f5f5f5;
  justify-content: space-evenly;
}
</style>
