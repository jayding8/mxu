<template>
  <div>
    <span @click="handleOpenTheme">
      团队分红设置
      <vab-icon icon="brush-2-line" />
    </span>

    <el-drawer
      append-to-body
      custom-class="vab-drawer"
      direction="rtl"
      size="50%"
      :title="translateTitle('团队分红设置')"
      :visible.sync="drawerVisible"
    >
      <div class="container">
        <el-select
          v-model="selectedLevel"
          placeholder="请选择会员等级"
          @change="handleLevelChange"
        >
          <el-option label="普通会员" value="普通会员" />
          <el-option label="黄金会员" value="黄金会员" />
          <el-option label="钻石会员" value="钻石会员" />
          <el-option label="王者会员" value="王者会员" />
        </el-select>
      </div>
    </el-drawer>
  </div>
</template>

<script>
  import { translateTitle } from '@/utils/i18n'

  export default {
    name: 'Teamfenhong',
    data() {
      return {
        drawerVisible: false,
      }
    },
    methods: {
      translateTitle,
      handleOpenTheme() {
        this.drawerVisible = true
      },
    },
  }
</script>
<style>
  .container {
    padding: 20px;
  }
</style>
