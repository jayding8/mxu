<template>
  <div class="index-container">
    用户列表
    <!-- <vab-theme /> -->
    <Teamfenhong />
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import Teamfenhong from './components/teamfenhong'
  export default {
    name: 'Index',
    components: {
      Teamfenhong,
    },
    data() {
      return {}
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {},
    methods: {},
  }
</script>

<style lang="scss" scoped></style>
