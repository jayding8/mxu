<template>
  <div class="index-container">
    <div style="margin-bottom: 20px;">
      <Teamfenhong :data="info.data" />
      <!-- 团队分红 -->
    </div>
    <div style="margin-bottom: 20px;">
      <Areafenhong :data="info.data" />
      <!-- 区域分红 -->
    </div>
    <div style="margin-bottom: 20px;">
      <Gdfenhong :data="info.data" />
      <!-- 股东分红 -->
    </div>
    <div style="margin-bottom: 20px;">
      <Teamshare :data="info.data" />
      <!-- 团队分红共享奖 -->
    </div>
    <div style="margin-bottom: 20px;">
      <Teampingj :data="info.data" />
      <!-- 团队分红平级奖 -->
    </div>
    <div style="margin-bottom: 20px;">
      <Teampeiyujiang :data="info.data" />
      <!-- 团队培育奖 -->
    </div>
    <div style="margin-bottom: 20px;">
      <Teampingjisingle :data="info.data" />
      <!-- 团队分红平级单独比例 -->
    </div>



    <!-- 团队级差分红  Teamjicha
    团队分红伯乐奖     Teambole
    团队长分红         Teamleader
    团队见单分红       Teamjiandan
    商品团队分红       Productteamfenhong
    等级团队分红       Levelteamfenhong
    
    购车基金
    旅游基金
    团队收益
    工资补贴
    加权分红
    加权合作分红
    回本股东分红
    商家团队分红平级奖
    商家团队分红 -->
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Teamfenhong from './components/teamfenhong'
import Areafenhong from './components/areafenhong'
import Gdfenhong from './components/gdfenhong'
import Teamshare from './components/teamshare'
import Teampingj from './components/teampingj'
import Teampeiyujiang from './components/teampeiyujiang'
import Teampingjisingle from './components/teampingjisingle'
import { MemberLevel } from '@/api/member'
export default {
  name: 'Index',
  components: {
    Teamfenhong, Areafenhong, Gdfenhong, Teamshare, Teampingj, Teampeiyujiang, Teampingjisingle
  },
  data() {
    return {
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {

    this.MemberLevel({ page: this.page.current, }).then((res) => {
      this.info.data = res.data
    })
  },
  methods: {
    MemberLevel,
  },
}
</script>

<style lang="scss" scoped></style>
