<template>
  <div class="index-container">
    <el-alert
      :closable="false"
      show-icon
      title="用于自提订单选择自提门店进行到店自提"
      type="success"
    />
    <vab-query-form>
      <vab-query-form-top-panel>
        <el-form
          ref="form"
          class="box"
          :inline="true"
          label-width="66px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="会员ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" />
          </el-form-item>
          <el-form-item label="昵称">
            <el-input v-model="queryForm.title" placeholder="请输入昵称" />
          </el-form-item>

          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
              @click="handleQuery"
            >
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel :span="24">
        <el-button icon="el-icon-plus" type="primary" @click="handleAdd">
          导出EXCEL
        </el-button>
        <el-button
          icon="el-icon-delete"
          type="danger"
          @click="handleDelete($event)"
        >
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="会员id" prop="mid" width="80" />
      <el-table-column label="会员信息">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <div style="height: 50px; width: 50px">
                <img
                  :src="props.row.headimg"
                  style="height: 100%; width: 100%"
                />
                <span>{{ props.row.nickname }}</span>
              </div>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="手机号" prop="tel" width="150" />
      <el-table-column label="提现金额" prop="txmoney" sortable width="150" />
      <el-table-column label="打款金额" prop="money" sortable width="150" />
      <el-table-column label="提现方式" prop="paytype" sortable width="150" />
      <el-table-column label="收款账号" width="200">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span>{{ props.row.bankname }}</span>
              <span>{{ props.row.bankcardnum }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="身份信息" prop="bankcarduser" width="150" />
      <el-table-column label="提现时间" prop="createtime" width="200" />

      <el-table-column label="状态" width="150">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span v-if="props.row.status == 0">审核中</span>
              <span v-if="props.row.status == 1">已审核</span>
              <span v-if="props.row.status == 2">已驳回</span>
              <span v-if="props.row.status == 3">已打款</span>
              <span v-if="props.row.status == 4">处理中</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column fixed="right" label="操作" width="200">
        <el-form>
          <el-form-item>
            <el-button v-if="props.row.status == 0" size="small" type="text">
              审核
            </el-button>
            <el-button v-if="props.row.status == 0" size="small" type="text">
              驳回
            </el-button>
            <el-button v-if="props.row.status == 1" size="small" type="text">
              改为已打款
            </el-button>
            <el-button v-if="props.row.status == 1" size="small" type="text">
              微信打款
            </el-button>
            <el-button v-if="props.row.status == 1" size="small" type="text">
              驳回
            </el-button>
            <el-button v-if="props.row.status == 3" size="small" type="text">
              删除
            </el-button>
          </el-form-item>
        </el-form>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { Withdrawlog } from '@/api/money'

  export default {
    name: 'Withdrawlog',

    data() {
      return {
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        layout: 'total, sizes, prev, pager, next, jumper',
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.Withdrawlog({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    methods: {
      Withdrawlog,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.page.limit = val
        this.Withdrawlog({
          page: this.page.current,
          limit: val,
        }).then((res) => {
          this.info = res
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.page.current = val
        this.Withdrawlog({
          page: val,
          limit: this.page.limit,
        }).then((res) => {
          this.info = res
        })
      },
      toggleSelection(rows) {
        if (rows) {
          rows.forEach((row) => {
            this.$refs.multipleTable.toggleRowSelection(row)
          })
        } else {
          this.$refs.multipleTable.clearSelection()
        }
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleClick(row) {
        console.log(row)
      },
    },
  }
</script>

<style lang="scss" scoped>
  .select-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .box {
    padding: 20px;
    background: #f2f5f8;
    border-radius: 6px;
    width: 100%;
  }
</style>
