<template>
  <div class="index-container">
    <el-tabs v-model="activeName" @tab-click="handleTab" class="goods-tab">
      <el-tab-pane label="基础设置" name="first" />
      <el-tab-pane label="升级条件" name="two" />
    </el-tabs>


    <Base :data="data" />
    <Updata :data="data" />

  </div>
</template>

<script>
import Base from './components/base'
import Updata from './components/updata'
import { getMemberLevelEdit, saveMemberLevelEdit } from '@/api/member'
export default {
  components: {
    Base, Updata
  },
  data() {
    return {
      id: '',
      data: '',
    };
  },
  created() {
    if (this.$route.query.id) {
      this.id = this.$route.query.id
      getMemberLevelEdit(this.id).then((res) => {
        this.data = res.data
      })
    }
  },
  methods: {

  },
};
</script>

<style scoped lang="scss">
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}



.strategy-buttons {
  margin-bottom: 20px;
}

.strategy-buttons .el-button {
  margin-right: 10px;
}

.goods-tab {
  background: #fff;
  position: relative;
  padding: 10px 38px;
  margin-bottom: 20px;
  border-radius: 4px;
}

.col-tab {
  height: 48px;
  font-size: 18px;
  white-space: pre;
  margin-bottom: 0;
  font-weight: 700;
}
</style>