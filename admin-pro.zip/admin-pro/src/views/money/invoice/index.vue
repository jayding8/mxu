<template>
  <div class="index-container">
    <el-tabs v-model="activeName" @tab-click="handleTab" class="goods-tab">
      <el-tab-pane label="基础设置" name="first" />
      <el-tab-pane label="升级条件" name="two" />
      <el-tab-pane label="降级策略" name="three" />
    </el-tabs>

    <div class="goods-tab" style="margin-top: 10px;">
      <el-button v-for="strategy in strategies" :key="strategy.value" :type="strategy.active ? 'danger' : ''"
        @click="toggleCondition(strategy.value)">
        {{ strategy.label }}
      </el-button>
    </div>

    <div class="goods-tab" style="margin-top: 10px;">
      <div v-if="conditions.getMembershipCard">
        <el-input placeholder="请输入会员卡信息"></el-input>
        <el-button type="danger" @click="removeCondition('getMembershipCard')">删除</el-button>
      </div>
      <div v-if="conditions.wechatPayAmount">
        <el-input placeholder="请输入微信支付金额"></el-input>
        <el-button type="danger" @click="removeCondition('wechatPayAmount')">删除</el-button>
      </div>
    </div>



  </div>
</template>

<script>
export default {
  data() {
    return {
      strategies: [
        { label: '领取会员卡', value: 'getMembershipCard', active: false },
        { label: '微信支付金额', value: 'wechatPayAmount', active: false },
        { label: '订单金额', value: 'orderAmount', active: false },
        { label: '充值金额', value: 'rechargeAmount', active: false },
        { label: '单次订单金额', value: 'singleOrderAmount', active: false },
        { label: '下级总订单金额', value: 'subordinateTotalOrderAmount', active: false },
        { label: '剔除最高的业绩', value: 'excludeHighestPerformance', active: false },
      ],
      conditions: {
        getMembershipCard: '',
        wechatPayAmount: ''
      }
    };
  },
  methods: {
    toggleCondition(conditionKey) {
      this.conditions[conditionKey] = !this.conditions[conditionKey];
      const strategy = this.strategies.find(s => s.value === conditionKey);
      if (strategy) {
        strategy.active = this.conditions[conditionKey];
      }
    },
    removeCondition(conditionKey) {
      this.conditions[conditionKey] = '';
      const strategy = this.strategies.find(s => s.value === conditionKey);
      if (strategy) {
        strategy.active = false;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}



.strategy-buttons {
  margin-bottom: 20px;
}

.strategy-buttons .el-button {
  margin-right: 10px;
}

.goods-tab {
  background: #fff;
  position: relative;
  padding: 10px 38px;
  margin-bottom: 20px;
  border-radius: 4px;
}

.col-tab {
  height: 48px;
  font-size: 18px;
  white-space: pre;
  margin-bottom: 0;
  font-weight: 700;
}
</style>