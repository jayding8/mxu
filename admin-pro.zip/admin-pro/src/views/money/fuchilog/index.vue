<template>
  <div class="index-container">
    <el-alert :closable="false" show-icon title="扶持金明细 " type="success" />
    <vab-query-form>
      <vab-query-form-top-panel>
        <el-form
          ref="form"
          class="box"
          :inline="true"
          label-width="66px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="会员ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" />
          </el-form-item>
          <el-form-item label="昵称">
            <el-input v-model="queryForm.title" placeholder="请输入昵称" />
          </el-form-item>

          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
            >
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel :span="24">
        <el-button icon="el-icon-plus" type="primary" @click="handleAdd">
          导出EXCEL
        </el-button>
        <el-button
          icon="el-icon-delete"
          type="danger"
          @click="handleDelete($event)"
        >
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>
    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="ID" prop="id" sortable width="80" />
      <el-table-column fixed label="会员ID" prop="mid" width="80" />
      <el-table-column label="会员信息">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.headimg" style="height: 50px; width: 50px" />
            <div>{{ props.row.nickname }}</div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column
        label="变更金额"
        prop="commission"
        sortable
        width="150"
      />
      <el-table-column label="变更后金额" prop="after" sortable width="150" />
      <el-table-column
        label="变更时间"
        prop="createtime"
        sortable
        width="150"
      />
      <el-table-column label="备注" prop="remark" width="200" />
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { fuchiLog } from '@/api/money'

  export default {
    name: 'Fuchilog',

    data() {
      return {
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        layout: 'total, sizes, prev, pager, next, jumper',
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.fuchiLog({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      fuchiLog,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.fuchiLog({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.fuchiLog({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped>
  .select-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .box {
    padding: 20px;
    background: #f2f5f8;
    border-radius: 6px;
    width: 100%;
  }
</style>
