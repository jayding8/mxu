<template>
  <!-- <el-row class="card" :gutter="20">
    <div v-for="item in list" :key="item.id" class="cardBox" :style="{ width: percentage }">
      <div class="title">{{ item.title }}</div>
      <el-row align="bottom" class="content">
        <div class="num">{{ item.num }}</div>
      </el-row>
    </div>
  </el-row> -->
  <el-row class="card" :gutter="20">
    <div v-for="item of list" :key="item.id" class="cardBox" :style="{ width: percentage }">
      <div :class="['cardItem', { active: activeId == item.id }]" @click="gotoTab(item)">
        <div class="title">{{ item.title }}</div>
        <el-row align="bottom" class="content">
          <div class="num">{{ item.num }}</div>
        </el-row>

      </div>
    </div>
  </el-row>
</template>

<script>
export default {
  name: 'DataList',
  props: {
    list: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  computed: {
    percentage() {
      return (100 / this.list.length).toFixed(2) + '%';
    },
  },
  mounted() {
    console.log(this.list);
  },
}
</script>
<style lang="scss" scoped>
.card {
  margin-top: 10px;
  display: flex;
}

.cardBox:last-child {
  .cardItem {
    margin-right: 0;
  }
}

.cardItem {
  padding: 20px;
  cursor: pointer;
  background: linear-gradient(0deg, #fbfbfb, #fbfbfb), #fafafa;
  box-sizing: border-box;

  margin-right: 12px;

  div {
    color: #333;
  }

  &:hover {
    box-shadow: 0px 0px 10px rgb(0 0 0 / 10%);
    transform: translateY(-5px);
    transition: all 0.3s linear;
  }
}


.title {
  color: #333;
  margin-right: 15px;
  margin-bottom: 10px;
  font-size: 16px;
  font-weight: 600;
  color: #262b30;
  vertical-align: middle;
}

.content {
  .num {
    font-size: 30px;
    font-weight: 700;
    color: #4390ff;
    margin: 12px 0;
  }

  .unit {
    font-size: 12px;
    color: #666;
    position: relative;
    top: -6px;
    left: 6px;
  }
}
</style>