<template>
  <div class="workBench">
    <el-row class="store">
      <div v-for="(v, i) in shopList" :key="i" class="item" @click="look(v)">
        <div class="t">
          <div style="display: flex;justify-content: space-between;">
            <div>
              <el-tag v-if="v.status == '6'" effect="light">待审核</el-tag>
              <el-tag v-else-if="v.status == '1'" effect="light" type="success">
                正常
              </el-tag>
              <el-tag v-else-if="v.status == '2'" effect="light" type="danger">
                拉黑
              </el-tag>
              <el-tag v-else-if="v.status == '5'" effect="light" type="danger">
                审核失败
              </el-tag>
            </div>

            <div>
              <el-button link size="small" type="text" @click.stop="look(v)">
                进入
              </el-button>
              <el-button link size="small" type="text" @click.stop="look(v)">
                修改
              </el-button>
              <el-button link size="small" type="text" @click.stop="handleDelete(v)">
                删除
              </el-button>

            </div>
          </div>

          <el-row style="margin-top: 15px;display: flex;">
            <div class="img">
              <img :src="v.applyImage || '@/assets/icon/avatar.png'" style="width: 100%" />
            </div>
            <div>
              <div class="name">{{ v.applyName }}</div>
              <div v-if="true" class="detail">
                <div>到期时间：{{ v.endTime }}</div>
                <div>
                  服务套餐：{{ v.muster && v.muster.title }}
                  <div class="ml-2 repair">
                    体验套餐
                  </div>
                </div>
                <el-row>
                  <div>用户渠道：</div>
                  <el-row v-if="v.userChannel && v.userChannel.length > 0" class="channel">
                    <div v-for="item in v.userChannel" :key="item" class="channelItem">
                      <img v-if="item.plug && item.plug.baseLogo" class="channelImg" :src="item.plug.baseLogo" />
                    </div>
                  </el-row>
                  <div v-else>无</div>
                </el-row>
              </div>
            </div>
          </el-row>
        </div>
        <el-row align="middle" class="dataBox">
          <div class="dataItem">
            <div class="num">
              {{ v.storeCount }}/{{
                v.storeNumInfinite == 0 ? v.storeNum : '无限'
              }}
            </div>
            <div class="txt">创建门店数(个)</div>
          </div>
          <div class="dataItem">
            <div class="num">{{ v.memberCount || 0 }}</div>
            <div class="txt">会员数(人)</div>
          </div>
          <div class="dataItem">
            <div class="num">{{ v.orderCount || 0 }}</div>
            <div class="txt">支付订单数(笔)</div>
          </div>
        </el-row>
      </div>
    </el-row>
  </div>
</template>
<script>
export default {
  name: 'StoreList',
  props: {
    shopList: {
      type: Array,
      default: () => [],
    },
    showCreate: {
      type: String,
      default: 'true',
    },
  },

}
</script>
<style lang="scss" scoped>
.workBench {
  margin-top: 20px;
}

.channelItem {
  margin-left: 4px;
}

.channelImg {
  width: 18px;
  height: 18px;
}

.store {
  gap: 20px;

  .item {
    position: relative;
    background: #fff;
    border-radius: 5px;
    // height: 271px;
    // width: 386px;
    width: 381px;
    box-sizing: border-box;
    cursor: pointer;
    box-shadow: 0 0 2px #eee;
    transition: all 0.2s ease-in-out;

    .actionBtn {
      display: none;
    }

    &:hover {
      transform: translateY(-10px);
      transition: all 0.2s ease-in-out;

      .actionBtn {
        display: block;
      }
    }

    .t {
      padding: 20px;

      .channel {
        margin-top: 4px;

        img {
          width: 20px;
          height: 20px;
        }
      }
    }

    .status {
      position: relative;
    }

    .img {
      position: relative;
      background: linear-gradient(0deg, #ebf0f7, #ebf0f7);
      border-radius: 8px;
      overflow: hidden;
      width: 96px;
      height: 96px;
      text-align: center;
      line-height: 126px;
      margin-right: 15px;
    }

    .name {
      color: rgba(0, 0, 0, 0.8);
      font-size: 16px;
      font-style: normal;
      font-weight: 600;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .detail {
      color: #999;
      font-size: 12px;
      margin-top: 12px;

      div {
        margin-top: 6px;
      }
    }
  }
}

.dataBox {
  background: linear-gradient(180deg, #f9f9fb, #fff);
  height: 88px;
  display: flex;
  justify-self: space-between;
  padding-top: 25px;
}

.dataItem {
  flex: 1;
  text-align: center;

  .num {
    color: rgba(0, 0, 0, 0.8);
    font-weight: 600;
    font-size: 16px !important;
    line-height: 20px;
  }

  .txt {
    font-size: 12px;
    margin-top: 10px;
    color: rgba(0, 0, 0, 0.6);
  }
}

.repair {
  color: #f90;
  background: #fff9e6;
  width: 50px;
}

.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}
</style>
