<template>
  <div class="index-container">
    <div>
      <DataList :list="surveyList" />
      <storeList v-show="list && list.length > 0" ref="storeList" :shop-list="list" @fetch-data="fetchData" />
    </div>

  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { WebUser } from '@/api/system'
import DataList from './components/dataList'
import storeList from './components/storeList'
export default {
  name: 'Index',
  components: {
    DataList, storeList
  },
  data() {
    return {
      surveyList: [{
        id: 1,
        title: '平台会员总数',
        num: 200,
      },
      {
        id: 2,
        title: '平台商品数量',
        num: 50,
      },
      {
        id: 3,
        title: '平台订单数 / 订单金额',
        num: 30,
      },
      {
        id: 4,
        title: '平台收款金额',
        num: 30,
      },
      ],
      list: [
        {
          "id": 293,
          "applyName": "筋斗云",
          "applyImage": "https://v3.b-ke.cn/storage/0/uploads/2024/07/20/99401562d3001874e8e453b6c27d302c.jpeg",
          "musterId": "1",
          "applyType": null,
          "createCount": null,
          "startTime": "2024-07-20 18:06:08",
          "endTime": "2025-07-20 18:06:08",
          "status": 1,
          "plugStr": null,
          "timeType": 2,
          "created_at": "2024-07-20 18:03:47",
          "updated_at": "2024-07-20 18:06:08",
          "deleted_at": null,
          "createUserId": 1,
          "attachmentType": 0,
          "notes": "6",
          "plugType": 1,
          "sort": 0,
          "day": 0,
          "adminId": 0,

          "attachmentData": null,
          "copyrightSwitch": 0,
          "copyright": null,
          "type": 0,
          "smsSign": null,
          "storeNum": 50,
          "storeNumInfinite": 0,
          "payChange": 1,
          "deliveryChannel": null,
          "typeFormat": "单门店",
          "muster": {
            "id": 1,
            "state": 1,
            "sort": 1,
            "title": "试用套餐",
            "subtitle": "此站点为演示站点，请勿填写敏感信息，如需了解系统详细功能，请联系云贝官方客服！",
            "desc": "此站点为演示站点，请勿填写敏感信息，如需了解系统详细功能，请联系云贝官方客服！",
            "marketingTagSwitch": 0,
            "marketingTag": null,
            "styleSwitch": 0,
            "style": {
              "bgColor": "rgb(64, 113, 255)",
              "txtColor": "#fff"
            },
            "deleted_at": null,
            "created_at": "2023-04-10 19:30:02",
            "updated_at": "2024-05-30 00:53:56",
            "type": 1,
            "day": 365,
            "smsNum": 50,
            "storeNum": 50
          },
          "memberCount": 10,
          "orderCount": 0,
          "storeCount": 0
        },
      ],
      info: {
        page: {
          current: 1,
          limit: 10,
          total: 0,
        },
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.WebUser({
      page: this.info.page.current,
      limit: this.info.page.limit,
    }).then((res) => {
      this.info = res
    })
    this.surveyList(); // 确保调用surveyList方法
  },
  methods: {
    WebUser,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.page.limit = val
      this.WebUser({
        page: this.info.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.page.current = val
      this.WebUser({
        page: val,
        limit: this.info.page.limit,
      })
    },
    surveyList() {
      // 这里可以是API调用或其他数据获取方式
      // 假设获取到的数据如下：
      this.surveyList = fetchedData; // 确保这里赋值给this.surveyList
    }
  },
}
</script>
<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}
</style>