<template>
  <div class="index-container">
    <vab-query-form>
      <vab-query-form-left-panel :span="4">
        <el-button type="primary" @click="handleAdd">添加</el-button>
        <el-button type="primary" @click="handleAdd">删除</el-button>
      </vab-query-form-left-panel>
    </vab-query-form>
    <el-table  :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="80" />

      <el-table-column label="名称" prop="name" width="150" />
      <el-table-column label="序号" prop="sort" width="150" />

      <el-table-column label="创建时间" width="200">
        <template slot-scope="props">
          <el-form>
            {{ new Date(props.row.createtime * 1000).toLocaleString() }}
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="120">
        <template slot-scope="props">
          <el-form>
            <span v-if="props.row.status == 1">显示</span>
            <span v-if="props.row.status == 0">关闭</span>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="150">
        <template slot-scope="scope">
          <div v-if="scope.row.status == 1">
            <a>编辑</a>
            <span class="line"></span>
            <a>删除</a>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit" :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Category } from '@/api/diy'
export default {
  name: 'Shopstock',
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Category({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    Category,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Category({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Category({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}
</style>
