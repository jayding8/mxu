<template>
  <div class="index-container">
    <vab-query-form>
      <vab-query-form-left-panel :span="24">
        <el-button type="primary" @click="handleAdd">添加</el-button>
        <el-button @click="handleAdd">删除</el-button>
        <el-button @click="handleAdd">开启</el-button>
      </vab-query-form-left-panel>
    </vab-query-form>
    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column align="center" type="selection" width="55" />
      <el-table-column align="center" fixed label="id" prop="id" width="80" />

      <el-table-column align="center" width="200" label="平台类型">
        <template slot-scope="props">

          <div>{{ props.row.platform }}</div>

        </template>
      </el-table-column>
      <el-table-column align="center" label="所属页面" prop="indexurl" width="200" />
      <el-table-column align="center" label="页面备注" prop="indexurlname" width="200" />

      <el-table-column align="center" label="分享内容">
        <template slot-scope="props">
          <div style="display: flex;">
            <el-image fit="fill" :lazy="true" :src="props.row.pic" />
            <div style="margin-left: 20px;">
              <div style="font-weight: bold;text-align: left;">{{ props.row.title }}</div>
              <div style="text-align: left;color: #888;">{{ props.row.desc }}</div>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" align="center" width="200">
        <template slot-scope="props">
          {{ new Date(props.row.createtime * 1000).toLocaleString() }}
        </template>
      </el-table-column>

      <el-table-column label="状态" width="150" align="center">
        <template slot-scope="props">

          <div v-if="props.row.status == 1">开启</div>
          <div v-else>关闭</div>

        </template>
      </el-table-column>
      <el-table-column align="center" fixed="right" label="操作" width="150">
        <template slot-scope="scope">
          <div v-if="scope.row.status == 1">
            <a>编辑</a>
            <span class="line"></span>
            <a>删除</a>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Share } from '@/api/diy'
export default {
  name: 'Shopstock',
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Share({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    Share,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Share({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Share({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}
</style>
