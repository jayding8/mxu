<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col :lg="18" :md="18" :sm="18" :xl="18" :xs="18">
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="150px"
          :model="info.data"
          :rules="rules"
        >
          <div>
            <el-form-item label="菜单一：" prop="menuType">
              <el-radio-group v-model="info.data.menudata.list[0].menuType">
                <el-radio label="1">客服</el-radio>
                <el-radio label="2">购物车</el-radio>
                <el-radio label="3">收藏</el-radio>
                <el-radio label="4">其他</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item
              v-if="info.data.menudata.list[0].menuType == 1"
              label="是否跟随："
              prop="btntype"
            >
              <el-radio-group v-model="info.data.menudata.list[0].useSystem">
                <el-radio label="1">跟随系统</el-radio>
                <el-radio label="0">自定义</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item label="名称：" prop="title">
              <el-input
                v-model="info.data.menudata.list[0].text"
                style="width: 240px"
              />
              <div v-if="info.data.menudata.list[0].menuType == 3">
                <span>选中名称</span>
                <el-input
                  v-model="info.data.menudata.list[0].selectedtext"
                  style="width: 240px"
                />
              </div>
            </el-form-item>
            <el-form-item
              v-if="info.data.menudata.list[0].useSystem == 0"
              label="链接："
              prop="pagePath"
            >
              <el-input
                v-model="info.data.menudata.list[0].pagePath"
                style="width: 240px"
              />
              <el-button size="default">选择链接</el-button>
              <span>{{ info.data.menudata.list[0].pagePathname }}</span>
            </el-form-item>
            <el-form-item label="图标：" prop="iconPath">
              <el-button size="default">上传图标</el-button>
              <el-image
                fit="fill"
                :lazy="true"
                :src="info.data.menudata.list[0].iconPath"
                style="width: 38px; height: 38px; margin-left: 20px"
              />
            </el-form-item>
            <el-form-item
              v-if="info.data.menudata.list[0].menuType == 3"
              label="选中图标："
              prop="selectedIconPath"
            >
              <el-button size="default">上传图标</el-button>
              <el-image
                fit="fill"
                :lazy="true"
                :src="info.data.menudata.list[0].selectedIconPath"
                style="width: 38px; height: 38px; margin-left: 20px"
              />
            </el-form-item>
            <el-form-item label="是否显示：" prop="isShow">
              <el-radio-group v-model="info.data.menudata.list[0].isShow">
                <el-radio label="1">显示</el-radio>
                <el-radio label="0">不显示</el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
          <div>
            <el-form-item label="菜单二：" prop="menuType">
              <el-radio-group v-model="info.data.menudata.list[1].menuType">
                <el-radio label="1">客服</el-radio>
                <el-radio label="2">购物车</el-radio>
                <el-radio label="3">收藏</el-radio>
                <el-radio label="4">其他</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item
              v-if="info.data.menudata.list[1].menuType == 1"
              label="是否跟随："
              prop="btntype"
            >
              <el-radio-group v-model="info.data.menudata.list[1].useSystem">
                <el-radio label="1">跟随系统</el-radio>
                <el-radio label="0">自定义</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item label="名称：" prop="title">
              <el-input
                v-model="info.data.menudata.list[1].text"
                style="width: 240px"
              />
              <div v-if="info.data.menudata.list[1].menuType == 3">
                <span>选中名称</span>
                <el-input
                  v-model="info.data.menudata.list[1].selectedtext"
                  style="width: 240px"
                />
              </div>
            </el-form-item>
            <el-form-item
              v-if="info.data.menudata.list[1].useSystem == 0"
              label="链接："
              prop="pagePath"
            >
              <el-input
                v-model="info.data.menudata.list[1].pagePath"
                style="width: 240px"
              />
              <el-button size="default">选择链接</el-button>
              <span>{{ info.data.menudata.list[1].pagePathname }}</span>
            </el-form-item>
            <el-form-item label="图标：" prop="iconPath">
              <el-button size="default">上传图标</el-button>
              <el-image
                fit="fill"
                :lazy="true"
                :src="info.data.menudata.list[1].iconPath"
                style="width: 38px; height: 38px; margin-left: 20px"
              />
            </el-form-item>
            <el-form-item
              v-if="info.data.menudata.list[1].menuType == 3"
              label="选中图标："
              prop="selectedIconPath"
            >
              <el-button size="default">上传图标</el-button>
              <el-image
                fit="fill"
                :lazy="true"
                :src="info.data.menudata.list[1].selectedIconPath"
                style="width: 38px; height: 38px; margin-left: 20px"
              />
            </el-form-item>
            <el-form-item label="是否显示：" prop="isShow">
              <el-radio-group v-model="info.data.menudata.list[1].isShow">
                <el-radio label="1">显示</el-radio>
                <el-radio label="0">不显示</el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
          <div>
            <el-form-item label="菜单三：" prop="menuType">
              <el-radio-group v-model="info.data.menudata.list[2].menuType">
                <el-radio label="1">客服</el-radio>
                <el-radio label="2">购物车</el-radio>
                <el-radio label="3">收藏</el-radio>
                <el-radio label="4">其他</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item
              v-if="info.data.menudata.list[2].menuType == 1"
              label="是否跟随："
              prop="btntype"
            >
              <el-radio-group v-model="info.data.menudata.list[2].useSystem">
                <el-radio label="1">跟随系统</el-radio>
                <el-radio label="0">自定义</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item label="名称：" prop="title">
              <el-input
                v-model="info.data.menudata.list[2].text"
                style="width: 240px"
              />
              <div v-if="info.data.menudata.list[2].menuType == 3">
                <span>选中名称</span>
                <el-input
                  v-model="info.data.menudata.list[2].selectedtext"
                  style="width: 240px"
                />
              </div>
            </el-form-item>
            <el-form-item
              v-if="info.data.menudata.list[2].useSystem == 0"
              label="链接："
              prop="pagePath"
            >
              <el-input
                v-model="info.data.menudata.list[2].pagePath"
                style="width: 240px"
              />
              <el-button size="default">选择链接</el-button>
              <span>{{ info.data.menudata.list[2].pagePathname }}</span>
            </el-form-item>
            <el-form-item label="图标：" prop="iconPath">
              <el-button size="default">上传图标</el-button>
              <el-image
                fit="fill"
                :lazy="true"
                :src="info.data.menudata.list[2].iconPath"
                style="width: 38px; height: 38px; margin-left: 20px"
              />
            </el-form-item>
            <el-form-item
              v-if="info.data.menudata.list[2].menuType == 3"
              label="选中图标："
              prop="selectedIconPath"
            >
              <el-button size="default">上传图标</el-button>
              <el-image
                fit="fill"
                :lazy="true"
                :src="info.data.menudata.list[2].selectedIconPath"
                style="width: 38px; height: 38px; margin-left: 20px"
              />
            </el-form-item>
            <el-form-item label="是否显示：" prop="isShow">
              <el-radio-group v-model="info.data.menudata.list[2].isShow">
                <el-radio label="1">显示</el-radio>
                <el-radio label="0">不显示</el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
          <div>
            <el-form-item
              label="商品描述
公共底部图片："
              prop="pagePath"
            >
              <el-input
                v-model="info.data.menudata.bottomImg"
                style="width: 240px"
              />
              <el-button size="default">上传图标</el-button>
              <div>用于展示公共的价格说明等信息</div>
              <div style="width: 200px">
                <el-image
                  fit="fill"
                  :lazy="true"
                  :src="info.data.menudata.bottomImg"
                />
              </div>
            </el-form-item>
          </div>
          <el-button size="default" type="primary">保存</el-button>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { Shopdetail } from '@/api/diy'
  export default {
    name: 'Shopstock',
    data() {
      return {
        bgcolor: '', // 默认颜色值
        colorValue: '#409EFF', // 默认颜色值
        predefineColors: [
          // 预定义的颜色列表
          '#409EFF',
          '#FF4500',
          '#FFD700',
          '#40E0D0',
          '#EE82EE',
          '#00CED1',
          '#8B008B',
          '#00FF00',
          '#1E90FF',
        ],
        form: {},
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.Shopdetail({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      Shopdetail,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.Shopdetail({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.Shopdetail({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped>
  .bg_div1 {
    width: 100%;
    height: 100%;
    overflow: hidden;
  }

  .content_div1 {
    width: 300px;
    margin: 0 auto;
  }

  .title1 {
    padding-top: 40px;
    margin-top: 40px;
    font-size: 25px;
    font-weight: bold;
    line-height: 45px;
    text-align: left;
    opacity: 1;
  }

  .subhead1 {
    font-size: 14px;
    font-weight: 500;
    line-height: 20px;
  }

  .card_div1 {
    width: 100%;
    padding: 20px;
    margin-top: 20px;
    margin-bottom: 100px;
    border-radius: 12px;
  }

  .tel1 {
    width: 100%;
    height: 50px;
    padding: 0 20px;
    margin: 10px 0;
    margin-top: 15px;
    line-height: 50px;
    color: #cacaca;
    background-color: #f5f7fa;
    border-radius: 50px;
  }

  .code1 {
    float: right;
    height: 50px;
    font-size: 12px;
    line-height: 50px;
  }

  .btn1 {
    width: 100%;
    height: 50px;
    margin: 10px 0;
    font-weight: bold;
    line-height: 50px;
    text-align: center;
    border-radius: 50px;
  }

  .other_line {
    width: 48px;
    height: 1px;
    margin-top: 12px;
    background: #d8d8d8;
  }

  .logo {
    width: 100px;
    height: 100px;
    margin: 0 auto;
    margin-top: 20px;
    margin-bottom: 20px;
    overflow: hidden;
    border-radius: 6px;
  }
</style>
