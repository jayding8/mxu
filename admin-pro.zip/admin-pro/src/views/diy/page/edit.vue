<template>
  <div class="diy-page">
    <el-row align="middle" class="acea-row row-between-wrapper" justify="space-between" type="flex">
      <el-col class="f_title" :span="12">
        <div class="acea-row row-middle" @click="returnTap">
          <div class="iconfanhui"></div>
          <div class="return">返回</div>
        </div>
        <div class="mr20">
          <span class="name">{{ nameTxt || '模板' }}</span>
          <!-- 使用 Element UI 的 Popover 组件来创建弹出菜单 -->
          <el-popover v-model="visible" placement="bottom" trigger="click" width="347">
            <div>
              <el-input v-model="nameTxt" placeholder="必填不超过15个字" />
              <el-button type="text" @click="cancel">取消</el-button>
              <el-button type="primary" @click="determine">确定</el-button>
            </div>
            <span slot="reference" class="iconfont iconzidingyicaidan"></span>
          </el-popover>
        </div>
      </el-col>
      <el-col class="buttons" :span="12">
        <!-- 使用 Element UI 的按钮组件 -->
        <el-button class="bnt" ghost @click="reast">重置</el-button>
        <el-button v-if="pageId" class="bnt w-74" ghost @click="preview">
          <span class="iconfont iconshouyintai-yanjing"></span>
          预览
        </el-button>
        <el-button class="bnt ml20 w-74" ghost :loading="loading" @click="saveConfig(1)">
          仅保存
        </el-button>
        <el-button class="release ml20 w-74" :loading="relLoading" @click="saveConfig(2)">
          保存关闭
        </el-button>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { welcome, shopProduct } from '@/api/user'
export default {
  name: 'Index',
  data() {
    return {
      info: {
        page: {
          current: 1,
          limit: 10,
          totle: 0,
        },
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.welcome()
    this.shopProduct({
      page: this.info.page.current,
      limit: this.info.page.limit,
    }).then((res) => {
      this.info = res
    })
  },
  methods: {
    welcome,
    shopProduct,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.page.limit = val
      this.shopProduct({
        page: this.info.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.page.current = val
      this.shopProduct({
        page: val,
        limit: this.info.page.limit,
      })
    },
  },
}
</script>

<style lang="scss" scoped>
.diy-page {
  padding: 16px 32px 0 32px;
  background: linear-gradient(270deg, #009dff, #0550ff);
  border-radius: 0;
}
</style>
