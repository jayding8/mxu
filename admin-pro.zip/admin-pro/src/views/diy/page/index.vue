<template>
  <div class="index-container">
    <el-row class="ivu-mt box-wrapper acea-el-row" type="flex">
      <el-col class="right-wrapper">
        <el-card :bordered="false" dis-hover>
          <el-row :gutter="20">
            <el-col :span="8" style="
                position: relative;
                width: 310px;
                height: 550px;
                margin-right: 30px;
              ">
              <iframe ref="iframe" class="iframe-box" frameborder="0"
                src="https://pro.crmeb.net/pages/annex/special/index?id=32"></iframe>
            </el-col>
            <el-col :span="16">
              <div class="acea-el-row el-row-between-wrapper">
                <el-row type="flex">
                  <el-col v-bind="grid">
                    <div class="button acea-el-row el-row-middle">
                      <el-button type="primary" @click="add">
                        添加主题
                      </el-button>
                    </div>
                    <el-table :data="info.data" stripe @selection-change="handleSelectionChange">
                      <el-table-column type="selection" width="55" />
                      <el-table-column label="ID" prop="id" width="100" />
                      <el-table-column label="页面名称" prop=" name
                      " width="100" />
                      <el-table-column label="页面类型" width="150">
                        <template slot-scope="props">
                          <el-form>
                            <el-form-item v-if="props.row.ishome == 1">
                              <div>商城首页</div>
                            </el-form-item>
                            <el-form-item v-else-if="props.row.ishome == 2">
                              <div>会员中心</div>
                            </el-form-item>
                            <el-form-item v-else="props.row.ishome == 0">
                              <div>其他页面</div>
                            </el-form-item>
                          </el-form>
                        </template>
                      </el-table-column>
                      <el-table-column label="创建时间" prop="createtime" width="180">
                        <template slot-scope="scope">
                          {{
                            new Date(
                              scope.row.createtime * 1000
                            ).toLocaleString()
                          }}
                        </template>
                      </el-table-column>
                      <el-table-column label="更新时间" prop="updatetime" sortable width="180">
                        <template slot-scope="scope">
                          {{
                            new Date(
                              scope.row.updatetime * 1000
                            ).toLocaleString()
                          }}
                        </template>
                      </el-table-column>
                      <el-table-column fixed="right" label="操作">
                        <template slot-scope="scope">
                          <a @click="handleClick(scope.row)">查看</a>
                          <span class="line"></span>
                          <a @click="handleEdit(scope.row.id)">编辑</a>
                          <span class="line"></span>
                          <a @click="handleEdit(scope.row.id)">删除</a>
                          <span class="line"></span>
                          <a @click="handleEdit(scope.row.id)">预览</a>
                        </template>
                      </el-table-column>
                    </el-table>
                  </el-col>
                </el-row>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { getList } from '@/api/diy'
export default {
  name: 'ShopCategory',
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',

      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.getList({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    getList,

    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.getList({
        page: this.page.current,
        limit: val,
      }).then((res) => {
        this.info = res
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.getList({
        page: val,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    add() {
      this.$router.push({
        path: '/views/diy/page/add',
        // query: { id: 0, name: '首页', type: 1 },
      })
    },
    add(id) {
      this.$router.push({ name: 'Diyedit', query: { id: id } })
    },
  },
}
</script>
<style lang="scss" scoped>
  .right-wrapper {
    width: 100%;
  }

  .table {
    width: 100%;
  }

  .ivu-mt {
    background-color: #fff;
  }

  .bnt {
    width: 80px !important;
  }

  .iframe-box {
    width: 100%;
    height: 100%;
    border: 1px solid #eee;
    border-radius: 10px;
  }

  .mask {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0);
  }

  .line {
    position: relative;
    top: -0.06em;
    box-sizing: border-box;
    display: inline-block;
    width: 1px;
    height: 0.9em;
    padding: 0;
    margin: 0 8px;
    font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
      Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
    font-size: 14px;
    line-height: 1.5;
    color: #515a6e;
    vertical-align: middle;
    list-style: none;
    background: #e8eaec;
  }
</style>
