<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col :lg="12" :md="12" :sm="12" :xl="12" :xs="12">
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="150px"
          :model="info.data"
          :rules="rules"
        >
          <el-form-item prop="bgimg">
            <el-input v-model="info.data.data.bgimg" style="width: 200px" />
            <el-button size="default" type="primary">上传图片</el-button>
            <el-image
              class="logo"
              fit="fill"
              :lazy="true"
              :src="info.data.data.bgimg"
            />
          </el-form-item>
          <el-button size="default" type="primary">保存</el-button>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { Mobile } from '@/api/diy'
  export default {
    name: 'Shopstock',
    data() {
      return {
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.Mobile({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      Mobile,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.Mobile({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.Mobile({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped></style>
