<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col :lg="12" :md="12" :sm="12" :xl="12" :xs="12">
        <div
          style="
            width: 480px;
            height: 100%;
            padding-right: 50px;
            padding-left: 50px;
          "
        >
          <div
            :style="{
              height: '800px',
              background:
                info.data.data.bgtype == 1
                  ? info.data.data.bgcolor
                  : `url(${info.data.data.bgimg}) no-repeat center`,
              backgroundSize: '100% 100%',
            }"
          >
            <div v-if="info.data.info.type == 1">
              <div
                class="title1"
                :style="{
                  color: info.data.data.titlecolor,
                  textAlign: info.data.data.titletype,
                }"
              >
                {{ info.data.data.title }}
              </div>
              <div
                class="subhead1"
                :style="{
                  color: info.data.data.subheadcolor,
                  textAlign: info.data.data.titletype,
                }"
              >
                {{ info.data.data.subhead }}
              </div>
            </div>
            <div v-if="info.data.info.type == 2" style="display: grid">
              <el-image
                class="logo"
                fit="fill"
                :lazy="true"
                :src="info.data.data.logo"
              />
            </div>
            <div class="content_div1">
              <div
                class="card_div1"
                :style="{
                  background: info.data.data.cardcolor,
                }"
              >
                <div v-if="info.data.info.type == 2">
                  <div
                    :style="{
                      color: info.data.data.titlecolor,
                      textAlign: info.data.data.titletype,
                      marginTop: '10px',
                      fontSize: '20px',
                    }"
                  >
                    {{ info.data.data.title }}
                  </div>
                  <div
                    v-if="info.data.data.subhead"
                    class="subhead1"
                    :style="{
                      color: info.data.data.subheadcolor,
                      textAlign: info.data.data.titletype,
                    }"
                  >
                    {{ info.data.data.subhead }}
                  </div>
                </div>
                <div class="tel1">请输入手机号码</div>
                <div class="tel1">
                  <span>请输入验证码</span>
                  <span
                    class="code1"
                    :style="{ color: info.data.data.codecolor }"
                  >
                    获取验证码
                  </span>
                </div>
                <div
                  style="overflow: hidden; font-size: 12px; line-height: 30px"
                >
                  <div
                    style="
                      display: inline-block;
                      width: 12px;
                      height: 12px;
                      background-color: #f5f7fa;
                      border: 1px solid #d3d5d7;
                      border-radius: 100%;
                    "
                  ></div>
                  <span :style="{ color: info.data.data.xytipcolor }">
                    {{ info.data.data.xytipword }}
                  </span>
                  <span :style="{ color: info.data.data.xycolor }">
                    {{ info.data.data.xyname }}
                  </span>
                </div>
                <div
                  v-show="info.data.data.btntype == 1"
                  class="btn1"
                  :style="{
                    background: '#0256FF',
                    color: info.data.data.btnwordcolor,
                  }"
                >
                  登录
                </div>
                <div
                  v-show="info.data.data.btntype == 2"
                  class="btn1"
                  :style="{
                    background: info.data.data.btncolor,
                    color: info.data.data.btnwordcolor,
                  }"
                >
                  登录
                </div>

                <div style="float: 12px; overflow: hidden; line-height: 50px">
                  <span :style="{ color: info.data.data.regbtncolor }">
                    注册账号
                  </span>
                </div>
                <div style="width: 210px; margin: 30px auto">
                  <div style="display: flex; width: 100%">
                    <div class="other_line"></div>
                    <div style="margin: 0 10px; color: #d8d8d8">
                      其他登录方式
                    </div>
                    <div class="other_line"></div>
                  </div>
                  <div
                    style="
                      width: 100%;
                      padding: 0 20px;
                      margin-top: 30px;
                      overflow: hidden;
                    "
                  >
                    <img
                      src="__STATIC__/img/login-weixin.png"
                      style="float: left; width: 50px; height: 50px"
                    />
                    <img
                      src="__STATIC__/img/reg-tellogin.png"
                      style="float: right; width: 50px; height: 50px"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :lg="12" :md="12" :sm="12" :xl="12" :xs="12">
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="150px"
          :model="info.data"
          :rules="rules"
        >
          <el-form-item label="页面样式：" prop="type">
            <el-radio-group v-model="info.data.info.type">
              <el-radio :label="1">样式一</el-radio>
              <el-radio :label="2">样式二</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="背景：" prop="btntype">
            <el-radio-group v-model="info.data.data.bgtype">
              <el-radio :label="'1'">背景色</el-radio>
              <el-radio :label="'2'">背景图片</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item
            v-if="info.data.data.bgtype == 1"
            label="背景："
            prop="btntype"
          >
            <div style="display: flex">
              <el-input v-model="info.data.data.bgcolor" style="width: 200px" />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.bgcolor"
                  :predefine="predefineColors"
                />
                <span style="margin-left: 20px">商城辅色调，如：#7E71F6</span>
              </div>
            </div>
          </el-form-item>

          <el-form-item v-if="info.data.data.bgtype == 2" prop="bgimg">
            <el-input v-model="info.data.data.bgimg" style="width: 200px" />
            <el-button size="default" type="primary">上传图片</el-button>
            <el-image
              class="logo"
              fit="fill"
              :lazy="true"
              :src="info.data.data.bgimg"
            />
          </el-form-item>
          <el-form-item
            v-if="info.data.info.type == 2"
            label="logo:"
            prop="logo"
          >
            <el-input v-model="info.data.data.bgimg" style="width: 200px" />
            <el-button size="default" type="primary">上传图片</el-button>
            <el-image
              class="logo"
              fit="fill"
              :lazy="true"
              :src="info.data.data.logo"
            />
          </el-form-item>
          <el-form-item label="卡片背景颜色：" prop="cardcolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.cardcolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.cardcolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item label="标题样式：" prop="titletype">
            <el-radio-group v-model="info.data.data.titletype">
              <el-radio :label="'left'">居左</el-radio>
              <el-radio :label="'center'">居中</el-radio>
              <el-radio :label="'right'">居右</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="标题样式：" prop="title">
            <el-input v-model="info.data.data.title" style="width: 240px" />
          </el-form-item>
          <el-form-item label="标题文字颜色：" prop="titlecolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.titlecolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.titlecolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item label="副标题内容：" prop="subhead">
            <el-input v-model="info.data.data.subhead" style="width: 240px" />
            <span style="margin-left: 20px">为空不显示</span>
          </el-form-item>
          <el-form-item label="副标题文字颜色：" prop="subheadcolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.subheadcolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.subheadcolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>

          <el-form-item label="登录按钮颜色：" prop="btntype">
            <el-radio-group v-model="info.data.data.btntype">
              <el-radio :label="'1'">跟随主题色</el-radio>
              <el-radio :label="'2'">自定义</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item v-if="info.data.data.btntype == 2" prop="btncolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.btncolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.btncolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item label="登录按钮文字：" prop="btnwordcolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.btnwordcolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.btnwordcolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item label="验证码：" prop="codecolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.codecolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.codecolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item label="注册文字/忘记密码：" prop="regpwdbtncolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.regpwdbtncolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.regpwdbtncolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item label="协议提示文字：" prop="xytipword">
            <el-input v-model="info.data.data.xytipword" style="width: 240px" />
          </el-form-item>
          <el-form-item label="协议提示文字颜色：" prop="xytipcolor">
            <div style="display: flex">
              <el-input
                v-model="info.data.data.xytipcolor"
                style="width: 200px"
              />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.xytipcolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item label="协议文字颜色：" prop="xycolor">
            <div style="display: flex">
              <el-input v-model="info.data.data.xycolor" style="width: 200px" />
              <div style="margin-left: 10px">
                <el-color-picker
                  v-model="info.data.data.xycolor"
                  :predefine="predefineColors"
                />
              </div>
            </div>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { Login } from '@/api/diy'
  export default {
    name: 'Shopstock',
    data() {
      return {
        bgcolor: '', // 默认颜色值
        colorValue: '#409EFF', // 默认颜色值
        predefineColors: [
          // 预定义的颜色列表
          '#409EFF',
          '#FF4500',
          '#FFD700',
          '#40E0D0',
          '#EE82EE',
          '#00CED1',
          '#8B008B',
          '#00FF00',
          '#1E90FF',
        ],
        form: {},
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.Login({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      Login,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.Login({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.Login({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped>
  .bg_div1 {
    width: 100%;
    height: 100%;
    overflow: hidden;
  }

  .content_div1 {
    width: 300px;
    margin: 0 auto;
  }

  .title1 {
    padding-top: 40px;
    margin-top: 40px;
    font-size: 25px;
    font-weight: bold;
    line-height: 45px;
    text-align: left;
    opacity: 1;
  }

  .subhead1 {
    font-size: 14px;
    font-weight: 500;
    line-height: 20px;
  }

  .card_div1 {
    width: 100%;
    padding: 20px;
    margin-top: 20px;
    margin-bottom: 100px;
    border-radius: 12px;
  }

  .tel1 {
    width: 100%;
    height: 50px;
    padding: 0 20px;
    margin: 10px 0;
    margin-top: 15px;
    line-height: 50px;
    color: #cacaca;
    background-color: #f5f7fa;
    border-radius: 50px;
  }

  .code1 {
    float: right;
    height: 50px;
    font-size: 12px;
    line-height: 50px;
  }

  .btn1 {
    width: 100%;
    height: 50px;
    margin: 10px 0;
    font-weight: bold;
    line-height: 50px;
    text-align: center;
    border-radius: 50px;
  }

  .other_line {
    width: 48px;
    height: 1px;
    margin-top: 12px;
    background: #d8d8d8;
  }

  .logo {
    width: 100px;
    height: 100px;
    margin: 0 auto;
    margin-top: 20px;
    margin-bottom: 20px;
    overflow: hidden;
    border-radius: 6px;
  }
</style>
