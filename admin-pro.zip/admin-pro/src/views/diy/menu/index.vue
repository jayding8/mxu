<template>
  <div class="index-container">
    <el-tabs v-model="activeName" @tab-click="handleTab">
      <el-tab-pane label="微信公众号" name="1">
        <tabbar />
      </el-tab-pane>
      <el-tab-pane label="微信小程序" name="2">11</el-tab-pane>
      <el-tab-pane label="支付宝小程序" name="3">22</el-tab-pane>
      <el-tab-pane label="百度小程序" name="4">33</el-tab-pane>
      <el-tab-pane label="抖音小程序" name="5">44</el-tab-pane>
      <el-tab-pane label="QQ小程序" name="6">55</el-tab-pane>
      <el-tab-pane label="手机H5" name="7">66</el-tab-pane>
      <el-tab-pane label="手机APP" name="8">77</el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Menu } from '@/api/diy'
import Tabbar from './components/tabbar.vue'
export default {
  name: 'Shopstock',
  components: {
    tabbar: () => import('./components/tabbar'),
  },
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Menu({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    Menu,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Menu({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Menu({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped></style>
