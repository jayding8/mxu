<template>
  <div class="index-container">
    <el-tabs v-model="activeName" @tab-click="handleTab">
      <el-tab-pane v-if="info.data.info.platform === 'mp'" label="微信公众号" name="1">
        <div class="tabbar-preview flex-1">
          <el-scrollbar class="ls-scrollbar" style="height: 100%">
            <div class="phone">
              <div style="display: flex">
                <div v-for="(item, index) in info.data.menudata.list.slice(
                  0,
                  info.data.info.menucount
                )" :key="index" class="image-container">
                  <img alt="" :src="item.selectedIconPath" srcset="" />
                  <span>{{ item.text }}</span>
                </div>
              </div>
            </div>
          </el-scrollbar>
        </div>
        <div>
          <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="150px" :model="info.data"
            :rules="rules">
            <el-form-item label="菜单个数：" prop="menucount">
              <el-radio-group v-model="info.data.info.menucount">
                <el-radio :label="0">无</el-radio>
                <el-radio :label="2">两个</el-radio>
                <el-radio :label="3">三个</el-radio>
                <el-radio :label="4">四个</el-radio>
                <el-radio :label="5">五个</el-radio>
              </el-radio-group>
            </el-form-item>


            <div v-for="(item, index) in info.data.menudata.list.slice(
              0,
              info.data.info.menucount
            )" :key="index">
              <el-form-item label="名称：" prop="text">
                <el-input v-model="item.text" style="width: 240px" />
              </el-form-item>
              <el-form-item label="链接：" prop="pagePath">
                <el-input v-model="item.pagePath" style="width: 240px" />
              </el-form-item>
              <el-form-item label="名称：" prop="pagePath">
                <div>{{ item.pagePathname }}</div>
              </el-form-item>
              <el-form-item label="图标：" prop="pagePath">
                <div>
                  <el-button size="default">默认图标</el-button>
                  <img alt="" :src="item.iconPath" srcset="" />
                  <el-button size="default">默认图标</el-button>
                  <img alt="" :src="item.selectedIconPath" srcset="" />
                </div>
              </el-form-item>

            </div>




            <el-form-item label="文字默认颜色：" prop="color">
              <div style="display: flex">
                <el-input v-model="info.data.menudata.color" style="width: 200px" />
                <div style="margin-left: 10px">
                  <el-color-picker v-model="info.data.menudata.color" :predefine="predefineColors" />
                </div>
              </div>
            </el-form-item>
            <el-form-item label="文字选中颜色：" prop="selectedColor">
              <div style="display: flex">
                <el-input v-model="info.data.menudata.selectedColor" style="width: 200px" />
                <div style="margin-left: 10px">
                  <el-color-picker v-model="info.data.menudata.selectedColor" :predefine="predefineColors" />
                </div>
              </div>
            </el-form-item>
            <el-form-item label="菜单背景色：" prop="backgroundColor">
              <div style="display: flex">
                <el-input v-model="info.data.menudata.backgroundColor" style="width: 200px" />
                <div style="margin-left: 10px">
                  <el-color-picker v-model="info.data.menudata.backgroundColor" :predefine="predefineColors" />
                </div>
              </div>
            </el-form-item>
            <el-form-item label="中间按钮突出：" prop="menustyle">
              <el-radio-group v-model="info.data.menudata.menustyle">
                <el-radio label="0">关闭</el-radio>
                <el-radio label="1">开启</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item label="同步到其他端：" prop="tongbu">
              <el-radio-group v-model="info.data.info.tongbu">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-form>
        </div>
      </el-tab-pane>
      <el-tab-pane label="微信小程序" name="2">11</el-tab-pane>
      <el-tab-pane label="支付宝小程序" name="3">22</el-tab-pane>
      <el-tab-pane label="百度小程序" name="4">33</el-tab-pane>
      <el-tab-pane label="抖音小程序" name="5">44</el-tab-pane>
      <el-tab-pane label="QQ小程序" name="6">55</el-tab-pane>
      <el-tab-pane label="手机H5" name="7">66</el-tab-pane>
      <el-tab-pane label="手机APP" name="8">77</el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

import { Menu } from '@/api/diy'
export default {
  name: 'Shopstock',

  data() {
    return {
      colorValue: '#409EFF', // 默认颜色值
      predefineColors: [
        // 预定义的颜色列表
        '#409EFF',
        '#FF4500',
        '#FFD700',
        '#40E0D0',
        '#EE82EE',
        '#00CED1',
        '#8B008B',
        '#00FF00',
        '#1E90FF',
      ],
      activeName: '1',
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),

  },
  created() {
    this.Menu({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    Menu,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Menu({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Menu({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.image-container {
  display: grid;
  align-content: center;
  justify-items: center;
}
</style>
