<template>
  <div class="shop-tabbar flex">
    <div class="tabbar-preview flex-1">
      <el-scrollbar class="ls-scrollbar" style="height: 100%">
        <div class="phone">
          2
          <!-- <w-tabbar :content="tabbar.content" :styles="tabbar.styles" /> -->
        </div>
      </el-scrollbar>
    </div>
    <div class="tabbar-setting">
      <el-scrollbar class="ls-scrollbar" style="height: 100%">
        <!-- <a-tabbar :content="tabbar.content" :styles="tabbar.styles" /> -->
        2
      </el-scrollbar>
    </div>
    <div class="tabbar-footer bg-white ls-fixed-footer">
      <div class="btns row-center flex" style="height: 100%">
        <el-button size="small" type="primary" @click="handleSave">
          保存
        </el-button>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.shop-tabbar {

  .tabbar-preview,
  .tabbar-setting {
    height: 100%;
  }

  .tabbar-setting {
    width: 400px;
    background: #fff;
  }

  .tabbar-preview {
    .phone {
      position: relative;
      width: 375px;
      height: 667px;
      margin: 50px auto 0;
      background: #f5f5f5;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.06);
    }
  }
}
</style>
