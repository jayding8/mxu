<template>
  <div class="index-container">
    <vab-query-form>
      <vab-query-form-left-panel :span="2">
        <el-button type="primary" @click="handleAdd">删除</el-button>
      </vab-query-form-left-panel>

      <vab-query-form-right-panel :span="22">
        <el-form ref="form" class="box" :inline="true" label-width="76px" :model="queryForm" @submit.native.prevent>
          <el-form-item label="会员ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" style="width: 150px" />
          </el-form-item>
          <el-form-item label="昵称">
            <el-input v-model="queryForm.title" placeholder="请输入昵称" style="width: 150px" />
          </el-form-item>
          <el-form-item label="姓名">
            <el-input v-model="queryForm.title" placeholder="请输入姓名" style="width: 150px" />
          </el-form-item>
          <el-form-item label="原推荐人ID">
            <el-input v-model="queryForm.title" placeholder="原推荐人ID" style="width: 150px" />
          </el-form-item>

          <el-form-item label="申请时间">
            <el-date-picker v-model="value2" end-placeholder="结束日期" range-separator="至" start-placeholder="开始日期"
              type="datetimerange" />
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-right-panel>
    </vab-query-form>
    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="80" />
      <el-table-column label="头像昵称" width="350">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.headimg" style="height: 50px; width: 50px" />
            <span>{{ props.row.nickname }}</span>
            <span>(ID:{{ props.row.mid }})</span>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="新推荐人" width="350">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.pheadimg" style="height: 50px; width: 50px" />
            <span>{{ props.row.pnickname }}</span>
            <span>(ID:{{ props.row.pid }})</span>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="新推荐人" width="350">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.pheadimg" style="height: 50px; width: 50px" />
            <span>{{ props.row.pnickname }}</span>
            <span>(ID:{{ props.row.pid }})</span>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="脱离时间" prop="levelup_time" />
    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { memberUpgrade } from '@/api/member'
export default {
  name: 'Index',
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.memberUpgrade({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    memberUpgrade,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.memberUpgrade({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.memberUpgrade({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.bigTitle {
  color: #333;
  font-weight: 700;
  font-size: 18px;
  position: relative;
  padding-left: 12px;
  margin-bottom: 20px;
}

.bigTitle:before {
  content: "";
  width: 4px;
  height: 80%;
  background-color: #136ffe !important;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
}
</style>
