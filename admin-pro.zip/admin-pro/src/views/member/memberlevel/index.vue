<template>
  <div class="index-container">
    <div class="bigTitle">等级列表</div>
    <vab-query-form-left-panel :span="4">
      <el-button type="primary" @click="handleAdd">添加</el-button>
    </vab-query-form-left-panel>
    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column align="center" type="selection" width="55" />
      <el-table-column fixed align="center" label="id" prop="id" sortable width="80" />

      <el-table-column align="center" label="等级名称" width="200">
        <template slot-scope="props">

          <span v-if="props.row.isdefault == 1">[默认]</span>
          <span>{{ props.row.name }}</span>
        </template>
      </el-table-column>

      <el-table-column label="申请条件" prop="applytj" width="250" />
      <el-table-column label="申请加盟费" prop="apply_paymoney" width="100" />
      <el-table-column label="升级条件(成为该等级的条件)" prop="uptj" />
      <el-table-column label="提成比例" prop="commission" width="200" />

      <el-table-column fixed="right" label="操作">
        <template slot-scope="props">
          <el-button size="small" type="text" @click="handleClick(props.row)">
            编辑
          </el-button>
          <span v-if="props.row.isdefault != 1">
            <el-button size="small" type="text">删除</el-button>
          </span>
        </template>
      </el-table-column>

    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { MemberLevel } from '@/api/member'
export default {
  name: 'Memberlevel',
  data() {
    return {
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.MemberLevel({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info = res
    })
  },
  methods: {
    MemberLevel,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.MemberLevel({
        page: this.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.MemberLevel({
        page: val,
        limit: this.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleClick({ id }) {
      this.$router.push({ name: 'invoice', query: { id: id } })
    },
  },
}
</script>

<style lang="scss" scoped>
.bigTitle {
  color: #333;
  font-weight: 700;
  font-size: 18px;
  position: relative;
  padding-left: 12px;
  margin-bottom: 20px;
}

.bigTitle:before {
  content: "";
  width: 4px;
  height: 80%;
  background-color: #136ffe !important;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
}
</style>
