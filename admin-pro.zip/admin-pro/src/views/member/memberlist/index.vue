<template>
  <div class="index-container">
    <div class="bigTitle">会员列表</div>

    <vab-query-form>
      <vab-query-form-top-panel>
        <el-form ref="form" class="box" :inline="true" :model="queryForm" @submit.native.prevent>
          <el-form-item label="ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" />
          </el-form-item>
          <el-form-item label="关键字">
            <el-input v-model="queryForm.title" placeholder="昵称/姓名/手机号/会员卡号" />
          </el-form-item>
          <el-form-item label="推荐人ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" />
          </el-form-item>
          <el-form-item label="原推荐人ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" />
          </el-form-item>

          <el-form-item label="等级">
            <el-select v-model="value1" filterable placeholder="请选择">
              <el-option v-for="item in options1" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel :span="24">
        <el-button type="primary" @click="handleAdd">添加</el-button>
        <el-button icon="el-icon-delete" type="danger" @click="handleDelete($event)">
          删除
        </el-button>
        <el-button type="primary" @click="handleAdd">导入</el-button>
        <el-button type="primary" @click="handleAdd">导出</el-button>
        <el-button type="primary" @click="handleAdd">批量修改额度</el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">

      <el-table-column align="center" type="selection" width="55" />
      <el-table-column fixed align="center" label="id" prop="id" sortable width="80" />

      <el-table-column label="推荐人" align="center" width="120">
        <template slot-scope="props">


          <div v-if="props.row.parent_origin.nickname == null || props.row.parent_origin.headimg == null">
            <img :src="props.row.parent.headimg" style="height: 44px; width: 44px; border-radius: 4px" />
            <div class="nicktext">{{ props.row.parent.nickname }}</div>
          </div>

          <div v-if="props.row.parent_origin.nickname != null || props.row.parent_origin.headimg != null">
            <div>
              <img :src="props.row.parent.headimg" style="height: 32px; width: 32px; border-radius: 4px" />
              <div class="nicktext"> <span style="color: #1890ff;">[现]</span>{{ props.row.parent.nickname }}</div>
            </div>
            <div>
              <img :src="props.row.parent_origin.headimg" style="height: 32px; width: 32px; border-radius: 4px" />
              <div class="nicktext"> <span style="color: #ff4d4f;">[原]</span> {{ props.row.parent_origin.nickname
              }}sdsdsdsdsdsdsdsds</div>
            </div>
          </div>




        </template>
      </el-table-column>

      <el-table-column label="头像昵称" align="center" width="120">
        <template slot-scope="props">

          <img :src="props.row.headimg" style="height: 44px; width: 44px;border-radius: 8px;" />
          <div class="nicktext">{{ props.row.nickname }}</div>

        </template>
      </el-table-column>
      <el-table-column align="center" label="来源" width="100">
        <template slot-scope="props">

          <span v-if="props.row.platform == 'wx'">小程序</span>
          <span v-if="props.row.platform == 'mp'">公众号</span>
          <span v-if="props.row.platform == 'h5'">手机H5</span>
          <span v-if="props.row.platform == 'alipay'">支付宝小程序</span>
          <span v-if="props.row.platform == 'qq'">QQ小程序</span>
          <span v-if="props.row.platform == 'baidu'">百度小程序</span>
          <span v-if="props.row.platform == 'toutiao'">抖音小程序</span>
          <span v-if="props.row.platform == 'app'">手机APP</span>
          <span v-if="props.row.platform == 'qywx'">企业微信</span>
          <span v-if="props.row.platform == 'cashdesk'">收银台</span>

        </template>
      </el-table-column>
      <el-table-column align="center" label="姓名/电话" prop="tel" width="150" />
      <el-table-column align="center" label="余额" prop="money" sortable width="100" />
      <el-table-column align="center" label="积分" prop="totalscore" sortable width="100" />
      <el-table-column align="center" label="佣金" prop="commission" sortable width="100" />
      <el-table-column align="center" label="等级" prop="levelname" width="100" />

      <el-table-column align="center" label="加入时间" prop="createtime" sortable width="150">
        <template slot-scope="scope">
          {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="关注状态" width="100">
        <template slot-scope="props">

          <span v-if="props.row.subscribe == 1">已关注</span>
          <span v-if="props.row.subscribe != 1" style="color: red">
            未关注
          </span>

        </template>
      </el-table-column>


      <el-table-column align="center" fixed="right" label="操作" width="300">
        <template slot-scope="scope">
          <el-button type="text" @click="handleClick(scope.row)">充值</el-button>
          <span class="line"></span>
          <el-button type="text" @click="handleEdit(scope.row)">订单</el-button>
          <span class="line"></span>
          <el-button type="text" @click="handleDetail(scope.row)">编辑</el-button>
          <span class="line"></span>
          <!-- <template> -->
          <el-dropdown type="primary" @command="handleCommand($event, scope.row)">
            <el-button type="text">
              更多
              <vab-icon icon="arrow-down-s-line" style="color: #2d8cf0" />
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="1">加积分</el-dropdown-item>
              <el-dropdown-item command="2">加佣金</el-dropdown-item>
              <el-dropdown-item command="3">加元宝</el-dropdown-item>
              <el-dropdown-item command="4">加贡献</el-dropdown-item>
              <el-dropdown-item command="5">关系图</el-dropdown-item>
              <el-dropdown-item command="6">加服务费</el-dropdown-item>
              <el-dropdown-item command="7">设置天数</el-dropdown-item>
              <el-dropdown-item command="8">脱离回归</el-dropdown-item>
              <!-- 其他下拉菜单项 -->
            </el-dropdown-menu>
          </el-dropdown>
          <!-- </template> -->
        </template>
      </el-table-column>




    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { member } from '@/api/member'
export default {
  name: 'Index',
  data() {
    return {
      options1: [
        { value: '1', label: '全部' },
        { value: '2', label: '分类一' },
        { value: '3', label: '分类二' },
      ],

      value1: '',
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      height: this.$baseTableHeight(3) - 30,
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.member({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    member,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.member({
        page: this.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.member({
        page: val,
        limit: this.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.nicktext {
  width: 100px;
  overflow: hidden;
  font-size: 12px;
  white-space: nowrap;
  /* 保持文本在同一行 */
  overflow: hidden;
  /* 隐藏超出部分 */
  text-overflow: ellipsis;
  /* 显示省略号 */

}

.bigTitle {
  color: #333;
  font-weight: 700;
  font-size: 18px;
  position: relative;
  padding-left: 12px;
  margin-bottom: 20px;
}

.bigTitle:before {
  content: "";
  width: 4px;
  height: 80%;
  background-color: #136ffe !important;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
}
</style>
