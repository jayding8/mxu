<template>
  <div class="index-container">
    <vab-query-form-left-panel :span="24">
      <span>会员ID：</span>
      <el-input
        placeholder="请输入会员ID"
        style="width: 200px; margin-right: 20px"
      />
      <el-button @click="handleAdd">查看</el-button>
    </vab-query-form-left-panel>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { member } from '@/api/member'
  export default {
    name: 'Index',
    data() {
      return {}
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.member()
    },
    methods: {
      member,
    },
  }
</script>

<style lang="scss" scoped></style>
