<template>
  <div class="index-container">
    <div class="bigTitle">会员关系网</div>
    <div class="operate">
      <span>会员ID</span>
      <el-input v-model="memberId" placeholder="请输入会员ID" class="search"></el-input>
      <el-button type="primary" @click="getUserRelations">查看</el-button>
    </div>
    <!-- ...其他代码保持不变 -->
    <!-- <el-card> -->
    <vab-chart class="trend-echart" :init-options="initOptions" :option="option" theme="vab-echarts-theme" />
    <!-- </el-card> -->
  </div>
</template>

<script>
import VabChart from '@/extra/VabChart';
import { memberCharts } from "@/api/member";

export default {
  name: 'Index',
  components: {
    VabChart,
  },
  data() {
    return {
      memberId: '',
      initOptions: {
        renderer: 'svg',
      },
      option: null, // 将初始化为null，稍后用模拟数据填充
    };
  },
  methods: {
    getUserRelations() {
      memberCharts({ mid: this.memberId })
        .then(res => {
          if (res.code !== 0) {
            this.$message.error("获取列表失败");
            return
          }
          const relations = this.getNodeData(res.data.member);
          console.log(relations);
          // 构建ECharts树形图选项
          const option = {
            tooltip: {
              trigger: 'item',
              triggerOn: 'mousemove'
            },
            series: [
              {
                type: 'tree',
                id: 0,
                data: [relations], // 将模拟数据传递给ECharts
                top: '20%',// 根节点距离容器左侧的距离
                left: '10%',// 根节点距离容器左侧的距离
                bottom: '20%',// 根节点距离容器左侧的距离
                right: '10%',// 根节点距离容器左侧的距离
                symbolSize: 0,
                // symbol: 'circle', // 节点形状
                orient: 'vertical', // 设置树形图为垂直方向
                direction: 'downward', // 设置节点的展开方向为向下
                // symbolOffset: [0, -50], // 设置节点形状的偏移量
                gapWidth: 10, // 设置节点之间的间距
                edgeShape: 'polyline',
                edgeForkPosition: '50%',
                initialTreeDepth: 10,//展示几层默认
                lineStyle: {
                  width: 2
                },
                lineStyle: {
                  color: '#eee', // 线条颜色
                  width: 1, // 线条宽度
                  type: 'solid' // 设置为实线
                },
                label: {//标签显示位置
                  backgroundColor: '#ffffff00',
                  position: 'inside',//显示位置
                  verticalAlign: 'middle',
                  align: 'middle',
                  //offset: [0, 0], // 标签的偏移量，数组形式 [x, y]
                  //show: true, // 总是显示标签
                },
                leaves: {
                  label: {// 叶子节点标签显示位置
                    position: 'inside',
                    verticalAlign: 'middle',
                    align: 'middle'
                  }
                },
                emphasis: {
                  focus: 'descendant'
                },
                expandAndCollapse: true,// 允许展开和折叠
                animationDuration: 550,
                animationDurationUpdate: 750
              },
            ],
          };
          this.option = option;
        }).catch(err => {
          console.log('getUserRelations', err);
        })
    },
    getNodeData(data) {
      const relations = {
        name: data.nickname,
        label: {
          formatter: [
            '{headimg|}',
            // `{id|${data.id}}`,
            // `{nickname|${data.nickname}}`,
            `{name|${data.name}}`,
            // `{level|${data.info ? data.info.level : ""}}`,
          ].join('\n'),

          rich: {
            headimg: {
              backgroundColor: {
                image: data.headimg
              },
              width: 40,
              height: 40,
              padding: [0, 0, 0, 0],
              borderRadius: 20,
            },
            // id: {
            //   height: 15,
            //   lineHeight: 15,
            //   align: 'center',
            // },
            // nickname: {
            //   height: 15,
            //   lineHeight: 15,
            //   align: 'center',
            // },
            name: {
              height: 15,
              lineHeight: 15,
              align: 'center',
            },
            // level: {
            //   fontSize: 18,
            //   fontFamily: 'Microsoft YaHei',
            //   borderColor: '#449933',
            //   borderRadius: 4
            // },
          },
        },
        children: []
      };
      if (data.children && data.children.length) {
        data.children.forEach(v => {
          relations.children.push(this.getNodeData(v));
        });
      }
      return relations;
    },
  },
};
</script>

<style lang="scss" scoped>
.index-container {
  width: 100%;
  padding: 20px;

  .operate {
    display: flex;
    justify-content: flex-start;
    align-items: center;

    .search {
      width: 300px;
      margin: 10px;
    }
  }
}

.trend-echart {
  width: 100%;
  height: 80vh;
}

.bigTitle {
  color: #333;
  font-weight: 700;
  font-size: 18px;
  position: relative;
  padding-left: 12px;
  margin-bottom: 20px;
}

.bigTitle:before {
  content: "";
  width: 4px;
  height: 80%;
  background-color: #136ffe !important;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
}
</style>