<template>
  <div class="index-container">
    <!-- ...其他代码保持不变 -->
    <el-card>
      <vab-chart class="trend-echart" :init-options="initOptions" :option="option" theme="vab-echarts-theme" />
    </el-card>
  </div>
</template>

<script>
import VabChart from '@/extra/VabChart';

export default {
  name: 'Index',
  components: {
    VabChart,
  },
  data() {
    return {
      initOptions: {
        renderer: 'svg',
      },
      option: null, // 将初始化为null，稍后用模拟数据填充
    };
  },
  created() {
    this.option = this.createOption();
  },
  methods: {

    handleAdd() {
      // 可以在这里添加获取真实数据的逻辑
      // 目前我们使用模拟数据
    },
    createOption() {
      // 模拟用户关系数据
      const relations = [
        {
          name: '顶级用户',
          children: [

            {
              name: 'data',
              children: [
                {
                  name: 'converters',
                  children: [
                    { name: 'Converters', value: 721 },
                    { name: 'DelimitedTextConverter', value: 4294 }
                  ]
                },
                {
                  name: 'DataUtil',
                  value: 3322
                }
              ]
            },
            {
              name: 'display',
              children: [
                { name: 'DirtySprite', value: 8833 },
                { name: 'LineSprite', value: 1732 },
                { name: 'RectSprite', value: 3623 }
              ]
            },
            {
              name: 'flex',
              children: [{ name: 'FlareVis', value: 4116 }]
            },
            {
              name: 'query',
              children: [
                { name: 'AggregateExpression', value: 1616 },
                { name: 'And', value: 1027 },
                { name: 'Arithmetic', value: 3891 },
                { name: 'Average', value: 891 },
                { name: 'BinaryExpression', value: 2893 },
                { name: 'Comparison', value: 5103 },
                { name: 'CompositeExpression', value: 3677 },
                { name: 'Count', value: 781 },
                { name: 'DateUtil', value: 4141 },
                { name: 'Distinct', value: 933 },
                { name: 'Expression', value: 5130 },
                { name: 'ExpressionIterator', value: 3617 },
                { name: 'Fn', value: 3240 },
                { name: 'If', value: 2732 },
                { name: 'IsA', value: 2039 },
                { name: 'Literal', value: 1214 },
                { name: 'Match', value: 3748 },
                { name: 'Maximum', value: 843 },
                {
                  name: 'methods',
                  children: [
                    { name: 'add', value: 593 },
                    { name: 'and', value: 330 },
                    { name: 'average', value: 287 },
                    { name: 'count', value: 277 },
                    { name: 'distinct', value: 292 },
                    { name: 'div', value: 595 },
                    { name: 'eq', value: 594 },
                    { name: 'fn', value: 460 },
                    { name: 'gt', value: 603 },
                    { name: 'gte', value: 625 },
                    { name: 'iff', value: 748 },
                    { name: 'isa', value: 461 },
                    { name: 'lt', value: 597 },
                    { name: 'lte', value: 619 },
                    { name: 'max', value: 283 },
                    { name: 'min', value: 283 },
                    { name: 'mod', value: 591 },
                    { name: 'mul', value: 603 },
                    { name: 'neq', value: 599 },
                    { name: 'not', value: 386 },
                    { name: 'or', value: 323 },
                    { name: 'orderby', value: 307 },
                    { name: 'range', value: 772 },
                    { name: 'select', value: 296 },
                    { name: 'stddev', value: 363 },
                    { name: 'sub', value: 600 },
                    { name: 'sum', value: 280 },
                    { name: 'update', value: 307 },
                    {
                      name: 'akak',
                      children: [
                        { name: 'add', value: 593 },
                        { name: 'and', value: 330 },
                        { name: 'average', value: 287 },
                        { name: 'count', value: 277 },
                        { name: 'distinct', value: 292 },
                        { name: 'div', value: 595 },
                        { name: 'eq', value: 594 },
                        { name: 'fn', value: 460 },
                        { name: 'gt', value: 603 },
                        { name: 'gte', value: 625 },
                        { name: 'iff', value: 748 },
                        { name: 'isa', value: 461 },
                        { name: 'lt', value: 597 },
                        { name: 'lte', value: 619 },
                        { name: 'max', value: 283 },
                        { name: 'min', value: 283 },
                        { name: 'mod', value: 591 },
                        { name: 'mul', value: 603 },
                        { name: 'neq', value: 599 },
                        { name: 'not', value: 386 },
                        { name: 'or', value: 323 },
                        { name: 'orderby', value: 307 },
                        { name: 'range', value: 772 },
                        { name: 'select', value: 296 },
                        { name: 'stddev', value: 363 },
                        { name: 'sub', value: 600 },
                        { name: 'sum', value: 280 },
                        { name: 'update', value: 307 },
                        { name: 'variance', value: 335 },
                        { name: 'where', value: 299 },
                        { name: 'xor', value: 354 },
                        { name: 'x_x', value: 264 }
                      ]
                    },
                    { name: 'where', value: 299 },
                    { name: 'xor', value: 354 },
                    { name: 'x_x', value: 264 }
                  ]
                },
                { name: 'Minimum', value: 843 },
                { name: 'Not', value: 1554 },
                { name: 'Or', value: 970 },
                { name: 'Query', value: 13896 },
                { name: 'Range', value: 1594 },
                { name: 'StringUtil', value: 4130 },
                { name: 'Sum', value: 791 },
                { name: 'Variable', value: 1124 },
                { name: 'Variance', value: 1876 },
                { name: 'Xor', value: 1101 }
              ]
            },
            {
              name: 'scale',
              children: [
                { name: 'IScaleMap', value: 2105 },
                { name: 'LinearScale', value: 1316 },
                { name: 'LogScale', value: 3151 },
                { name: 'OrdinalScale', value: 3770 },
                { name: 'QuantileScale', value: 2435 },
                { name: 'QuantitativeScale', value: 4839 },
                { name: 'RootScale', value: 1756 },
                { name: 'Scale', value: 4268 },
                { name: 'ScaleType', value: 1821 },
                { name: 'TimeScale', value: 5833 }
              ]
            }
          ]

        },
      ];

      // 构建ECharts树形图选项
      const option = {
        tooltip: {
          trigger: 'item',
          triggerOn: 'mousemove'
        },
        series: [
          {
            type: 'tree',
            id: 0,
            data: relations, // 将模拟数据传递给ECharts


            top: '10%',// 根节点距离容器左侧的距离
            left: '8%',// 根节点距离容器左侧的距离
            bottom: '22%',// 根节点距离容器左侧的距离
            right: '20%',// 根节点距离容器左侧的距离
            symbolSize: 20,
            // symbol: 'circle', // 节点形状
            // orient: 'vertical', // 设置树形图为垂直方向
            // direction: 'downward', // 设置节点的展开方向为向下
            // symbolOffset: [0, -50], // 设置节点形状的偏移量
            gapWidth: 10, // 设置节点之间的间距
            edgeShape: 'polyline',
            edgeForkPosition: '63%',
            initialTreeDepth: 10,//展示几层默认
            lineStyle: {
              width: 2
            },
            lineStyle: {
              color: '#eee', // 线条颜色
              width: 1, // 线条宽度
              type: 'solid' // 设置为实线
            },
            label: {//标签显示位置
              backgroundColor: '#fff',
              position: 'left',
              verticalAlign: 'middle',
              align: 'right'
            },
            leaves: {
              label: {// 叶子节点标签显示位置
                position: 'right',
                verticalAlign: 'middle',
                align: 'left'
              }
            },
            emphasis: {
              focus: 'descendant'
            },
            expandAndCollapse: true,// 允许展开和折叠
            animationDuration: 550,
            animationDurationUpdate: 750
          },
        ],
      };
      return option;
    },
  },
};
</script>

<style lang="scss" scoped>
.index-container {
  width: 100%;
  padding: 20px;
}

.trend-echart {
  width: 100%;
  height: 1200px;
}
</style>