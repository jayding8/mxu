<template>
  <div class="index-container">
    用户列表
    <vab-theme />

    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="80" />
      <el-table-column label="推荐人" prop="platform" width="100" />
      <el-table-column label="头像昵称" width="150">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.headimg" style="height: 50px; width: 50px" />
            <span>{{ props.row.nickname }}</span>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="来源" prop="platform" width="150" />
      <el-table-column label="姓名/电话" prop="paytype" width="150" />
      <el-table-column label="余额" prop="sales" width="150" />
      <el-table-column label="积分" prop="freight_text" width="150" />
      <el-table-column label="佣金" prop="freight_text" width="150" />
      <el-table-column label="等级" prop="freight_text" width="150" />
      <el-table-column label="关注状态" width="120">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span v-if="props.row.status == 1">已支付</span>
              <span v-if="props.row.status == 3">已完成</span>
              <span v-if="props.row.status == 2">待发货</span>
              <span v-if="props.row.status == 0">待支付</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作">
        <template slot-scope="scope">
          <el-button size="small" type="text" @click="handleClick(scope.row)">
            查看
          </el-button>
          <el-button size="small" type="text">编辑</el-button>
          <el-button size="small" type="text">编辑</el-button>
          <el-button size="small" type="text">编辑</el-button>
          <el-button size="small" type="text">编辑</el-button>
          <el-button size="small" type="text">编辑</el-button>
          <el-button size="small" type="text">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { member } from '@/api/member'
export default {
  name: 'Index',
  data() {
    return {
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.member({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    member,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.member({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.member({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.bigTitle {
  color: #333;
  font-weight: 700;
  font-size: 18px;
  position: relative;
  padding-left: 12px;
  margin-bottom: 20px;
}

.bigTitle:before {
  content: "";
  width: 4px;
  height: 80%;
  background-color: #136ffe !important;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
}
</style>
