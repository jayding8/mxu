<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="500px" @close="close">
    <el-form ref="form" label-width="80px" :model="form">
      <el-form-item label="详情">
        <div>{{ form.order }}</div>
      </el-form-item>
      <el-form-item label="审核备注">
        <el-input v-model="reason" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button type="primary" @click="agree">同意并退款</el-button>
      <el-button @click="disagree">驳回退款申请</el-button>
    </template>
  </el-dialog>
</template>

<script>
import { getRefundOrderDetail } from '@/api/shop'

export default {
  name: 'TableEdit',
  data() {
    return {
      form: {},
      title: '',
      reason: '',
      dialogFormVisible: false,
    }
  },
  created() { },
  methods: {
    showEdit(row) {
      this.title = '退款审核'
      getRefundOrderDetail({ orderid: row.id }).then((res) => {
        this.form = res
      })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    agree() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await doEdit(this.form)
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
    disagree() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await doEdit(this.form)
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
  },
}
</script>
