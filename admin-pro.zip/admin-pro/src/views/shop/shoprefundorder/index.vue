<template>
  <div class="index-container">
    <el-alert
      :closable="false"
      show-icon
      title="商品库商品变更商品基础信息或将单规格商品调整成多规格商品将会自动同步至门店；如需修改门店商品价格或库存请在商品模板库调整"
      type="success"
    />

    <el-tabs v-model="activeName" @tab-click="handleTab">
      <el-tab-pane label="全部" name="first">1111</el-tab-pane>
      <el-tab-pane label="待审核" name="second">2222</el-tab-pane>
      <el-tab-pane label="审核通过" name="Third">3333</el-tab-pane>
      <el-tab-pane label="驳回" name="Fourth">2222</el-tab-pane>
      <el-tab-pane label="取消" name="Fifth">3333</el-tab-pane>
    </el-tabs>

    <vab-query-form-top-panel>
      <el-form
        ref="form"
        class="box"
        :inline="true"
        label-width="66px"
        :model="queryForm"
        @submit.native.prevent
      >
        <el-form-item label="退款单号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>
        <el-form-item label="退货单号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>

        <el-form-item label="申请时间">
          <el-date-picker
            v-model="value2"
            end-placeholder="结束日期"
            range-separator="至"
            start-placeholder="开始日期"
            type="datetimerange"
          />
        </el-form-item>
        <el-form-item v-show="!fold" label="订单号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>
        <el-form-item v-show="!fold" label="手机号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>
        <el-form-item v-show="!fold" label="状态">
          <el-select v-model="value1" filterable placeholder="请选择状态">
            <el-option
              v-for="item in options3"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button
            icon="el-icon-search"
            native-type="submit"
            type="primary"
            @click="handleQuery"
          >
            查询
          </el-button>
          <el-button type="text" @click="handleFold">
            <span v-if="fold">展开</span>
            <span v-else>合并</span>
            <vab-icon
              class="vab-dropdown"
              :class="{ 'vab-dropdown-active': fold }"
              icon="arrow-up-s-line"
            />
          </el-button>
        </el-form-item>
      </el-form>
    </vab-query-form-top-panel>

    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="80" />
      <el-table-column label="商品信息" width="250">
        <template slot-scope="props">
          <el-form>
            <div v-html="props.row.goodsdata"></div>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="退款单号/申请时间" width="200">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <div>{{ props.row.refund_ordernum }}</div>
              <div>{{ props.row.createtime }}</div>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="原订单号" prop="ordernum" width="200" />
      <el-table-column label="退款金额" prop="refund_money" width="200" />
      <el-table-column label="退货快递信息" prop="return_address" width="200" />
      <el-table-column label="状态" width="120">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span v-if="props.row.status == 1">已支付</span>
              <span v-if="props.row.status == 3">已完成</span>
              <span v-if="props.row.status == 2">待发货</span>
              <span v-if="props.row.status == 0">退款待审核</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column fixed="right" label="操作">
        <template slot-scope="scope">
          <el-button size="small" type="text" @click="handleClick(scope.row)">
            详情
          </el-button>
          <el-button size="small" type="text">退款</el-button>
          <el-button size="small" type="text">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { ShopRefundOrder } from '@/api/shop'
export default {
  name: 'ShopRefundOrder',
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      fold: false,
      height: this.$baseTableHeight(3) - 30,

      options3: [
        { value: '1', label: '全部' },
        { value: '2', label: '取消' },
        { value: '3', label: '待审核' },
        { value: '4', label: '已退款' },
        { value: '5', label: '退款驳回' },
        { value: '6', label: '审核通过，待退货' },
        { value: '7', label: '审核通过，已寄回' },
      ],

      value1: '',
      activeName: 'first',

      layout: 'total, sizes, prev, pager, next, jumper',

      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.ShopRefundOrder({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    ShopRefundOrder,
    handleTab(tab, event) {
      console.log(tab, event)
    },
    handleFold() {
      this.fold = !this.fold
      this.handleHeight()
    },
    handleHeight() {
      if (this.fold) this.height = this.$baseTableHeight(2) - 47
      else this.height = this.$baseTableHeight(3) - 30
    },

    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.ShopRefundOrder({
        page: this.page.current,
        limit: val,
      }).then((res) => {
        this.info = res
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.ShopRefundOrder({
        page: val,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
  width: 100%;
  margin-bottom: 20px;
}
</style>
