<template>
  <div class="index-container">







    <!-- <vab-query-form-top-panel>
      <el-form ref="form" class="box" :inline="true" label-width="66px" :model="queryForm" @submit.native.prevent>
        <el-form-item label="退款单号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>
        <el-form-item label="退货单号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>

        <el-form-item label="申请时间">
          <el-date-picker v-model="value2" end-placeholder="结束日期" range-separator="至" start-placeholder="开始日期"
            type="datetimerange" />
        </el-form-item>
        <el-form-item v-show="!fold" label="订单号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>
        <el-form-item v-show="!fold" label="手机号">
          <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
        </el-form-item>
        <el-form-item v-show="!fold" label="状态">
          <el-select v-model="value1" filterable placeholder="请选择状态">
            <el-option v-for="item in options3" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
            查询
          </el-button>
          <el-button type="text" @click="handleFold">
            <span v-if="fold">展开</span>
            <span v-else>合并</span>
            <vab-icon class="vab-dropdown" :class="{ 'vab-dropdown-active': fold }" icon="arrow-up-s-line" />
          </el-button>
        </el-form-item>
      </el-form>
    </vab-query-form-top-panel> -->














    <el-tabs v-model="activeName" @tab-click="handleTab">
      <el-tab-pane label="全部" name="all"></el-tab-pane>
      <el-tab-pane label="待审核" name="1"></el-tab-pane>
      <el-tab-pane label="审核通过" name="2"></el-tab-pane>
      <el-tab-pane label="驳回" name="3"></el-tab-pane>
      <el-tab-pane label="取消" name="0"></el-tab-pane>
    </el-tabs>

    <el-table border :data="info.data" style="width: 100%">
      <el-table-column align="center" fixed label="id" prop="id" width="55" />
      <el-table-column align="center" label="商品图" width="80">
        <template slot-scope="props">
          <el-image fit="fill" v-for=" (item, index) in props.row.goodsdata" :key="index" :lazy="true"
            :src="item.pic" />
        </template>
      </el-table-column>
      <el-table-column label="商品信息" min-width="300">
        <template slot-scope="props">
          <div v-for=" (item, index) in props.row.goodsdata" :key="index">
            <el-tooltip :content="item.name" :delay="600" effect="dark" max-width="300" :transfer="true">
              <span class="line2">
                {{ item.name }}
              </span>
            </el-tooltip>
            {{ item.ggname }}
            {{ item.sell_price }}x{{ item.refund_num }}
          </div>
        </template>
      </el-table-column>
      <el-table-column align="center" label="退款单号/申请时间" width="200">
        <template slot-scope="props">

          <div>{{ props.row.refund_ordernum }}</div>
          <div>{{ new Date(props.row.createtime * 1000).toLocaleString() }}</div>


        </template>
      </el-table-column>
      <el-table-column align="center" label="原订单号" prop="ordernum" width="200" />
      <el-table-column align="center" label="退款金额" prop="refund_money" width="100" />
      <el-table-column align="center" label="退货快递信息" prop="return_address" width="200" />
      <el-table-column align="center" label="状态" width="120">
        <template slot-scope="props">

          <span v-if="props.row.status == 1">已支付</span>
          <span v-if="props.row.status == 3">已完成</span>
          <span v-if="props.row.status == 2">待发货</span>
          <span v-if="props.row.status == 0">退款待审核</span>

        </template>
      </el-table-column>


      <el-table-column align="center" fixed="right" label="操作" width="160">
        <template slot-scope="scope">

          <el-button type="text" @click="handleClick(scope.row)">详情</el-button>
          <span class="line"></span>
          <el-button type="text" @click="handleRefund(scope.row)">退款审核</el-button>
          <span class="line"></span>
          <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>

        </template>
      </el-table-column>

    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit" :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>

    <table-edit ref="detail" @fetch-data="refresh" />
    <table-refund ref="refund" @fetch-data="refresh" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { ShopRefundOrder, ShopRefundOrderStatus } from '@/api/shop'
import TableEdit from './components/TableEdit'
import TableRefund from './components/TableRefund.vue'
export default {
  name: 'ShopRefundOrder',
  components: {
    TableEdit,
    TableRefund,
  },
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      fold: false,
      height: this.$baseTableHeight(3) - 30,

      options3: [
        { value: '1', label: '全部' },
        { value: '2', label: '取消' },
        { value: '3', label: '待审核' },
        { value: '4', label: '已退款' },
        { value: '5', label: '退款驳回' },
        { value: '6', label: '审核通过，待退货' },
        { value: '7', label: '审核通过，已寄回' },
      ],

      value1: '',
      activeName: 'all',

      layout: 'total, sizes, prev, pager, next, jumper',

      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    ShopRefundOrder({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    refresh() {
      ShopRefundOrder({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    handleTab(tab) {
      console.log(tab.name)
      if (tab.name == "all") {
        ShopRefundOrder({
          page: this.page.current,
          limit: this.page.limit,
        }).then((res) => {
          this.info.data = res.data
          this.info.count = res.count
        })
      } else {
        ShopRefundOrderStatus({
          page: this.page.current,
          limit: this.page.limit,
          status: tab.name,
        }).then((res) => {
          this.info.data = res.data
          this.info.count = res.count
        })
      }
    },

    handleClick(data) {
      this.$refs['detail'].showEdit(data)
    },

    handleRefund(data) {
      this.$refs['refund'].showEdit(data)
    },

    handleFold() {
      this.fold = !this.fold
      this.handleHeight()
    },
    handleDelete(row) {
      console.log(row)
      if (row.id) {
        this.$baseConfirm('你确定要删除吗', null, async () => {
          const { msg } = await productDelete({ ids: row.id })
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          await this.ShopRefundOrder({
            page: this.page.current,
            limit: this.page.limit,
          }).then((res) => {
            this.info.data = res.data
            this.info.count = res.count
          })
        })
      }
    },
    handleHeight() {
      if (this.fold) this.height = this.$baseTableHeight(2) - 47
      else this.height = this.$baseTableHeight(3) - 30
    },

    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.ShopRefundOrder({
        page: this.page.current,
        limit: val,
      }).then((res) => {
        this.info = res
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.ShopRefundOrder({
        page: val,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
  width: 100%;
  margin-bottom: 20px;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.line2 {
  display: -webkit-box;

  overflow: hidden;
  -o-text-overflow: ellipsis;
  text-overflow: ellipsis;
  word-break: break-all;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
}
</style>
