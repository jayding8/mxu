<template>
  <div class="index-container">服务编辑</div>
</template>

<script>
  import { mapGetters } from 'vuex'
  export default {
    name: 'Edit',
    data() {
      return {}
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    // created() {
    //   this.getUserInfo()
    // },
    // methods: {
    //   ...mapActions({
    //     getUserInfo: 'user/getUserInfo',
    //   }),
    // },
  }
</script>

<style lang="scss" scoped></style>
