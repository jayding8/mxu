<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 16, offset: 0 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form>
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>基础设置</span>
              </div>
            </template>
            <el-form-item label="自动收货天数" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <span style="margin-left: 20px">天</span>
              <span style="margin-left: 20px; color: #969696">
                发货后多少天用户未确认收货自动完成收货
              </span>
            </el-form-item>
            <el-form-item label="自动关闭订单" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <span style="margin-left: 20px">分钟</span>
              <span style="margin-left: 20px; color: #969696">
                下单后多久不支付自动关闭订单，释放占用的库存
              </span>
            </el-form-item>
            <el-form-item label="货到付款" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后支付时可以选择货到付款
              </span>
            </el-form-item>
            <el-form-item label="未登录查看价格" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后未登录可以查看价格
              </span>
            </el-form-item>
            <el-form-item label="未审核查看价格" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后未审核可以查看价格
              </span>
            </el-form-item>
            <el-form-item label="购物车推荐" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后购物车显示为您推荐
              </span>
            </el-form-item>
            <el-form-item label="库存预警值" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <span style="margin-left: 20px; color: #969696">
                库存低于此数量发送通知
              </span>
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>退货设置</span>
              </div>
            </template>
            <el-form-item label="退款退货" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后用户无法申请退款退货
              </span>
            </el-form-item>
            <el-form-item label="退款图片" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                选择必填后退款时，无需退货选项图片必须上传，退货退款选项图片选填
              </span>
            </el-form-item>
            <el-form-item label="联系人" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
            </el-form-item>
            <el-form-item label="联系电话" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
            </el-form-item>
            <el-form-item label="退货地址" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <el-input v-model="form.name" style="width: 200px" />
              <el-input v-model="form.name" style="width: 200px" />
            </el-form-item>
            <el-form-item label="详细地址" prop="name">
              <el-input v-model="form.name" style="width: 400px" />
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>奖金池</span>
              </div>
            </template>
            <el-form-item label="奖金池推荐人数" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <span style="margin-left: 20px">人</span>
              <span style="margin-left: 20px; color: #969696">
                推荐n人，获得一个贡献值
              </span>
            </el-form-item>
            <el-form-item label="奖金池持续释放" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <span style="margin-left: 20px">天</span>
              <span style="margin-left: 20px; color: #969696">持续n天释放</span>
            </el-form-item>
            <el-form-item label="奖金池不释放" prop="type">
              <el-checkbox-group v-model="form.type">
                <el-checkbox label="所有人" name="type" />
                <el-checkbox label="普通会员" name="type" />
                <el-checkbox label="VIP" name="type" />
                <el-checkbox label="白金" name="type" />
              </el-checkbox-group>
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>优惠券</span>
              </div>
            </template>
            <el-form-item label="退款时退回已使用优惠券" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>商品评价</span>
              </div>
            </template>
            <el-form-item label="商品评价" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
            </el-form-item>
            <el-form-item label="评价审核" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="开启" />
                <el-radio label="关闭" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后用户的评价将直接显示,不需要后台审核
              </span>
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>详情页显示</span>
              </div>
            </template>
            <el-form-item label="显示店铺信息" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="显示" />
                <el-radio label="不显示" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后商品详情页显示店铺信息
              </span>
            </el-form-item>
            <el-form-item label="显示佣金" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="显示" />
                <el-radio label="不显示" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后商品详情页显示分销佣金
              </span>
            </el-form-item>
            <el-form-item label="显示销量" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="显示" />
                <el-radio label="不显示" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后商品列表及详情不显示销量
              </span>
            </el-form-item>
            <el-form-item label="显示库存" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="显示" />
                <el-radio label="不显示" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后商品列表及详情不显示库存
              </span>
            </el-form-item>
            <el-form-item label="显示升级优惠" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="显示" />
                <el-radio label="不显示" />
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                商品详情页是否显示升级到下一级可节省多少元
              </span>
            </el-form-item>
            <el-form-item label="商品详情标题" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio label="默认" />
                <el-radio label="文本" />
                <el-radio label="图片" />
                <el-radio label="不显示" />
              </el-radio-group>
            </el-form-item>
          </el-card>

          <el-form-item>
            <el-button type="primary" @click="submitForm('form')">
              立即创建
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { shopSet } from '@/api/shop'
  export default {
    name: 'Shopset',
    data() {
      const generateData = () => {
        const data = []
        const cities = ['上海', '北京', '广州']
        const pinyin = ['shanghai', 'beijing', 'guangzhou']
        cities.forEach((city, index) => {
          data.push({
            label: city,
            key: index,
            pinyin: pinyin[index],
          })
        })
        return data
      }
      return {
        labelPosition: 'right',
        form: {
          name: '',
          region: '',
          date: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          description: '',
          rate: 0,
          area: [],
          transfer: [],
        },
        areaOptions: [],
        rules: {
          name: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            {
              min: 3,
              max: 5,
              message: '长度在 3 到 5 个字符',
              trigger: 'blur',
            },
          ],
          region: [
            { required: true, message: '请选择活动区域', trigger: 'change' },
          ],
          date: [
            {
              type: 'date',
              required: true,
              message: '请选择日期',
              trigger: 'change',
            },
          ],
          type: [
            {
              type: 'array',
              required: true,
              message: '请至少选择一个活动性质',
              trigger: 'change',
            },
          ],
          resource: [
            { required: true, message: '请选择活动资源', trigger: 'change' },
          ],
          description: [
            { required: true, message: '请填写活动形式', trigger: 'blur' },
          ],
        },
        data: generateData(),
        filterMethod(query, item) {
          return item.pinyin.indexOf(query) > -1
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.shopSet()
    },
    methods: {
      shopSet,
    },
  }
</script>

<style lang="scss" scoped></style>
