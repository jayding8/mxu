<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 24, offset: 0 }"
        :md="{ span: 24, offset: 2 }"
        :sm="{ span: 24, offset: 2 }"
        :xl="{ span: 24, offset: 6 }"
        :xs="24"
      >
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="200px"
          :model="form"
          :rules="rules"
        >
          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>基础设置</span>
              </div>
            </template>
            <el-form-item label="可确认收货时间" prop="ordercollect_time">
              <el-input
                v-model="form.info.ordercollect_time"
                style="width: 200px"
              />
              <span style="margin-left: 20px">天</span>
              <span style="margin-left: 20px; color: #969696">
                多少天后，用户可以点击确认收货
              </span>
            </el-form-item>
            <el-form-item label="自动收货天数" prop="autoshdays">
              <el-input v-model="form.info.autoshdays" style="width: 200px" />
              <span style="margin-left: 20px">天</span>
              <span style="margin-left: 20px; color: #969696">
                发货后多少天用户未确认收货自动完成收货
              </span>
            </el-form-item>
            <el-form-item label="自动关闭订单" prop="autoclose">
              <el-input v-model="form.info.autoclose" style="width: 200px" />
              <span style="margin-left: 20px">分钟</span>
              <span style="margin-left: 20px; color: #969696">
                下单后多久不支付自动关闭订单，释放占用的库存
              </span>
            </el-form-item>
            <el-form-item label="货到付款" prop="cancod">
              <el-radio-group v-model="form.info.cancod">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后支付时可以选择货到付款
              </span>
            </el-form-item>
            <el-form-item label="未登录查看价格" prop="is_show_price_unlogin">
              <el-radio-group v-model="form.info.is_show_price_unlogin">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后未登录可以查看价格
              </span>
            </el-form-item>
            <el-form-item label="未审核查看价格" prop="is_show_price_uncheck">
              <el-radio-group v-model="form.info.is_show_price_uncheck">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后未审核可以查看价格
              </span>
            </el-form-item>
            <el-form-item label="购物车推荐" prop="gwctj">
              <el-radio-group v-model="form.info.gwctj">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后购物车显示为您推荐
              </span>
            </el-form-item>
            <el-form-item label="库存预警值" prop="shop_stock_warning_num">
              <el-input
                v-model="form.info.shop_stock_warning_num"
                style="width: 200px"
              />
              <span style="margin-left: 20px; color: #969696">
                库存低于此数量发送通知
              </span>
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>退货设置</span>
              </div>
            </template>
            <el-form-item label="退款退货" prop="canrefund">
              <el-radio-group v-model="form.info.canrefund">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后用户无法申请退款退货
              </span>
            </el-form-item>
            <el-form-item label="退款图片" prop="refundpic">
              <el-radio-group v-model="form.info.refundpic">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                选择必填后退款时，无需退货选项图片必须上传，退货退款选项图片选填
              </span>
            </el-form-item>
            <el-form-item label="联系人" prop="return_name">
              <el-input v-model="form.info.return_name" style="width: 200px" />
            </el-form-item>
            <el-form-item label="联系电话" prop="return_tel">
              <el-input v-model="form.info.return_tel" style="width: 200px" />
            </el-form-item>
            <el-form-item label="退货地址" prop="return_province">
              <el-input
                v-model="form.info.return_province"
                style="width: 200px"
              />
              <el-input v-model="form.info.return_city" style="width: 200px" />
              <el-input v-model="form.info.return_area" style="width: 200px" />
            </el-form-item>
            <el-form-item label="详细地址" prop="return_address">
              <el-input
                v-model="form.info.return_address"
                style="width: 400px"
              />
            </el-form-item>
          </el-card>

          <!-- <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>奖金池</span>
              </div>
            </template>
            <el-form-item label="奖金池推荐人数" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <span style="margin-left: 20px">人</span>
              <span style="margin-left: 20px; color: #969696">
                推荐n人，获得一个贡献值
              </span>
            </el-form-item>
            <el-form-item label="奖金池持续释放" prop="name">
              <el-input v-model="form.name" style="width: 200px" />
              <span style="margin-left: 20px">天</span>
              <span style="margin-left: 20px; color: #969696">持续n天释放</span>
            </el-form-item>
            <el-form-item label="奖金池不释放" prop="type">
              <el-checkbox-group v-model="form.type">
                <el-checkbox label="所有人" name="type" />
                <el-checkbox label="普通会员" name="type" />
                <el-checkbox label="VIP" name="type" />
                <el-checkbox label="白金" name="type" />
              </el-checkbox-group>
            </el-form-item>
            <el-form-item label="奖金池不释放" prop="type">
              <el-input v-model="form.info.commission2moneypercent1" placeholder="" style="width: 200px">
                <template slot="prepend">数量</template>
              </el-input>
              <span style="color: #999; margin-left: 10px; margin-right: 20px">
                %
              </span>
            </el-form-item>

            <el-form-item label="可拿分红会员数量" prop="type">
              <el-input v-model="form.info.commission2moneypercent1" placeholder="" style="width: 200px">
                <template slot="prepend">数量</template>
              </el-input>
              <span style="color: #999; margin-left: 10px; margin-right: 20px">
                %
              </span>
            </el-form-item>
          </el-card> -->

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>优惠券</span>
              </div>
            </template>
            <el-form-item label="退款时退回已使用优惠券" prop="return_coupon">
              <el-radio-group v-model="form.info.return_coupon">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>商品评价</span>
              </div>
            </template>
            <el-form-item label="商品评价" prop="comment">
              <el-radio-group v-model="form.info.comment">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="评价审核" prop="comment_check">
              <el-radio-group v-model="form.info.comment_check">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后用户的评价将直接显示,不需要后台审核
              </span>
            </el-form-item>
          </el-card>

          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>详情页显示</span>
              </div>
            </template>
            <el-form-item label="显示店铺信息" prop="showjd">
              <el-radio-group v-model="form.info.showjd">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后商品详情页显示店铺信息
              </span>
            </el-form-item>
            <el-form-item label="显示佣金" prop="showcommission">
              <el-radio-group v-model="form.info.showcommission">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                开启后商品详情页显示分销佣金
              </span>
            </el-form-item>
            <el-form-item label="显示销量" prop="hide_sales">
              <el-radio-group v-model="form.info.hide_sales">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后商品列表及详情不显示销量
              </span>
            </el-form-item>
            <el-form-item label="显示库存" prop="hide_stock">
              <el-radio-group v-model="form.info.hide_stock">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                关闭后商品列表及详情不显示库存
              </span>
            </el-form-item>
            <el-form-item label="显示升级优惠" prop="show_lvupsavemoney">
              <el-radio-group v-model="form.info.show_lvupsavemoney">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                商品详情页是否显示升级到下一级可节省多少元
              </span>
            </el-form-item>
            <!-- <el-form-item label="商品详情标题" prop="resource">
              <el-radio-group v-model="form.resource">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item> -->
          </el-card>
        </el-form>
      </el-col>
    </el-row>
    <div class="el-footer">
      <el-button type="primary" @click="submitForm(form)">保存</el-button>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { shopSet, shopSetSave } from '@/api/shop'
  export default {
    name: 'Shopset',
    data() {
      return {
        labelPosition: 'right',
        form: {},
        areaOptions: [],
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.shopSet().then((res) => {
        this.form = res.data
      })
    },
    methods: {
      shopSet,
      submitForm(form) {
        shopSetSave(form).then((res) => {
          this.$message({
            type: 'success',
            message: res.msg,
          })
        })
      },
    },
  }
</script>

<style lang="scss" scoped>
  .index-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }
</style>
