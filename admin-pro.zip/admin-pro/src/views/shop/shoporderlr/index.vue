<template>
  <div class="comprehensive-form-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 12, offset: 6 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="100px"
          :model="form"
          :rules="rules"
        >
          <el-form-item label="会员ID" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item label="选择商品" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item label="已选商品" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item label="备注" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item label="收货人姓名" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item label="收货人电话" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item label="活动区域" prop="region">
            <el-select v-model="form.region" placeholder="请选择省">
              <el-option label="区域一" value="shanghai" />
              <el-option label="区域二" value="beijing" />
            </el-select>
            <el-select v-model="form.region" placeholder="请选择市">
              <el-option label="区域一" value="shanghai" />
              <el-option label="区域二" value="beijing" />
            </el-select>
            <el-select v-model="form.region" placeholder="请选择区县">
              <el-option label="区域一" value="shanghai" />
              <el-option label="区域二" value="beijing" />
            </el-select>
          </el-form-item>
          <el-form-item label="拉取地址" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>

          <el-form-item label="识别地址" prop="description">
            <el-input v-model="form.description" type="textarea" />
          </el-form-item>
          <el-form-item label="配送方式" prop="resource">
            <el-radio-group v-model="form.resource">
              <el-radio label="普通快递" />
              <el-radio label="到店自提" />
            </el-radio-group>
          </el-form-item>
          <el-form-item label="配送费" prop="description">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item label="支付方式" prop="resource">
            <el-radio-group v-model="form.resource">
              <el-radio label="后台付款" />
              <el-radio label="会员付款" />
            </el-radio-group>
          </el-form-item>
          <el-form-item label="付款方式">
            <el-cascader
              v-model="form.area"
              clearable
              filterable
              :options="areaOptions"
              :props="{ label: 'name', value: 'code' }"
            />
          </el-form-item>
          <el-form-item label="付款时间" prop="date">
            <el-date-picker
              v-model="form.date"
              placeholder="选择日期时间"
              type="datetime"
            />
          </el-form-item>
          <el-form-item label="总金额" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('form')">
              立即创建
            </el-button>
            <el-button @click="resetForm('form')">重置</el-button>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { shopOrderlr } from '@/api/shop'

  export default {
    name: 'ShopOrderlr',
    data() {
      const generateData = () => {
        const data = []
        const cities = ['上海', '北京', '广州']
        const pinyin = ['shanghai', 'beijing', 'guangzhou']
        cities.forEach((city, index) => {
          data.push({
            label: city,
            key: index,
            pinyin: pinyin[index],
          })
        })
        return data
      }
      return {
        labelPosition: 'right',
        form: {
          name: '',
          region: '',
          date: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          description: '',
          rate: 0,
          area: [],
          transfer: [],
        },
        areaOptions: [],
        rules: {
          name: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            {
              min: 3,
              max: 5,
              message: '长度在 3 到 5 个字符',
              trigger: 'blur',
            },
          ],
          region: [
            { required: true, message: '请选择活动区域', trigger: 'change' },
          ],
          date: [
            {
              type: 'date',
              required: true,
              message: '请选择日期',
              trigger: 'change',
            },
          ],
          type: [
            {
              type: 'array',
              required: true,
              message: '请至少选择一个活动性质',
              trigger: 'change',
            },
          ],
          resource: [
            { required: true, message: '请选择活动资源', trigger: 'change' },
          ],
          description: [
            { required: true, message: '请填写活动形式', trigger: 'blur' },
          ],
        },
        data: generateData(),
      }
    },
    created() {
      this.shopOrderlr()
    },
    methods: {
      //获取行政区划
      shopOrderlr,
    },
  }
</script>

<style lang="scss" scoped>
  .comprehensive-form-container {
    .demo-form {
      margin-top: 10px;
    }

    :deep() {
      .el-form-item__content {
        .el-rate {
          display: inline-block;
          font-size: 0;
          line-height: 1;
          vertical-align: middle;
        }

        .el-transfer__buttons {
          padding: 10px 10px 0 10px;
        }
      }
    }
  }
</style>
