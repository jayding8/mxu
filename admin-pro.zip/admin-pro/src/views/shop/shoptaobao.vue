<template>
  <div class="personal-center-container">
    <div class="bigTitle">订单列表</div>
    <el-tabs v-model="activeName">
      <el-tab-pane label="淘宝" name="first">
        <el-row :gutter="20">
          <el-col :lg="{ span: 16, offset: 0 }" :md="{ span: 20, offset: 2 }" :sm="{ span: 20, offset: 2 }"
            :xl="{ span: 12, offset: 6 }" :xs="24">
            <el-alert show-icon title="填写商品链接，点击提交即可自动添加淘宝商品到商品列表；由于采集数据的不确定性，并非所有商品都能获取到，如获取失败请手动添加，如数据存在偏差请手动修改"
              type="info" />
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="150px" :model="form"
              :rules="rules">
              <el-form-item label="99APIKEY" prop="name">
                <el-input v-model="form.name" style="width: 500px" />
                <div>
                  99api接口密钥，没有注册请先注册
                  <a href="https://www.99api.com/register" target="_blank">
                    前往注册
                  </a>
                  ，注册完成后需要在我的数据接口中点击添加接口添加[淘宝API][天猫API][京东商城API][1688阿里巴巴API]
                </div>
              </el-form-item>
              <el-form-item label="商品ID或商品链接" prop="url">
                <el-input v-model="form.url" style="width: 500px" />
                <div>商品ID在商品链接中查找</div>
              </el-form-item>
              <el-form-item>
                <el-button native-type="submit" size="medium" style="width: 100px" type="primary" @click="handleQuery">
                  提交
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="天猫" name="second">2222</el-tab-pane>
      <el-tab-pane label="京东" name="Third">3333</el-tab-pane>
      <el-tab-pane label="阿里巴巴" name="Fourth">2222</el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { shopPoster } from '@/api/shop'

export default {
  name: 'ShopPoster',
  data() {
    return {
      activeName: 'first',
      form: {
        name: '',
        url: '',
      },
    }
  },
  computed: {
    ...mapGetters({}),
  },
  created() {
    this.shopPoster()
  },
  methods: {
    shopPoster,
  },
}
</script>

<style lang="scss" scoped>
$base: '.personal-center';

#{$base}-container {
  padding: 0 !important;
  background: $base-color-background !important;

  #{$base}-user-info {
    padding: $base-padding;
    text-align: center;

    :deep() {
      .el-avatar {
        img {
          cursor: pointer;
        }
      }
    }

    &-full-name {
      margin-top: 15px;
      font-size: 24px;
      font-weight: 500;
      color: #262626;
    }

    &-description {
      margin-top: 8px;
    }

    &-follow {
      margin-top: 15px;
    }

    &-list {
      margin-top: 18px;
      line-height: 30px;
      text-align: left;
      list-style: none;

      h5 {
        margin: -20px 0 5px 0;
      }

      :deep() {
        .el-tag {
          margin-right: 10px !important;
        }

        .el-tag+.el-tag {
          margin-left: 0;
        }
      }
    }
  }

  #{$base}-item {
    display: flex;

    i {
      font-size: 40px;
    }

    &-content {
      box-sizing: border-box;
      flex: 1;
      margin-left: $base-margin;

      &-second {
        margin-top: 8px;
      }
    }
  }
}
</style>
