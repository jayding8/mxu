<template>
  <div>
    <div class="poster">
      <div class="poster-preview">
        <div class="dsn-phone-top"></div>
        <div class="dsn-phone-main">
          <div class="dsn-mod dsn-topbar dsn-mod-nohover">
            <div style="float:left;width:30%">&nbsp;<i class="fa fa-signal"></i> wechat <i class="fa fa-wifi"></i>
            </div>
            <div style="float:left;text-align:center;width:40%">12:00</div>
            <div style="float:left;text-align:right;width:30%">100% <i class="fa fa-battery-full"></i>&nbsp;
            </div>
          </div>
          <div class="editor-content">
            <div class="poster-item bg-img"
              :style="{ background: `url(${bgPicUrl}) no-repeat 100%`, backgroundSize: '100%' }"></div>
            <template v-if="posterArr.length" v-for="(poster, idx) in posterArr">
              <div class="poster-item head-img"
                :style="{ width: poster.width, height: poster.height, top: poster.top, left: poster.left, borderRadius: poster.radius / 2 + '%' }"
                v-if="poster.type == 'head'" @click="updateAttr(idx)" @dblclick="deleteAttr(idx)">
              </div>
              <div class="poster-item"
                :style="{ width: poster.width, height: poster.height, top: poster.top, left: poster.left, color: poster.color, fontSize: poster.size }"
                v-else-if="poster.type == 'text'" @click="updateAttr(idx)" @dblclick="deleteAttr(idx)">
                {{ poster.content }}
              </div>
              <div class="poster-item poster-img"
                :style="{ width: poster.width, height: poster.height, top: poster.top, left: poster.left }"
                v-else-if="poster.type == 'img'" @click="updateAttr(idx)" @dblclick="deleteAttr(idx)">
              </div>
              <div class="poster-item"
                :style="{ width: poster.width, height: poster.height, top: poster.top, left: poster.left, backgroundColor: poster.shadow }"
                v-else-if="poster.type == 'shadow'" @click="updateAttr(idx)" @dblclick="deleteAttr(idx)">
                {{ poster.content }}
              </div>
              <div class="poster-item"
                :style="{ width: poster.width, height: poster.height, top: poster.top, left: poster.left, color: poster.color, fontSize: poster.size }"
                v-else-if="poster.type == 'textarea'" @click="updateAttr(idx)" @dblclick="deleteAttr(idx)">
                {{ poster.content }}
              </div>
              <div class="poster-item poster-qrmp"
                :style="{ width: poster.width, height: poster.height, top: poster.top, left: poster.left }"
                v-else-if="poster.type == 'qrmp'" @click="updateAttr(idx)" @dblclick="deleteAttr(idx)">
              </div>
              <div class="poster-item poster-qrwx"
                :style="{ width: poster.width, height: poster.height, top: poster.top, left: poster.left }"
                v-else-if="poster.type == 'qrwx'" @click="updateAttr(idx)" @dblclick="deleteAttr(idx)">
              </div>
            </template>

          </div>
        </div>
        <div class="dsn-phone-bottom"></div>
      </div>
      <div class="poster-attr">
        <div class="line">
          <div class="label">背景图片</div>
          <el-button plain @click="uploadImg">选择或上传</el-button>
        </div>
        <div class="line">
          <div class="label">海报元素</div>
          <el-button plain @click="addItem('head')">头像</el-button>
          <el-button plain @click="addItem('text')">文字</el-button>
          <el-button plain @click="addItem('img')">图片</el-button>
          <!-- <el-button plain @click="addItem('head')">商品图片</el-button> -->
          <el-button plain @click="addItem('shadow')">阴影区</el-button>
          <el-button plain @click="addItem('textarea')">文本块</el-button>
        </div>
        <div class="line">
          <div class="label">二维码元素</div>
          <el-button plain @click="addItem('qrmp')">网页二维码</el-button>
          <el-button plain @click="addItem('qrwx')">微信小程序码</el-button>
        </div>
        <template v-if="posterArr.length">
          <!-- 公共属性 start -->
          <div class="line">
            <div class="label">长</div>
            <el-input v-model="activePoster.width" class="w200"></el-input>
          </div>
          <div class="line">
            <div class="label">宽</div>
            <el-input v-model="activePoster.height" class="w200"></el-input>
          </div>
          <div class="line">
            <div class="label">上间距</div>
            <el-input v-model="activePoster.top" class="w200" @input="checkTop"></el-input>
          </div>
          <div class="line">
            <div class="label">左间距</div>
            <el-input v-model="activePoster.left" class="w200" @input="checkLeft"></el-input>
          </div>
          <!-- 公共属性 end -->
          <div class="line" v-if="activePoster.type == 'head'">
            <div class="label">圆角值</div>
            <el-slider v-model="activePoster.radius" class="w200"></el-slider>
          </div>
          <template v-else-if="activePoster.type == 'text'">
            <div class="line">
              <div class="label">文字内容</div>
              <el-input v-model="activePoster.content" class="w200"></el-input>
            </div>
            <div class="line">
              <div class="label">文字颜色</div>
              <el-input v-model="activePoster.color" class="w200"></el-input>
              <el-color-picker v-model="activePoster.color"></el-color-picker>
            </div>
            <div class="line">
              <div class="label">文字大小</div>
              <el-input v-model="activePoster.size" class="w200"></el-input>
            </div>
          </template>
          <div class="line" v-else-if="activePoster.type == 'img'">
          </div>
          <div class="line" v-else-if="activePoster.type == 'shadow'">
            <div class="label">颜色及透明度</div>
            <el-input v-model="activePoster.shadow" class="w200"></el-input>
            <el-color-picker v-model="activePoster.shadow" show-alpha></el-color-picker>
          </div>
          <template v-else-if="activePoster.type == 'textarea'">
            <div class="line">
              <div class="label">文字内容</div>
              <el-input v-model="activePoster.content" class="w200"></el-input>
            </div>
            <div class="line">
              <div class="label">文字颜色</div>
              <el-input v-model="activePoster.color" class="w200"></el-input>
              <el-color-picker v-model="activePoster.color"></el-color-picker>
            </div>
            <div class="line">
              <div class="label">文字大小</div>
              <el-input v-model="activePoster.size" class="w200"></el-input>
            </div>
          </template>
        </template>
        <el-button type="primary" size="medium" @click="savePoster">保存</el-button>
      </div>
    </div>
    <el-dialog :visible="modalPic" width="960px" title='上传背景图' :close-on-click-modal="false" :z-index="1"
      @close="closePicDialog">
      <uploadPictures :isChoice="isChoice" @getPic="getPic" :gridBtn="gridBtn" :gridPic="gridPic" v-if="modalPic">
      </uploadPictures>
    </el-dialog>
  </div>
</template>

<script>
import { createShopPoster } from '@/api/shop'
import uploadPictures from '@/components/uploadPictures';

export default {
  name: 'ShopPosterItem',
  components: {
    uploadPictures
  },
  props: {
    type: {
      type: String,
      default: "",
    },
  },
  data() {
    return {
      modalPic: false,
      isChoice: '单选',
      gridBtn: {
        xl: 4,
        lg: 8,
        md: 8,
        sm: 8,
        xs: 8
      },
      gridPic: {
        xl: 6,
        lg: 8,
        md: 12,
        sm: 12,
        xs: 12
      },
      bgPicUrl: "https://dip.iappwx.com/static/imgsrc/posterbg.jpg",
      posterArr: [],
      activePosterIdx: 0,
    }
  },
  computed: {
    activePoster() {
      return this.posterArr[this.activePosterIdx];
    }
  },
  created() {
  },
  methods: {
    uploadImg() {
      this.modalPic = true;
    },
    getPic(pc) {
      this.$nextTick(() => {
        this.bgPicUrl = pc.att_dir;
        this.closePicDialog();
      })
    },
    closePicDialog() {
      this.modalPic = false;
    },
    addItem(type) {
      const publicAttr = {
        type,
        left: "0px",
        top: "0px",
        width: "80px",
        height: "80px",
      }
      let extraAttr = {}
      switch (type) {
        case "head":
          extraAttr.radius = 30
          break;
        case "text":
          extraAttr.size = "16px";
          extraAttr.color = "#000";
          extraAttr.content = "[昵称]";
          break;
        case "img":
          extraAttr.src = "https://dip.iappwx.com/static/imgsrc/picture-1.jpg";
          break;
        case "shadow":
          extraAttr.shadow = "rgba(50, 50, 50, 0.5)";
          break;
        case "textarea":
          extraAttr.size = "16px";
          extraAttr.color = "#000";
          extraAttr.content = "文本内容";
          break;

        default:
          break;
      }
      this.posterArr.push(Object.assign(publicAttr, extraAttr));
      this.activePosterIdx = this.posterArr.length - 1;

    },
    updateAttr(idx) {
      this.activePosterIdx = idx;
    },
    deleteAttr(idx) {
      if (this.activePosterIdx == idx) {
        this.activePosterIdx = 0
      }
      this.posterArr.splice(idx, 1)
    },
    savePoster() {
      const param = {
        type: this.type,
        poster_bg: this.bgPicUrl,
        poster_data: this.posterArr,
        clearhistory: 1,
      }
      createShopPoster(param);
    },
    checkTop(val) {
      const top = parseInt(val);
      if (top < 0) {
        this.activePoster.top = "0px";
      }
      const height = parseInt(this.activePoster.height);
      if (top + height > 570) {
        this.activePoster.top = `${570 - height}px`;
      }
    },
    checkLeft(val) {
      const left = parseInt(val);
      if (left < 0) {
        this.activePoster.left = "0px";
      }
      const width = parseInt(this.activePoster.width);
      if (left + width > 342) {
        this.activePoster.left = `${342 - width}px`;
      }
    },
  },
}
</script>

<style lang="scss" scoped>
$phoneWidth: 372px;

.poster {
  display: flex;

  .poster-preview {
    width: $phoneWidth;


    .dsn-phone-top {
      height: 50px;
      background: url(~@/assets/images/phone_top.png) 0px 0px no-repeat;
    }

    .dsn-phone-main {
      min-height: 600px;
      background: url(~@/assets/images/phone_center.png) 0px 0px repeat-y;
      padding: 0px 15px;

      .dsn-mod {
        color: #fff;
        background: #000;
        height: 30px;
        line-height: 30px;
      }

      .editor-content {
        position: relative;

        .poster-item {
          position: absolute;
          top: 0;
          left: 0;
          border: 1px dashed #000;

          &.bg-img {
            width: 342px;
            min-height: 570px;
            border: none;
          }

          &.head-img {
            background: url(~@/assets/images/default-avatar.png) no-repeat 100%;
            background-size: 100%
          }

          &.poster-img {
            background: url(~@/assets/images/img.png) no-repeat 100%;
            background-size: 100%
          }

          &.poster-qrmp {
            background: url(~@/assets/images/qrmp.jpeg) no-repeat 100%;
            background-size: 100%
          }

          &.poster-qrwx {
            background: url(~@/assets/images/qrwx.jpeg) no-repeat 100%;
            background-size: 100%
          }
        }
      }
    }

    .dsn-phone-bottom {
      height: 92px;
      background: url(~@/assets/images/phone_bottom.png) 0px 0px no-repeat;
      padding-top: 60px;
      text-align: center;
    }

    // }
  }

  .poster-attr {
    padding: 10px;
    padding-top: 150px;
    text-align: center;

    .line {
      display: flex;
      margin-bottom: 15px;

      .label {
        width: 120px;
        line-height: 20px;
        padding: 9px 15px;
        color: #666;
        text-align: right;
      }

      .w200 {
        width: 200px;
      }
    }
  }
}
</style>
