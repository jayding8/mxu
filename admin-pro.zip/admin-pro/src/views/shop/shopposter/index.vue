<template>
  <div class="personal-center-container">
    <el-tabs v-model="activeName">
      <el-tab-pane label="微信公众号" name="first">
        <div class="poster">
          <div class="poster-preview">
            <div class="dsn-phone-top"></div>
            <div class="dsn-phone-main">
              <div class="dsn-mod dsn-topbar dsn-mod-nohover">
                <div style="float:left;width:30%">&nbsp;<i class="fa fa-signal"></i> wechat <i class="fa fa-wifi"></i>
                </div>
                <div style="float:left;text-align:center;width:40%">12:00</div>
                <div style="float:left;text-align:right;width:30%">100% <i class="fa fa-battery-full"></i>&nbsp;
                </div>
              </div>
              <div id="editor-content">
                <div id="poster"></div>
              </div>
            </div>
            <div class="dsn-phone-bottom"></div>
          </div>
          <div class="poster-attr">
            <div class="line">
              <div class="label">背景图片</div>
              <el-button plain>选择或上传</el-button>
            </div>
            <div class="line">
              <div class="label">海报元素</div>
              <el-button plain>头像</el-button>
              <el-button plain>文字</el-button>
              <el-button plain>图片</el-button>
              <el-button plain>商品图片</el-button>
              <el-button plain>阴影区</el-button>
              <el-button plain>文本块</el-button>
            </div>
          </div>
        </div>

      </el-tab-pane>
      <el-tab-pane label="微信小程序" name="second">2222</el-tab-pane>
      <el-tab-pane label="支付宝小程序" name="Third">3333</el-tab-pane>
      <el-tab-pane label="百度小程序" name="Fourth">2222</el-tab-pane>
      <el-tab-pane label="抖音小程序" name="Fifth">3333</el-tab-pane>
      <el-tab-pane label="QQ小程序" name="Sixth">2222</el-tab-pane>
      <el-tab-pane label="手机H5" name="Seventh">3333</el-tab-pane>
      <el-tab-pane label="手机APP" name="Eighth">2222</el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { shopPoster } from '@/api/shop'

export default {
  name: 'ShopPoster',
  data() {
    return {
      activeName: 'first',

    }
  },
  computed: {
    ...mapGetters({}),
  },
  created() {
    this.shopPoster()
  },
  methods: {
    shopPoster,
  },
}
</script>

<style lang="scss" scoped>
$phoneWidth: 372px;

.poster {
  display: flex;

  .poster-preview {
    width: $phoneWidth;

    // .dsn-phone {
    .dsn-phone-top {
      height: 50px;
      background: url(~@/assets/images/phone_top.png) 0px 0px no-repeat;
    }

    .dsn-phone-main {
      min-height: 600px;
      background: url(~@/assets/images/phone_center.png) 0px 0px repeat-y;
      padding: 0px 15px;

      .dsn-mod {
        color: #fff;
        background: #000;
        height: 30px;
        line-height: 30px;
      }

      .editor-content {}
    }

    .dsn-phone-bottom {
      height: 92px;
      background: url(~@/assets/images/phone_bottom.png) 0px 0px no-repeat;
      padding-top: 60px;
      text-align: center;
    }

    // }
  }

  .poster-attr {
    padding: 10px;
    padding-top: 150px;

    .line {
      display: flex;
      margin-bottom: 15px;

      .label {
        width: 80px;
        line-height: 20px;
        padding: 9px 15px;
        color: #666;
        text-align: right;
        box-sizing: content-box;
      }
    }
  }
}
</style>
