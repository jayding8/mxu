<template>
  <div class="personal-center-container">
    <div class="bigTitle">超级海报</div>
    <el-tabs v-model="activeName">
      <el-tab-pane label="微信公众号" name="mp">
        <shopPosterItem type="mp"></shopPosterItem>
      </el-tab-pane>
      <el-tab-pane label="微信小程序" name="wx">
        <shopPosterItem type="wx"></shopPosterItem>
      </el-tab-pane>
      <el-tab-pane label="支付宝小程序" name="alipay">
        <shopPosterItem type="alipay"></shopPosterItem>
      </el-tab-pane>
      <el-tab-pane label="百度小程序" name="baidu">
        <shopPosterItem type="baidu"></shopPosterItem>
      </el-tab-pane>
      <el-tab-pane label="抖音小程序" name="toutiao">
        <shopPosterItem type="toutiao"></shopPosterItem>
      </el-tab-pane>
      <el-tab-pane label="QQ小程序" name="qq">
        <shopPosterItem type="qq"></shopPosterItem>
      </el-tab-pane>
      <el-tab-pane label="手机H5" name="h5">
        <shopPosterItem type="h5"></shopPosterItem>
      </el-tab-pane>
      <el-tab-pane label="手机APP" name="app">
        <shopPosterItem type="app"></shopPosterItem>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { createShopPoster } from '@/api/shop'
import shopPosterItem from "./shopPosterItem.vue";

export default {
  name: 'ShopPoster',
  components: {
    shopPosterItem
  },
  data() {
    return {
      activeName: 'mp',
    }
  },
  computed: {
    activePoster() {
      return this.posterArr[this.activePosterIdx];
    }
  },
  created() {
  },
  methods: {
  },
}
</script>

<style lang="scss" scoped>
.bigTitle {
  color: #333;
  font-weight: 700;
  font-size: 18px;
  position: relative;
  padding-left: 12px;
  margin-bottom: 20px;
}

.bigTitle:before {
  content: "";
  width: 4px;
  height: 80%;
  background-color: #136ffe !important;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
}
</style>
