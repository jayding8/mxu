<template>
  <div class="index-container">
    这里是内容
    <vab-theme />
    <div>
      <!-- <iframe
        src="https://dd.origin.ranyun.online/app/view/backstage/welcome.html"
        width="800"
        height="600"
      ></iframe> -->
    </div>
    <div class="block">
      <span class="demonstration">完整功能</span>

      <el-pagination
        :current-page="info.page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="info.page.limit"
        :page-sizes="[10, 20, 50, 100]"
        :total="info.page.total"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { welcome, shopProduct } from '@/api/user'
  export default {
    name: 'Index',
    data() {
      return {
        info: {
          page: {
            current: 1,
            limit: 10,
            totle: 0,
          },
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.welcome()
      this.shopProduct({
        page: this.info.page.current,
        limit: this.info.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    methods: {
      welcome,
      shopProduct,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.page.limit = val
        this.shopProduct({
          page: this.info.page.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.page.current = val
        this.shopProduct({
          page: val,
          limit: this.info.page.limit,
        })
      },
    },
  }
</script>

<style lang="scss" scoped></style>
