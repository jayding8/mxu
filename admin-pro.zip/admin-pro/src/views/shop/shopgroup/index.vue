<template>
  <div class="index-container">
    <div class="bigTitle">订单列表</div>
    <el-alert :closable="false" show-icon title="商品库商品变更商品基础信息或将单规格商品调整成多规格商品将会自动同步至门店；如需修改门店商品价格或库存请在商品模板库调整"
      type="success" />
    <vab-query-form>
      <vab-query-form-left-panel :span="24">
        <el-button icon="el-icon-plus" type="primary" @click="handleAdd">
          发布商品
        </el-button>
        <el-button icon="el-icon-delete" type="danger" @click="handleDelete($event)">
          删除
        </el-button>
        <el-button type="primary" @click="handleAdd">导入</el-button>
        <el-button type="primary" @click="handleAdd">导出</el-button>
        <el-button type="primary" @click="handleAdd">上架</el-button>
        <el-button type="primary" @click="handleAdd">下架</el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="80" />
      <el-table-column label="名称" prop="name" width="400" />
      <el-table-column label="图片" width="400">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <div style="height: 80px; width: 80px">
                <img :src="props.row.pic" style="height: 100%; width: 100%" />
              </div>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="序号" prop="sort" width="100" />
      <el-table-column label="状态" width="120">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span v-if="props.row.status == 1">显示</span>
              <span v-if="props.row.status == 0">隐藏</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作">
        <template slot-scope="scope">
          <el-button size="small" type="text" @click="handleClick(scope.row)">
            编辑
          </el-button>
          <el-button size="small" type="text">删除</el-button>
          <el-button size="small" type="text">添加子分类</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { shopGroup } from '@/api/shop'
export default {
  name: 'Shopgroup',
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',

      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.shopGroup({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    shopGroup,

    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.shopGroup({
        page: this.page.current,
        limit: val,
      }).then((res) => {
        this.info = res
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.shopGroup({
        page: val,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
  width: 100%;
}
</style>
