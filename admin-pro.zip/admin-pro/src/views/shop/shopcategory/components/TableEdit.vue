<template>
  <el-dialog
    append-to-body
    :title="title"
    :visible.sync="dialogFormVisible"
    width="800px"
    @close="close"
  >
    <el-form ref="form" label-width="100px" :model="form">
      <el-form-item label="上级分类" prop="category">
        <el-select
          v-model="form.pid"
          placeholder="-作为顶级分类-"
          style="width: 250px"
        >
          <el-option
            v-for="item in pcatelist"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="分类名称" prop="name">
        <el-input v-model="form.name" />
      </el-form-item>
      <el-form-item label="分类图标" prop="pic">
        <el-input v-model="form.pic" />
      </el-form-item>
      <el-form-item label="序号" prop="sort">
        <el-input v-model="form.sort" />
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-input v-model="form.status" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="save">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script>
  import { saveCate, getCategory, getEdit, getSonCate } from '@/api/category'

  export default {
    name: 'TableEdit',
    data() {
      return {
        form: {
          sort: 0,
          status: 1,
        },
        pcatelist: [],
        title: '',
        dialogFormVisible: false,
      }
    },
    created() {
      getCategory().then((res) => {
        this.pcatelist = [
          {
            name: '作为顶级分类',
            id: 0,
          },
          ...res.data.pcatelist,
        ]
      })
    },
    methods: {
      showEdit(row, type) {
        console.log(row.id)
        if (!row.id) {
          this.title = '添加'
          getCategory().then((res) => {
            this.pcatelist = [
              {
                name: '作为顶级分类',
                id: 0,
              },
              ...res.data.pcatelist,
            ]
          })
        } else {
          this.title = '编辑'
          if (type == 1) {
            getEdit(row.id).then((res) => {
              this.form = res.data.info
              this.pcatelist = [
                {
                  name: '作为顶级分类',
                  id: 0,
                },
                ...res.data.pcatelist,
              ]
            })
          } else if (type == 2) {
            getSonCate(row.id).then((res) => {
              this.form.pid = parseInt(res.data.info.pid)
              this.pcatelist = [
                {
                  name: '作为顶级分类',
                  id: 0,
                },
                ...res.data.pcatelist,
              ]
            })
          }
        }
        this.dialogFormVisible = true
      },
      close() {
        ;(this.form = {
          sort: 0,
          status: 1,
        }),
          (this.dialogFormVisible = false)
      },
      save() {
        this.$refs['form'].validate(async (valid) => {
          if (valid) {
            const { msg } = await saveCate({
              info: this.form,
            })
            this.$baseMessage(msg, 'success', 'vab-hey-message-success')
            this.$emit('fetch-data')
            this.close()
          }
        })
      },
    },
  }
</script>
