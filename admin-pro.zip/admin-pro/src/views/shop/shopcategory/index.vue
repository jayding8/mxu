<template>
  <div class="index-container">
    <vab-query-form>
      <vab-query-form-left-panel :span="24">
        <el-button icon="el-icon-plus" type="primary" @click="handleAdd">
          添加
        </el-button>
        <el-button icon="el-icon-delete" type="danger" @click="handleDelete($event)">
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column align="center" type="selection" width="55" />
      <el-table-column align="center" fixed label="id" prop="id" width="55" />
      <el-table-column label="名称" prop="name" align="center" />
      <el-table-column label="图片" width="400" align="center">
        <template slot-scope="props">

          <div style="height: 80px; width: 80px;margin: auto;">
            <img :src="props.row.pic" style="height: 100%; width: 100%" />
          </div>

        </template>
      </el-table-column>
      <el-table-column label="序号" prop="sort" width="100" align="center" />
      <el-table-column label="状态" width="120" align="center">
        <template slot-scope="props">

          <span v-if="props.row.status == 1">显示</span>
          <span v-if="props.row.status == 0">隐藏</span>

        </template>
      </el-table-column>

      <el-table-column align="center" fixed="right" label="操作" width="200">
        <template slot-scope="scope">

          <el-button type="text" @click="handleAdd(scope.row, 1)">编辑</el-button>
          <span class="line"></span>
          <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
          <span class="line"></span>
          <el-button type="text" @click="handleAdd(scope.row, 2)">添加子分类</el-button>

        </template>
      </el-table-column>

    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>

    <table-edit ref="edit" @fetch-data="refresh" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { shopCategory, cateDelete } from '@/api/shop'
import TableEdit from './components/TableEdit'
export default {
  name: 'ShopCategory',
  components: {
    TableEdit,
  },
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',

      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    shopCategory({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    refresh() {
      shopCategory({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    handleDelete(row) {
      console.log(row)
      if (row.id) {
        this.$baseConfirm('你确定要删除吗', null, async () => {
          const { msg } = await cateDelete({ ids: row.id })
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          await shopCategory({
            page: this.page.current,
            limit: this.page.limit,
          }).then((res) => {
            this.info.data = res.data
            this.info.count = res.count
          })
        })
      } else {
        if (this.multipleSelection.length > 0) {
          const ids = this.multipleSelection.map((item) => item.id).join()
          this.$baseConfirm('你确定要删除选中项吗', null, async () => {
            const { msg } = await cateDelete({ ids: ids })
            this.$baseMessage(msg, 'success', 'vab-hey-message-success')
            await shopCategory({
              page: this.page.current,
              limit: this.page.limit,
            }).then((res) => {
              this.info.data = res.data
              this.info.count = res.count
            })
          })
        } else {
          this.$baseMessage('未选中任何行', 'error', 'vab-hey-message-error')
        }
      }
    },
    handleSelectionChange(val) {
      console.log(val)
      this.multipleSelection = val
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.shopCategory({
        page: this.page.current,
        limit: val,
      }).then((res) => {
        this.info = res
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.shopCategory({
        page: val,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    handleAdd(data, type) {
      this.$refs['edit'].showEdit(data, type)
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
  width: 100%;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}
</style>
