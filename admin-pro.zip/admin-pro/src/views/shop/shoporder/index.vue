<template>
  <div class="index-container">
    <div class="box">
      <vab-query-form>
        <vab-query-form-top-panel>
          <el-form
            ref="form"
            :inline="true"
            :model="queryForm"
            @submit.native.prevent
          >
            <el-form-item>
              <el-input
                v-model="queryForm.keyword"
                placeholder="请输入内容"
                style="width: 300px"
              >
                <el-select
                  slot="prepend"
                  v-model="queryForm.keyword_type"
                  placeholder="请选择"
                >
                  <el-option label="订单号" :value="1" />
                  <el-option label="会员ID" :value="2" />
                  <el-option label="会员信息" :value="3" />
                  <el-option label="收货信息" :value="4" />
                  <el-option label="快递单号" :value="5" />
                  <el-option label="商品ID" :value="6" />
                  <el-option label="商品名称" :value="7" />
                  <el-option label="商品编码" :value="8" />
                  <el-option label="核销员" :value="9" />
                  <el-option label="所属门店" :value="10" />
                </el-select>
              </el-input>
            </el-form-item>

            <el-form-item>
              <el-button
                icon="el-icon-search"
                native-type="submit"
                type="primary"
                @click="handleQuery"
              >
                查询
              </el-button>
            </el-form-item>
          </el-form>
        </vab-query-form-top-panel>
        <vab-query-form-left-panel :span="24">
          <el-button @click="handleAdd">导入</el-button>
          <el-button @click="handleAdd">导出</el-button>
          <el-button @click="handleAdd">批量发货</el-button>
          <el-button @click="handleAdd">批量打印送货单</el-button>
        </vab-query-form-left-panel>
      </vab-query-form>
    </div>

    <div class="box">
      <el-tabs v-model="activeName" @tab-click="handleTab">
        <el-tab-pane label="全部订单" name="all" />
        <el-tab-pane label="未支付" name="0" />
        <el-tab-pane label="待发货" name="1" />
        <el-tab-pane label="已发货" name="2" />
        <el-tab-pane label="已完成" name="3" />
        <el-tab-pane label="已关闭" name="4" />
      </el-tabs>

      <el-table
        border
        :data="info.data"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column
          align="center"
          show-overflow-tooltip
          type="selection"
          width="55"
        />
        <el-table-column
          align="center"
          fixed
          label="id"
          prop="id"
          show-overflow-tooltip
          sortable
          width="60"
        />
        <el-table-column align="center" label="商品图" width="80">
          <template slot-scope="props">
            <el-image
              v-for="(item, index) in props.row.goodsdata"
              :key="index"
              fit="fill"
              :lazy="true"
              :src="item.grstr.goods_pic"
            />
          </template>
        </el-table-column>
        <el-table-column label="商品信息" min-width="300">
          <template slot-scope="props">
            <div
              v-for="(item, index) in props.row.goodsdata"
              :key="index"
              style="padding: 5px 0"
            >
              <el-tooltip
                :content="item.grstr.name"
                :delay="600"
                effect="dark"
                max-width="300"
                :transfer="true"
              >
                <span class="line2">
                  {{ item.grstr.name }}
                </span>
              </el-tooltip>
              <span class="red" style="margin-right: 10px">
                {{ item.grstr.ggname }}
              </span>
              <span style="color: #999">
                {{ item.grstr.sell_price }} x {{ item.grstr.num }}
              </span>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          label="订单号/下单时间"
          show-overflow-tooltip
          width="180"
        >
          <template slot-scope="props">
            {{ new Date(props.row.createtime * 1000).toLocaleString() }}
            <div>{{ props.row.ordernum }}</div>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="实付款"
          show-overflow-tooltip
          sortable
          width="150"
        >
          <template slot-scope="props">
            <div style="margin-bottom: 5px">
              总价:￥{{ props.row.product_price }}
            </div>
            <div style="color: #ff4d4f">实付:￥{{ props.row.totalprice }}</div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="收货地址" width="200">
          <template slot-scope="props">
            <div style="text-align: left; font-weight: bold">
              {{ props.row.linkman }}
            </div>
            <div style="text-align: left">{{ props.row.tel }}</div>
            <div style="text-align: left">
              <span>{{ props.row.area }}</span>
              <span>{{ props.row.address }}</span>
            </div>
          </template>
        </el-table-column>
        <!-- <el-table-column align="center" label="来源" prop="platform" width="100" /> -->
        <el-table-column align="center" label="头像昵称" width="100">
          <template slot-scope="props">
            <img
              :src="props.row.headimg"
              style="width: 42px; height: 42px; border-radius: 4px"
            />
            <div style="font-size: 12px">{{ props.row.nickname }}</div>
            <div
              v-if="props.row.m_remark"
              class="boxcontent yellow"
              style="font-size: 12px"
            >
              {{ props.row.m_remark }}
            </div>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="支付方式"
          prop="paytype"
          width="100"
        />

        <el-table-column align="center" label="社区/门店" width="150">
          <template slot-scope="props">
            <div v-if="props.row.mdxqname">
              <div style="text-align: left">{{ props.row.mdname }}</div>
              <div style="text-align: left">{{ props.row.mdtel }}</div>
              <div style="text-align: left">小区：{{ props.row.mdxqname }}</div>
            </div>
            <div v-else>无</div>
          </template>
        </el-table-column>

        <el-table-column
          align="center"
          label="配送方式"
          prop="freight_text"
          width="150"
        />
        <el-table-column align="center" label="状态" width="150">
          <template slot-scope="props">
            <div v-if="props.row.status == 4" class="boxcontent green">
              已关闭
            </div>
            <div v-if="props.row.status == 3" class="boxcontent green">
              已完成
            </div>
            <div v-if="props.row.status == 1" class="boxcontent red">
              待发货
            </div>

            <div v-if="props.row.status == 2" class="boxcontent blue">
              <div v-if="props.row.express_isbufen == 1">部分发货</div>
              <div v-else>已发货</div>
            </div>

            <div v-if="props.row.status == 0" class="boxcontent yellow">
              待支付
            </div>

            <div v-if="props.row.refund_status == 1" class="boxcontent red">
              退款待审核,￥{{ props.row.refund_money }}
            </div>
            <div v-if="props.row.refund_status == 2" class="boxcontent red">
              已退款,￥{{ props.row.refund_money }}
            </div>
            <div v-if="props.row.refund_status == 3" class="boxcontent red">
              退款驳回,￥{{ props.row.refund_money }}
            </div>
            <div v-if="props.row.balance_price > 0" class="boxcontent red">
              尾款￥{{
                props.row.balance_pay_status == 0 ? '未支付' : '已支付'
              }}
            </div>
            <div v-if="props.row.refundCount > 0" class="boxcontent red">
              有退款{{ props.row.refundCount }}
            </div>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="备注"
          prop="remark"
          width="150"
        />
        <el-table-column align="center" fixed="right" label="操作" width="220">
          <template slot-scope="scope">
            <span
              v-if="
                scope.row.paytypeid == 5 && scope.row.payorder.check_status >= 0
              "
            >
              <el-button v-if="scope.row.transfer_check == 1" type="text">
                付款凭证
              </el-button>
              <el-button v-else-if="scope.row.transfer_check == 0" type="text">
                转账审核
              </el-button>
              <el-button v-else-if="scope.row.transfer_check == -1" type="text">
                转账已驳回
              </el-button>
            </span>

            <el-button type="text" @click="handleDetail(scope.row)">
              详情
            </el-button>
            <el-button type="text" @click="handleSHD(scope.row)">
              送货单
            </el-button>
            <el-button type="text" @click="handlePrint(scope.row)">
              打印小票
            </el-button>
            <el-button type="text" @click="handleModify(scope.row)">
              修改
            </el-button>
            <el-button type="text" @click="handleDelete(scope.row)">
              删除
            </el-button>

            <span v-if="scope.row.refund_status == 1">
              <!--退款待审核 -->
              <el-button type="text">退款审核</el-button>
            </span>
            <span v-if="scope.row.status == 0">
              <!--未支付 -->
              <el-button type="text">关闭订单</el-button>
              <el-button type="text">改为已支付</el-button>
            </span>

            <span
              v-if="
                scope.row.balance_price > 0 && scope.row.balance_pay_status == 0
              "
            >
              <!--尾款未支付 -->
              <el-button type="text">改为已支付</el-button>
            </span>

            <span v-if="scope.row.status == 1">
              <!--已支付 -->
              <el-button type="text" @click="handleExpress(scope.row)">
                发货
              </el-button>
              <span v-if="scope.row.freight_type == 1">
                <el-button type="text" @click="handleExpress(scope.row)">
                  核销
                </el-button>
                <el-button
                  v-if="scope.row.hexiao_code_member"
                  type="text"
                  @click="handleExpress(scope.row)"
                >
                  核销密码
                </el-button>
              </span>
              <el-button type="text" @click="handleRefund(scope.row)">
                退款
              </el-button>
            </span>

            <span v-if="scope.row.status == 2">
              <!--已发货 -->
              <el-button type="text" @click="handleDelivery(scope.row)">
                查物流
              </el-button>
              <el-button type="text" @click="handleExpress(scope.row)">
                改物流
              </el-button>
              <span v-if="scope.row.freight_type == 1">
                <el-button type="text" @click="handleExpress(scope.row)">
                  核销
                </el-button>
              </span>
              <span v-if="scope.row.freight_type == 4">
                <el-button type="text" @click="handleReceive(scope.row)">
                  确认收货
                </el-button>
              </span>
              <el-button type="text" @click="handleRefund(scope.row)">
                退款
              </el-button>
            </span>

            <span v-if="scope.row.status == 3">
              <!--已完成 -->
              <el-button type="text" @click="handleDelivery(scope.row)">
                查物流
              </el-button>
            </span>

            <!-- <div v-if="scope.row.status == 1">
              <el-button type="text" @click="handleDetail(scope.row)">详情</el-button>
              <span class="line"></span>
              <el-button type="text" @click="handleExpress(scope.row)">发货</el-button>
              <span class="line"></span>
              <el-button type="text" @click="handleRefund(scope.row)">退款</el-button>
              <span class="line"></span>
              <el-dropdown type="primary" @command="handleCommand($event, scope.row)">
                <el-button type="text">
                  更多
                  <vab-icon icon="arrow-down-s-line" style="color: #2d8cf0" />
                </el-button>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item command="1">送货单</el-dropdown-item>
                  <el-dropdown-item command="2">打印小票</el-dropdown-item>
                  <el-dropdown-item command="3">付款凭证</el-dropdown-item>
                  <el-dropdown-item command="4">转账审核</el-dropdown-item>
                  <el-dropdown-item command="5">转账已驳回</el-dropdown-item>
                  <el-dropdown-item command="7">修改订单</el-dropdown-item>
                  <el-dropdown-item command="8">已同步商家</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
            <div v-if="scope.row.status == 2">
              <el-button type="text" @click="handleDelivery(scope.row)">查物流</el-button>
              <span class="line"></span>
              <el-button type="text" @click="handleDetail(scope.row)">核销</el-button>
              <span class="line"></span>
              <el-button type="text" @click="handleRefund(scope.row)">退款</el-button>
              <span class="line"></span>
              <el-dropdown type="primary" @command="handleCommand2($event, scope.row)">
                <el-button type="text">
                  更多
                  <vab-icon icon="arrow-down-s-line" style="color: #2d8cf0" />
                </el-button>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item command="1">改物流</el-dropdown-item>
                  <el-dropdown-item command="2">确认收货</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
            <div v-if="scope.row.status == 3">
              <el-button type="text" @click="handleDetail(scope.row)">详情</el-button>
              <span class="line"></span>
              <el-button type="text" @click="handleDelivery(scope.row)">查物流</el-button>
              <span class="line"></span>
              <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
            </div>
            <div v-if="scope.row.status == 4">
              <el-button type="text" @click="handleDetail(scope.row)">详情</el-button>
              <span class="line"></span>
              <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
            </div> -->
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>

    <table-detail ref="detail" @fetch-data="fetchData" />
    <table-express ref="express" @fetch-data="fetchData" />
    <table-delivery ref="delivery" @fetch-data="fetchData" />
    <table-refund ref="refund" @fetch-data="fetchData" />
    <table-modify ref="modify" @fetch-data="fetchData" />
    <table-shd ref="shd" @fetch-data="fetchData" />
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import {
    shopOrder,
    shopOrderStatus,
    doReceive,
    doDelete,
    doPrint,
  } from '@/api/user'
  import TableDetail from './components/TableDetail'
  import TableDelivery from './components/TableDelivery'
  import TableExpress from './components/TableExpress'
  import TableRefund from './components/TableRefund'
  import TableModify from './components/TableModify'
  import TableShd from './components/TableSHD'
  export default {
    name: 'Shoporder',
    components: {
      TableDetail,
      TableDelivery,
      TableRefund,
      TableModify,
      TableExpress,
      TableShd,
    },
    data() {
      return {
        activeName: 'all',
        queryForm: {
          keyword_type: 1,
        },
        layout: 'total, sizes, prev, pager, next, jumper',
        fold: false,
        height: this.$baseTableHeight(3) - 30,
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      shopOrder({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      fetchData() {
        shopOrder({
          page: this.page.current,
          limit: this.page.limit,
        }).then((res) => {
          this.info.data = res.data
          this.info.count = res.count
        })
      },
      handleQuery() {
        shopOrderStatus({
          page: this.page.current,
          limit: this.page.limit,
          status: this.activeName,
          ...this.queryForm,
        }).then((res) => {
          this.info.data = res.data
          this.info.count = res.count
        })
      },
      handleDetail(data) {
        this.$refs['detail'].showEdit(data)
      },
      handleExpress(data) {
        this.$refs['express'].showEdit(data)
      },
      handleDelivery(data) {
        this.$refs['delivery'].showEdit(data)
      },
      handleRefund(data) {
        this.$refs['refund'].showEdit(data)
      },
      handleSHD(data) {
        this.$refs['shd'].showEdit(data)
      },
      handleModify(data) {
        this.$refs['modify'].showEdit(data)
      },
      handleTab(tab) {
        console.log(tab.name)
        if (tab.name == 'all') {
          this.fetchData()
        } else {
          shopOrderStatus({
            page: this.page.current,
            limit: this.page.limit,
            status: tab.name,
          }).then((res) => {
            this.info.data = res.data
            this.info.count = res.count
          })
        }
      },

      handleAdd() {
        this.$refs['edit'].showEdit()
      },
      handleFold() {
        this.fold = !this.fold
        this.handleHeight()
      },
      handleHeight() {
        if (this.fold) this.height = this.$baseTableHeight(2) - 47
        else this.height = this.$baseTableHeight(3) - 30
      },
      handlePrint(row) {
        if (row.id) {
          this.$baseConfirm('你确定要打印小票吗', null, async () => {
            const { msg } = await doPrint({ id: row.id })
            this.$baseMessage(msg, 'success', 'vab-hey-message-success')
            await this.fetchData()
          })
        }
      },
      handleReceive(row) {
        if (row.id) {
          this.$baseConfirm('你确定要改为已完成状态吗', null, async () => {
            const { msg } = await doReceive({ orderid: row.id })
            this.$baseMessage(msg, 'success', 'vab-hey-message-success')
            await this.fetchData()
          })
        }
      },
      handleDelete(row) {
        if (row.id) {
          this.$baseConfirm('你确定要删除吗', null, async () => {
            const { msg } = await doDelete({ ids: row.id })
            this.$baseMessage(msg, 'success', 'vab-hey-message-success')
            await this.fetchData()
          })
        } else {
          if (this.selectRows.length > 0) {
            const ids = this.selectRows.map((item) => item.id).join()
            this.$baseConfirm('你确定要删除选中项吗', null, async () => {
              const { msg } = await doDelete({ ids: ids })
              this.$baseMessage(msg, 'success', 'vab-hey-message-success')
              await this.fetchData()
            })
          } else {
            this.$baseMessage('未选中任何行', 'error', 'vab-hey-message-error')
          }
        }
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.page.limit = val
        shopOrder({
          page: this.page.current,
          limit: val,
        }).then((res) => {
          this.info = res
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.page.current = val
        shopOrder({
          page: val,
          limit: this.page.limit,
        }).then((res) => {
          this.info = res
        })
      },
      toggleSelection(rows) {
        if (rows) {
          rows.forEach((row) => {
            this.$refs.multipleTable.toggleRowSelection(row)
          })
        } else {
          this.$refs.multipleTable.clearSelection()
        }
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleClick(row) {
        console.log(row)
      },
      handleCommand(command, row) {
        if (command === 'close') {
          // 关闭下拉菜单的逻辑
          this.closeDropdown()
        } else {
          // 处理其它命令
          console.log('执行的命令:', command)
          // 根据 command 执行相应的操作
          if (command == '1') {
            this.handleSHD(row)
          }
          if (command == '2') {
            this.handlePrint(row)
          }
          if (command == '7') {
            this.handleModify(row)
          }
        }
      },
      handleCommand2(command, row) {
        if (command === 'close') {
          // 关闭下拉菜单的逻辑
          this.closeDropdown()
        } else {
          // 处理其它命令
          console.log('执行的命令:', command)
          // 根据 command 执行相应的操作
          if (command == '1') {
            this.handleExpress(row)
          }
          if (command == '2') {
            this.handleReceive(row)
          }
        }
      },
      closeDropdown() {
        // 这里可以添加关闭下拉菜单的逻辑
        // 如果是通过点击页面其它区域来关闭下拉菜单，可以使用点击页面的事件监听器
        // this.$refs.dropdown.doClose(); // 假设您给 el-dropdown 组件添加了 ref="dropdown"
      },
    },
  }
</script>

<style lang="scss" scoped>
  .index-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .select-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .box {
    width: 100%;
    padding: 20px;
    margin-bottom: 20px;
    background: #fff;
    border-radius: 6px;
  }

  .input-add {
    width: 230px !important;
  }

  .line {
    position: relative;
    top: -0.06em;
    box-sizing: border-box;
    display: inline-block;
    width: 1px;
    height: 0.9em;
    padding: 0;
    margin: 0 8px;
    font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
      Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
    font-size: 14px;
    line-height: 1.5;
    color: #515a6e;
    vertical-align: middle;
    list-style: none;
    background: #e8eaec;
  }

  :deep() {
    .el-input {
      width: 180px;

      &:first-child {
        margin-right: 10px;
        margin-bottom: 10px;
      }

      & + .el-input {
        margin-right: 10px;
        margin-bottom: 10px;
        margin-left: 0;
      }
    }

    .el-textarea {
      width: 180px;
    }

    .el-select {
      .el-input {
        width: 90px;
        margin-bottom: 0;
      }
    }
  }

  .line2 {
    display: -webkit-box;
    // color: #343434;
    overflow: hidden;
    font-weight: bold;
    -o-text-overflow: ellipsis;
    text-overflow: ellipsis;
    word-break: break-all;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
  }

  .boxcontent {
    border-style: solid;
    border-width: 1px;
    height: 28px;
    padding: 4px 8px;
    border-radius: 2.5px;
    font-size: 12px;
    margin: 5px 0;
  }

  .blue {
    color: #1890ff;
    background-color: #e8f4ff;
    border-color: #d1e9ff;
  }

  .red {
    color: #ff4d4f;
    background-color: #ffeded;
    border-color: #ffdbdc;
  }

  .green {
    color: #13ce66;
    background-color: #e7faf0;
    border-color: #d0f5e0;
  }

  .yellow {
    color: #faa500;
    background-color: #fff6e6;
    border-color: #fff6e6;
  }
</style>
