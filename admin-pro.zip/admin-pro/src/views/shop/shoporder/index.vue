<template>
  <div class="index-container">
    <div class="box">
      <el-alert :closable="false" show-icon title="商品库商品变更商品基础信息或将单规格商品调整成多规格商品将会自动同步至门店；如需修改门店商品价格或库存请在商品模板库调整"
        type="success" />
      <vab-query-form>
        <vab-query-form-top-panel>
          <el-form ref="form" :inline="true" label-width="100px" :model="queryForm" @submit.native.prevent>
            <el-form-item label="商品搜索：">
              <el-input v-model="queryForm.name" class="input-add" placeholder="请输入ID或商品名称" />
            </el-form-item>

            <el-input v-model="input9" placeholder="请输入内容" style="width: 350px">
              <el-select slot="prepend" v-model="keyword_type" placeholder="请选择">
                <el-option label="订单号" :value="1" />
                <el-option label="会员ID" :value="2" />
                <el-option label="会员信息" :value="3" />
                <el-option label="收货信息" :value="4" />
                <el-option label="快递单号" :value="5" />
                <el-option label="商品ID" :value="6" />
                <el-option label="商品名称" :value="7" />
                <el-option label="商品编码" :value="8" />
                <el-option label="核销员" :value="9" />
                <el-option label="所属门店" :value="10" />
              </el-select>
              <!-- <el-button slot="append" /> -->
            </el-input>

            <el-form-item label="商品分类：">
              <el-select v-model="queryForm.cid" class="input-add" filterable placeholder="请选择">
                <el-option v-for="item in options1" :key="item.value" class="input-add" :label="item.label"
                  :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item v-show="!fold" label="商品类型：">
              <el-select v-model="queryForm.gid" class="input-add" filterable placeholder="请选择类型">
                <el-option v-for="item in options2" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item v-show="!fold" label="商品分组：">
              <el-select v-model="queryForm.gid" class="input-add" filterable placeholder="请选择分类">
                <el-option v-for="item in options2" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item v-show="!fold" label="商品状态：">
              <el-select v-model="queryForm.status" class="input-add" filterable placeholder="请选择状态">
                <el-option v-for="item in options3" :key="item.value" class="input-add" :label="item.label"
                  :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
                查询
              </el-button>
              <el-button type="text" @click="handleFold">
                <span v-if="fold">展开</span>
                <span v-else>合并</span>
                <vab-icon class="vab-dropdown" :class="{ 'vab-dropdown-active': fold }" icon="arrow-up-s-line" />
              </el-button>
            </el-form-item>
          </el-form>
        </vab-query-form-top-panel>
        <vab-query-form-left-panel :span="24">
          <el-button @click="handleAdd">导入</el-button>
          <el-button @click="handleAdd">导出</el-button>
          <el-button @click="handleAdd">批量发货</el-button>
          <el-button @click="handleAdd">批量打印送货单</el-button>
        </vab-query-form-left-panel>
      </vab-query-form>
    </div>

    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="50" />
      <el-table-column label="商品图片" width="100">
        <template slot-scope="props">
          <!-- <el-form> -->
          <el-image fit="fill" :lazy="true" :src="props.row.goodsdata.grstr.goods_pic" />
          <!-- </el-form> -->
        </template>
      </el-table-column>
      <el-table-column label="商品信息" min-width="200">
        <template slot-scope="props">
          <!-- <el-form> -->
          <!-- <el-form-item> -->
          <el-tooltip :content="props.row.goodsdata.grstr.name" :delay="600" effect="dark" max-width="300"
            :transfer="true">
            <span class="line2">
              {{ props.row.goodsdata.grstr.name }}
            </span>
          </el-tooltip>
          <div>{{ props.row.goodsdata.grstr.ggname }}</div>
          <div>
            {{ props.row.goodsdata.grstr.num }}x{{
              props.row.goodsdata.grstr.sell_price
            }}
          </div>
          <!-- </el-form-item> -->
          <!-- </el-form> -->
        </template>
      </el-table-column>

      <el-table-column label="订单号/下单时间" width="180">
        <template slot-scope="props">
          <!-- <el-form> -->
          <!-- <div>{{ new Date(scope.row.paytime * 1000).toLocaleString() }}</div> -->
          {{ new Date(props.row.createtime * 1000).toLocaleString() }}
          <div>{{ props.row.ordernum }}</div>
          <!-- </el-form> -->
        </template>
      </el-table-column>
      <el-table-column label="实付款" width="100">
        <template slot-scope="props">
          <!-- <el-form> -->
          <div>{{ props.row.product_price }}</div>
          <div>{{ props.row.totalprice }}</div>
          <!-- </el-form> -->
        </template>
      </el-table-column>
      <el-table-column label="收货地址" width="200">
        <template slot-scope="props">

          <div>{{ props.row.linkman }}</div>
          <div>{{ props.row.tel }}</div>
          <div>
            <span>{{ props.row.area }}</span>
            <span>{{ props.row.address }}</span>
          </div>

        </template>
      </el-table-column>
      <el-table-column label="来源" prop="platform" width="100" />
      <el-table-column label="头像昵称" width="100">
        <template slot-scope="props">

          <img :src="props.row.headimg" style="width: 50px; height: 50px" />

        </template>
      </el-table-column>
      <el-table-column label="支付方式" prop="paytype" width="100" />

      <el-table-column label="社区/门店" width="100">
        <template slot-scope="props">

          <span>{{ props.row.mdname }}</span>
          <span>{{ props.row.mdtel }}</span>
          <span>{{ props.row.mdxqname }}</span>

        </template>
      </el-table-column>

      <el-table-column label="配送方式" prop="freight_text" width="150" />
      <el-table-column label="状态" width="100">
        <template slot-scope="props">

          <div v-if="props.row.status == 1">已支付</div>
          <div v-if="props.row.status == 3">已完成</div>
          <div v-if="props.row.status == 2">待发货</div>
          <div v-if="props.row.status == 0">待支付</div>

        </template>
      </el-table-column>
      <el-table-column label="备注" prop="remark" width="150" />
      <el-table-column fixed="right" label="操作" width="220">
        <template slot-scope="scope">
          <div v-if="scope.row.status == 1">
            <a>详情</a>
            <span class="line"></span>
            <a>发货</a>
            <span class="line"></span>
            <a>退款</a>
            <span class="line"></span>
            <el-dropdown type="primary" @command="handleCommand">
              <a>
                更多
                <vab-icon icon="arrow-down-s-line" style="color: #2d8cf0" />
              </a>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="1">送货单</el-dropdown-item>
                <el-dropdown-item command="2">打印小票</el-dropdown-item>
                <el-dropdown-item command="3">付款凭证</el-dropdown-item>
                <el-dropdown-item command="4">转账审核</el-dropdown-item>
                <el-dropdown-item command="5">转账已驳回</el-dropdown-item>
                <el-dropdown-item command="6">订单详情</el-dropdown-item>
                <el-dropdown-item command="7">修改订单</el-dropdown-item>
                <el-dropdown-item command="8">已同步商家</el-dropdown-item>
                <!-- 其他下拉菜单项 -->
              </el-dropdown-menu>
            </el-dropdown>
          </div>
          <div v-if="scope.row.status == 2">
            <a>查物流</a>
            <span class="line"></span>
            <a>核销</a>
            <span class="line"></span>
            <a>退款</a>
            <span class="line"></span>
            <el-dropdown type="primary" @command="handleCommand">
              <a>
                更多
                <vab-icon icon="arrow-down-s-line" style="color: #2d8cf0" />
              </a>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="1">改物流</el-dropdown-item>
                <el-dropdown-item command="2">确认收货</el-dropdown-item>
                <!-- 其他下拉菜单项 -->
              </el-dropdown-menu>
            </el-dropdown>
          </div>
          <div v-if="scope.row.status == 3">
            <a>详情</a>
            <span class="line"></span>
            <a>查物流</a>
            <span class="line"></span>
            <a>删除</a>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { shopOrder } from '@/api/user'
import { doDelete } from '@/api/table'

// import TableEdit from './components/TableEdit'
export default {
  name: 'Shoporder',
  // components: {
  //   TableEdit,
  // },
  data() {
    return {
      options1: [
        { value: '1', label: '全部' },
        { value: '2', label: '分类一' },
        { value: '3', label: '分类二' },
      ],
      options2: [
        { value: '1', label: '全部' },
        { value: '2', label: '最新' },
        { value: '3', label: '热卖' },
        { value: '3', label: '推荐' },
        { value: '3', label: '促销' },
      ],
      options3: [
        { value: '1', label: '全部' },
        { value: '2', label: '已上架' },
        { value: '3', label: '未上架' },
      ],
      keyword_type: 1,
      value1: '',
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      height: this.$baseTableHeight(3) - 30,
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    shopOrder({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    handleAdd() {
      this.$refs['edit'].showEdit()
    },
    handleFold() {
      this.fold = !this.fold
      this.handleHeight()
    },
    handleHeight() {
      if (this.fold) this.height = this.$baseTableHeight(2) - 47
      else this.height = this.$baseTableHeight(3) - 30
    },
    handleDelete(row) {
      if (row.id) {
        this.$baseConfirm('你确定要删除当前项吗', null, async () => {
          const { msg } = await doDelete({ ids: row.id })
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          await this.fetchData()
        })
      } else {
        if (this.selectRows.length > 0) {
          const ids = this.selectRows.map((item) => item.id).join()
          this.$baseConfirm('你确定要删除选中项吗', null, async () => {
            const { msg } = await doDelete({ ids: ids })
            this.$baseMessage(msg, 'success', 'vab-hey-message-success')
            await this.fetchData()
          })
        } else {
          this.$baseMessage('未选中任何行', 'error', 'vab-hey-message-error')
        }
      }
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.shopOrder({
        page: this.page.current,
        limit: val,
      }).then((res) => {
        this.info = res
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.shopOrder({
        page: val,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleClick(row) {
      console.log(row)
    },
    handleCommand(command) {
      if (command === 'close') {
        // 关闭下拉菜单的逻辑
        this.closeDropdown()
      } else {
        // 处理其它命令
        console.log('执行的命令:', command)
        // 根据 command 执行相应的操作
      }
    },
    closeDropdown() {
      // 这里可以添加关闭下拉菜单的逻辑
      // 如果是通过点击页面其它区域来关闭下拉菜单，可以使用点击页面的事件监听器
      // this.$refs.dropdown.doClose(); // 假设您给 el-dropdown 组件添加了 ref="dropdown"
    },
  },
}
</script>

<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 6px;
}

.input-add {
  width: 230px !important;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

:deep() {
  .el-input {
    width: 180px;

    &:first-child {
      margin-right: 10px;
      margin-bottom: 10px;
    }

    &+.el-input {
      margin-right: 10px;
      margin-bottom: 10px;
      margin-left: 0;
    }
  }

  .el-textarea {
    width: 180px;
  }

  .el-select {
    .el-input {
      width: 90px;
      margin-bottom: 0;
    }
  }
}

.line2 {
  display: -webkit-box;

  overflow: hidden;
  -o-text-overflow: ellipsis;
  text-overflow: ellipsis;
  word-break: break-all;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
}
</style>
