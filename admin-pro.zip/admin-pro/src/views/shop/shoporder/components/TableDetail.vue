<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="500px" @close="close">
    <el-form ref="form" label-width="80px" :model="form">
      <el-form-item label="详情">
        <div>{{ form.order }}</div>
      </el-form-item>
      <el-form-item label="下单人">
        <div>{{ form.member }}</div>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="close">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script>
import { doEdit } from '@/api/table'
import { getDetail } from '@/api/user'
export default {
  name: 'TableEdit',
  data() {
    return {
      form: {},
      title: '',
      dialogFormVisible: false,
    }
  },
  created() { },
  methods: {
    showEdit(row) {
      this.title = '订单详情'
      getDetail({ orderid: row.id }).then((res) => {
        this.form = res
      })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    save() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await doEdit(this.form)
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
  },
}
</script>
