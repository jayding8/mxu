<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="800px" @close="close">
    <el-form ref="form" label-width="120px" :model="form">
      <!-- <el-form-item label="详情">
        <div>{{ form.order }}</div>


      </el-form-item> -->

      <div style="border-bottom: 1px dashed #dddddd;padding-bottom: 20px;">
        {{ form.order.linkman }}
        {{ form.order.company }}
        {{ form.order.tel }}

        <div>
          {{ form.order.area }}{{ form.order.address }}
        </div>

      </div>

      <div style="border-bottom: 1px dashed #dddddd;padding: 20px 0;">
        <div class="log-te1">快递公司：{{ form.order.express_com }}</div>
        <div class="log-te1">快递单号：{{ form.order.express_no }}</div>
      </div>

      <div style="margin-left: 0px;">
        <div class="content" v-for="item in form.oglist" :key="index"
          style="display: flex;justify-content: space-between; border-bottom: 1px dashed #dddddd; margin: 20px 0;">
          <div>
            <el-image :src="item.pic" fit="fill" :lazy="true"
              style="width: 72px;height:72px;margin-right: 10px;"></el-image>
          </div>
          <div class="detail">
            <div class="t1">{{ item.name }}</div>
            <div style="color: #ccc;">{{ item.ggname }}</div>

            <div style="display: flex;justify-content: space-between;">
              <div>￥{{ item.sell_price }}</div>
              <div>×{{ item.num }}</div>
            </div>
          </div>
        </div>
      </div>


      <el-form-item label="后台备注">
        <div>{{ form.order.remark ? form.order.remark : '无' }}</div>
      </el-form-item>

      <el-form-item label="下单人">
        <div class="item">
          <el-image :src="form.member.headimg" fit="fill" :lazy="true"></el-image>

          <span class="t2"> {{ form.member.nickname }}
            {{ form.member.realname }} {{ form.member.tel }}</span>
        </div>
      </el-form-item>
      <el-form-item label="会员ID">
        <div>{{ form.member.id }}</div>
      </el-form-item>
      <el-form-item label="订单编号">
        <div>{{ form.order.ordernum }}</div>
      </el-form-item>
      <el-form-item label="下单时间">
        <div>{{ form.order.ordernum }}</div>
      </el-form-item>

      <el-form-item label="支付时间">
        <div>{{ form.order.createtime }}</div>
      </el-form-item>
      <el-form-item label="支付方式">
        <div>{{ form.order.paytype }}</div>
      </el-form-item>
      <el-form-item label="商品金额">
        <div>{{ form.order.product_price }}</div>
      </el-form-item>
      <el-form-item label="配送方式">
        <div>{{ form.order.freight_text }}</div>
      </el-form-item>


      <el-form-item label="配送费/服务费">
        <div>{{ form.order.ordernum }}</div>
      </el-form-item>
      <el-form-item label="实付款">
        <div>{{ form.order.totalprice }}</div>
      </el-form-item>
      <el-form-item label="订单状态">
        <span style="color:#ff8758" v-if="form.order.status == 0">未付款</span>
        <span style="color:#008000" v-if="form.order.status == 1 && form.order.paytypeid == '4'">待发货</span>
        <span style="color:#008000" v-if="form.order.status == 1 && form.order.paytypeid != '4'">已支付</span>
        <span style=" color:#ff4246" v-if="form.order.status == 2">已发货</span>
        <span style="color:#999" v-if="form.order.status == 3">已收货</span>
        <span style="color:#bbb" v-if="form.order.status == 4">已关闭</span>
      </el-form-item>


      <el-form-item label="尾款金额" v-if="form.order.balance_price > 0">
        <div>¥{{ form.order.balance_price }}</div>
      </el-form-item>
      <el-form-item label="尾款状态" v-if="form.order.balance_price > 0">
        <div v-if="form.order.balance_pay_status == 1">已支付</div>
        <div v-if="form.order.balance_pay_status == 0">未支付</div>
      </el-form-item>

      <el-form-item label="退款状态" v-if="form.order.refund_status > 0">
        <span style="color:#999" v-if="form.order.refund_status == 1">审核中,¥{{ form.order.refund_money }}</span>
        <span style="color:#bbb" v-if="form.order.refund_status == 2">已退款,¥{{ form.order.refund_money }}</span>
        <span style="color:#bbb" v-if="form.order.refund_status == 3">已驳回,¥{{ form.order.refund_money }}</span>
      </el-form-item>

      <el-form-item label="审核备注" v-if="form.order.refund_checkremark">
        <div>{{ form.order.refund_checkremark }}</div>
      </el-form-item>

      <el-form-item label="分销奖励" v-if="form.comdata.parent1.mid">

        <div>一级奖励</div>
        <div>
          <el-image :src="form.comdata.parent1.headimg" fit="fill" :lazy="true"></el-image>
          <div>{{ form.comdata.parent1.nickname }}</div>
          <div>{{ form.comdata.parent1.money }}元</div>
          <div v-if="form.comdata.parent1.score">{{ form.comdata.parent1.score }}积分</div>
        </div>

      </el-form-item>

    </el-form>
    <template #footer>

      <el-button type="primary" @click="close">发 货</el-button>
      <el-button @click="close">退 款</el-button>
      <el-button @click="close">删 除</el-button>
      <el-button @click="close">设置备注</el-button>
    </template>
  </el-dialog>
</template>

<script>
import { doEdit } from '@/api/table'
import { getDetail } from '@/api/user'
export default {
  name: 'TableEdit',
  data() {
    return {
      form: {},
      title: '',
      dialogFormVisible: false,
    }
  },
  created() { },
  methods: {
    showEdit(row) {
      this.title = '订单详情'
      getDetail({ orderid: row.id }).then((res) => {
        this.form = res
      })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    save() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await doEdit(this.form)
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
  },
}
</script>
