<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="500px" @close="close">
    <el-form label-width="80px">
      <div v-for="(item, index) in form" :key="index">
        <el-form-item label="快递公司">
          <div>{{ item.express_com }}</div>
        </el-form-item>
        <el-form-item label="快递单号">
          <div>{{ item.express_no }}</div>
        </el-form-item>
      </div>
    </el-form>
    <template #footer>
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="close">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script>
import { doEdit } from '@/api/table'
import { getExpress } from '@/api/user'
export default {
  name: 'TableEdit',
  data() {
    return {
      form: {},
      title: '',
      dialogFormVisible: false,
    }
  },
  created() { },
  methods: {
    showEdit(row) {
      this.title = '查看物流'
      getExpress({ orderid: row.id }).then((res) => {
        this.form = res.data
      })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    save() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await doEdit(this.form)
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
  },
}
</script>
