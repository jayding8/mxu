<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="900" @close="close">
    <el-form ref="form" label-width="120px" :model="form">
      <el-form-item label="商品信息" prop="product">
        <div>{{ form.order_goods }}</div>
      </el-form-item>
      <el-form-item label="订单详情" prop="order">
        <div>{{ form }}</div>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="save">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script>
import { shopOrderEdit, doEdit } from '@/api/user'

export default {
  name: 'TableEdit',
  data() {
    return {
      form: {},
      title: '',
      dialogFormVisible: false,
    }
  },
  created() { },
  methods: {
    showEdit(row) {
      this.title = '修改订单'
      shopOrderEdit(row.id).then((res) => {
        this.form = res.data
      })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    save() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await doEdit(this.form)
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
  },
}
</script>
