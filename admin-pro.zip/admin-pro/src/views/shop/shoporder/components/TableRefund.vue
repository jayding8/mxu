<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="500px" @close="close">
    <el-form ref="form" label-width="80px" :model="form">
      <el-form-item label="订单详情" prop="order">
        <div>{{ form.prolist }}</div>
      </el-form-item>
      <el-form-item label="退款原因" prop="reason">
        <el-input v-model="reason" />
      </el-form-item>
      <el-form-item label="退款金额" prop="money">
        <el-input v-model="money" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="save">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script>
import { refundInit, refund } from '@/api/user'
export default {
  name: 'TableEdit',
  data() {
    return {
      form: {},
      title: '',
      money: '',
      reason: '',
      dialogFormVisible: false,
    }
  },
  created() { },
  methods: {
    showEdit(row) {
      this.title = '退款'
      refundInit({ orderid: row.id }).then((res) => {
        this.form = res
      })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    save() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await refund({
            orderid: this.form.detail.id,
            money: this.money,
            reason: this.reason,
            refundNum: this.form.prolist.map((item) => ({
              ogid: item.id,
              num: item.num
            }))
          })
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
  },
}
</script>
