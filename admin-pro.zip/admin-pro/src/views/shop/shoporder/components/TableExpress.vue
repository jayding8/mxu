<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="500px" @close="close">
    <el-form ref="form" label-width="80px" :model="form">
      <el-form-item label="快递公司" prop="express_com">
        <el-input v-model="form.express_com" />
      </el-form-item>
      <el-form-item label="快递单号" prop="express_no">
        <el-input v-model="form.express_no" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="save">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script>
import { getDetail, sendExpress } from '@/api/user'
export default {
  name: 'TableEdit',
  data() {
    return {
      form: {},
      title: '',
      orderid: '',
      dialogFormVisible: false,
    }
  },
  created() { },
  methods: {
    showEdit(row) {
      this.title = '订单发货'
      getDetail({ orderid: row.id }).then((res) => {
        this.form = res.order
      })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    save() {
      this.$refs['form'].validate(async (valid) => {
        if (valid) {
          const { msg } = await sendExpress({
            orderid: this.orderid,
            ...this.form
          })
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          this.$emit('fetch-data')
          this.close()
        }
      })
    },
  },
}
</script>
