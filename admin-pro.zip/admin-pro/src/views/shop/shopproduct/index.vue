<template>
  <div class="index-container">
    <div class="box">
      <el-alert :closable="false" show-icon title="商品库商品变更商品基础信息或将单规格商品调整成多规格商品将会自动同步至门店；如需修改门店商品价格或库存请在商品模板库调整"
        type="success" />
      <vab-query-form>
        <vab-query-form-top-panel>
          <el-form ref="form" :inline="true" label-width="100px" :model="queryForm" @submit.native.prevent>
            <el-form-item label="商品搜索：">
              <el-input v-model="queryForm.name" class="input-add" placeholder="请输入ID或商品名称" />
            </el-form-item>
            <el-form-item label="商品分类：">
              <el-select v-model="queryForm.cid" class="input-add" filterable placeholder="请选择">
                <el-option v-for="item in options1" :key="item.value" class="input-add" :label="item.label"
                  :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item v-show="!fold" label="商品类型：">
              <el-select v-model="queryForm.gid" class="input-add" filterable placeholder="请选择类型">
                <el-option v-for="item in options2" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item v-show="!fold" label="商品分组：">
              <el-select v-model="queryForm.gid" class="input-add" filterable placeholder="请选择分类">
                <el-option v-for="item in options2" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item v-show="!fold" label="商品状态：">
              <el-select v-model="queryForm.status" class="input-add" filterable placeholder="请选择状态">
                <el-option v-for="item in options3" :key="item.value" class="input-add" :label="item.label"
                  :value="item.value" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
                查询
              </el-button>
              <el-button type="text" @click="handleFold">
                <span v-if="fold">展开</span>
                <span v-else>合并</span>
                <vab-icon class="vab-dropdown" :class="{ 'vab-dropdown-active': fold }" icon="arrow-up-s-line" />
              </el-button>
            </el-form-item>
          </el-form>
        </vab-query-form-top-panel>
        <vab-query-form-left-panel :span="24">
          <el-button type="primary" @click="handleAdd">发布商品</el-button>
          <el-button type="danger" @click="handleDelete($event)">
            删除
          </el-button>
          <el-button @click="handleAdd">导入</el-button>
          <el-button @click="handleAdd">导出</el-button>
          <el-button @click="handleAdd">上架</el-button>
          <el-button @click="handleAdd">下架</el-button>
          <!-- <el-button @click="handleAdd">编辑分类</el-button>
          <el-button @click="handleAdd">同步到商家</el-button>

          <el-button @click="handleAdd">商品复制</el-button>
          <el-button @click="handleAdd">同步商品</el-button>
          <el-button @click="handleAdd">库存录入</el-button>
          <el-button @click="handleAdd">批量改价</el-button> -->
        </vab-query-form-left-panel>
      </vab-query-form>
    </div>




    <div class="box">
      <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column align="center" show-overflow-tooltip type="selection" width="55" />
        <el-table-column align="center" show-overflow-tooltip fixed label="id" prop="id" sortable width="60" />
        <el-table-column align="center" label="商品图" width="80">
          <template slot-scope="props">
            <div style="width: 60px; height: 60px;border-radius: 3px;">
              <img :src="props.row.pic" style="width: 100%; height: 100%;" />
            </div>
          </template>
        </el-table-column>

        <el-table-column label="商品信息" min-width="200">
          <template slot-scope="props">
            <el-tooltip :content="props.row.name" :delay="600" effect="dark" max-width="300" :transfer="true">
              <span class="line2"> <span v-if="props.row.cname" class="red boxcontent">{{ props.row.cname }}</span>{{
                props.row.name }}</span>
            </el-tooltip>
          </template>
        </el-table-column>

        <el-table-column align="center" label="商品售价" prop="sell_price" sortable width="110">
          <template slot-scope="props">
            <span style="color: #1890ff;">￥{{ props.row.sell_price }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="库存" prop="stock" sortable width="110" />
        <el-table-column align="center" label="显示销量" prop="sales" sortable width="110" />
        <el-table-column align="center" label="实际销量" prop="realsalenum" sortable width="110" />
        <el-table-column align="center" label="序号" prop="sales" sortable width="100" />
        <el-table-column align="center" label="创建时间" prop="createtime" sortable width="180">
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="商品状态" width="100">
          <template slot-scope="props">
            <span class="blue boxcontent" v-if="props.row.status == 1">已上架</span>
            <span class="red boxcontent" v-if="props.row.status == 0">未上架</span>
          </template>
        </el-table-column>
        <el-table-column align="center" fixed="right" label="操作" width="200">
          <template slot-scope="scope">
            <el-button type="text" @click="handleClick(scope.row)">查看</el-button>
            <span class="line"></span>
            <el-button type="text" @click="handleEdit(scope.row)">编辑</el-button>
            <span class="line"></span>
            <el-button type="text" @click="handleDetail(scope.row)">删除</el-button>
            <span class="line"></span>
            <!-- <template> -->
            <el-dropdown type="primary" @command="handleCommand($event, scope.row)">
              <el-button type="text">
                更多
                <vab-icon icon="arrow-down-s-line" style="color: #2d8cf0" />
              </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="1">查看链接</el-dropdown-item>
                <el-dropdown-item command="2">复制商品</el-dropdown-item>
                <el-dropdown-item command="3">上/下架商品</el-dropdown-item>
                <!-- <el-dropdown-item command="4">修改价格</el-dropdown-item>
                <el-dropdown-item command="5">库存记录</el-dropdown-item>
                <el-dropdown-item command="6">卡密信息</el-dropdown-item>
                <el-dropdown-item command="7">规格拆分</el-dropdown-item>
                <el-dropdown-item command="8">已同步商家</el-dropdown-item> -->
                <!-- 其他下拉菜单项 -->
              </el-dropdown-menu>
            </el-dropdown>
            <!-- </template> -->
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination :current-page="info.page.current" layout="total, sizes, prev, pager, next, jumper"
        :page-size="info.page.limit" :page-sizes="[10, 20, 1, 2]" :total="info.page.total"
        @current-change="handleCurrentChange" @size-change="handleSizeChange" />
    </div>


    <!-- 此处是弹窗插件 -->
    <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="100px" :model="form"
      :rules="rules">
      <el-form-item label="穿梭框">
        <el-transfer filter-placeholder="请输入城市拼音" filterable />
      </el-form-item>
    </el-form>
    <el-button icon="el-icon-plus" type="primary" @click="handleAdd1">
      导入
    </el-button>
    <daoru ref="edit" />

    <el-button icon="el-icon-plus" type="primary" @click="handleExcel">
      导出
    </el-button>
    <excel ref="excel" />

    <el-button type="primary" @click="handlesj">
      上架
    </el-button>
    <el-button type="primary" @click="handlexj">
      下架
    </el-button>
    <el-button type="primary" @click="handleshowqr">
      链接
    </el-button>
    <showqr ref="showqr" />
    <el-button type="primary" @click="handlecopy">
      商品复制
    </el-button>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import {
  shopProduct,
  productDelete,
  productCopy,
  productStatus,
} from '@/api/user'

import daoru from './components/daoru'
import excel from './components/excel'
import showqr from './components/showqr'

export default {
  name: 'Shopproduct',
  components: {
    daoru, excel, showqr
  },
  data() {
    return {
      options1: [
        { value: '1', label: '全部' },
        { value: '2', label: '分类一' },
        { value: '3', label: '分类二' },
      ],
      options2: [
        { value: '1', label: '全部' },
        { value: '2', label: '最新' },
        { value: '3', label: '热卖' },
        { value: '3', label: '推荐' },
        { value: '3', label: '促销' },
      ],
      options3: [
        { value: '', label: '全部' },
        { value: '1', label: '已上架' },
        { value: '0', label: '未上架' },
      ],
      queryForm: {
        name: '',
        cid: '',
        gid: '',
        status: '',
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      height: this.$baseTableHeight(3) - 30,
      info: {
        page: {
          current: 1,
          limit: 10,
          totle: 0,
        },
      },
      data: [],
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.shopProduct({
      page: this.info.page.current,
      limit: this.info.page.limit,
    }).then((res) => {
      this.info = res
    })
  },
  methods: {
    shopProduct,
    //搜索
    handleQuery() {
      console.log('111111')
      this.shopProduct({
        page: this.info.page.current,
        limit: this.info.page.limit,
        ...this.queryForm,
      }).then((res) => {
        this.info = res
      })
    },
    handleEdit({ id }) {
      this.$router.push({ name: 'productEdit', query: { id: id } })
    },
    handleAdd() {
      this.$router.push({ name: 'productEdit' })
    },
    handleFold() {
      this.fold = !this.fold
      this.handleHeight()
    },
    handleHeight() {
      if (this.fold) this.height = this.$baseTableHeight(2) - 47
      else this.height = this.$baseTableHeight(3) - 30
    },
    handleCopy(id) {
      this.$baseConfirm('你确定要复制吗', null, async () => {
        const { msg } = await productCopy({ id: id })
        this.$baseMessage(msg, 'success', 'vab-hey-message-success')
        await this.shopProduct({
          page: this.info.page.current,
          limit: this.info.page.limit,
          ...this.queryForm,
        }).then((res) => {
          this.info = res
        })
      })
    },
    handleStatus(row) {
      console.log(row.status)
      let st = row.status === 1 ? 0 : 1
      console.log(st)
      this.$baseConfirm('你确定要改变上下架状态吗', null, async () => {
        const { msg } = await productStatus({
          ids: row.id,
          st: st,
        })
        this.$baseMessage(msg, 'success', 'vab-hey-message-success')
        await this.shopProduct({
          page: this.info.page.current,
          limit: this.info.page.limit,
          ...this.queryForm,
        }).then((res) => {
          this.info = res
        })
      })
    },
    handleDelete(row) {
      console.log(row)
      if (row.id) {
        this.$baseConfirm('你确定要删除吗', null, async () => {
          const { msg } = await productDelete({ ids: row.id })
          this.$baseMessage(msg, 'success', 'vab-hey-message-success')
          await this.shopProduct({
            page: this.info.page.current,
            limit: this.info.page.limit,
            ...this.queryForm,
          }).then((res) => {
            this.info = res
          })
        })
      } else {
        if (this.multipleSelection.length > 0) {
          const ids = this.multipleSelection.map((item) => item.id).join()
          this.$baseConfirm('你确定要删除选中项吗', null, async () => {
            const { msg } = await productDelete({ ids: ids })
            this.$baseMessage(msg, 'success', 'vab-hey-message-success')
            await this.shopProduct({
              page: this.info.page.current,
              limit: this.info.page.limit,
              ...this.queryForm,
            }).then((res) => {
              this.info = res
            })
          })
        } else {
          this.$baseMessage('未选中任何行', 'error', 'vab-hey-message-error')
        }
      }
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.page.limit = val
      this.shopProduct({
        page: this.info.page.current,
        limit: val,
      }).then((res) => {
        this.info = res
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.page.current = val
      this.shopProduct({
        page: val,
        limit: this.info.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange(val) {
      console.log(val)
      this.multipleSelection = val
    },
    handleClick(row) {
      console.log(row)
    },
    handleCommand(command, row) {
      if (command === 'close') {
        // 关闭下拉菜单的逻辑
        this.closeDropdown()
      } else {
        // 处理其它命令
        console.log('执行的命令:', command)
        // 根据 command 执行相应的操作
        if (command == '2') {
          this.handleCopy(row.id)
        }
        if (command == '3') {
          this.handleStatus(row)
        }
      }
    },
    closeDropdown() {
      // 这里可以添加关闭下拉菜单的逻辑
      // 如果是通过点击页面其它区域来关闭下拉菜单，可以使用点击页面的事件监听器
      // this.$refs.dropdown.doClose(); // 假设您给 el-dropdown 组件添加了 ref="dropdown"
    },



    handleAdd1() {
      this.$refs['edit'].showEdit()
    },
    handleExcel() {
      this.$refs['excel'].showEdit()
    },
    handlesj() {
      this.$baseConfirm(
        '确定要上架吗?',
        null,
        () => {
          /* 可以写回调; */
        },
        () => {
          /* 可以写回调; */
        }
      )
    },
    handlexj() {
      this.$baseConfirm(
        '确定要下架吗?',
        null,
        () => {
          /* 可以写回调; */
        },
        () => {
          /* 可以写回调; */
        }
      )
    },
    handlecopy() {
      this.$baseConfirm(
        '确定要复制该商品吗?',
        null,
        () => {
          /* 可以写回调; */
        },
        () => {
          /* 可以写回调; */
        }
      )
    },


    handleshowqr() {
      this.$refs['showqr'].showEdit()
    },



  },
}
</script>

<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 6px;
}

.input-add {
  width: 230px !important;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.line2 {
  display: -webkit-box;

  overflow: hidden;
  -o-text-overflow: ellipsis;
  text-overflow: ellipsis;
  word-break: break-all;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.boxcontent {
  border-style: solid;
  border-width: 1px;
  height: 28px;
  padding: 4px 8px;
  border-radius: 2.5px;
  font-size: 12px;
}

.blue {
  color: #1890ff;
  background-color: #e8f4ff;
  border-color: #d1e9ff;

}

.red {
  color: #ff4d4f;
  background-color: #ffeded;
  border-color: #ffdbdc;
}
</style>
