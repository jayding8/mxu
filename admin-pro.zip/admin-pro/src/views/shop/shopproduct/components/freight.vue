<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="1000px" @close="close">
    <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column fixed label="ID" prop="id" sortable width="80" align="center" />
      <el-table-column fixed label="名称" prop="name" width="100" align="center" />
      <el-table-column label="配送方式" width="100" align="center">
        <template slot-scope="props">
          <el-form>
            <span v-if="props.row.pstype == '0'">普通快递</span>
            <span v-if="props.row.pstype == '1'">到店自提</span>
            <span v-if="props.row.pstype == '2'">同城配送</span>
            <span v-if="props.row.pstype == '5'">门店配送</span>
            <span v-if="props.row.pstype == '10'">货运托运</span>
            <span v-if="props.row.pstype == '11'">物流配送</span>
            <span v-if="props.row.pstype == '12'">平台跑腿</span>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="区域及价格" align="center">
        <template slot-scope="props">
          <el-form>
            <div v-html="props.row.pricedatahtml"></div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="满额包邮" width="100" align="center">
        <template slot-scope="props">
          <el-form>
            <span v-if="props.row.freeset == '0' || props.row.pstype == '1'">
              不开启
            </span>
            <span v-if="props.row.freeset == '1'">
              满{{ props.row.free_price }}元包邮
            </span>
          </el-form>
        </template>
      </el-table-column>

      <!-- <el-table-column label="序号" prop="sort" sortable width="80" align="center" /> -->

      <el-table-column label="状态" width="100" align="center">
        <template slot-scope="props">
          <el-form>
            <div v-if="props.row.status == 1">开启</div>
            <div v-else>关闭</div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column fixed="right" label="操作" width="80" align="center">
        <template slot-scope="scope">
          <el-button size="small" type="text" @click="choose(scope.row)">选择</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit" :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>
  </el-dialog>
</template>

<script>
// import { addcareedit } from '@/api/user'
import { Freight } from '@/api/set'
export default {

  name: 'freight',
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      title: '',
      dialogFormVisible: false,
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }

  },
  mounted() {

  },
  beforeDestroy() {

  },
  created() {
    this.Freight({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    showEdit(row) {
      this.title = '配送模板'
      // addcareedit(row.id).then((res) => {
      //   this.form = res.data
      // })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    choose(row) {
      this.$emit('addFreightData', row);
      this.close();
    },
    Freight,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Freight({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Freight({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}
</style>
