<template>
  <div>
    <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="100px" :model="data">
      <!-- <el-form-item label="" prop="commissionset"> -->
      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span>分销设置</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.commissionset">
            <el-radio style="height: 40px;margin-top: 10px;" :label="0">按照会员等级</el-radio>
            <el-radio :label="1">设置提成比例</el-radio>
            <el-radio :label="2">设置提成金额</el-radio>
            <el-radio :label="3">分销送积分</el-radio>
            <el-radio :label="7">分销按比例送积分</el-radio>
            <el-radio :label="5">比例+积分</el-radio>
            <el-radio :label="6">金额+积分</el-radio>
            <el-radio :label="-1">不参与分销</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item>
          <div v-if="data.info.commissionset == 0">按照会员等级：按照会员等级中设置的提成比例进行提成分配，提成=对应会员等级的提成比例×销售价×购买数量</div>
          <div v-if="data.info.commissionset == 1">单独设置提成比例：按照单独设置的提成比例进行提成分配，提成=设置的百分比×销售价×购买数量</div>
          <div v-if="data.info.commissionset == 2">单独设置提成金额：按照单独设置的提成金额进行提成分配，提成=提成金额×购买数量</div>
          <div v-if="data.info.commissionset == 3">分销送积分：分销提成不给销售奖励而是给积分，得到的积分=提成积分×购买数量</div>
          <div v-if="data.info.commissionset == 7">分销按比例送积分：分销提成不给佣金而是给积分，得到的积分=设置的百分比×销售价×购买数量，四舍五入取整</div>
        </el-form-item>

        <div v-for="item in data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 1">
          <!-- 单独设置提成比例 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(%)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-for="item in data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 2">
          <!-- 单独设置提成金额 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(元)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-if="data.info.commissionset == 2">
          <!-- 单独设置提成金额 -->
          <el-form-item label="逢单奖励" size="normal">
            <el-input v-model="input7" placeholder="数值" size="normal" clearable style="width: 200px;"></el-input>
            <span style="margin-left: 20px;">即尾数为第几单给奖励,用英文逗号","分割,如:3,6,9</span>
          </el-form-item>
        </div>

        <div v-for="item in data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 3">
          <!-- 分销送积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-for="item in data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 5">
          <!-- 提成比例+积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(%)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-for="item in data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 6">
          <!-- 提成金额+积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(元)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-if="data.info.commissionset == 6">
          <!-- 单独设置提成金额 -->
          <el-form-item label="逢单奖励" size="normal">
            <el-input v-model="input7" placeholder="数值" size="normal" clearable style="width: 200px;"></el-input>
            <span style="margin-left: 20px;">即尾数为第几单给奖励,用英文逗号","分割,如:3,6,9</span>
          </el-form-item>
        </div>
        <div v-for="item in data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 7">
          <!-- 分销比例送积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分%)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
      </el-card>

      <!-- <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span>提成平级奖</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.commission_parent_pj_status">
            <el-radio style="height: 40px;margin-top: 10px;" :label="0">按照会员等级</el-radio>
            <el-radio :label="1">单独设置</el-radio>
            <el-radio :label="-1">关闭</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.commission_parent_pj_status == 1">
          <el-form-item label="配置" size="normal">
            <div style="display: flex;">
              <el-input v-model="input7" placeholder="级数" style="width: 200px;margin-right: 20px;">
                <template slot="prepend">平级级数</template>
              </el-input>
              <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                <template slot="prepend">平级奖(元)</template>
              </el-input>
              <el-input v-model="input7" placeholder="比例" style="width: 250px;margin-right: 20px;">
                <template slot="prepend">支付金额比例(%)</template>
              </el-input>
            </div>
          </el-form-item>
        </div>
      </el-card> -->

      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span>平级奖</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.commissionpingjiset">
            <el-radio :label="0">按照会员等级</el-radio>
            <el-radio :label="1">设置提成比例</el-radio>
            <el-radio :label="2">设置提成金额</el-radio>
            <el-radio :label="-1">不参与平级奖</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.commissionpingjiset == 1">
          <div v-for="(item, index) in data.aglevellist" :key="index">
            <!-- 单独设置提成比例 -->
            <el-form-item size="normal">
              <el-input v-model="commissionpingjidata1[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>
            </el-form-item>
          </div>
        </div>
        <div v-if="data.info.commissionpingjiset == 2">
          <div v-for="(item, index) in data.aglevellist" :key="index">
            <!-- 单独设置提成比例 -->
            <el-form-item size="normal">
              <el-input v-model="commissionpingjidata2[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>
            </el-form-item>
          </div>
        </div>

      </el-card>

      <!-- <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div style="display: flex;justify-content: space-between;">
            <span>直推平级奖</span><span>推荐相同等级会员购物奖励</span>
          </div>
        </template>

        <div v-for="item in   data.levellist  " :key="index">
          <el-form-item size="normal">
            <el-input v-model="input7" placeholder="金额" style="width: 400px;margin-right: 20px;">
              <template slot="prepend">{{ item.name }}推荐{{ item.name }}</template>
              <template slot="append">元</template>
            </el-input>
          </el-form-item>
        </div>
      </el-card> -->


      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span style="color: red;">团队分红</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.teamfenhongset">
            <el-radio :label="0">按照会员等级</el-radio>
            <el-radio :label="1">设置提成比例</el-radio>
            <el-radio :label="2">设置提成金额</el-radio>
            <el-radio :label="-1">不参与分红</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.teamfenhongset == 1">
          <div v-for="(item, index) in data.teamlevellist" :key="index">
            <!-- 单独设置提成比例 -->
            <el-form-item size="normal">
              <el-input v-model="teamfenhongdata1[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>
            </el-form-item>
          </div>
        </div>
        <div v-if="data.info.teamfenhongset == 2">
          <div v-for=" (item, index) in data.teamlevellist" :key="index">
            <!-- 单独设置提成比例 -->
            <el-form-item size="normal">
              <el-input v-model="teamfenhongdata2[item.id].commission" placeholder="金额"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>
            </el-form-item>
          </div>
        </div>
      </el-card>


      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span style="color: red;">团队分红平级奖励</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.teamfenhongpjset">
            <el-radio :label="0">按照会员等级</el-radio>
            <el-radio :label="1">设置提成比例</el-radio>
            <el-radio :label="2">设置提成金额</el-radio>
            <el-radio :label="-1">不参与分红</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.teamfenhongpjset == 1">
          <div v-for="(item, index) in data.teampjlevellist" :key="index">
            <!-- 比例 -->
            <el-form-item size="normal">
              <el-input v-model="teamfenhongpjdata1[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>
            </el-form-item>
          </div>
        </div>
        <div v-if="data.info.teamfenhongpjset == 2">
          <div v-for=" (item, index) in data.teampjlevellist" :key="index">

            <!-- 金额 -->
            <el-form-item size="normal">
              <el-input v-model="teamfenhongpjdata2[item.id].commission" placeholder="金额"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>
            </el-form-item>
          </div>
        </div>

      </el-card>


      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span style="color:red">股东分红</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.gdfenhongset">
            <el-radio :label="0">按照会员等级</el-radio>
            <el-radio :label="1">提成比例</el-radio>
            <el-radio :label="2">提成金额</el-radio>
            <el-radio :label="3">积分金额</el-radio>
            <el-radio :label="4">积分比例</el-radio>
            <el-radio :label="-1">不参与</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.gdfenhongset == 1">
          <!-- 单独设置提成比例 -->
          <div style="color:red" v-if="data.gdlevellist == ''">未设置具有股东分红权限的{:t('会员')}等级，请先在[{:t('会员')}]-[等级及分销]设置</div>
          <div v-for="(item, index) in data.gdlevellist" :key="index">
            <!-- 比例 -->
            <el-form-item size="normal">
              <el-input v-model="gdfenhongdata1[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>
            </el-form-item>
          </div>
        </div>
        <div v-if="data.info.gdfenhongset == 2">
          <div style="color:red" v-if="data.gdlevellist == ''">未设置具有股东分红权限的{:t('会员')}等级，请先在[{:t('会员')}]-[等级及分销]设置</div>
          <!-- 单独设置提成比例 -->
          <div v-for="(item, index) in data.gdlevellist" :key="index">
            <el-form-item size="normal">
              <el-input v-model="gdfenhongdata2[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>

            </el-form-item>
          </div>
        </div>
        <div v-if="data.info.gdfenhongset == 3">
          <div style="color:red" v-if="data.gdlevellist == ''">未设置具有股东分红权限的{:t('会员')}等级，请先在[{:t('会员')}]-[等级及分销]设置</div>
          <!-- 单独设置提成金额 -->
          <div v-for="(item, index) in data.gdlevellist" :key="index">
            <el-form-item size="normal">
              <el-input v-model="gdfenhongdata2[item.id].score" placeholder="比例" style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>

            </el-form-item>
          </div>
        </div>
        <div v-if="data.info.gdfenhongset == 4">
          <div style="color:red" v-if="data.gdlevellist == ''">未设置具有股东分红权限的{:t('会员')}等级，请先在[{:t('会员')}]-[等级及分销]设置</div>
          <!-- 单独设置积分比例 -->
          <div v-for="(item, index) in data.gdlevellist" :key="index">
            <el-form-item size="normal">
              <el-input v-model="gdfenhongdata1[item.id].score" placeholder="比例" style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>

            </el-form-item>
          </div>
        </div>

      </el-card>

      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span style="color:red">区域代理分红</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.areafenhongset">
            <el-radio style="height: 40px;margin-top: 10px;" :label="0">按照会员等级</el-radio>
            <el-radio :label="1">提成比例</el-radio>
            <el-radio :label="2">提成金额</el-radio>
            <el-radio :label="4">积分比例</el-radio>
            <el-radio :label="-1">不参与分红</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.areafenhongset == 1">
          <!-- 单独设置提成比例 -->
          <div style="color:red" v-if="data.areafhlevellist == ''">未设置具有股东分红权限的{:t('会员')}等级，请先在[{:t('会员')}]-[等级及分销]设置
          </div>

          <div v-for="(item, index) in data.areafhlevellist" :key="index">

            <el-form-item size="normal">
              <el-input v-model="areafenhongdata1[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>

            </el-form-item>
          </div>
        </div>
        <div v-if="data.info.areafenhongset == 2">
          <!-- 单独设置提成比例 -->
          <div style="color:red" v-if="data.areafhlevellist == ''">未设置具有股东分红权限的{:t('会员')}等级，请先在[{:t('会员')}]-[等级及分销]设置
          </div>

          <div v-for="(item, index) in data.areafhlevellist" :key="index">
            <el-form-item size="normal">
              <el-input v-model="areafenhongdata2[item.id].commission" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>

            </el-form-item>

          </div>
        </div>
        <div v-if="data.info.areafenhongset == 4">
          <!-- 单独设置积分比例 -->
          <div style="color:red" v-if="data.areafhlevellist == ''">未设置具有股东分红权限的{:t('会员')}等级，请先在[{:t('会员')}]-[等级及分销]设置
          </div>

          <div v-for="(item, index) in data.areafhlevellist" :key="index">

            <el-form-item size="normal">
              {{ areafhlevellist }}
              <el-input v-model="areafenhongdata1[item.id].score" placeholder="比例"
                style="width: 200px;margin-right: 20px;">
                <template slot="prepend">{{ item.name }}</template>
              </el-input>

            </el-form-item>
          </div>
        </div>

      </el-card>


    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 团队分红 比例 金额
      teamfenhongdata1: {},
      teamfenhongdata2: {},
      // 团队分红平级奖励  比例 金额 积分
      teamfenhongpjdata1: {},
      teamfenhongpjdata2: {},
      // 股东分红  比例 金额
      gdfenhongdata1: {},
      gdfenhongdata2: {},
      // 区域分红  比例 金额
      areafenhongdata1: {},
      areafenhongdata2: {},
      // 直推平级 比例 金额
      commissionpingjidata1: {},
      commissionpingjidata2: {},
    };
  },
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  created() {
    // 团队分红 比例 金额
    this.teamfenhongdata1 = JSON.parse(this.data.info.teamfenhongdata1)
    this.teamfenhongdata2 = JSON.parse(this.data.info.teamfenhongdata2)
    // 团队分红平级奖励  比例 金额 积分
    this.teamfenhongpjdata1 = JSON.parse(this.data.info.teamfenhongpjdata1)
    this.teamfenhongpjdata2 = JSON.parse(this.data.info.teamfenhongpjdata2)
    // 股东分红  比例 金额
    this.gdfenhongdata1 = JSON.parse(this.data.info.gdfenhongdata1)
    this.gdfenhongdata2 = JSON.parse(this.data.info.gdfenhongdata2)
    //  区域分红  比例 金额
    this.areafenhongdata1 = JSON.parse(this.data.info.areafenhongdata1)
    this.areafenhongdata2 = JSON.parse(this.data.info.areafenhongdata2)
    //  直推平级 比例 金额
    this.commissionpingjidata1 = JSON.parse(this.data.info.commissionpingjidata1)
    this.commissionpingjidata2 = JSON.parse(this.data.info.commissionpingjidata2)
  },
  methods: {

  }
};
</script>
<style scoped>
.input-new-spec {
  width: 120px;
  margin-right: 10px;
}
</style>