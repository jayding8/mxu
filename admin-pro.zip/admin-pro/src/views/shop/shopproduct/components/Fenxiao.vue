<template>
  <div>
    <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="100px" :model="data"
      :rules="rules">
      <!-- <el-form-item label="" prop="commissionset"> -->
      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span>分销设置</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.commissionset">
            <el-radio style="height: 40px;margin-top: 10px;" :label="0">按照会员等级</el-radio>
            <el-radio :label="1">设置提成比例</el-radio>
            <el-radio :label="2">设置提成金额</el-radio>
            <el-radio :label="3">分销送积分</el-radio>
            <el-radio :label="7">分销按比例送积分</el-radio>
            <el-radio :label="5">比例+积分</el-radio>
            <el-radio :label="6">金额+积分</el-radio>
            <el-radio :label="-1">不参与分销</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item>
          <div v-if="data.info.commissionset == 0">按照会员等级：按照会员等级中设置的提成比例进行提成分配，提成=对应会员等级的提成比例×销售价×购买数量</div>
          <div v-if="data.info.commissionset == 1">单独设置提成比例：按照单独设置的提成比例进行提成分配，提成=设置的百分比×销售价×购买数量</div>
          <div v-if="data.info.commissionset == 2">单独设置提成金额：按照单独设置的提成金额进行提成分配，提成=提成金额×购买数量</div>
          <div v-if="data.info.commissionset == 3">分销送积分：分销提成不给销售奖励而是给积分，得到的积分=提成积分×购买数量</div>
          <div v-if="data.info.commissionset == 7">分销按比例送积分：分销提成不给佣金而是给积分，得到的积分=设置的百分比×销售价×购买数量，四舍五入取整</div>
        </el-form-item>

        <div v-for="item in   data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 1">
          <!-- 单独设置提成比例 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(%)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-for="item in   data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 2">
          <!-- 单独设置提成金额 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(元)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-if="data.info.commissionset == 2">
          <!-- 单独设置提成金额 -->
          <el-form-item label="逢单奖励" size="normal">
            <el-input v-model="input7" placeholder="数值" size="normal" clearable style="width: 200px;"></el-input>
            <span style="margin-left: 20px;">即尾数为第几单给奖励,用英文逗号","分割,如:3,6,9</span>
          </el-form-item>
        </div>

        <div v-for="item in   data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 3">
          <!-- 分销送积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-for="item in   data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 5">
          <!-- 提成比例+积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(%)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-for="item in   data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 6">
          <!-- 提成金额+积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(元)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(元)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="数值" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-if="data.info.commissionset == 6">
          <!-- 单独设置提成金额 -->
          <el-form-item label="逢单奖励" size="normal">
            <el-input v-model="input7" placeholder="数值" size="normal" clearable style="width: 200px;"></el-input>
            <span style="margin-left: 20px;">即尾数为第几单给奖励,用英文逗号","分割,如:3,6,9</span>
          </el-form-item>
        </div>
        <div v-for="item in   data.levellist  " :key="index" v-if="item.can_agent !== 0 && data.info.commissionset == 7">
          <!-- 分销比例送积分 -->
          <el-form-item :label="item.name" size="normal">
            <div style="display: flex;">
              <div>
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">一级(积分%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 1">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">二级(积分%)</template>
                </el-input>
              </div>
              <div v-if="item.can_agent > 2">
                <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                  <template slot="prepend">三级(积分%)</template>
                </el-input>
              </div>
            </div>
          </el-form-item>
        </div>
      </el-card>

      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span>提成平级奖</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.commission_parent_pj_status">
            <el-radio style="height: 40px;margin-top: 10px;" :label="0">按照会员等级</el-radio>
            <el-radio :label="1">单独设置</el-radio>
            <el-radio :label="-1">关闭</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.commission_parent_pj_status == 1">
          <!-- 单独设置提成比例 -->
          <el-form-item label="配置" size="normal">
            <div style="display: flex;">
              <el-input v-model="input7" placeholder="级数" style="width: 200px;margin-right: 20px;">
                <template slot="prepend">平级级数</template>
              </el-input>
              <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
                <template slot="prepend">平级奖(元)</template>
              </el-input>
              <el-input v-model="input7" placeholder="比例" style="width: 250px;margin-right: 20px;">
                <template slot="prepend">支付金额比例(%)</template>
              </el-input>
            </div>
          </el-form-item>
        </div>
      </el-card>

      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div>
            <span>平级奖</span>
          </div>
        </template>
        <el-form-item label="类型">
          <el-radio-group v-model="data.info.commissionpingjiset">
            <el-radio style="height: 40px;margin-top: 10px;" :label="0">按照会员等级</el-radio>
            <el-radio :label="1">设置提成比例</el-radio>
            <el-radio :label="2">设置提成金额</el-radio>
            <el-radio :label="-1">不参与平级奖</el-radio>
          </el-radio-group>
        </el-form-item>
        <div v-if="data.info.commissionpingjiset == 1" v-for="item in   data.levellist  " :key="index">
          <!-- 单独设置提成比例 -->
          <el-form-item size="normal">
            <el-input v-model="input7" placeholder="比例" style="width: 200px;margin-right: 20px;">
              <template slot="prepend">{{ item.name }}</template>
            </el-input>
          </el-form-item>
        </div>
        <div v-if="data.info.commissionpingjiset == 2" v-for="item in   data.levellist  " :key="index">
          <!-- 单独设置提成比例 -->
          <el-form-item size="normal">
            <el-input v-model="input7" placeholder="金额" style="width: 200px;margin-right: 20px;">
              <template slot="prepend">{{ item.name }}</template>
            </el-input>
          </el-form-item>
        </div>

      </el-card>

      <el-card shadow="hover" :body-style="{ padding: '20px' }">
        <template #header>
          <div style="display: flex;justify-content: space-between;">
            <span>直推平级奖</span><span>推荐相同等级会员购物奖励</span>
          </div>
        </template>

        <div v-for="item in   data.levellist  " :key="index">
          <!-- 单独设置提成比例 -->
          <el-form-item size="normal">
            <el-input v-model="input7" placeholder="金额" style="width: 400px;margin-right: 20px;">
              <template slot="prepend">{{ item.name }}推荐{{ item.name }}</template>
              <template slot="append">元</template>
            </el-input>
          </el-form-item>
        </div>
      </el-card>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
    };
  },
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  methods: {

  }
};
</script>
<style scoped>
.input-new-spec {
  width: 120px;
  margin-right: 10px;
}
</style>