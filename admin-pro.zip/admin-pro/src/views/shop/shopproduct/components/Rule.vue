<template>
  <div class="sku-list">
    <template v-if="!disabled">
      <div class="sku-list-head">
        <el-button type="primary" size="mini" @click="addSkuRow">添加规格</el-button>
      </div>
      <div class="sku-list-item" v-for="(item, index) in skuData.attrList" :key="index">
        <div class="sku-list-item-main">
          <div class="sku-list-item__layout">
            <span class="span">规格名</span>
            <el-input size="small" v-model="item.attrName" class="input"></el-input>
          </div>
          <div class="sku-list-item__layout">
            <span class="span">规格值</span>
            <div class="sku-list-item-tags">
              <el-tag class="sku-list-item-tag" closable @close="removeSkuAttr(index, i)"
                v-for="(subitem, i) in item.attrValue" :key="i">{{ subitem.attrValue }}</el-tag>
              <el-button size="small" icon="el-icon-plus" @click="addSkuAttr(index)">添加</el-button>
            </div>
          </div>
        </div>
        <el-button type="text" size="small" class="sku-list-item-removeBtn"
          @click="removeSkuRow(index)">删除规格</el-button>
      </div>
      <div class="sku-list-head">
        <el-button type="primary" size="mini" @click="refreshTable">刷新规格项目表</el-button>
        <el-button type="primary" size="mini" @click="addlvpriceset"><span v-if="lvpriceset == 1">关闭会员价</span> <span
            v-if="lvpriceset == 0">开启会员价</span></el-button>
      </div>
    </template>

    <el-table border :data="data.newgglist" :span-method="mergeCells">
      <el-table-column label="规格名称" align="center" prop="name" v-if="!skuData.attrList.length"></el-table-column>
      <template v-else>
        <el-table-column :label="item.attrName" align="center" prop="index" v-for="(item, index) in skuData.attrList"
          :key="index"></el-table-column>
      </template>
      <el-table-column label="商品编号" align="center">
        <template slot-scope="scope">
          <el-input v-model="scope.row.barcode" />
        </template>
      </el-table-column>
      <el-table-column label="市场价(元)" align="center">
        <template slot-scope="scope">
          <el-input :readonly="disabled" v-model="scope.row.market_price"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="成本价(元)" align="center">
        <template slot-scope="scope">
          <el-input v-model="scope.row.cost_price" :precision="2" :min="0.01" />
        </template>
      </el-table-column>
      <el-table-column label="销售价(元)" align="center" v-if="lvpriceset == 0">
        <template slot-scope="scope">
          <el-input :readonly="disabled" v-model="scope.row.sell_price"></el-input>
        </template>
      </el-table-column>
      <el-table-column :label="item.name + '（元）'" align="center" v-if="lvpriceset == 1" v-for="item in data.levellist  "
        :key="index">
        <template slot-scope="scope">
          <el-input :readonly="disabled" v-model="scope.row.lvprice_data[item.id]"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="重量(克)" align="center">
        <template slot-scope="scope">
          <el-input v-model="scope.row.weight" />
        </template>
      </el-table-column>
      <el-table-column label="库存" align="center">
        <template slot-scope="scope">
          <el-input v-model="scope.row.stock" />
        </template>
      </el-table-column>
      <el-table-column label="赠积分(个)" align="center">
        <template slot-scope="scope">
          <el-input :readonly="disabled" v-model="scope.row.givescore"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="图片" align="center">
        <template slot-scope="scope">
          <!-- <image :src="scope.row.pic" /> -->
          <el-image :src="scope.row.pic" fit="fill"></el-image>

          <!-- <el-button type="text" size="small">上传</el-button> -->
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<!-- 字段说明 -->
<!-- barcode  [123456789] 规格编号-->
<!-- market_price [123.01] 市场价（元）-->
<!-- cost_price [99.01] 成本价（元）-->
<!-- givescore [1207] 赠积分(个)-->
<!-- sell_price [1001.00] 销售价格-->
<!-- lvprice_data [数组] -->
<!-- weight [998] 重量（克）-->
<!-- stock [899] 库存-->
<!-- pic 图片 -->

<!-- procode [123] -->
<!-- sales [101] -->


<script>
export default {
  model: {
    prop: "skuData",
    event: "changeSku",
  },
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      lvpriceset: 0,
      skuData: {
        attrList: [],
        skuList: [],
        initSkuList: []
      }
    };
  },
  watch: {
    "skuData.attrList": {
      handler() {
        if (!this.disabled) {
          this.$set(this.skuData, "skuList", this.getTable());
        }
      },
      deep: true,
      immediate: true,
    },
  },
  methods: {
    // 添加规格行
    addSkuRow(i) {
      this.skuData.attrList.push({
        attrName: "",
        attrValue: []
      })
      this.$emit("changeSku", this.skuData);
    },
    addlvpriceset() {
      if (this.lvpriceset === 1) {
        // 如果 numprice 为 1，则将其设置为 0
        this.lvpriceset = 0;
      } else {
        // 否则，将其设置为 1
        this.lvpriceset = 1;
      }
    },

    // 删除规格行
    removeSkuRow(i) {
      this.skuData.attrList.splice(i, 1);
      this.$emit("changeSku", this.skuData);
    },
    // 删除规格属性值
    removeSkuAttr(a, b) {
      this.skuData.attrList[a].attrValue.splice(b, 1);
      this.$emit("changeSku", this.skuData);
    },
    // 添加规格属性值
    addSkuAttr(i) {
      this.$prompt("请输入规格值", "添加规格值", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        inputPattern: /\S+/,
        inputErrorMessage: "规格值不能为空",
        closeOnClickModal: false,
      }).then(({ value }) => {
        this.skuData.attrList[i].attrValue.push({
          attrValue: value,
        });
        this.$emit("changeSku", this.skuData);
      });
    },
    onUploadImgSuccess(res, file, row) {
      if (!file) {
        return;
      }
      row.icon = file;
      this.$emit("changeSku", this.skuData);
    },
    getTable() {
      const table = [];
      const attrValueAry = [];
      const arr = [];
      const tmpSkuData = (this.skuData.attrList || []).filter(
        (d) => d.attrName !== "" && d.attrValue.length > 0
      );
      if (!tmpSkuData || tmpSkuData.length === 0) {
        return [];
      }

      tmpSkuData.forEach((item) => {
        attrValueAry.push(item.attrValue);
      });

      function func(skuArr = [], i) {
        for (let j = 0; j < attrValueAry[i].length; j++) {
          if (i < attrValueAry.length - 1) {
            skuArr[i] = attrValueAry[i][j];
            func(skuArr, i + 1);
          } else {
            arr.push([...skuArr, attrValueAry[i][j]]);
          }
        }
      }
      func([], 0);
      arr.forEach((item) => {
        let attrPath = "";
        // const findItem = {};
        // const tableItem = {};
        item.forEach((d, idx) => {
          attrPath += `${tmpSkuData[idx].attrName}:${d.attrValue};`;
        });
        attrPath = attrPath.slice(0, attrPath.length - 1);
        const findItem =
          this.skuData.initSkuList.find((item) => {
            return attrPath.includes(item.attrPath);
          }) || {};

        const tableItem = Object.assign(
          {
            barcode,
            market_price,
            cost_price,
            givescore,
            sell_price,
            lvprice_data,
            weight,
            stock,
            pic
          },
          findItem,
          {
            attrPath,
          }
        );
        table.push(tableItem);
      });
      return table;
    },
    refreshTable() {
      console.log('refreshTable');
      this.getTable()
    },
    mergeCells({ row, column, rowIndex, columnIndex }) {
      console.log(row, column, rowIndex, columnIndex);
    },
  },
};
</script>

<style lang="scss" scoped>
.sku-list {
  &-head {
    margin-bottom: 10px;
  }

  &-item {
    display: flex;
    align-items: center;
    border: 1px solid #eee;
    border-radius: 5px;
    margin-bottom: 20px;
    padding: 20px 50px;
    background-color: #fff;

    &-main {
      flex: 1;
    }

    &-removeBtn {
      margin-left: 20px;
      color: #f56c6c;
    }

    &__layout {
      display: flex;
      align-items: center;
      margin-bottom: 20px;

      &:last-child {
        margin-bottom: 0;
      }

      .input {
        width: 240px;
      }

      .span {
        font-size: 13px;
        font-weight: bold;
        margin-right: 10px;
      }
    }

    &-tags {
      flex: 1;
    }

    &-tag {
      margin-bottom: 10px;
      margin-right: 10px;
    }
  }
}
</style>
