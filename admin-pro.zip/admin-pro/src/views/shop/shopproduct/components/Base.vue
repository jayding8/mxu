<template>
  <div>
    <el-col :span="24">
      <el-form>
        <el-form-item label="商品分类：" prop="cid" size="normal">
          <el-cascader v-model="data.info.cid" clearable filterable :options="treeSelect" placeholder="请选择商品分类"
            :props="props" size="mini" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品名称：" prop="name" size="normal">
          <el-input v-model="data.info.name" clearable placeholder="请输入商品名称" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品副标题：" prop="sellpoint" size="normal">
          <el-input v-model="data.info.sellpoint" clearable placeholder="在商品详情页标题下面展示商品卖点，建议60字以内" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品主图：" size="normal">
          <div class="acea-row">
            <el-image class="pictrue" fit="fill" :lazy="true" :src="data.info.pic" />
            <vab-icon class="btndel" icon="close-line" />
            <div class="upLoad">
              <vab-icon class="icon" icon="camera-2-line" />
            </div>
          </div>
        </el-form-item>
        {{ data.picsArray }}
        <el-form-item label="商品轮播图：" size="normal">
          <div class="acea-row">
            <div v-for="(pic, index) in picsArray" :key="index" class="pictrue">
              <el-image fit="fill" :lazy="true" :src="pic" />
              <vab-icon class="btndel" icon="close-line" @click="removePic(index)" />
            </div>
            <div class="upLoad">
              <vab-icon class="icon" icon="camera-2-line" />
            </div>
          </div>
        </el-form-item>

        <el-form-item label="商品视频：" style="display: flex">
          <div>
            <div class="acea-row">
              <el-image class="pictrue" fit="fill" :lazy="true" :src="data.info.pic" />
              <vab-icon class="btndel" icon="close-line" />
              <div class="upLoad">
                <vab-icon class="icon" icon="camera-2-line" />
              </div>
              <div class="upLoad" style="margin-left: 15px">
                <vab-icon class="icon" icon="chat-upload-line" />
              </div>
            </div>
            <el-input v-model="data.info.video" clearable placeholder="" size="normal" style="width: 400px" />
            <div>
              填写视频链接或上传视频，视频链接必须为mp4格式的源链接，视频大小须在50MB以内
            </div>
          </div>
        </el-form-item>

        <el-form-item label="商品编码：" prop="procode" size="normal">
          <el-input v-model="data.info.procode" clearable placeholder="请输入商品编码" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品条码：" prop="barcode" size="normal">
          <el-input v-model="data.info.barcode" clearable placeholder="请输入商品条码" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品单位：" prop="product_unit" size="normal">
          <el-input v-model="data.info.product_unit" clearable placeholder="请输入商品单位" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品分组：" prop="glist" style="display: flex">
          <el-checkbox-group v-for="(item, index) in data.glist" :key="index" v-model="data.glist">
            <el-checkbox :label="item.id">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="商品服务：" prop="fuwulist" style="display: flex">
          <el-checkbox-group v-for="(item, index) in data.fuwulist" :key="index" v-model="data.fuwulist">
            <el-checkbox :label="item.id">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>

      </el-form>

    </el-col>
  </div>
</template>

<script>
export default {
  name: 'Base',
  data() {



    return {}
  },
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  computed: {
    picsArray() {
      return this.data.info.pics.split(',')
    },
  },
  methods: {
    removePic(index) {
      // 从数组中删除指定索引的图片
      this.$set(this.picsArray, index, null)
      this.picsArray.splice(index, 1)
      console.log('选中的删除图片:', index)
    },
  },

}
</script>


<style lang="scss" scoped>
.acea-row {
  .mr20 {
    margin-right: 20px;
    margin-left: 16px;
    font-size: 16px;
    font-weight: 500;
    line-height: 3.5;
    color: #17233d;
  }

  .pl10 {
    padding-left: 10px;
  }

  .after-line {
    position: relative;
    display: inline-block;
    padding-top: 20px;
    margin-right: 16px;
    font-size: 14px;

    color: rgba(0, 0, 0, 0.85);
  }

  display: flex;

  .after-line:after {
    position: absolute;
    top: 3px;
    right: -16px;
    width: 1px;
    height: 16px;
    margin-top: 18px;
    content: '';
    background: #eee;
  }
}

.upLoad {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 72px;
  height: 72px;

  line-height: 72px;
  cursor: pointer;
  background: rgba(0, 0, 0, 0.02);
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;

  .icon {
    font-size: 24px;
    color: #999999;
  }
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.btndel {
  position: absolute;
  top: -10px;
  left: 140px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue .btndel {
  position: absolute;
  top: -10px;
  left: 58px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.product_type {
  position: relative;
  float: left;
  width: 120px;
  height: 60px;
  padding-top: 8px;
  margin-right: 12px;
  line-height: 23px;
  text-align: center;
  cursor: pointer;
  background: #ffffff;
  border: 1px solid #e7e7e7;
  border-radius: 3px;

  &.on {
    border-color: #1890ff;
  }

  .name {
    font-size: 14px;
    font-weight: 600;
    color: rgba(0, 0, 0, 0.85);
  }

  .title {
    font-size: 12px;
    font-weight: 400;
    color: #999999;
  }

  .jiao {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 0;
    height: 0;
    border-bottom: 26px solid #1890ff;
    border-left: 26px solid transparent;
  }

  .iconfont {
    position: absolute;
    right: 1px;
    bottom: -3px;
    font-size: 12px;
    color: #ffffff;
  }
}

.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
}
</style>
