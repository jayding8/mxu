<template>
  <div>
    <el-col :span="24">
      <el-form>
        <el-form-item label="商品分类：" prop="cid" size="normal">
          <el-cascader v-model="data.info.cid" clearable filterable :options="data.clist" placeholder="请选择商品分类"
            :show-all-levels="false"
            :props="{ value: 'id', label: 'name', children: 'child', checkStrictly: true, multiple: true }" size="mini"
            style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品名称：" prop="name" size="normal">
          <el-input v-model="data.info.name" clearable placeholder="请输入商品名称" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品副标题：" prop="sellpoint" size="normal">
          <el-input v-model="data.info.print_name" clearable placeholder="在商品详情页标题下面展示商品卖点，建议60字以内"
            style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品主图：" size="normal">
          <div class="acea-row">
            <el-image class="pictrue" fit="fill" :lazy="true" :src="data.info.pic" />
            <vab-icon class="btndel" icon="close-line" @click="delMainPic" v-if="data.info.pic" />
            <div class="upLoad" @click="showPicDialog(1)">
              <vab-icon class="icon" icon="camera-2-line" />
            </div>
          </div>
        </el-form-item>
        <el-form-item label="商品轮播图：" size="normal">
          <div class="acea-row">
            <div v-for="(pic, index) in data.info.pics" :key="index" class="pictrue">
              <el-image fit="fill" :lazy="true" :src="pic" />
              <vab-icon class="btndel" icon="close-line" @click="removePic(index)" />
            </div>
            <div class="upLoad" @click="showPicDialog(2)">
              <vab-icon class="icon" icon="camera-2-line" />
            </div>
          </div>
        </el-form-item>

        <el-form-item label="商品视频：" style="display: flex">
          <div>
            <el-input v-model="data.info.video" clearable placeholder="" size="normal" style="width: 400px" />
            <div>
              填写视频链接，视频链接必须为mp4格式的源链接，视频大小须在50MB以内
            </div>
          </div>
        </el-form-item>

        <el-form-item label="商品编码：" prop="procode" size="normal">
          <el-input v-model="data.info.procode" clearable placeholder="请输入商品编码" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品条码：" prop="barcode" size="normal">
          <el-input v-model="data.info.barcode" clearable placeholder="请输入商品条码" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品单位：" prop="product_unit" size="normal">
          <el-input v-model="data.info.product_unit" clearable placeholder="请输入商品单位" style="width: 50%" />
        </el-form-item>
        <el-form-item label="商品分组：" prop="glist" style="display: flex">
          <el-checkbox-group v-model="data.info.gid">
            <el-checkbox v-for="(item, index) in data.glist" :key="index" :label="item.id">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="商品服务" prop="fwid" style="display: flex">
          <el-checkbox-group v-model="data.info.fwid">
            <el-checkbox v-for="(item, index) in data.fuwulist" :key="index" :label="item.id">{{ item.name
              }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>


        <el-form-item label="价格模式" prop="price_type">
          <el-radio-group v-model="data.info.price_type">
            <el-radio :label="0">默认</el-radio>
            <el-radio :label="1">询价</el-radio>
          </el-radio-group>
          <span style="margin-left: 20px; color: #969696">
            默认：展示售价，详情页展示购买和加入购物车，可下单；询价：不设置售价时不展示，详情页展示联系按钮（点击展示系统设置的商家名称和服务电话），不可下单。
          </span>
        </el-form-item>

        <el-form-item label="配送模板" prop="freighttype">
          <el-radio-group v-model="data.info.freighttype">
            <el-radio :label="1">全部模板</el-radio>
            <el-radio :label="0">选择模板</el-radio>
            <el-radio :label="3">自动发货</el-radio>
            <el-radio :label="4">在线卡密</el-radio>
          </el-radio-group>
        </el-form-item>


        <div v-if="data.info.freighttype == 0" style="margin-left: 80px;">
          <el-table border style="width: 100%" :data="data.freightTableData">
            <el-table-column fixed label="模板ID" prop="id" />
            <el-table-column fixed label="模板名称" prop="name" />
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button type="text" size="default" @click="delFreight(scope.$index)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="fr">
            <el-button class="btn" type="text" size="default" @click="handleFreight">添加</el-button>
          </div>
        </div>

        <div v-if="data.info.freighttype == 3 || data.info.freighttype == 4" style="margin-left: 80px;">
          <el-checkbox-button label="必填联系人、手机号信息" v-model="data.info.contact_require"
            style="margin: 10px 0;"></el-checkbox-button><br>
          <el-input v-if="data.info.freighttype == 3" type="textarea" :rows="3" placeholder="请输入内容"
            v-model="data.info.freightcontent" style="margin: 10px 0;width: 450px;">
          </el-input>
          <div v-if="data.info.freighttype == 4" style="margin: 10px 0;">请保存商品信息后在商品列表中上传卡密信息；用户购买几件将发送几个卡密信息</div>
        </div>



        <el-form-item label="积分抵扣" prop="scoredkmaxset">
          <el-radio-group v-model="data.info.scoredkmaxset">
            <el-radio :label="0">按照系统设置抵扣</el-radio>
            <el-radio :label="1">单独设置抵扣比例</el-radio>
            <el-radio :label="2">单独设置抵扣金额</el-radio>
            <el-radio :label="-1">不可用积分抵扣</el-radio>
          </el-radio-group>
          <div v-if="data.info.scoredkmaxset == 1 || data.info.scoredkmaxset == 2"
            style="width: 300px;margin-left: 80px;">
            <el-input placeholder="请输入内容" v-model="data.info.scoredkmaxval">
              <template slot="prepend">{{ data.info.scoredkmaxset == 1 ? '最多抵扣(%)' : '最多抵扣(元)' }}</template>
            </el-input>
          </div>
        </el-form-item>

        <!-- TODO：待接入分销 -->
        <!-- <Fenxiao v-show="activeName === '8'" :data="data" /> -->

        <el-form-item label="销量" prop="sales" size="normal">
          <el-input v-model="data.info.sales" clearable placeholder="0" style="width: 50%" />
        </el-form-item>

        <el-form-item label="起售数量" prop="limit_start" size="normal">
          <el-input v-model="data.info.limit_start" clearable placeholder="0" style="width: 50%" />
          <span style="margin-left: 20px; color: #969696">
            多少件起卖，0表示不限购；整批：单规格数量限制，混批:不同规格总数量限制
          </span>
        </el-form-item>

        <el-form-item label="每人限购" prop="perlimit" size="normal">
          <el-input v-model="data.info.perlimit" clearable placeholder="0" style="width: 50%" />
          <span style="margin-left: 20px; color: #969696">
            每人最多可购买多少件，0表示不限购
          </span>
        </el-form-item>
        <el-form-item label="每单限购" prop="perlimitdan" size="normal">
          <el-input v-model="data.info.perlimitdan" clearable placeholder="0" style="width: 50%" />

          <span style="margin-left: 20px; color: #969696">
            每单最多可购买多少件，0表示不限购
          </span>
        </el-form-item>
        <el-form-item label="序号" prop="sort" size="normal">
          <el-input v-model="data.info.sort" clearable placeholder="0" style="width: 50%" />
          <span style="margin-left: 20px; color: #969696">
            用于排序,越大越靠前
          </span>
        </el-form-item>
        <el-form-item label="显示条件" prop="showtj" style="display: flex">
          <el-checkbox-group v-model="data.info.showtj">
            <el-checkbox :label="-1">所有人</el-checkbox>
            <el-checkbox :label="-2">未登录用户</el-checkbox>
            <el-checkbox :label="0">关注用户</el-checkbox>
            <el-checkbox v-for="(item, index) in data.levellist" :key="index" :label="item.id">{{ item.name
              }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="购买条件" prop="gettj" style="display: flex">
          <el-checkbox-group v-model="data.info.gettj">
            <el-checkbox :label="-1">所有人</el-checkbox>
            <el-checkbox :label="0">关注用户</el-checkbox>
            <el-checkbox v-for="(item, index) in data.levellist" :key="index" :label="item.id">{{ item.name
              }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="data.info.status">
            <el-radio :label="1">已上架</el-radio>
            <el-radio :label="0">未上架</el-radio>
            <el-radio :label="2">设置上架时间</el-radio>
            <el-radio :label="3">设置上架周期</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="上架时间" v-if="data.info.status == 2">
          <el-date-picker v-model="data.info.groundingDate" type="datetimerange" range-separator="至"
            start-placeholder="开始日期" end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="上架周期" v-else-if="data.info.status == 3">
          <el-input v-model="data.info.start_hours" placeholder="开始时间" style="width: 150px;"></el-input>
          <span style="margin: 0 10px;">至</span>
          <el-input v-model="data.info.end_hours" placeholder="结束时间" style="width: 150px;"></el-input>
          <span style="margin-left: 20px; color: #969696">
            结束时间小于或等于开始时间表示跨天,如:16:00到06:00表示下午4点到次日早晨6点
          </span>
        </el-form-item>


      </el-form>
      <freight ref="freight" @addFreightData="addFreightData" />

    </el-col>
    <el-dialog :visible="modalPic" width="960px" title='图片选择' :close-on-click-modal="false" :z-index="1"
      @close="closePicDialog">
      <uploadPictures :isChoice="isChoice" @getPic="getPic" :gridBtn="gridBtn" :gridPic="gridPic" v-if="modalPic">
      </uploadPictures>
    </el-dialog>
  </div>
</template>

<script>
import uploadPictures from '@/components/uploadPictures';
import freight from './freight'
export default {
  name: 'Base',
  components: {
    uploadPictures, freight
  },
  data() {
    return {
      modalPic: false,
      isChoice: '单选',
      gridBtn: {
        xl: 4,
        lg: 8,
        md: 8,
        sm: 8,
        xs: 8
      },
      gridPic: {
        xl: 6,
        lg: 8,
        md: 12,
        sm: 12,
        xs: 12
      },
      type: 1,
    }
  },
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  methods: {
    addPics(pic) {
      this.data.info.pics.push(pic.att_dir)
    },
    removePic(index) {
      // 从数组中删除指定索引的图片
      this.data.info.pics.splice(index, 1)
    },
    delMainPic() {
      this.data.info.pic = '';
    },
    addMainPic(pic) {
      this.data.info.pic = pic.att_dir;
    },
    showPicDialog(type) {
      this.modalPic = true;
      this.type = type;
    },
    closePicDialog() {
      this.modalPic = false;
    },
    getPic(pic) {
      if (this.type == 1) {
        this.addMainPic(pic)
      } else {
        this.addPics(pic)
      }
    },
    handleFreight(data) {
      if (!data) {
        data = {
          line_name: "",
          status: 1,
          remark: "",
        }
      }
      this.$refs['freight'].showEdit(data)
    },
    addFreightData(row) {
      this.data.freightTableData.push(row);
    },
    delFreight(idx) {
      this.data.freightTableData.splice(idx, 1);
    },
  },

}
</script>


<style lang="scss" scoped>
.acea-row {
  .mr20 {
    margin-right: 20px;
    margin-left: 16px;
    font-size: 16px;
    font-weight: 500;
    line-height: 3.5;
    color: #17233d;
  }

  .pl10 {
    padding-left: 10px;
  }

  .after-line {
    position: relative;
    display: inline-block;
    padding-top: 20px;
    margin-right: 16px;
    font-size: 14px;

    color: rgba(0, 0, 0, 0.85);
  }

  display: flex;

  .after-line:after {
    position: absolute;
    top: 3px;
    right: -16px;
    width: 1px;
    height: 16px;
    margin-top: 18px;
    content: '';
    background: #eee;
  }
}

.upLoad {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 72px;
  height: 72px;

  line-height: 72px;
  cursor: pointer;
  background: rgba(0, 0, 0, 0.02);
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;

  .icon {
    font-size: 24px;
    color: #999999;
  }
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.btndel {
  cursor: pointer;
  position: absolute;
  top: -10px;
  left: 140px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue .btndel {
  position: absolute;
  top: -10px;
  left: 58px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.product_type {
  position: relative;
  float: left;
  width: 120px;
  height: 60px;
  padding-top: 8px;
  margin-right: 12px;
  line-height: 23px;
  text-align: center;
  cursor: pointer;
  background: #ffffff;
  border: 1px solid #e7e7e7;
  border-radius: 3px;

  &.on {
    border-color: #1890ff;
  }

  .name {
    font-size: 14px;
    font-weight: 600;
    color: rgba(0, 0, 0, 0.85);
  }

  .title {
    font-size: 12px;
    font-weight: 400;
    color: #999999;
  }

  .jiao {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 0;
    height: 0;
    border-bottom: 26px solid #1890ff;
    border-left: 26px solid transparent;
  }

  .iconfont {
    position: absolute;
    right: 1px;
    bottom: -3px;
    font-size: 12px;
    color: #ffffff;
  }
}

.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
}

.fr {
  border-right: 1px solid #ebeef5;
  border-left: 1px solid #ebeef5;
  border-bottom: 1px solid #ebeef5;
  background: #fff;
  text-align: center;

  .btn {
    color: #1890ff;
  }
}
</style>
