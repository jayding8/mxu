<template>
  <div class="index-container">
    <el-card :body-style="{ padding: '20px' }" shadow="hover">
      <div class="acea-row">
        <router-link :to="{ path: '/admin/product/product_list' }">
          <div class="font-sm after-line">
            <vab-icon icon="arrow-left-s-line" />
            <span class="pl10">返回</span>
          </div>
        </router-link>
        <span class="mr20" v-text="data.info.id ? '编辑' : '添加'"></span>
        <div v-for="(item, index) in productType" :key="index" class="product_type"
          :class="data.info.product_type == item.id ? 'on' : ''" @click="productTypeTap(item.id, item)">
          <div class="name">{{ item.name }}</div>
          <div class="title">({{ item.title }})</div>
          <div v-if="data.info.product_type == item.id" class="jiao"></div>
          <vab-icon v-if="data.info.product_type == item.id" class="iconfont iconduihao" icon="check-line" />
        </div>
      </div>
    </el-card>

    <el-tabs v-model="activeName">
      <el-tab-pane v-for="(item, index) in headTab" :key="index" :label="item.title" :name="item.name" />
    </el-tabs>

    <el-form ref="form" class="box">
      <el-row :gutter="24" type="flex">
        <Base v-if="activeName === '1'" :data="data" />
      </el-row>

      <el-row v-if="activeName === '2'" :gutter="24" type="flex">
        <el-col :span="24">
          <Rule v-if="activeName === '2'" :data="data" />
        </el-col>
      </el-row>
      <el-row v-show="activeName === '3'" :gutter="24" type="flex">
        <el-col :span="24">
          <div>id：{{ id }}商品详情</div>
        </el-col>
      </el-row>
      <!-- <el-row v-show="activeName === '5'" :gutter="24" type="flex">
        <el-col :span="24">
          <div>id：{{ id }}物流设置</div>
        </el-col>
      </el-row> -->
      <el-row v-show="activeName === '5'" :gutter="24" type="flex">
        <el-col :span="24">
          <div>id：{{ id }}营销设置</div>
        </el-col>
      </el-row>
      <el-row v-show="activeName === '6'" :gutter="24" type="flex">
        <el-col :span="24">
          <div>id：{{ id }}其他设置</div>
        </el-col>
      </el-row>
      <el-row v-if="activeName === '8'" :gutter="24" type="flex">
        <el-col :span="24">
          <Fenxiao v-if="activeName === '8'" :data="data" />
        </el-col>
      </el-row>


    </el-form>
    <div class="el-footer"><el-button type="primary" @click="submitForm">立即保存</el-button></div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Base from './components/Base'
import Rule from './components/Rule'
import Fenxiao from './components/Fenxiao'

import { getProductEdit, productSave } from '@/api/shop'

export default {
  name: 'Shopproduct',
  components: {
    Base, Rule, Fenxiao
  },
  data() {
    return {
      id: '',
      activeName: '1', // 默认选中第一个标签页
      currentTab: '', // 当前选中的标签页
      headTab: [
        { title: '基础信息', name: '1' },
        { title: '规格库存', name: '2' },
        { title: '商品参数', name: '3' },
        // { title: '商品限购', name: '4' },
        { title: '商品详情', name: '5' },
        // { title: '门店设置', name: '6' },
        // { title: '营销设置', name: '7' },
        { title: '分销设置', name: '8' },
        // { title: '分红设置', name: '9' },
        { title: '分享设置', name: '10' },
      ],
      productType: [
        { name: '普通商品', title: '物流发货', id: 0 },
        // { name: '眼镜商品', title: '自动发货', id: 1 },
        // { name: '称重商品', title: '虚拟发货', id: 3 },
        // { name: '手工活商品', title: '到店核销', id: 4 },
        { name: '批发商品', title: '到店核销', id: 5 },
        // { name: '分期商品', title: '分期商品', id: 6 },
        // { name: '启用多单位', title: '启用多单位', id: 7 },
        // { name: '押金商品', title: '桶装水、菜筐', id: 8 },
      ],
      data: {
        info: {
          // 确保这里有一个产品类型的属性，例如
          product_type: '1',
          pics: '',
        },
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
    picsArray() {
      return this.data.info.pics.split(',')
    },
  },
  watch: {
    $route() {
      if (this.$route.query.id) {
        this.id = this.$route.query.id
        this.getProductEdit(this.id).then((res) => {
          this.data = res.data
        })
      }
    },
  },
  created() {
    this.id = this.$route.query.id
    this.getProductEdit(this.id).then((res) => {
      this.data = res.data
    })
    this.picsArray = this.data.info.pics.split(',')
  },
  methods: {
    getProductEdit,
    submitForm() {
      const data = {
        id: this.id,
        ...this.data,
      }
      productSave(data)
    },
    onhangeTab(name) {
      ; (this.currentTab = name), console.log(this.currentTab)
    },
    productTypeTap(id, item) {
      // 这里应该是处理商品类型点击的逻辑
      // 例如，更新选中的商品类型 ID
      this.data.info.product_type = id
      console.log('选中的商品类型 ID:', id)
      // 可能还需要其他逻辑处理
    },
  },
}
</script>

<style lang="scss" scoped>
.acea-row {
  .mr20 {
    margin-right: 20px;
    margin-left: 16px;
    font-size: 16px;
    font-weight: 500;
    line-height: 3.5;
    color: #17233d;
  }

  .pl10 {
    padding-left: 10px;
  }

  .after-line {
    position: relative;
    display: inline-block;
    padding-top: 20px;
    margin-right: 16px;
    font-size: 14px;

    color: rgba(0, 0, 0, 0.85);
  }

  display: flex;

  .after-line:after {
    position: absolute;
    top: 3px;
    right: -16px;
    width: 1px;
    height: 16px;
    margin-top: 18px;
    content: '';
    background: #eee;
  }
}

.upLoad {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 72px;
  height: 72px;

  line-height: 72px;
  cursor: pointer;
  background: rgba(0, 0, 0, 0.02);
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;

  .icon {
    font-size: 24px;
    color: #999999;
  }
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.btndel {
  position: absolute;
  top: -10px;
  left: 140px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue .btndel {
  position: absolute;
  top: -10px;
  left: 58px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.product_type {
  position: relative;
  float: left;
  width: 120px;
  height: 60px;
  padding-top: 8px;
  margin-right: 12px;
  line-height: 23px;
  text-align: center;
  cursor: pointer;
  background: #ffffff;
  border: 1px solid #e7e7e7;
  border-radius: 3px;

  &.on {
    border-color: #1890ff;
  }

  .name {
    font-size: 14px;
    font-weight: 600;
    color: rgba(0, 0, 0, 0.85);
  }

  .title {
    font-size: 12px;
    font-weight: 400;
    color: #999999;
  }

  .jiao {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 0;
    height: 0;
    border-bottom: 26px solid #1890ff;
    border-left: 26px solid transparent;
  }

  .iconfont {
    position: absolute;
    right: 1px;
    bottom: -3px;
    font-size: 12px;
    color: #ffffff;
  }
}

.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
}
</style>
