<template>
  <div class="index-container">
    <vab-query-form>
      <vab-query-form-left-panel :span="4">
        <el-button type="primary" @click="handleAdd">录入库存</el-button>
        <el-button type="primary" @click="handleAdd">导出EXCEL</el-button>
      </vab-query-form-left-panel>

      <vab-query-form-right-panel :span="20">
        <el-form
          ref="form"
          class="box"
          :inline="true"
          label-width="76px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="商品ID">
            <el-input v-model="queryForm.title" placeholder="请输入商品ID" />
          </el-form-item>
          <el-form-item label="商品名称">
            <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
          </el-form-item>

          <el-form-item label="时间">
            <el-date-picker
              v-model="value2"
              end-placeholder="结束日期"
              range-separator="至"
              start-placeholder="开始日期"
              type="datetimerange"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
              @click="handleQuery"
            >
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-right-panel>
    </vab-query-form>
    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="商品id" prop="id" width="80" />

      <el-table-column label="商品信息">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.pic" style="height: 50px; width: 50px" />
            <div>{{ props.row.name }}</div>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="商品规格" prop="ggname" width="150" />
      <el-table-column label="变更库存" prop="stock" width="150" />
      <el-table-column label="变更后剩余" prop="afterstock" width="150" />
      <el-table-column label="操作人" prop="uname" width="100" />

      <el-table-column label="变更时间" prop="createtime" width="200" />
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { shopStock } from '@/api/shop'
  export default {
    name: 'Shopstock',
    data() {
      return {
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.shopStock({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      shopStock,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.shopStock({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.shopStock({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped></style>
