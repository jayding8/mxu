<template>
  <div class="index-container">
    <vab-query-form>
      <vab-query-form-left-panel :span="10">
        <el-button
          icon="el-icon-delete"
          type="danger"
          @click="handleDelete($event)"
        >
          删除
        </el-button>
        <el-button type="primary" @click="handleAdd">已审</el-button>
        <el-button type="primary" @click="handleAdd">未审</el-button>
      </vab-query-form-left-panel>

      <vab-query-form-right-panel :span="14">
        <el-form
          ref="form"
          class="box"
          :inline="true"
          label-width="76px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="评价内容">
            <el-input v-model="queryForm.title" placeholder="请输入关键字" />
          </el-form-item>

          <el-form-item label="评价时间">
            <el-date-picker
              v-model="value2"
              end-placeholder="结束日期"
              range-separator="至"
              start-placeholder="开始日期"
              type="datetimerange"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
              @click="handleQuery"
            >
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-right-panel>
    </vab-query-form>
    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="80" />

      <el-table-column label="商品信息" width="250">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.propic" style="height: 50px; width: 50px" />
            <div>{{ props.row.proname }}</div>
            <div>{{ props.row.ggname }}</div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="评价人信息" width="180">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.headimg" style="height: 50px; width: 50px" />
            <span>{{ props.row.nickname }}</span>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="评分" width="180">
        <template slot-scope="props">
          <el-rate
            v-model="props.row.score"
            disabled
            score-template="{value}"
            show-score
            text-color="#ff9900"
          />
        </template>
      </el-table-column>

      <el-table-column label="评价内容" prop="content" />
      <el-table-column label="评价时间" prop="createtime" width="200" />
      <el-table-column label="状态" width="120">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span v-if="props.row.status == 0">未审核</span>
              <span v-if="props.row.status == 1">已审核</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="200">
        <template>
          <el-button size="small" type="text">查看</el-button>
          <el-button size="small" type="text">回复</el-button>
          <el-button size="small" type="text">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { shopComment } from '@/api/shop'
  export default {
    name: 'ShopComment',
    data() {
      return {
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.shopComment({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      shopComment,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.shopComment({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.shopComment({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped></style>
