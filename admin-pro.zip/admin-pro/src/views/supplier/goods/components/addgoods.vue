<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="650px" @close="close">
    <el-form ref="form" :rules="rules" label-width="140px" :inline="false" :model="data" size="normal">

      <el-form-item label="货品名称">
        <el-input v-model="data" placeholder="请输入货品名称" style="width: 400px;"></el-input>
      </el-form-item>
      <el-form-item label="货品介绍">
        <el-input v-model="data" placeholder="请输入货品介绍" style="width: 400px;"></el-input>
      </el-form-item>

      <el-form-item label="货品图片">
        <div class="acea-row">
          <el-image class="pictrue" fit="fill" :lazy="true" :src="data" />
          <vab-icon class="btndel" icon="close-line" />
          <div class="upLoad">
            <vab-icon class="icon" icon="camera-2-line" />
          </div>
        </div>
        <div style="color: #999; ">
          请上传 大小不超过 <span style="color: #ff4d4f;">5MB</span> 格式为<span style="color: #ff4d4f;">png/jpg/jpeg</span> 的文件
        </div>
      </el-form-item>
      <el-form-item label="货品分类">
        <el-input v-model="data" placeholder="请选择货品分类" style="width: 400px;"></el-input>
      </el-form-item>
      <el-form-item label="单套价格">
        <el-input v-model="data" placeholder="请输入单套价格" style="width: 400px;"></el-input>
      </el-form-item>
      <el-form-item label="单位">
        <el-input v-model="data" placeholder="请输入单位" style="width: 400px;"></el-input>
      </el-form-item>
      <el-form-item label="整箱套数">
        <el-input v-model="data" placeholder="请输入整箱套数" style="width: 400px;"></el-input>
      </el-form-item>
      <el-form-item label="库存">
        <el-input v-model="data" placeholder="请选择货品分类" style="width: 400px;"></el-input>
      </el-form-item>
      <el-form-item label="序号">
        <el-input v-model="data" placeholder="请选择货品分类" style="width: 400px;"></el-input>
      </el-form-item>

      <el-form-item label="状态">
        <el-radio-group v-model="data">
          <el-radio label="1">开启</el-radio>
          <el-radio label="0">关闭</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="记店存">
        <el-radio-group v-model="data">
          <el-radio label="1">开启</el-radio>
          <el-radio label="0">关闭</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="data" placeholder="请输入备注" style="width: 400px;"></el-input>
      </el-form-item>


      <el-form-item>
        <el-button type="primary" @click="onSubmit">确认</el-button>
        <el-button>取消</el-button>
      </el-form-item>
    </el-form>

  </el-dialog>
</template>

<script>
// import { addcareedit } from '@/api/user'
export default {

  name: 'addgoods',
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      title: '',
      dialogFormVisible: false,
    }
  },
  mounted() {

  },
  beforeDestroy() {

  },
  methods: {
    showEdit(row) {
      this.title = '添加商品'
      // addcareedit(row.id).then((res) => {
      //   this.form = res.data
      // })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}
</style>
