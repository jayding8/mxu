<template>
  <div class="index-container">
    <vab-query-form class="box">
      <vab-query-form-top-panel>
        <el-form ref="form" :inline="true" :model="queryForm" @submit.native.prevent>
          <el-form-item label="订单状态">
            <el-input v-model="queryForm.title" placeholder="请输入线路名称" />
          </el-form-item>
          <el-form-item label="商家名称" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item label="订单号" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item label="业务员" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item label="司机名称" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item label="结算方式" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item label="支付类型" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item label="下单方式" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <!-- <vab-query-form-left-panel>
        <el-button type="primary" @click="handleAddmakesettle">添加</el-button>
        <el-button type="danger" @click="handleDelete($event)">
          删除
        </el-button>
      </vab-query-form-left-panel> -->
    </vab-query-form>

    <div class="box">
      <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">

        <el-table-column align="center" type="selection" width="55" />
        <el-table-column fixed align="center" label="id" prop="id" sortable width="80" />
        <el-table-column align="center" label="订单状态" width="100">
          <template slot-scope="props">
            <div>待付款</div>
            <div>待出库</div>
            <div>待审核</div>
            <div>待配送</div>
            <div>配送中</div>
            <div>已完成</div>
            <div>退货</div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="商家名称" prop="tel" width="150" />
        <el-table-column align="center" label="电话" prop="tel" width="150" />
        <el-table-column align="center" label="线路名称" prop="tel" width="150" />
        <el-table-column align="center" label="业务员" prop="tel" width="150" />
        <el-table-column align="center" label="货品名称" width="200">
          <template slot-scope="props">
            <div class="custom-cell">
              <div class="cell-item">商品1</div>
              <div class="cell-item">商品2</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="下单箱数" width="200">
          <template slot-scope="props">
            <div class="custom-cell">
              <div class="cell-item">1</div>
              <div class="cell-item">2</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="支付类型" prop="tel" width="150" />
        <el-table-column align="center" label="总价" prop="money" width="150" />
        <el-table-column align="center" label="实付" prop="money" width="150" />
        <!-- <el-table-column align="center" label="商家名称">
          <template slot-scope="props">
            <div style="color: #46a6ff;">商家列表</div>
          </template>
        </el-table-column> -->
        <!-- <el-table-column align="center" label="状态" width="100">
          <template slot-scope="props">
            <el-switch v-model="data" />
          </template>
        </el-table-column> -->
        <el-table-column align="center" label="下单时间" prop="createtime" sortable width="200">
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="支付时间" prop="createtime" sortable width="200">
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="送达时间" prop="createtime" sortable width="200">
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="结算方式" prop="money" width="150" />
        <el-table-column align="center" label="单号" prop="commission" />
        <el-table-column align="center" label="备注" prop="commission" />


        <!-- 
        <el-table-column align="center" fixed="right" width="150" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="handleAddmakesettle(scope.row)">商品详情</el-button>
            <span class="line"></span>
            <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
 -->



      </el-table>
    </div>

    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>



    <Addmakesettle ref="addmakesettle" @fetch-data="fetchData" />


  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { member } from '@/api/member'
import Addmakesettle from './components/addmakesettle'
export default {
  name: 'makesettle',
  components: {
    Addmakesettle,
  },
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.member({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    member,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.member({
        page: this.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.member({
        page: val,
        limit: this.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleAddmakesettle(data) {
      this.$refs['addmakesettle'].showEdit(data)
    },
    handleDelete() {
      this.$baseConfirm(
        '是否确认删除车辆号码为"车牌照字段"的数据项？?',
        null,
        () => {
          /* 可以写回调; */
        },
        () => {
          /* 可以写回调; */
        }
      )
    },
  },
}
</script>

<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.nicktext {
  width: 100px;
  overflow: hidden;
  font-size: 12px;
  white-space: nowrap;
  /* 保持文本在同一行 */
  overflow: hidden;
  /* 隐藏超出部分 */
  text-overflow: ellipsis;
  /* 显示省略号 */

}

.pl-20 {
  padding-left: 20px;
}

.box {
  width: 100%;
  padding: 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 6px;
}

.custom-cell {
  display: flex;
  justify-content: space-between;
  flex-direction: column;
}

.cell-item {
  width: 100%;
  /* 根据需要调整宽度 */
}

::v-deep .el-table .cell,
::v-deep .el-table--small .el-table__cell {
  padding: 0 !important;
  /* 根据需要调整内边距 */
  box-sizing: border-box;
}

/* 隐藏特定列的单元格边框 */
.el-table .custom-cell .cell-item {
  // border: none;
  /* 隐藏边框 */
  padding: 8px;
  /* 根据需要调整内边距 */
  box-sizing: border-box;
}

/* 确保除了特定列之外，其他列的单元格边框正常显示 */
.cell-item {
  border-bottom: 1px solid #e6e6e6;
  /* 默认情况下，每个单元格都有下边框 */
}

.cell-item:last-child {
  border-bottom: none;
  /* 最后一个单元格没有下边框 */
}
</style>
