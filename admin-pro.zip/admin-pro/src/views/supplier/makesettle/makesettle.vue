<template>
  <div class="index-container">
    <vab-query-form class="box">
      <vab-query-form-top-panel>
        <el-form ref="form" :inline="true" :model="queryForm" @submit.native.prevent>
          <div>
            <el-form-item label="配送时间">


              <el-select v-model="value1" placeholder="请选择" style="width: 100px">
                <el-option v-for="item in options1" :key="item.value" :label="item.label" :value="item.value" />
              </el-select>
              <el-date-picker v-model="value7" end-placeholder="结束日期" range-separator="至" start-placeholder="开始日期"
                type="daterange" />
              <el-checkbox v-model="checked">制作是否包含 0 订单</el-checkbox>
              <el-checkbox-group v-model="checkedCities" :max="1" :min="0">
                <el-checkbox v-for="city in cities" :key="city" :label="city">
                  {{ city }}
                </el-checkbox>
              </el-checkbox-group>



            </el-form-item>
          </div>
          <!-- <div>
            <el-form-item label="收据备注">
              <el-input v-model="data" placeholder="请输入收据备注" style="width: 450px" />
            </el-form-item>
          </div> -->


          <el-form-item label="商家ID">
            <el-input v-model="queryForm.title" placeholder="请输入商家ID" />
          </el-form-item>
          <el-form-item class="pl-20" label="商家名称">
            <el-input v-model="queryForm.title" placeholder="请输入商家名称" />
          </el-form-item>
          <el-form-item class="pl-20" label="商家分类">
            <el-input v-model="queryForm.title" placeholder="请选择商家分类" />
          </el-form-item>
          <el-form-item class="pl-20" label="线路">
            <el-input v-model="queryForm.title" placeholder="请选择线路" />
          </el-form-item>
          <el-form-item class="pl-20" label="业务员">
            <el-input v-model="queryForm.title" placeholder="请选择业务员" />
          </el-form-item>
          <el-form-item class="pl-20" label="结算方式">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item class="pl-20" label="商家状态">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item class="pl-20" label="商家备注">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel>
        <el-button type="primary" @click="handleAddmakesettle">
          制作单据
        </el-button>
        <span>
          智能制单开启中，系统将在每个月 1
          日凌晨提前为您将收据做好（请确保单价无调整）
        </span>
        <!-- <el-button type="danger" @click="handleDelete($event)">删除</el-button> -->
      </vab-query-form-left-panel>
    </vab-query-form>

    <div class="box">
      <el-table border :data="data" style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column align="center" type="selection" width="55" />
        <el-table-column align="center" fixed label="id" prop="restaurantCode" sortable width="80" />

        <el-table-column align="center" label="商家名称" prop="restaurantName" width="150" />
        <el-table-column align="center" label="店存" prop="stockNum" width="150" />
        <el-table-column align="center" label="电话" prop="phone" width="150" />
        <el-table-column align="center" label="结算方式" prop="dictLabel" width="150" />
        <el-table-column align="center" label="配送次数" prop="count" width="150" />
        <el-table-column align="center" label="金额" prop="payPrice" width="150" />
        <el-table-column align="center" label="回收箱数" prop="recoveryNum" width="150" />

        <el-table-column align="center" label="配送开始" prop="min_confirm_time" sortable width="200">
          <template slot-scope="scope">
            {{ new Date(scope.row.min_confirm_time * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="配送结束" prop="max_confirm_time" sortable width="200">
          <template slot-scope="scope">
            {{ new Date(scope.row.max_confirm_time * 1000).toLocaleString() }}
          </template>
        </el-table-column>

        <el-table-column align="center" label="备注" prop="rmank" width="200" />

        <el-table-column align="center" fixed="right" label="操作" width="150">
          <template slot-scope="scope">
            <el-button type="text" @click="handleAddmakesettle(scope.row)">
              单据记录
            </el-button>
            <span class="line"></span>
            <el-button type="text" @click="handleDelete(scope.row)">
              制作单据
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>


    <el-alert :closable="false">
      <h3>配送时间</h3>
      <p>1、下拉时间选项：本周 、 本月 、 上月</p>
      <p>2、具体时间使用则前面下拉时间失效，以具体时间段优先查询</p>
      <p>3、制单包含0个单，是商家没有下单的制单就是0单</p>
      <p>4、是否抹0 和 四舍五入 这两个是唯一选择，选择其中一个则另一个不可以被选择</p>
      <br />
      <h3>收据备注</h3>
      <p>查询的是已经制单过的商家，已经制单的时间商家单据备注，这里显示的是制单单据 不是商家制单列表</p>

    </el-alert>


    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>

    <Addmakesettle ref="addmakesettle" @fetch-data="fetchData" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { member } from '@/api/member'
import Addmakesettle from './components/addmakesettle'
export default {
  name: 'Makesettle',
  components: {
    Addmakesettle,
  },
  data() {
    return {
      checkedCities: ['是否抹零'],
      cities: ['是否抹零', '是否四舍五入'],
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      data: [
        // restaurantCode  商家id
        // restaurantName  商家名称
        // payPrice     金额
        // dictLabel  结算方式
        // count   配送次数
        // stockNum   店存
        // phone  手机号
        // recoveryNum 回收箱数
        // max_confirm_time  结束配送时间
        // min_confirm_time  开始配送时间
        // rmank 备注
        { restaurantCode: "2501", restaurantName: "银河爆炸串", payPrice: "107.00", dictLabel: "月结", count: "111", stockNum: "8", phone: "15720808808", recoveryNum: "15", max_confirm_time: "1721755360", min_confirm_time: "1717301272", rmank: "局座的大舅子" },
        { restaurantCode: "2701", restaurantName: "夸父烤串", payPrice: "21.00", dictLabel: "半月结", count: "121", stockNum: "58", phone: "15720808808", recoveryNum: "15", max_confirm_time: "1721755360", min_confirm_time: "1717301272", rmank: "局座的大舅子" },
        { restaurantCode: "2471", restaurantName: "爆肚火锅", payPrice: "2134.00", dictLabel: "月结", count: "114", stockNum: "118", phone: "15720808808", recoveryNum: "15", max_confirm_time: "1721755360", min_confirm_time: "1717301272", rmank: "局座的大舅子" },
        { restaurantCode: "2341", restaurantName: "阿萨姆炒饭", payPrice: "6789.00", dictLabel: "实时支付", count: "611", stockNum: "958", phone: "15720808808", recoveryNum: "15", max_confirm_time: "1721755360", min_confirm_time: "1717301272", rmank: "局座的大舅子" },
      ],
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.member({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    member,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.member({
        page: this.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.member({
        page: val,
        limit: this.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleAddmakesettle(data) {
      this.$refs['addmakesettle'].showEdit(data)
    },
    handleDelete() {
      this.$baseConfirm(
        '是否确认删除车辆号码为"车牌照字段"的数据项？?',
        null,
        () => {
          /* 可以写回调; */
        },
        () => {
          /* 可以写回调; */
        }
      )
    },
  },
}
</script>

<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.nicktext {
  width: 100px;
  overflow: hidden;
  /* 保持文本在同一行 */
  overflow: hidden;
  font-size: 12px;
  /* 隐藏超出部分 */
  text-overflow: ellipsis;
  white-space: nowrap;
  /* 显示省略号 */
}

.pl-20 {
  padding-left: 20px;
}

.box {
  width: 100%;
  padding: 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 6px;
}

.custom-cell {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.cell-item {
  width: 100%;
  /* 根据需要调整宽度 */
}

::v-deep .el-table .cell,
::v-deep .el-table--small .el-table__cell {
  /* 根据需要调整内边距 */
  box-sizing: border-box;
  padding: 0 !important;
}

/* 隐藏特定列的单元格边框 */
.el-table .custom-cell .cell-item {
  /* 根据需要调整内边距 */
  box-sizing: border-box;
  // border: none;
  /* 隐藏边框 */
  padding: 8px;
}

/* 确保除了特定列之外，其他列的单元格边框正常显示 */
.cell-item {
  border-bottom: 1px solid #e6e6e6;
  /* 默认情况下，每个单元格都有下边框 */
}

.cell-item:last-child {
  border-bottom: none;
  /* 最后一个单元格没有下边框 */
}
</style>
