<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="1000px" @close="close">
    <el-form ref="form" :rules="rules" label-width="140px" :inline="false" :model="data" size="normal">

      <el-form-item label="线路名称">
        <el-input v-model="data" placeholder="请输入线路名称" style="width: 400px;"></el-input>
      </el-form-item>

      <el-form-item label="是否启用">
        <el-radio-group v-model="data">
          <el-radio label="1">开启</el-radio>
          <el-radio label="0">关闭</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="data" placeholder="请输入备注" style="width: 400px;"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">确认</el-button>
        <el-button>取消</el-button>
      </el-form-item>
    </el-form>

    <!-- <div class="invoice-tmp">
      <h1 class="title">XX市增值税XX票XX发票</h1>
      <el-row class="header">
        <el-col :span="18" class="no-border">
          <el-row>
            <el-col :span="8">
              <span class="label">发票代码</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
            <el-col :span="8">
              <span class="label">发票号码</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
            <el-col :span="8">
              <span class="label">开票日期</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <span class="label">校验码</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="6" class="no-border">
          <el-row>
            <el-col :span="24">
              <span class="label">购买方</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <span class="label">名称</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <span class="label">纳税人识别号</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <span class="label">地址及电话</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <span class="label">开户行及账号</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
      <el-row class="details">
        <el-col :span="24">
          <el-table :data="data" border>
            <el-table-column label="订单名称/订单号" prop="1" width="180"></el-table-column>
            <el-table-column label="规格型号" prop="2" width="180"></el-table-column>
            <el-table-column label="单位" prop="3" width="180"></el-table-column>
            <el-table-column label="数量" prop="4" width="180"></el-table-column>
            <el-table-column label="单价" prop="5" width="180"></el-table-column>
            <el-table-column label="金额" prop="6" width="180"></el-table-column>
            <el-table-column label="税率" prop="7" width="180"></el-table-column>
            <el-table-column label="税额" prop="8" width="180"></el-table-column>
          </el-table>
        </el-col>
      </el-row>
      <el-row class="total">
        <el-col :span="15" class="no-border">
          <span class="label">价税合计（大写）</span>
          
        </el-col>
        <el-col :span="9" class="no-border">
          <span class="label">（小写）</span>￥900.00
        </el-col>
      </el-row>
      <el-row class="footer">
        <el-col :span="24">
          <el-row>
            <el-col :span="8">
              <span class="label">销售方</span>
            </el-col>
            <el-col :span="8">
              <span class="label">名称</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
            <el-col :span="8">
              <span class="label">纳税人识别号</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <span class="label">地址及电话</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
            <el-col :span="8">
              <span class="label">开户行及账号</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
            <el-col :span="8">
              <span class="label">备注</span>：<span class="content">xxxxxxxxxxxxxxxx</span>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
      <el-row class="footer">
        <el-col :span="24">
          <el-row>
            <el-col :span="6" class="no-border">
              <span class="label">收款人：</span><span class="content">XXX公司</span>
            </el-col>
            <el-col :span="6" class="no-border">
              <span class="label">复核：</span>
            </el-col>
            <el-col :span="6" class="no-border">
              <span class="label">开票人：</span>
            </el-col>
            <el-col :span="6" class="no-border">
              <span class="label">销售方：（章）</span>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </div> -->

    <div class="receipt">
      <h1 class="title">收 款 收 据</h1>
      <div class="header">
        <div class="date">2024-07-24</div>
        <div class="number">No 240724014051339633</div>
      </div>
      <div class="content">
        <div class="row acea-sb">
          <p>今 收 到 </p>
          <p>测试餐厅45</p>
          <p>餐具结算（2024-07-11 ~ 2024-07-16）</p>
        </div>
        <div class="row acea-sb">
          <p>配 送</p>
          <p>五件套</p>
          <p>( 8箱 x 5套/箱 ) </p>
          <p>x 0.8</p>
          <p>元/套 = 32.00元</p>
        </div>
        <div class="row acea-sb">
          <p>优 惠 金 额</p>
          <p>0元</p>
        </div>
        <div class="row acea-sb">
          <p>金额人民币(大写)</p>
          <p>{{ convertToChinese(32) }}</p>
        </div>
        <div class="row acea-sb">
          <p>备 注</p>
          <p>总金额：32.00</p>
        </div>
        <div class="row acea-sw last-row">
          <p>单位盖章</p>
          <p>会计：</p>
          <p>出纳：</p>
          <p> 经手人：</p>
        </div>
      </div>
    </div>

  </el-dialog>
</template>

<script>
// import { addcareedit } from '@/api/user'
// import { digitToCNchar } from 'num_operation';
export default {
  name: 'line',
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      title: '',
      dialogFormVisible: false,
      data: [
        { "1": '第一笔订单', "2": '2019-12-07', "3": '台', "4": 3, "5": '￥100', "6": '￥300.00', "7": 0, "8": '￥0.00' },
        { "1": '第二笔订单', "2": '2019-12-08', "3": '台', "4": 3, "5": '￥100', "6": '￥300.00', "7": 0, "8": '￥0.00' },
        { "1": '第三笔订单', "2": '2019-12-09', "3": '台', "4": 3, "5": '￥100', "6": '￥300.00', "7": 0, "8": '￥0.00' },
      ]
    }
  },
  mounted() { },
  beforeDestroy() { },
  methods: {
    showEdit(row) {
      this.title = '添加线路'
      // addcareedit(row.id).then((res) => {
      //   this.form = res.data
      // })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
    convertToChinese(num) {
      const numMap = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
      const unitMap = ['', '拾', '佰', '仟'];
      let str = '';
      let hasValue = false; // 标记是否找到非零数值

      // 取出整数部分，去掉小数点和后面的数字
      let integerPart = num.toFixed(0).split('.')[0];

      // 从最高位开始遍历每一位数字
      for (let i = integerPart.length - 1; i >= 0; i--) {
        let n = parseInt(integerPart[i], 10); // 当前位的数字
        if (n !== 0 || hasValue) {
          str = numMap[n] + unitMap[3 - (integerPart.length - i) % 4] + str;
          hasValue = true; // 标记找到非零数值
        } else if (n === 0 && i === 0) {
          // 只有当个位为0时，才在最后添加“零”
          str = '零' + str;
        }
      }

      // 如果整个数字都是0，则特别处理
      if (!hasValue) {
        return '零元整';
      }

      // 清理字符串中的零佰、零拾
      str = str.replace(/零佰/g, '佰').replace(/零拾/g, '拾');

      // 添加元整
      return str + '元整';
    }
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}

.acea-sb {
  justify-content: space-between;
  display: flex;
}

.acea-sw {
  justify-content: space-around;
  display: flex;
}

.receipt {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  font-family: '微软雅黑';
}

h1 {
  text-align: center;
}

.header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
}

.content {
  margin-top: 20px;
}

.row {
  // margin-bottom: 10px;
  line-height: 1.5;
}

.date,
.number {
  font-size: 16px;
}

.row p {
  font-size: 14px;
}



.invoice-tmp {
  font-size: 12px;
  width: 720px;
  margin: 0 auto;
}

.title {
  font-size: 26px;
  color: #B16363;
  text-align: center;
  line-height: 56px;
}

.header,
.details,
.total,
.footer {
  margin-bottom: 20px;
}

.label {
  width: 78px;
  display: inline-block;
  text-align-last: justify;
  text-align: justify;
}

.content {
  color: #181818;
}

.no-border {
  border-left: none !important;
}

.row {
  border-top: 1px solid rgb(177, 99, 99);
  border-right: 1px solid rgb(177, 99, 99);
  border-left: 1px solid rgb(177, 99, 99);
  border-image: initial;
  border-bottom: none;
  color: rgb(177, 91, 22);
}

.last-row {
  // color: rgb(177, 91, 22);
  // border-top: 1px solid rgb(177, 99, 99);
  border-left: none;

  border-right: none;

}
</style>
