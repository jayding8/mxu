<template>
  <div class="index-container">
    <vab-query-form class="box">
      <vab-query-form-top-panel>
        <el-form ref="form" :inline="true" :model="queryForm" @submit.native.prevent>
          <el-form-item label="分类名称">
            <el-input v-model="queryForm.title" placeholder="请输入分类名称" />
          </el-form-item>


          <el-form-item label="状态" class="pl-20">
            <el-input v-model="queryForm.title" placeholder="请选择状态" />
          </el-form-item>

          <el-form-item>
            <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel>
        <el-button type="primary" @click="handleAddcategory">添加</el-button>
        <el-button type="danger" @click="handleDelete($event)">
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <div class="box">
      <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">

        <el-table-column align="center" type="selection" width="55" />
        <el-table-column fixed align="center" label="id" prop="id" sortable width="80" />
        <el-table-column align="center" label="分类名称" prop="tel" width="150" />
        <el-table-column align="center" label="排序" prop="money" width="150" />

        <el-table-column align="center" label="状态" width="100">
          <template slot-scope="props">
            <el-switch v-model="data" />
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间" prop="createtime" sortable>
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>




        <el-table-column align="center" fixed="right" width="150" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="handleAddcategory(scope.row)">修改</el-button>
            <span class="category"></span>
            <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>




      </el-table>
    </div>

    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>



    <Addcategory ref="addcategory" @fetch-data="fetchData" />


  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { member } from '@/api/member'
import Addcategory from './components/addcategory'
export default {
  name: 'category',
  components: {
    Addcategory,
  },
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.member({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    member,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.member({
        page: this.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.member({
        page: val,
        limit: this.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleAddcategory(data) {
      this.$refs['addcategory'].showEdit(data)
    },
    handleDelete() {
      this.$baseConfirm(
        '是否确认删除车辆号码为"车牌照字段"的数据项？?',
        null,
        () => {
          /* 可以写回调; */
        },
        () => {
          /* 可以写回调; */
        }
      )
    },
  },
}
</script>

<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.category {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: incategory-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  category-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.nicktext {
  width: 100px;
  overflow: hidden;
  font-size: 12px;
  white-space: nowrap;
  /* 保持文本在同一行 */
  overflow: hidden;
  /* 隐藏超出部分 */
  text-overflow: ellipsis;
  /* 显示省略号 */

}

.pl-20 {
  padding-left: 20px;
}

.box {
  width: 100%;
  padding: 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 6px;
}
</style>
