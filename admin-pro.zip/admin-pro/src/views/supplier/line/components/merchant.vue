<template>
  <el-dialog append-to-body :title="this.data.id ? '商家列表' : '商家列表'" :visible.sync="dialogFormVisible" width="800px"
    @close="close">
    <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="100px" :model="form"
      :rules="rules">
      <el-form-item label="穿梭框">
        <el-transfer v-model="form.transfer" :data="data" :filter-method="filterMethod" filter-placeholder="请输入城市拼音"
          filterable />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">确认</el-button>
        <el-button @click="close">取消</el-button>
      </el-form-item>
    </el-form>


  </el-dialog>
</template>

<script>
export default {
  name: 'merchant',
  data() {
    const generateData = () => {
      const data = []
      const cities = ['上海', '北京', '广州']
      const pinyin = ['shanghai', 'beijing', 'guangzhou']
      cities.forEach((city, index) => {
        data.push({
          label: city,
          key: index,
          pinyin: pinyin[index],
        })
      })
      return data
    }
    return {
      labelPosition: 'right',
      form: {
        transfer: [],
      },
      areaOptions: [],
      data: generateData(),
      dialogFormVisible: false,
      rules: {
        // 表单验证规则
      },
      filterMethod(query, item) {
        return item.pinyin.indexOf(query) > -1
      },
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    fetchData() {
      // 这里可以加载更多数据
    },
    showEdit() {
      this.dialogFormVisible = true
    },
    onSubmit() {
      // 处理表单提交
      console.log(this.form.transfer)
    },
    close() {
      this.dialogFormVisible = false
    },
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}
</style>
