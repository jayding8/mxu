<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="1000px" @close="close">



    <el-form ref="form" :rules="rules" label-width="140px" :inline="false" :model="data" size="normal">

      <div style="display: flex; justify-content: space-between;padding-right: 100px;">

        <el-form-item label="配送线路">
          <el-text v-model="data">归西路</el-text>
        </el-form-item>
        <el-form-item label="车次">
          <el-text v-model="data">1212</el-text>
        </el-form-item>
        <el-form-item label="商家">
          <el-text v-model="data">15</el-text>
        </el-form-item>
        <el-form-item label="统计时间">
          <el-text v-model="data">2024-04-06 20:14</el-text>
        </el-form-item>
      </div>


      <el-form-item label="商家名称">
        <el-text v-model="data">商家1、商家1、商家1、商家1、商家1、商家1</el-text>
      </el-form-item>








      <el-form-item label="商品明细" size="normal">
        <el-table border :data="idata" style="width: 100%" @selection-change="handleSelectionChange">
          <!-- <el-table-column fixed align="center" label="操作 " width="180">
            <el-button type="primary" @click="(scope.row)">增加</el-button>
            <span class="line"></span>
            <el-button type="danger" @click="(scope.row)">删除</el-button>
          </el-table-column> -->

          <el-table-column align="center" label="商品名称" prop="tel" />

          <el-table-column align="center" label="单位" prop="tel" width="200" />
          <!-- <el-table-column align="center" label="配送数量" prop="money" width="100" />
          <el-table-column align="center" label="回收数量" prop="money" width="100" />
          <el-table-column align="center" label="换货数量" prop="money" width="100" />
          <el-table-column align="center" label="单价(元)" prop="tel" width="100" />
          <el-table-column align="center" label="金额(元)" prop="tel" width="100" />
          <el-table-column align="center" label="退回箱数" prop="tel" width="100" /> -->
        </el-table>
      </el-form-item>






      <el-form-item>
        <!-- <el-button type="primary" @click="onSubmit">保存</el-button> -->
        <!-- <el-button type="primary" @click="onSubmit">提交</el-button> -->
        <!-- <el-button type="danger" @click="onSubmit">打印</el-button> -->
        <el-button>取消</el-button>
      </el-form-item>
    </el-form>



  </el-dialog>
</template>

<script>
// import { addcareedit } from '@/api/user'
export default {

  name: 'detail',
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      title: '',
      dialogFormVisible: false,
    }
  },
  mounted() {

  },
  beforeDestroy() {

  },
  methods: {
    showEdit(row) {
      this.title = '预报明细'
      // addcareedit(row.id).then((res) => {
      //   this.form = res.data
      // })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}
</style>
