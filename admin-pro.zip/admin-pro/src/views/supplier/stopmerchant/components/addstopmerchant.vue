<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="1200px" @close="close">
    <el-table border :data="data" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column align="center" type="selection" width="55" />
      <el-table-column fixed align="center" label="id" prop="id" sortable width="80" />
      <el-table-column align="center" label="货品名称" prop="tel" width="300" />
      <el-table-column label="货品图片" align="center" width="120">
        <template slot-scope="props">
          <img :src="props.row.headimg" style="height: 44px; width: 44px;border-radius: 8px;" />
        </template>
      </el-table-column>
      <el-table-column align="center" label="单套价格" prop="tel" width="100" />
      <el-table-column align="center" label="单位" prop="money" width="100" />
      <el-table-column align="center" label="整箱套数" prop="tel" width="100" />
      <el-table-column align="center" label="包装单位" prop="money" width="100" />
      <el-table-column align="center" fixed="right" width="150" label="操作">
        <template slot-scope="scope">
          <el-button type="text" @click="handleAddgoods(scope.row)">调价</el-button>
          <el-button type="text" @click="handleAddgoods(scope.row)">调价记录</el-button>
          <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>




    </el-table>

  </el-dialog>
</template>

<script>
// import { addcareedit } from '@/api/user'
export default {

  name: 'addmerchant',
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      title: '',
      dialogFormVisible: false,
    }
  },
  mounted() {

  },
  beforeDestroy() {

  },
  methods: {
    showEdit(row) {
      this.title = '专享商品列表'
      // addcareedit(row.id).then((res) => {
      //   this.form = res.data
      // })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}
</style>
