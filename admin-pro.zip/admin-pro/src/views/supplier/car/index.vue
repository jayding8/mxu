<template>
  <div class="index-container">
    <vab-query-form class="box">
      <vab-query-form-top-panel>
        <el-form ref="form" :inline="true" :model="queryForm" @submit.native.prevent>
          <el-form-item label="车辆型号">
            <el-input v-model="queryForm.car_model" placeholder="请输入车辆型号" />
          </el-form-item>
          <el-form-item label="车牌号码" class="pl-20">
            <el-input v-model="queryForm.car_license" placeholder="请输入车牌号码" />
          </el-form-item>

          <el-form-item label="状态" class="pl-20">
            <el-input v-model="queryForm.status" placeholder="请选择状态" />
          </el-form-item>
          <el-form-item label="保险到期时间" class="pl-20">
            <el-input v-model="queryForm.expiration_time" placeholder="请输入保险到期时间" />
          </el-form-item>
          <el-form-item label="年审到期时间" class="pl-20">
            <el-input v-model="queryForm.annual_inspection_time" placeholder="请输入年审到期时间" />
          </el-form-item>
          <el-form-item>
            <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel>
        <el-button type="primary" @click="handleAddcar">添加</el-button>
        <el-button type="danger" @click="handleDelete($event)">
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <div class="box">
      <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">

        <el-table-column align="center" type="selection" width="55" />
        <el-table-column fixed align="center" label="id" prop="id" sortable width="80" />
        <el-table-column label="车辆图片" align="center" width="120">
          <template slot-scope="props">
            <img :src="props.row.headimg" style="height: 44px; width: 44px;border-radius: 8px;" />
          </template>
        </el-table-column>

        <el-table-column align="center" label="车辆型号" prop="tel" width="150" />
        <el-table-column align="center" label="车牌号码" prop="money" width="150" />
        <el-table-column align="center" label="司机名称" prop="totalscore" width="150" />


        <el-table-column align="center" label="年审到期时间" prop="createtime" sortable>
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="保险到期时间" prop="createtime" sortable>
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="状态" width="100">
          <template slot-scope="props">
            <el-switch v-model="data" />
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间" prop="createtime" sortable>
          <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="备注" prop="commission" />
        <el-table-column align="center" fixed="right" width="150" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="handleAddcar(scope.row)">修改</el-button>
            <span class="line"></span>
            <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>




      </el-table>



    </div>

    <el-alert :closable="false">
      <h3>搜索选项功能项说明</h3>
      <p>1、【车辆型号】由后台用户自定义添加的车辆型号字段决定，这里数据需要循环所有型号数据</p>
      <p>2、【车辆车牌】由后台用户自定义添加的车辆车牌数据，可做为司机绑定车辆唯一标识，同时也可以通过搜索查询到对应信息</p>
      <p>3、【车辆状态】查询对应车辆是否启用 status 0 / 1</p>
      <p>4、【保险到期时间】/【年审到期时间】时间戳字段 可用于查询 同时决定 当时间过期时候需要自动修改车辆状态 status=0 除非手动修改 到期时间</p>

      <br />
      <h3>列表数据项功能说明</h3>
      <p>
        暂无需要复杂解释的选项
      </p>
    </el-alert>

    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper" :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>



    <Addcar ref="addcar" @fetch-data="fetchData" />


  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getCarList } from '@/api/supplier'
import Addcar from './components/addcar'

export default {
  name: 'car',
  components: {
    Addcar,
  },
  data() {
    return {
      options1: [
        { value: '1', label: '全部' },
        { value: '2', label: '分类一' },
        { value: '3', label: '分类二' },
      ],

      value1: '',
      queryForm: {
        car_model: '',
        car_license: '',
        status: '',
        expiration_time: '',
        annual_inspection_time: '',
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      height: this.$baseTableHeight(3) - 30,
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.getCarList();
    // this.member({
    //   page: this.page.current,
    //   limit: this.page.limit,
    // }).then((res) => {
    //   this.info.data = res.data
    //   this.info.count = res.count
    // })
  },
  methods: {
    getCarList(params) {
      getCarList({
        ...params,
        ...this.queryForm,
      }).then(res => {
        if (res.code !== 200) {
          this.$message.error("获取列表失败");
        }
        this.info.data = res.data;
        this.info.count = res.count;
      })
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.member({
        page: this.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.member({
        page: val,
        limit: this.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleAddcar(data) {
      this.$refs['addcar'].showEdit(data)
    },
    handleDelete() {
      this.$baseConfirm(
        '是否确认删除车辆号码为"车牌照字段"的数据项？?',
        null,
        () => {
          /* 可以写回调; */
        },
        () => {
          /* 可以写回调; */
        }
      )
    },
    handleQuery() {
      this.getCarList();
    },
  },
}
</script>

<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.nicktext {
  width: 100px;
  overflow: hidden;
  font-size: 12px;
  white-space: nowrap;
  /* 保持文本在同一行 */
  overflow: hidden;
  /* 隐藏超出部分 */
  text-overflow: ellipsis;
  /* 显示省略号 */

}

.pl-20 {
  padding-left: 20px;
}

.box {
  width: 100%;
  padding: 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 6px;
}
</style>
