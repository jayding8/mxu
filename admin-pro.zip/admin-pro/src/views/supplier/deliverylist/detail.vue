<template>
  <el-dialog append-to-body :title="title" :visible.sync="dialogFormVisible" width="1400px" @close="close">

    <el-alert :closable="false" show-icon title="补单可能订单已经配送完成，需要配送员手动上传配送信息明细以便于商家查看和记录配送数据所有用" type="error" />
    <el-form ref="form" :rules="rules" label-width="140px" :inline="false" :model="data" size="normal">

      <div style="display: flex;">
        <el-form-item label="商家名称">
          <el-input v-model="data" placeholder="选择商家" style="width: 400px;"></el-input>
        </el-form-item>
        <el-form-item label="配送单号">
          <el-input v-model="data" placeholder="自动生成系统单号" style="width: 400px;"></el-input>
        </el-form-item>
      </div>

      <div style="display: flex;">
        <el-form-item label="配送时间">
          <el-input v-model="data" placeholder="选择配送时间" style="width: 400px;"></el-input>
        </el-form-item>
        <el-form-item label="配送线路">
          <el-input v-model="data" placeholder="选择配送线路" style="width: 400px;"></el-input>
        </el-form-item>
      </div>


      <div style="display: flex;">
        <el-form-item label="配送司机">
          <el-input v-model="data" placeholder="选择配送司机" style="width: 400px;"></el-input>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="data" placeholder="请输入备注" style="width: 400px;"></el-input>
        </el-form-item>
      </div>




      <el-form-item label="配送明细" size="normal">
        <el-table border :data="idata" style="width: 100%" @selection-change="handleSelectionChange">
          <el-table-column fixed align="center" label="操作 " width="180">
            <el-button type="primary" @click="(scope.row)">增加</el-button>
            <span class="line"></span>
            <el-button type="danger" @click="(scope.row)">删除</el-button>
          </el-table-column>

          <el-table-column align="center" label="货品名称" prop="tel" />

          <el-table-column align="center" label="单位" prop="tel" width="100" />
          <el-table-column align="center" label="配送数量" prop="money" width="100" />
          <el-table-column align="center" label="回收数量" prop="money" width="100" />
          <el-table-column align="center" label="换货数量" prop="money" width="100" />
          <el-table-column align="center" label="单价(元)" prop="tel" width="100" />
          <el-table-column align="center" label="金额(元)" prop="tel" width="100" />
          <el-table-column align="center" label="退回箱数" prop="tel" width="100" />
        </el-table>
      </el-form-item>

      <el-form-item label="配送图" size="normal">
        <div class="acea-row">
          <el-image class="pictrue" fit="fill" :lazy="true" :src="data" />
          <vab-icon class="btndel" icon="close-line" />
          <div class="upLoad">
            <vab-icon class="icon" icon="camera-2-line" />
          </div>
        </div>
      </el-form-item>
      <el-form-item label="*回收图" size="normal">
        <div class="acea-row">
          <el-image class="pictrue" fit="fill" :lazy="true" :src="data" />
          <vab-icon class="btndel" icon="close-line" />
          <div class="upLoad">
            <vab-icon class="icon" icon="camera-2-line" />
          </div>
        </div>
      </el-form-item>





      <el-form-item>
        <el-button type="primary" @click="onSubmit">保存</el-button>
        <!-- <el-button type="primary" @click="onSubmit">提交</el-button> -->
        <el-button type="danger" @click="onSubmit">打印</el-button>
        <!-- <el-button>取消</el-button> -->
      </el-form-item>
    </el-form>

  </el-dialog>
</template>

<script>
// import { addcareedit } from '@/api/user'
export default {

  name: 'line',
  props: {
    data: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      title: '',
      dialogFormVisible: false,
    }
  },
  mounted() {

  },
  beforeDestroy() {

  },
  methods: {
    showEdit(row) {
      this.title = '补单录单'
      // addcareedit(row.id).then((res) => {
      //   this.form = res.data
      // })
      this.dialogFormVisible = true
    },
    close() {
      this.dialogFormVisible = false
    },
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}
</style>
