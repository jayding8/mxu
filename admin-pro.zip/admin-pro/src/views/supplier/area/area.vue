<template>
  <div class="index-container">
    <vab-query-form class="box">
      <vab-query-form-top-panel>
        <el-form ref="form" :inline="true" :model="queryForm" @submit.native.prevent>
          <el-form-item label="区域名称">
            <el-input v-model="queryForm.keyword" placeholder="请输入区域名称" />
          </el-form-item>


          <el-form-item label="状态" class="pl-20">
            <el-select v-model="queryForm.status" placeholder="请选择">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-button icon="el-icon-search" native-type="submit" type="primary" @click="handleQuery">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel>
        <el-button type="primary" @click="handleAddarea()">添加</el-button>
        <el-button type="danger" @click="handleDelete()">
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <div class="box">
      <el-table border :data="info.data" style="width: 100%" @selection-change="handleSelectionChange">

        <el-table-column align="center" type="selection" width="55" />
        <el-table-column fixed align="center" label="id" prop="id" sortable width="80" />
        <!-- <el-table-column label="区域名称" align="center" width="120">
          <template slot-scope="props">
            <img :src="props.row.headimg" style="height: 44px; width: 44px;border-radius: 8px;" />
          </template>
</el-table-column> -->

        <el-table-column align="center" label="区域名称" prop="area_name" width="150" />
        <el-table-column align="center" label="商家数量" prop="shop_num" width="150" />
        <!-- <el-table-column align="center" label="商家名称">
          <template slot-scope="props">
            <div style="color: #46a6ff;">商家列表</div>
          </template>
        </el-table-column> -->
        <el-table-column align="center" label="状态" width="100">
          <template slot-scope="scope">
            <el-switch v-model="scope.row.status" :active-value=1 :inactive-value=0
              @change="changeStatus(scope.row)"></el-switch>
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间" prop="create_time" sortable>
          <!-- <template slot-scope="scope">
            {{ new Date(scope.row.createtime * 1000).toLocaleString() }}
          </template> -->
        </el-table-column>

        <el-table-column align="center" fixed="right" width="150" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="handleAddarea(scope.row)">修改</el-button>
            <span class="line"></span>
            <el-button type="text" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div class="block">
      <el-pagination :current-page="page.current" layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit" :page-sizes="[10, 20, 1, 2]" :total="info.count" @current-change="handleCurrentChange"
        @size-change="handleSizeChange" />
    </div>

    <Addarea ref="addarea" :data="info.data" @refreshList="getAreaList" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getAreaList, delArea, updateAreaStatus } from '@/api/supplier'
import Addarea from './components/addarea'
export default {
  name: 'area',
  components: {
    Addarea,
  },
  data() {
    return {
      queryForm: {
        keyword: '',
        status: '',
      },
      multipleSelection: [],
      layout: 'total, sizes, prev, pager, next, jumper',
      fold: false,
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
      options: [{
        value: '1',
        label: '已开启'
      }, {
        value: '0',
        label: '已关闭'
      }],
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.getAreaList();
  },
  methods: {
    getAreaList(params) {
      getAreaList({
        ...params,
        ...this.queryForm,
      }).then(res => {
        if (res.code !== 200) {
          this.$message.error("获取列表失败");
        }
        this.info.data = res.data;
        this.info.count = res.count;
      })
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.page.limit = val
      this.getAreaList({
        page: this.page.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.page.current = val
      this.getAreaList({
        page: val,
        limit: this.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleAddarea(data) {
      if (!data) {
        data = {
          area_name: "",
          status: 1,
        }
      }
      this.$refs['addarea'].showEdit(data)
    },
    handleDelete(data) {
      if (!data && !this.multipleSelection.length) {
        this.$message.error("请先选择需要删除的记录");
        return
      }
      this.$baseConfirm(
        data ? `是否确认删除区域名称为${data.area_name}的数据项？` : '确认批量删除？',
        null,
        () => {
          const id = data ? data.id : this.multipleSelection.map(v => v.id).join(',')
          delArea({ id }).then(res => {
            this.$message.success("删除成功");
            this.getAreaList({
              page: 1,
              limit: 10,
            });
          }).catch(err => {
            this.$message.error("删除失败");
          })
        },
        () => {
          /* 可以写回调; */
        }
      )
    },
    handleQuery() {
      this.getAreaList({
        page: 1,
        limit: 10,
      })
    },
    changeStatus(row) {
      updateAreaStatus({ id: row.id, status: row.status })
        .then(res => {
          this.$message.success("修改状态成功");
        }).catch(err => {
          this.$message.error("修改状态失败");
        })
    },
  },
}
</script>

<style lang="scss" scoped>
.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.line {
  position: relative;
  top: -0.06em;
  box-sizing: border-box;
  display: inline-block;
  width: 1px;
  height: 0.9em;
  padding: 0;
  margin: 0 8px;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, '\5FAE\8F6F\96C5\9ED1', Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: #515a6e;
  vertical-align: middle;
  list-style: none;
  background: #e8eaec;
}

.nicktext {
  width: 100px;
  overflow: hidden;
  font-size: 12px;
  white-space: nowrap;
  /* 保持文本在同一行 */
  overflow: hidden;
  /* 隐藏超出部分 */
  text-overflow: ellipsis;
  /* 显示省略号 */

}

.pl-20 {
  padding-left: 20px;
}

.box {
  width: 100%;
  padding: 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 6px;
}
</style>
