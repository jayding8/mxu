<template>
  <el-dialog append-to-body :title="this.data.id ? '修改区域' : '添加区域'" :visible.sync="dialogFormVisible" width="650px"
    @close="close">
    <el-form ref="form" :rules="rules" label-width="140px" :inline="false" :model="data" size="normal">

      <el-form-item label="区域名称">
        <el-input v-model="data.area_name" placeholder="请输入区域名称" style="width: 400px;"></el-input>
      </el-form-item>

      <el-form-item label="是否启用">
        <el-radio-group v-model="data.status">
          <el-radio :label="1">开启</el-radio>
          <el-radio :label="0">关闭</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">确认</el-button>
        <el-button @click="close">取消</el-button>
      </el-form-item>
    </el-form>

  </el-dialog>
</template>

<script>
import { addOrEditArea } from '@/api/supplier'

export default {
  name: 'area',
  data() {
    return {
      dialogFormVisible: false,
      data: {}
    }
  },
  mounted() {

  },
  beforeDestroy() {

  },
  methods: {
    showEdit(data) {
      if (data) {
        this.data = data;
      }
      this.dialogFormVisible = true;
    },
    onSubmit() {
      if (!this.data.area_name) {
        this.$message.error("请先填写区域名称");
        return;
      }
      const param = {
        area_name: this.data.area_name,
        status: this.data.status,
      }
      if (this.data.id) {
        param.id = this.data.id;
      }
      addOrEditArea(param).then(res => {
        this.$message.success(this.data.id ? "修改区域成功" : "新增区域成功");
        this.$emit("refreshList");
      }).catch(err => {
        this.$message.error("新增区域失败");
      })
      this.close();
    },
    close() {
      this.dialogFormVisible = false;
    },
  },
}
</script>

<style lang="scss" scoped>
.btndel {
  position: absolute;
  top: -10px;
  left: 60px;
  z-index: 1;
  width: 20px !important;
  height: 20px !important;
  line-height: 20px;
  color: #515a6e;
  background: #fff;
  background-color: #fff;
  border: 1px solid transparent;
  border-color: #dcdee2;
  border-radius: 100%;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.pictrue {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
}

.upLoad {
  position: relative;
  display: inline-block;
  width: 72px;
  height: 72px;
  margin-right: 15px;
  margin-bottom: 10px;
  cursor: pointer;
  border: 1px dotted rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  text-align: center;
  line-height: 72px;
  color: #8c939d;
  background: #fff;
  border-color: #dcdee2;
  transition: color 0.2s linear, background-color 0.2s linear,
    border 0.2s linear, box-shadow 0.2s linear;
}

.acea-row {
  display: flex;
}
</style>
