<template>
  <div class="index-container">
    <el-alert :closable="false" show-icon title="分红明细" type="success" />
    <vab-query-form>
      <vab-query-form-top-panel>
        <el-form
          ref="form"
          class="box"
          :inline="true"
          label-width="66px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="会员ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" />
          </el-form-item>
          <el-form-item label="昵称">
            <el-input v-model="queryForm.title" placeholder="请输入昵称" />
          </el-form-item>

          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
            >
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel :span="24">
        <el-button
          icon="el-icon-delete"
          type="danger"
          @click="handleDelete($event)"
        >
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>
    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="ID" prop="id" sortable width="80" />
      <el-table-column label="类型" width="100">
        <template slot-scope="props">
          <el-form>
            <div v-if="props.row.type == 0">易联云</div>
            <div v-if="props.row.type == 1">飞鹅</div>
            <div v-if="props.row.type == 2">映美云</div>
            <div v-if="props.row.type == 3">大趋</div>
            <div v-if="props.row.type == 4">芯烨</div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="名称" prop="name" />
      <el-table-column label="标题" prop="title" />
      <el-table-column label="终端号" prop="machine_code" />
      <el-table-column label="添加时间" prop="createtime" sortable />
      <el-table-column label="状态" width="100">
        <template slot-scope="props">
          <el-form>
            <div v-if="props.row.status == 0">已关闭</div>
            <div v-if="props.row.status == 1">已开启</div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column fixed="right" label="操作" width="100">
        <el-button size="small" type="text">编辑</el-button>
        <el-button size="small" type="text">删除</el-button>
        <el-button size="small" type="text">打印测试</el-button>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Wifiprint } from '@/api/set'

export default {
  name: 'Fenhonglog',

  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Wifiprint({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    Wifiprint,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Wifiprint({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Wifiprint({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
}
</style>
