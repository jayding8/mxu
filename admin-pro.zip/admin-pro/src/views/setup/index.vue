<template>
  <div class="index-container">
    占用页面
    <vab-theme />
  </div>
</template>
