<template>
  <div class="index-container">
    <el-tabs v-model="activeName" @tab-click="handleTab">
      <el-tab-pane label="基础设置" name="first">
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-form-item label="短信状态：" prop="status">
            <el-radio-group v-model="form.status">
              <el-radio :label="1">开启</el-radio>
              <el-radio :label="0">关闭</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="短信接口：" prop="smstype">
            <el-select
              v-model="form.smstype"
              placeholder="请选择短信接口"
              style="width: 250px"
            >
              <el-option :label="1" value="1">阿里云</el-option>
              <el-option :label="2" value="2">腾讯云</el-option>
            </el-select>
          </el-form-item>
          <div v-if="form.smstype == 1">
            <!-- 阿里云短信 -->
            <el-form-item label="AccessKey ID：" prop="accesskey">
              <el-input v-model="form.accesskey" style="width: 250px" />
            </el-form-item>
            <el-form-item label="AccessKey Secret：" prop="accesssecret">
              <el-input v-model="form.accesssecret" style="width: 250px" />
            </el-form-item>
            <el-form-item label="短信签名：" prop="sign_name">
              <el-input v-model="form.sign_name" style="width: 250px" />
            </el-form-item>
          </div>

          <div v-if="form.smstype == 2">
            <!-- 腾讯云短信 -->
            <el-form-item label="SecretId：" prop="">
              <el-input v-model="form.accesskey" style="width: 250px" />
            </el-form-item>
            <el-form-item label="SecretKey：" prop="">
              <el-input v-model="form.accesssecret" style="width: 250px" />
            </el-form-item>
            <el-form-item label="应用SDK AppID：" prop="">
              <el-input v-model="form.sdkappid" style="width: 250px" />
            </el-form-item>
            <el-form-item label="短信签名：" prop="">
              <el-input v-model="form.sign_name" style="width: 250px" />
            </el-form-item>
          </div>
          <el-card :body-style="{ padding: '20px' }" shadow="none">
            <template #header>
              <div>
                <span>短信模板</span>
              </div>
            </template>
            <el-form-item label="短信验证码：" prop="tmpl_smscode">
              <el-input
                v-model="form.tmpl_smscode"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_smscode_st"
                active-text="开启"
                inactive-text="关闭"
                active-value="1"
                inactive-value="0"
              ></el-switch>
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：您的验证码：{1}，该验证码5分钟内有效，请勿泄漏于他人！
              </span>
            </el-form-item>
            <el-form-item label="订单支付成功：" prop="tmpl_orderpay">
              <el-input
                v-model="form.tmpl_orderpay"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_orderpay_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：恭喜您订单支付成功，订单号：{1}，我们会尽快为您准备发货。
              </span>
            </el-form-item>
            <el-form-item label="订单发货通知：" prop="tmpl_orderfahuo">
              <el-input
                v-model="form.tmpl_orderfahuo"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_orderfahuo_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：您的订单{1}已发货，快递公司：{2}，快递单号：{3}，请留意查收。
              </span>
            </el-form-item>
            <el-form-item label="拼团成功通知：" prop="tmpl_collagesuccess">
              <el-input
                v-model="form.tmpl_collagesuccess"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_collagesuccess_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                填写模板ID
                模板内容示例：恭喜您的订单{1}拼团成功，我们会尽快为您准备发货。
              </span>
            </el-form-item>
            <el-form-item label="退款成功通知：" prop="tmpl_tuisuccess">
              <el-input
                v-model="form.tmpl_tuisuccess"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_tuisuccess_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：您的订单{1}退款成功，退款金额：{2}元，请留意查收。
              </span>
            </el-form-item>
            <el-form-item label="退款驳回通知：" prop="tmpl_tuierror">
              <el-input
                v-model="form.tmpl_tuierror"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_tuierror_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：抱歉您的订单{1}退款申请失败，原因：{2}。
              </span>
            </el-form-item>
            <el-form-item label="提现成功通知：" prop="tmpl_tixiansuccess">
              <el-input
                v-model="form.tmpl_tixiansuccess"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_tixiansuccess_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：恭喜您提现成功，打款金额：{1}，请留意查收。
              </span>
            </el-form-item>
            <el-form-item label="提现失败通知：" prop="tmpl_tixianerror">
              <el-input
                v-model="form.tmpl_tixianerror"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_tixianerror_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID 模板内容示例：抱歉您的提现申请失败，原因：{1}。
              </span>
            </el-form-item>
            <el-form-item label="分销成功提醒：" prop="tmpl_fenxiaosuccess">
              <el-input
                v-model="form.tmpl_fenxiaosuccess"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_fenxiaosuccess_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：恭喜您成功获得佣金：{1}元，请留意查收。
              </span>
            </el-form-item>
            <el-form-item
              label="餐饮预定成功提醒："
              prop="tmpl_restaurant_booking"
            >
              <el-input
                v-model="form.tmpl_restaurant_booking"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_restaurant_booking_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：恭喜您预定成功，餐厅名称：{1}，订位信息：{2}，预定时间：{3}，请准时到达。
              </span>
            </el-form-item>
            <el-form-item
              label="餐饮预定失败提醒："
              prop="tmpl_restaurant_booking_fail"
            >
              <el-input
                v-model="form.tmpl_restaurant_booking_fail"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_restaurant_booking_fail_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板ID
                模板内容示例：抱歉您的预定失败，餐厅名称：{1}，请重新预定。
              </span>
            </el-form-item>
            <el-form-item label="消费时间到期提醒：" prop="tmpl_use_expire">
              <el-input
                v-model="form.tmpl_use_expire"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_use_expire_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板编号
                模板内容示例：您消费的时间即将到期，为不影响您正常的使用，如有需要，请及时续费。
              </span>
            </el-form-item>
            <el-form-item
              label="约车支付成功提醒："
              prop="tmpl_carhailing_sucess"
            >
              <el-input
                v-model="form.tmpl_carhailing_sucess"
                style="width: 200px; margin-right: 20px"
              />
              <el-switch
                v-model="form.tmpl_carhailing_sucess_st"
                active-text="开启"
                inactive-text="关闭"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写模板编号
                模板内容示例：恭喜您！约车订单({1})已支付成功！我们会尽快提前安排，祝您旅途愉快！
              </span>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" @click="submitForm">确认修改</el-button>
            </el-form-item>
          </el-card>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="发送记录" name="second">11</el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Sms, SetSms, Sendlog } from '@/api/set'

export default {
  name: 'Fuchilog',

  data() {
    return {
      form: {},
      activeName: 'first',
      info: '',
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Sms().then((res) => {
      this.form = res.data.info
      this.form.tmpl_smscode_st = res.data.info.tmpl_smscode_st.toString()
    })
  },
  methods: {
    Sms,
    handleTab(tab) {
      if (tab.name == 'first') {
        this.Sms().then((res) => {
          this.form = res.data.info
          this.form.tmpl_smscode_st = res.data.info.tmpl_smscode_st.toString()
        })
      }
      if (tab.name == 'second') {
        Sendlog({
          page: this.page.current,
          limit: this.page.limit,
        }).then((res) => {
          this.info.data = res.data
          this.info.count = res.count
        })
      }
    },
    submitForm() {
      SetSms(this.form)
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Sendlog({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Sendlog({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
}
</style>
