<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 18, offset: 0 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card
            :body-style="{ padding: '20px' }"
            shadow="hover"
            style="border: none"
          >
            <template #header>
              <div>
                <span>退货设置</span>
              </div>
            </template>

            <el-form-item label="送货单打印标题：" prop="shipping_pagetitle">
              <el-input
                v-model="form.info.shipping_pagetitle"
                style="width: 200px"
              />
            </el-form-item>
            <el-form-item label="送货单每页行数：" prop="shipping_pagenum">
              <el-input
                v-model="form.info.shipping_pagenum"
                style="width: 200px"
              />
              <span style="margin-left: 20px; color: #969696">
                仅支持商城送货单，送货单每页显示行数(根据自己纸张大小修改)，0为不限制
              </span>
            </el-form-item>
            <el-form-item
              label="送货单品名及规格行数："
              prop="shipping_linenum"
            >
              <el-input
                v-model="form.info.shipping_linenum"
                style="width: 200px"
              />
              <span style="margin-left: 20px; color: #969696">
                仅支持商城送货单，送货单打印时品名及规格文字显示几行，多出的用省略号表示，0为不限制
              </span>
            </el-form-item>
            <el-form-item label="批量打印金额：" prop="printmoney">
              <el-radio-group v-model="form.info.printmoney">
                <el-radio :label="1">显示</el-radio>
                <el-radio :label="0">隐藏</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                仅支持商城送货单
              </span>
            </el-form-item>
            <el-form-item label="批量打印第几联：" prop="printlian">
              <el-radio-group v-model="form.info.printlian">
                <el-radio :label="1">显示</el-radio>
                <el-radio :label="0">隐藏</el-radio>
              </el-radio-group>
              <span style="margin-left: 20px; color: #969696">
                仅支持商城送货单
              </span>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm('form')">
                提交
              </el-button>
            </el-form-item>
          </el-card>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { ShdSet } from '@/api/set'
  export default {
    name: 'Shopset',
    data() {
      return {
        labelPosition: 'right',
        form: {
          name: '',
          region: '',
          date: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          description: '',
          rate: 0,
          area: [],
          transfer: [],
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.ShdSet().then((res) => {
        this.form = res.data
      })
    },
    methods: {
      ShdSet,
    },
  }
</script>

<style lang="scss" scoped></style>
