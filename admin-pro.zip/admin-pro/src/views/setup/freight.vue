<template>
  <div class="index-container">
    <el-alert :closable="false" show-icon title="扶持金明细 " type="success" />
    <vab-query-form>
      <vab-query-form-top-panel>
        <el-form
          ref="form"
          class="box"
          :inline="true"
          label-width="66px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="会员ID">
            <el-input v-model="queryForm.title" placeholder="请输入会员ID" />
          </el-form-item>
          <el-form-item label="昵称">
            <el-input v-model="queryForm.title" placeholder="请输入昵称" />
          </el-form-item>

          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
            >
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel :span="24">
        <el-button icon="el-icon-plus" type="primary" @click="handleAdd">
          添加
        </el-button>
        <el-button
          icon="el-icon-delete"
          type="danger"
          @click="handleDelete($event)"
        >
          删除
        </el-button>
      </vab-query-form-left-panel>
    </vab-query-form>
    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="ID" prop="id" sortable width="80" />
      <el-table-column fixed label="名称" prop="name" width="100" />
      <el-table-column label="配送方式" width="100">
        <template slot-scope="props">
          <el-form>
            <span v-if="props.row.pstype == '0'">普通快递</span>
            <span v-if="props.row.pstype == '1'">到店自提</span>
            <span v-if="props.row.pstype == '2'">同城配送</span>
            <span v-if="props.row.pstype == '5'">门店配送</span>
            <span v-if="props.row.pstype == '10'">货运托运</span>
            <span v-if="props.row.pstype == '11'">物流配送</span>
            <span v-if="props.row.pstype == '12'">平台跑腿</span>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="区域及价格">
        <template slot-scope="props">
          <el-form>
            <div v-html="props.row.pricedatahtml"></div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="满额包邮" width="100">
        <template slot-scope="props">
          <el-form>
            <span v-if="props.row.freeset == '0' || props.row.pstype == '1'">
              不开启
            </span>
            <span v-if="props.row.freeset == '1'">
              满{{ props.row.free_price }}元包邮
            </span>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="序号" prop="sort" sortable width="80" />

      <el-table-column label="状态" width="100">
        <template slot-scope="props">
          <el-form>
            <div v-if="props.row.status == 1">开启</div>
            <div v-else>关闭</div>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column fixed="right" label="操作" width="200">
        <el-button size="small" type="text">编辑</el-button>
        <el-button size="small" type="text">删除</el-button>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { Freight } from '@/api/set'

  export default {
    name: 'Fuchilog',

    data() {
      return {
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        layout: 'total, sizes, prev, pager, next, jumper',
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.Freight({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
      })
    },
    methods: {
      Freight,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.Freight({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.Freight({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped>
  .select-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .box {
    padding: 20px;
    background: #f2f5f8;
    border-radius: 6px;
    width: 100%;
  }
</style>
