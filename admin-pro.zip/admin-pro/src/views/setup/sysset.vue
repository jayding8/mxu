<template>
  <div class="index-container">
    <vab-theme />

    <el-tabs v-model="activeName">
      <el-tab-pane label="基础设置" name="first">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <vab-query-form>
              <!-- <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel> -->
            </vab-query-form>
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="125px" :model="form">
              <el-form-item label="商家名称：" prop="name">
                <el-input v-model="form.info.name" style="width: 240px" />
              </el-form-item>
              <el-form-item label="商家LOGO：" prop="logo">
                <el-button @click="handleShow()">上传logo图标</el-button>
                <el-image fit="fill" :lazy="true" :src="form.info.logo" />

                <span style="color: #999; margin-left: 20px">
                  建议尺寸：200×200像素
                </span>
                <vab-upload ref="vabUpload" :limit="50" name="file" :size="2" url="/upload" />
              </el-form-item>

              <el-form-item label="系统模式：" prop="mode">
                <el-radio-group v-model="form.info.mode">
                  <el-radio :label="0">商家模式</el-radio>
                  <el-radio :label="1">商户门店模式</el-radio>
                  <el-radio :label="2">定位模式</el-radio>
                  <el-radio :label="3">门店模式</el-radio>
                </el-radio-group>
              </el-form-item>
              <div v-if="form.info.mode === 0">
                <el-form-item>
                  <span style="color: #999">商城模式：传统在线商城；</span>
                </el-form-item>
              </div>
              <div v-else-if="form.info.mode === 1">
                <el-form-item>
                  <span style="color: #999">
                    商户门店模式：根据定位显示最近商户首页，不显示平台页面；
                  </span>
                </el-form-item>
                <el-form-item label="显示商户：" prop="loc_business_show_type">
                  <el-radio-group v-model="form.info.loc_business_show_type">
                    <el-radio :label="0">距离最近</el-radio>
                    <el-radio :label="1">推荐人商户</el-radio>
                  </el-radio-group>
                </el-form-item>
              </div>

              <div v-else-if="form.info.mode === 2">
                <el-form-item>
                  <span style="color: #999">
                    定位模式：根据用户位置，显示范围内的商家和商品信息；
                  </span>
                </el-form-item>
                <el-form-item label="定位显示：" prop="loc_area_type">
                  <el-radio-group v-model="form.info.loc_area_type">
                    <el-radio :label="0">当前城市</el-radio>
                    <el-radio :label="1">当前地址</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="显示范围：" prop="loc_range_type">
                  <el-radio-group v-model="form.info.loc_range_type">
                    <el-radio :label="0">同城</el-radio>
                    <el-radio :label="1">自定义范围距离</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item v-if="form.info.loc_range_type === 1" label="附近范围：" prop="loc_range">
                  <el-input v-model="form.info.loc_range" placeholder="请输入距离" style="width: 100px" />
                  <span style="color: #999; margin-left: 10px">Km</span>
                </el-form-item>
              </div>

              <div v-else-if="form.info.mode === 3">
                <el-form-item>
                  <span style="color: #999">
                    门店模式：根据组件归属门店，显示对应的门店和商品信息等；
                  </span>
                </el-form-item>
              </div>

              <el-form-item label="商家简介：" prop="desc">
                <el-input v-model="form.info.desc" style="width: 240px" type="textarea" />
              </el-form-item>
              <el-form-item label="商家服务电话：" prop="tel">
                <el-input v-model="form.info.tel" style="width: 240px" />
              </el-form-item>
              <el-form-item label="商家地址：" prop="address">
                <el-input v-model="form.info.address" style="width: 240px" />
              </el-form-item>
              <el-form-item label="经纬度：" prop="longitude">
                <el-input v-model="form.info.longitude" style="width: 114px" />
                -
                <el-input v-model="form.info.latitude" style="width: 114px" />
                <el-button style="margin-left: 20px" @click="submitForm('form')">
                  选择坐标
                </el-button>
              </el-form-item>

              <el-form-item label="微信小程序客服：" prop="wxkf">
                <el-radio-group v-model="form.info.wxkf">
                  <el-radio :label="0">客服链接</el-radio>
                  <el-radio :label="1">小程序客服</el-radio>
                  <el-radio :label="2">微信客服</el-radio>
                </el-radio-group>
              </el-form-item>
              <div v-if="form.info.wxkf === 0">
                <el-form-item>
                  <span style="color: #999">
                    客服链接：使用填写的客服链接，不填写则使用商城内部客服系统；如使用电话客服，链接格式为：tel:0539-123456；
                  </span>
                </el-form-item>
                <el-form-item label="客服链接：" prop="wxkfurl">
                  <el-input v-model="form.info.wxkfurl" style="width: 240px" />
                </el-form-item>
              </div>

              <div v-if="form.info.wxkf === 1">
                <el-form-item>
                  <div style="color: #999">
                    小程序客服：在小程序后台-功能-客服-小程序客服，配置客服人员；
                  </div>
                  <div style="color: #999">
                    选择系统管理员时需要配置消息推送
                  </div>
                </el-form-item>
                <el-form-item label="客服人员：" prop="wxkftransfer">
                  <el-select v-model="form.info.wxkftransfer" placeholder="请选择人员">
                    <el-option label="系统管理员" :value="0">
                      系统管理员
                    </el-option>
                    <el-option label="小程序客服" :value="1">
                      小程序客服
                    </el-option>
                  </el-select>
                </el-form-item>
              </div>

              <div v-if="form.info.wxkf === 2">
                <el-form-item>
                  <span style="color: #999">
                    微信客服：在微信客服系统注册账号并绑定，查看绑定流程，填写企业ID并复制客服链接填写到客服链接处
                  </span>
                </el-form-item>
                <el-form-item label="客服链接：" prop="wxkfurl">
                  <el-input v-model="form.info.wxkfurl" style="width: 240px" />
                </el-form-item>
                <el-form-item label="企业ID：" prop="corpid">
                  <el-input v-model="form.info.corpid" style="width: 240px" />
                </el-form-item>
              </div>

              <el-form-item label="公众号关注组件：" prop="official_account_status">
                <el-radio-group v-model="form.info.official_account_status">
                  <el-radio :label="0">开启</el-radio>
                  <el-radio :label="1">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item>
                <span style="color: #999">
                  仅微信小程序端生效（支持场景：扫描二维码、扫描小程序码），设置方式：小程序后台，在“设置”->“关注公众号”中设置要展示的公众号
                </span>
              </el-form-item>

              <el-form-item label="关注提示：" prop="gzts">
                <el-checkbox-group v-model="form.info.gzts">
                  <el-checkbox label="1">首页</el-checkbox>
                  <el-checkbox label="3">商品详情页</el-checkbox>
                </el-checkbox-group>
                <span style="color: #999">仅公众号端有效</span>
              </el-form-item>

              <el-form-item label="订单播报：" prop="ddbb">
                <el-checkbox-group v-model="form.info.ddbb">
                  <el-checkbox label="1">首页</el-checkbox>
                  <el-checkbox label="3">商品详情页</el-checkbox>
                </el-checkbox-group>
                <span style="color: #999">
                  首页或商品详情页滚动显示最近购买信息
                </span>
              </el-form-item>

              <el-form-item label="主色调" prop="color1">
                <div style="display: flex">
                  <el-input v-model="form.info.color1" style="width: 200px" />
                  <div style="margin-left: 10px">
                    <el-color-picker v-model="form.info.color1" :predefine="predefineColors" />
                    <span style="margin-left: 20px">
                      商城主色调，如：#FD4A46
                    </span>
                  </div>
                </div>
              </el-form-item>

              <el-form-item label="辅色调" prop="color2">
                <div style="display: flex">
                  <el-input v-model="form.info.color2" style="width: 200px" />
                  <div style="margin-left: 10px">
                    <el-color-picker v-model="form.info.color2" :predefine="predefineColors" />
                    <span style="margin-left: 20px">
                      商城辅色调，如：#7E71F6
                    </span>
                  </div>
                </div>
              </el-form-item>

              <el-form-item label="进入条件：" prop="gettj">
                <el-checkbox-group v-model="form.info.gettj">
                  <el-checkbox label="-1">所有人</el-checkbox>
                  <div v-for="(item, index) in form.levellist" :key="index">
                    <el-checkbox :label="item.id">{{ item.name }}</el-checkbox>
                  </div>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item v-if="form.info.gettj == '-1'" label="无权限提示：" prop="gettj">
                <el-input v-model="form.info.gettjtip" type="text" />
              </el-form-item>

              <el-form-item>
                <el-button type="primary" @click="submitForm()">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="财务设置" name="second">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="150px" :model="form">
              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>余额宝</span>
                  </div>
                </template>

                <el-form-item label="是否开启:" prop="open_yuebao">
                  <el-radio-group v-model="form.info.open_yuebao">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="余额宝收益利率：" prop="yuebao_rate">
                  <el-input v-model="form.info.yuebao_rate" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px">%</span>
                </el-form-item>
                <el-form-item label="收益提现天数：" prop="yuebao_withdraw_time">
                  <el-input v-model="form.info.yuebao_withdraw_time" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px">天</span>
                  <div style="color: #999">
                    注意：1、必须为整数
                    2、填0为不限制，填其他数字，如填写10，为每10天可提现一次
                    3、会员单独设置后此设置失效
                  </div>
                </el-form-item>
                <el-form-item label="收益转余额：" prop="yuebao_turn_yue">
                  <el-radio-group v-model="form.info.yuebao_turn_yue">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="余额宝收益提现：" prop="yuebao_withdraw">
                  <el-radio-group v-model="form.info.yuebao_withdraw">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-card>

              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>元宝</span>
                  </div>
                </template>
                <el-form-item label="元宝支付：" prop="yuanbao_pay">
                  <el-radio-group v-model="form.info.yuanbao_pay">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="元宝转账:" prop="yuanbao_transfer">
                  <el-radio-group v-model="form.info.yuanbao_transfer">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="与现金兑换比例：" prop="yuanbao_money_ratio">
                  <el-input v-model="form.info.yuanbao_money_ratio" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px">%</span>
                </el-form-item>
              </el-card>

              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>提现设置</span>
                  </div>
                </template>
                <el-form-item label="提现方式：" prop="name">
                  <el-checkbox-group v-model="form.info.othermoney_withdraw">
                    <el-checkbox border :label="form.info.withdraw_weixin">微信钱包</el-checkbox>
                    <el-checkbox border :label="form.info.withdraw_aliaccount">支付宝</el-checkbox>
                    <el-checkbox border :label="form.info.withdraw_bankcard">银行卡</el-checkbox>
                  </el-checkbox-group>
                  <div style="color: #999">
                    提现到微信钱包需开通企业付款到零钱功能；
                  </div>
                </el-form-item>
                <el-form-item label="其他余额提现：" prop="othermoney_withdraw">
                  <el-radio-group v-model="form.info.othermoney_withdraw">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                  <span style="color: #999; margin-left: 20px">
                    开启后解冻符合条件的会员
                  </span>
                </el-form-item>
                <el-form-item label="自动打款：" prop="withdraw_autotransfer">
                  <el-radio-group v-model="form.info.withdraw_autotransfer">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                  <span style="color: #999; margin-left: 20px">
                    开启后提现到微信钱包时不需要审核，自动用企业付款打款。
                  </span>
                </el-form-item>
                <el-form-item label="日提现次数：" prop="day_withdraw_num">
                  <el-input v-model="form.info.day_withdraw_num" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px">
                    次 会员每日余额和佣金可提现总次数，设为0时为无限制提现
                  </span>
                </el-form-item>
                <el-form-item label="提现说明：" prop="name">
                  <el-input v-model="form.info.withdraw_desc" style="width: 350px" type="textarea" />
                </el-form-item>
              </el-card>

              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>支付宝打款</span>
                  </div>
                </template>
                <el-form-item label="支付宝自动打款：" prop="ali_withdraw_autotransfer">
                  <el-radio-group v-model="form.info.ali_withdraw_autotransfer">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                  <div style="color: #999">
                    开启后提现到支付宝时不需要审核，自动用转账到支付宝账户，需开通转账到支付宝账户
                  </div>
                </el-form-item>
                <el-form-item label="支付宝APPID：" prop="ali_appid">
                  <el-input v-model="form.info.ali_appid" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px">
                    支付宝分配给开发者的应用ID
                  </span>
                </el-form-item>
                <el-form-item label="应用私钥：" prop="ali_privatekey">
                  <el-input v-model="form.info.ali_privatekey" style="width: 350px" />
                  <div style="color: #999">
                    请填写应用私钥去头去尾去回车，一行字符串
                  </div>
                </el-form-item>
                <el-form-item label="应用公钥：" prop="ali_apppublickey">
                  <el-input v-model="form.info.ali_apppublickey" style="width: 200px;margin-right: 10px;" />
                  <el-button @click="submitForm('form')">上传</el-button>
                </el-form-item>
                <el-form-item label="支付宝公钥：" prop="name">
                  <el-input v-model="form.info.ali_publickey" style="width: 200px;margin-right: 10px;" />

                  <el-button @click="submitForm('form')">上传</el-button>
                </el-form-item>
                <el-form-item label="支付宝根证书：" prop="name">
                  <el-input v-model="form.info.ali_rootcert" style="width: 200px;margin-right: 10px;" />

                  <el-button @click="submitForm('form')">上传</el-button>
                </el-form-item>
              </el-card>
              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>充值业绩提现</span>
                  </div>
                </template>
                <el-form-item label="充值业绩提现：" prop="rechargeyj_withdraw">
                  <el-radio-group v-model="form.info.rechargeyj_withdraw">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="提现最小金额：" prop="rechargeyj_withdrawmin">
                  <el-input v-model="form.info.rechargeyj_withdrawmin" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px; margin-left: 20px">
                    元
                  </span>
                </el-form-item>
                <el-form-item label="提现手续费：" prop="rechargeyj_withdrawfee">
                  <el-input v-model="form.info.rechargeyj_withdrawfee" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px; margin-left: 20px">
                    %
                  </span>
                </el-form-item>
              </el-card>

              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>微信支付</span>
                  </div>
                </template>

                <el-form-item label="使用权限：" prop="wxpay_gettj">
                  <el-checkbox-group v-model="form.info.wxpay_gettj">
                    <el-checkbox label="-1">所有人</el-checkbox>
                    <div v-for="(item, index) in form.levellist" :key="index">
                      <el-checkbox :label="item.id">{{ item.name }}</el-checkbox>
                    </div>
                  </el-checkbox-group>

                </el-form-item>
              </el-card>
              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>信用额度</span>
                  </div>
                </template>
                <el-form-item label="信用额度支付：" prop="overdraft_moneypay">
                  <el-radio-group v-model="form.info.overdraft_moneypay">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-card>
              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>好友代付</span>
                  </div>
                </template>
                <el-form-item label="好友代付开关：" prop="pay_daifu">
                  <el-radio-group v-model="form.info.pay_daifu">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="提现说明：" prop="name">
                  <el-input v-model="form.info.pay_daifu_desc" style="width: 350px" type="textarea" />
                </el-form-item>
              </el-card>

              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>转账汇款</span>
                  </div>
                </template>
                <el-form-item label="转账汇款支付：" prop="pay_transfer">
                  <el-radio-group v-model="form.info.pay_transfer">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                  <span style="color: #999; margin-left: 20px">
                    开启后会员下单时可使用此支付方式，后台需审核并处理订单，仅平台支持
                  </span>
                </el-form-item>
                <el-form-item label="户名：" prop="pay_transfer_account_name">
                  <el-input v-model="form.info.pay_transfer_account_name" style="width: 350px" />
                </el-form-item>
                <el-form-item label="账号：" prop="pay_transfer_account">
                  <el-input v-model="form.info.pay_transfer_account" style="width: 350px" />
                </el-form-item>
                <el-form-item label="开户行：" prop="pay_transfer_bank">
                  <el-input v-model="form.info.pay_transfer_bank" style="width: 350px" />
                </el-form-item>

                <el-form-item label="提示信息：" prop="pay_transfer_desc">
                  <el-input v-model="form.info.pay_transfer_desc" style="width: 350px" type="textarea" />
                  <div style="color: #999">
                    展示在转账信息下面的提示说明，如：汇款时请将订单号填写在附言，备注等栏位
                  </div>
                </el-form-item>
                <el-form-item label="使用权限：" prop="pay_transfer_gettj">
                  <el-checkbox-group v-model="form.info.pay_transfer_gettj">
                    <el-checkbox label="-1">所有人</el-checkbox>
                    <div v-for="(item, index) in form.levellist" :key="index">
                      <el-checkbox :label="item.id">{{ item.name }}</el-checkbox>
                    </div>
                  </el-checkbox-group>

                </el-form-item>
                <el-form-item label="转账审核:" prop="pay_transfer_check">
                  <el-radio-group v-model="form.info.pay_transfer_check">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                  <div style="color: #999; margin-left: 20px">
                    开启后会员下单时需要先审核，才能使用转换汇款功能
                  </div>
                </el-form-item>
              </el-card>

              <el-card :body-style="{ padding: '20px' }" shadow="hover">
                <template #header>
                  <div>
                    <span>发票设置</span>
                  </div>
                </template>
                <el-form-item label="发票开关 ：" prop="invoice">
                  <el-radio-group v-model="form.info.invoice">
                    <el-radio :label="1">开启</el-radio>
                    <el-radio :label="0">关闭</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="发票类型：" prop="invoice_type">
                  <el-checkbox-group v-model="form.info.invoice_type">
                    <el-checkbox :label="1" name="type">普通发票</el-checkbox>
                    <el-checkbox :label="2" name="type">增值税专用发票</el-checkbox>
                  </el-checkbox-group>
                </el-form-item>
                <el-form-item label="发票税点：" prop="invoice_rate">
                  <el-input v-model="form.info.invoice_rate" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px; margin-left: 20px">
                    %
                  </span>
                </el-form-item>
              </el-card>

              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="余额设置" name="Third">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="150px" :model="form">
              <el-form-item label="余额支付：" prop="moneypay">
                <el-radio-group v-model="form.info.moneypay">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="余额充值：" prop="recharge">
                <el-radio-group v-model="form.info.recharge">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="佣金转余额：" prop="commission2money">
                <el-radio-group v-model="form.info.commission2money">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  开启后会员可以将佣金直接转入余额中用于消费
                </span>
              </el-form-item>
              <el-form-item label="佣金转余额消耗积分：" prop="comtomoney_need_score">
                <el-radio-group v-model="form.info.comtomoney_need_score">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="佣金余额兑换比例：" prop="commission_money_exchange_num">
                <el-input v-model="form.info.commission_money_exchange_num" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  佣金可兑换1.00余额
                </span>
              </el-form-item>
              <el-form-item label="佣金百分比到积分：" prop="commission_perc_to_score">
                <el-input v-model="form.info.commission_perc_to_score" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  % 获取佣金时百分比到积分
                </span>
              </el-form-item>

              <el-form-item label="余额转账：" prop="money_transfer">
                <el-radio-group v-model="form.info.money_transfer">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="余额转账范围：" prop="money_transfer_range">
                <el-radio-group v-model="form.info.money_transfer_range">
                  <el-radio :label="0">全站</el-radio>
                  <el-radio :label="1">所有上下级</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="余额转账支付密码：" prop="money_transfer_pwd">
                <el-radio-group v-model="form.info.money_transfer_pwd">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="余额抵扣：" prop="money_dec">
                <el-radio-group v-model="form.info.money_dec">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="最高抵扣比例：" prop="money_dec_rate">
                <el-input v-model="form.info.money_dec_rate" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  % 余额最高抵扣比例
                </span>
              </el-form-item>
              <el-form-item label="余额组合支付：" prop="iscombine">
                <el-radio-group v-model="form.info.iscombine">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item>
                <span style="color: #999">
                  开启后：仅商城商品订单支付可以选择余额和微信，或者余额和支付宝多形式的组合支付;
                  使用组合支付，提交支付不管微信或支付宝是否支付成功，都会直接扣除余额支付的部分
                  订单退款先退微信或支付宝支付部分，后退余额支付部分
                </span>
              </el-form-item>
              <el-form-item label="余额提现：" prop="withdraw">
                <el-radio-group v-model="form.info.withdraw">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="提现最小金额：" prop="withdrawmin">
                <el-input v-model="form.info.withdrawmin" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">元</span>
              </el-form-item>
              <el-form-item label="提现最高金额：" prop="withdrawmax">
                <el-input v-model="form.info.withdrawmax" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  元 单笔最高提现金额，大于0生效，0为无限制
                </span>
              </el-form-item>
              <el-form-item label="提现倍数：" prop="withdrawmul">
                <el-input v-model="form.info.withdrawmul" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  元
                  单笔提现整数倍，提现金额必须为设定值的整数倍，设置0或空不做限制
                </span>
              </el-form-item>
              <el-form-item label="提现手续费：" prop="withdrawfee">
                <el-input v-model="form.info.withdrawfee" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">%</span>
              </el-form-item>
              <el-form-item label="余额可提现日期：" prop="comwithdrawdate_money">
                <el-input v-model="form.info.comwithdrawdate_money" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  0表示不限制，多个用英文逗号分隔，如：01,02
                  表示每月1号和2号可以提现
                </span>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="佣金设置" name="Fourth1">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="180px" :model="form">
              <el-form-item label="佣金提现：" prop="comwithdraw">
                <el-radio-group v-model="form.info.comwithdraw">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="佣金自动提现：" prop="commission_autowithdraw">
                <el-radio-group v-model="form.info.commission_autowithdraw">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  开启后佣金结算后将自动通过企业付款到零钱，需开通企业付款到零钱功能
                </span>
              </el-form-item>

              <el-form-item label="佣金提现消耗积分：" prop="comwithdraw_need_score">
                <el-radio-group v-model="form.info.comwithdraw_need_score">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="佣金积分兑换比例：" prop="commission_score_exchange_num">
                <el-input v-model="form.info.commission_score_exchange_num" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  积分可兑换1佣金
                </span>
              </el-form-item>
              <el-form-item label="提现最小金额：" prop="comwithdrawmin">
                <el-input v-model="form.info.comwithdrawmin" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">元</span>
              </el-form-item>
              <el-form-item label="提现最高金额：" prop="comwithdrawmax">
                <el-input v-model="form.info.comwithdrawmax" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">元</span>
                <div style="color: #999">
                  元 单笔最高提现金额，大于0生效，0为无限制
                </div>
              </el-form-item>

              <el-form-item label="提现倍数：" prop="comwithdrawmul">
                <el-input v-model="form.info.comwithdrawmul" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  元
                  单笔提现整数倍，提现金额必须为设定值的整数倍，设置0或空不做限制
                </span>
              </el-form-item>
              <el-form-item label="佣金提现最小单位：" prop="comwithdraw_integer_type">
                <el-radio-group v-model="form.info.comwithdraw_integer_type">
                  <el-radio :label="0">不限</el-radio>
                  <el-radio :label="1">个</el-radio>
                  <el-radio :label="2">十</el-radio>
                  <el-radio :label="3">百</el-radio>
                  <el-radio :label="4">千</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  提现最小金额 按个，十，百，千整数提现选择。
                </span>
              </el-form-item>
              <el-form-item label="提现积分与佣金对碰比例：" prop="comwithdraw_duipeng_score_bili">
                <el-input v-model="form.info.comwithdraw_duipeng_score_bili" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  例：填2，提现积分:佣金提现=2:1 ，两个提现积分对比1
                  填写0则没有对碰比例
                </span>
              </el-form-item>
              <el-form-item label="提现手续费：" prop="comwithdrawfee">
                <el-input v-model="form.info.comwithdrawfee" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">%</span>
              </el-form-item>
              <el-form-item label="提现冻结：" prop="comwithdraw_freeze">
                <el-checkbox label="" name="type" />
                <span style="color: #999; margin-left: 20px; margin-right: 20px">
                  累计提现
                </span>
                <el-input v-model="form.info.comwithdraw_totalmoney" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">元</span>
              </el-form-item>

              <el-form-item label="解冻条件：" prop="jiedong_condtion">
                <el-checkbox label="" name="type" />
                <span style="color: #999; margin-left: 20px; margin-right: 20px">
                  购买商品ID
                </span>
                <el-input v-model="form.info.buy_proid" style="width: 200px" />
                <span style="color: #999; margin-left: 20px; margin-right: 20px">
                  数量
                </span>
                <el-input v-model="form.info.buypro_num" style="width: 100px" />
              </el-form-item>

              <el-form-item>
                <span style="color: #999">
                  商品ID：多个ID用英文逗号分隔，对应的购买数量也用英文逗号分隔，用法1：多个商品ID多个购买数量表示任一商品购买数量≥对应数量即满足条件，用法2：多个商品ID一个购买数量表示所有商品的购买总量≥数量即满足条件
                </span>
              </el-form-item>
              <el-form-item label="是否解冻：" prop="comwithdraw_isjiedong">
                <el-radio-group v-model="form.info.comwithdraw_isjiedong">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  开启后解冻符合条件的会员
                </span>
              </el-form-item>
              <el-form-item label="佣金可提现日期：" prop="comwithdrawdate">
                <el-input v-model="form.info.comwithdrawdate" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  0表示不限制，多个用英文逗号分隔，如：01,02
                  表示每月1号和2号可以提现
                </span>
              </el-form-item>
              <el-form-item label="可提现比例：" prop="comwithdrawbl">
                <el-input v-model="form.info.comwithdrawbl" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  % 可提现比例不是100%时,不可提现部分在提现时直接转换为余额
                </span>
              </el-form-item>
              <el-form-item label="佣金到积分账户比例：" prop="commission2scorepercent">
                <el-input v-model="form.info.commission2scorepercent" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  % 产生佣金时其中一部分按设置比例自动转成积分
                </span>
              </el-form-item>
              <el-form-item label="佣金到余额账户比例：" prop="commission2moneypercent1">
                <el-input v-model="form.info.commission2moneypercent1" placeholder="" style="width: 200px">
                  <template slot="prepend">首单</template>
                </el-input>
                <span style="color: #999; margin-left: 10px; margin-right: 20px">
                  %
                </span>
                <el-input v-model="form.info.commission2moneypercent2" placeholder="" style="width: 200px">
                  <template slot="prepend">复购</template>
                </el-input>
                <span style="color: #999; margin-left: 10px">%</span>
                <div style="color: #999">
                  设置后商城订单产生佣金时就有一部分比例自动转成余额
                </div>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="积分设置" name="Fifth3">
        <el-row :gutter="20">
          <el-col :lg="{ span: 16, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 14, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="180px" :model="form">
              <el-form-item label="消费赠积分：" prop="scorein_money">
                <el-input v-model="form.info.scorein_money" placeholder="" style="width: 200px">
                  <template slot="prepend">消费每满</template>
                </el-input>
                <span style="color: #999; margin-left: 10px; margin-right: 20px">
                  元
                </span>
                <el-input v-model="form.info.scorein_score" placeholder="" style="width: 200px">
                  <template slot="prepend">赠送</template>
                </el-input>
                <span style="color: #999; margin-left: 10px">积分</span>
                <div style="color: #999">
                  支付后积分即到账，发生退款时不会扣除
                </div>
              </el-form-item>
              <el-form-item label="充值赠积分：" prop="scorecz_money">
                <el-input v-model="form.info.scorecz_money" placeholder="" style="width: 200px">
                  <template slot="prepend">充值每满</template>
                </el-input>
                <span style="color: #999; margin-left: 10px; margin-right: 20px">
                  元
                </span>
                <el-input v-model="form.info.scorecz_score" placeholder="" style="width: 200px">
                  <template slot="prepend">赠送</template>
                </el-input>
                <span style="color: #999; margin-left: 10px">积分</span>
              </el-form-item>
              <el-form-item label="积分抵扣：" prop="score2money">
                <el-input v-model="form.info.score2money" placeholder="" style="width: 200px">
                  <template slot="prepend">每积分抵扣</template>
                </el-input>
                <span style="color: #999; margin-left: 10px; margin-right: 20px">
                  元
                </span>
                <el-input v-model="form.info.scoredkmaxpercent" placeholder="" style="width: 250px">
                  <template slot="prepend">最多抵扣百分比</template>
                </el-input>
                <span style="color: #999; margin-left: 10px">%</span>
                <div style="color: #999">
                  付款时一个积分可抵扣多少元，0表示不开启积分抵扣；选择使用积分抵扣时，最多可抵扣订单额的百分之多少
                </div>
              </el-form-item>
              <el-form-item label="积分不抵扣运费：" prop="scorebdkyf">
                <el-switch v-model="form.info.scorebdkyf" />
                <span style="color: #999; margin-left: 20px">
                  开启后积分不能抵扣运费
                </span>
              </el-form-item>
              <el-form-item label="余额支付送积分：" prop="score_from_moneypay">
                <el-radio-group v-model="form.info.score_from_moneypay">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  [营销]-[充值赠送]也可赠送积分，开启后余额支付会再次赠送
                </span>
              </el-form-item>
              <el-form-item label="积分过期：" prop="score_expire_status">
                <el-radio-group v-model="form.info.score_expire_status">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  开启后佣金结算后将自动通过企业付款到零钱，需开通企业付款到零钱功能
                </span>
              </el-form-item>
              <el-form-item label="过期天数：" prop="score_expire_days">
                <el-input v-model="form.info.score_expire_days" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">0为不过期</span>
              </el-form-item>
              <el-form-item label="积分转赠：" prop="score_transfer">
                <el-radio-group v-model="form.info.score_transfer">
                  <el-radio :label="0">开启</el-radio>
                  <el-radio :label="1">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="积分转赠范围：" prop="score_transfer_range">
                <el-radio-group v-model="form.info.score_transfer_range">
                  <el-radio :label="0">全站</el-radio>
                  <el-radio :label="1">所有上下级</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="积分转赠使用权限：" prop="score_transfer_gettj">
                <el-checkbox-group v-model="form.info.score_transfer_gettj">
                  <el-checkbox label="所有人" name="type" />
                  <el-checkbox label="普通会员" name="type" />
                  <el-checkbox label="VIP" name="type" />
                  <el-checkbox label="白金会员" name="type" />
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="积分转赠支付密码：" prop="score_transfer_pwd">
                <el-radio-group v-model="form.info.score_transfer_pwd">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="积分提现到余额：" prop="score_withdraw">
                <el-radio-group v-model="form.info.score_withdraw">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="每日转允提积分比例：" prop="score_withdraw_percent_day">
                <el-input v-model="form.info.score_withdraw_percent_day" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  %
                  每日普通积分转为可提现积分的百分比，不足1积分按1积分，大于1积分时，对小数位四舍五入取整数
                </span>
              </el-form-item>
              <el-form-item label="积分转余额换算比例：" prop="score_to_money_percent">
                <el-input v-model="form.info.score_to_money_percent" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  如设置0.5，表示1积分换0.5元余额
                </span>
              </el-form-item>
              <el-form-item label="积分自动转余额：" prop="score_to_money_auto">
                <el-radio-group v-model="form.info.score_to_money_auto">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>

              <div v-if="form.info.score_to_money_auto == 1">
                <el-form-item label="每日积分自动转余额比例：" prop="score_to_money_auto_day">
                  <el-input v-model="form.info.score_to_money_auto_day" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px">%</span>
                  <span style="color: #999; margin-left: 20px">
                    每日普通积分转为余额的百分比，不足1积分按1积分，大于1积分时，对小数位四舍五入取整数
                  </span>
                </el-form-item>

                <el-form-item label="每日积分自动转余额换算比例：" prop="score_to_money_auto_percent">
                  <el-input v-model="form.info.score_to_money_auto_percent" style="width: 100px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
              </div>
              <el-form-item label="积分小数位数：" prop="score_weishu">
                <el-input v-model="form.info.score_weishu" style="width: 100px" />
                <span style="color: #999; margin-left: 20px">
                  系统中积分保留小数位数，最高支持三位
                </span>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
        </el-row>
      </el-tab-pane>

      <el-tab-pane label="分销设置" name="Fourth">
        <el-row :gutter="20">
          <el-col :lg="{ span: 16, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 14, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="180px" :model="form">
              <el-form-item label="分销结算方式：" prop="fxjiesuantype">
                <el-radio-group v-model="form.info.fxjiesuantype">
                  <el-radio :label="0">按商品价格</el-radio>
                  <el-radio :label="1">按成本价格</el-radio>
                  <el-radio :label="2">按销售利润</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  按商品价格结算：商品价格×提成百分比；
                </div>
                <div style="color: #999">
                  按成交价格结算：成交价格×提成百分比,即扣除会员折扣、满减优惠、优惠券抵扣及积分抵扣后计算分销；
                </div>
                <div style="color: #999">
                  按销售利润结算：（成交价格-商品成本）×提成百分比
                </div>
              </el-form-item>
              <el-form-item label="分销结算时间：" prop="fxjiesuantime">
                <el-radio-group v-model="form.info.fxjiesuantime">
                  <el-radio :label="0">确认收货后</el-radio>
                  <el-radio :label="1">收款后</el-radio>
                </el-radio-group>
                <el-input v-model="form.info.fxjiesuantime_delaydays" style="width: 100px; margin-left: 20px" />
                <span style="color: #999; margin-left: 20px">天结算</span>
                <div style="color: #999">
                  注意：0代表付款或确认收货后立即结算，如果产生退款，已发放的佣金不会扣除
                </div>
              </el-form-item>

              <el-form-item label="分销级差：" prop="fx_differential">
                <el-radio-group v-model="form.info.fx_differential">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  开启后分销将按照级差进行计算，仅限按金额和比例方式
                </span>
              </el-form-item>

              <el-form-item label="分销紧缩：" prop="fx_jinsuo">
                <el-radio-group v-model="form.info.fx_jinsuo">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  开启后分销将紧缩掉分销"提成比例"并且"买单提成积分"为0的用户
                </span>
              </el-form-item>
              <el-form-item label="分销补贴：" prop="fx_butie_type">
                <el-radio-group v-model="form.info.fx_butie_type">
                  <el-radio :label="1">按周</el-radio>
                  <el-radio :label="0">按月</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">补贴周期</span>
                <el-input v-model="form.info.fx_butie_circle" style="width: 100px; margin-left: 20px" />
                <div v-if="form.info.fx_butie_type === 1" style="margin-top: 20px">
                  <el-input v-model="form.info.fx_butie_send_week" placeholder="" style="width: 200px">
                    <template slot="prepend">每周</template>
                  </el-input>
                  <span style="color: #999; margin-left: 20px">
                    发放（填写数字1-7）
                  </span>
                </div>
                <div v-if="form.info.fx_butie_type === 0" style="margin-top: 20px">
                  <el-input v-model="form.info.fx_butie_send_day" placeholder="" style="width: 200px">
                    <template slot="prepend">每月</template>
                  </el-input>
                  <span style="color: #999; margin-left: 20px">
                    号发放（填写数字1-31））
                  </span>
                </div>
                <div style="margin-top: 20px">
                  1、发放佣金时立马发放第一期补贴
                  <br />
                  2、补贴周期：共分多少期发放
                  <br />
                  3、按周：填写数字1-7，每周发放一次
                  <br />
                  4、按月：填写数字1-31，每月发放一次，没有31号的月份自动提前到30号发放
                  <br />
                  5、产生补贴时会记录当前设置参数，补贴以已生成再改参数不会生效
                </div>
              </el-form-item>

              <el-form-item label="直推复购奖：" prop="is_fugou_commission">
                <el-radio-group v-model="form.info.is_fugou_commission">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
              </el-form-item>

              <el-form-item v-if="form.info.is_fugou_commission === 1" label="复购奖励设置：" prop="fugou_recursion_percent">
                <el-input v-model="form.info.fugou_recursion_percent" style="width: 100px; margin-left: 20px" />
                <span style="color: #999; margin-left: 20px">
                  ，逐级递减，当金额低于
                </span>
                <el-input v-model="form.info.fugou_commission_min" style="width: 100px; margin-left: 20px" />
                <span style="color: #999; margin-left: 20px">
                  元时，停止佣金发放
                </span>
              </el-form-item>

              <el-form-item label="买单收款分销：" prop="maidanfenxiao">
                <el-radio-group v-model="form.info.maidanfenxiao">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  买单收款功能是否参与分销
                </span>
              </el-form-item>
              <el-form-item label="收银台分销：" prop="cashdeskfenxiao">
                <el-radio-group v-model="form.info.cashdeskfenxiao">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  买单收款功能是否参与分销
                </span>
              </el-form-item>

              <el-form-item label="分红结算方式：" prop="fhjiesuantype">
                <el-radio-group v-model="form.info.fhjiesuantype">
                  <el-radio :label="0">按照销售金额</el-radio>
                  <el-radio :label="1">按照销售利润</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  按销售金额结算即：销售价格×提成百分比，按销售利润即：（销售价格-商品成本）×提成百分比
                </div>
              </el-form-item>

              <el-form-item label="分红结算时间：" prop="fhjiesuantime_type">
                <el-radio-group v-model="form.info.fhjiesuantime_type">
                  <el-radio :label="0">确认收货后结算</el-radio>
                  <el-radio :label="1">付款后结算</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  确认收货后结算：可选计算周期，付款后结算：每分钟计算一次
                </div>
                <div style="color: #ff0000">
                  注意：选择付款后结算退款时无法退回分红
                </div>
              </el-form-item>
              <el-form-item v-if="form.info.fhjiesuantime_type === 0" label="分红结算周期：" prop="fhjiesuantime">
                <el-radio-group v-model="form.info.fhjiesuantime">
                  <el-radio :label="3">每分钟结算</el-radio>
                  <el-radio :label="2">每小时结算</el-radio>
                  <el-radio :label="0">每天结算</el-radio>
                  <!-- <el-radio :label="7">周一结算</el-radio> -->
                  <el-radio :label="1">月初结算</el-radio>
                  <el-radio :label="4">月底结算</el-radio>
                  <el-radio :label="5">年底结算</el-radio>
                  <!-- <el-radio :label="10">手动结算</el-radio> -->
                </el-radio-group>
                <div style="color: #999">
                  每天结算则第二天计算前一天的分红并发放，月初结算则每月一号计算上一个月的分红并发放（确认收货的订单）
                </div>
              </el-form-item>

              <el-form-item label="分红合并结算：" prop="fhjiesuanhb">
                <el-radio-group v-model="form.info.fhjiesuanhb">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">
                  分红合并结算即结算时所有需要分红的订单合并为一条,产生一条结算记录
                </span>
              </el-form-item>

              <el-form-item label="团队分红级差：" prop="teamfenhong_differential">
                <el-radio-group v-model="form.info.teamfenhong_differential">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <el-checkbox label="" name="type" style="margin-left: 20px">
                  包含平级奖励
                </el-checkbox>
                <div style="color: #999">开启后团队分红将按照级差进行分红</div>
              </el-form-item>

              <el-form-item label="区域代理分红级差：" prop="areafenhong_differential">
                <el-radio-group v-model="form.info.areafenhong_differential">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  开启后区域代理分红将按照级差进行分红
                </div>
              </el-form-item>
              <el-form-item label="团队见单分红级差：" prop="teamfenhong_jiandan_differential">
                <el-radio-group v-model="form.info.teamfenhong_jiandan_differential">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">开启后见单分红将按照级差进行分红</div>
              </el-form-item>
              <el-form-item label="多商户商品分红：" prop="fhjiesuanbusiness">
                <el-radio-group v-model="form.info.fhjiesuanbusiness">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">开启后多商户的商品也参与分红</div>
              </el-form-item>

              <el-form-item label="股东分红上限累加低级别：" prop="fenhong_max_add">
                <el-radio-group v-model="form.info.fenhong_max_add">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  开启后高等级的股东也会参与低等级的股东分红
                </div>
              </el-form-item>

              <el-form-item label="股东分红仅奖励购买人上级等级：" prop="partner_parent_only">
                <el-radio-group v-model="form.info.partner_parent_only">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  开启后股东分红仅奖励购买人上级等级，其他等级不奖励，无上级也不奖励
                </div>
              </el-form-item>

              <el-form-item label="股东加权分红：" prop="partner_jiaquan">
                <el-radio-group v-model="form.info.partner_jiaquan">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  开启后高等级的股东也会参与低等级的股东分红
                </div>
              </el-form-item>

              <el-form-item label="股东分红叠加：" prop="gdfenhong_add">
                <el-radio-group v-model="form.info.gdfenhong_add">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  1、开启后高等级的股东也会参与低等级的股东分红
                  <br />
                  2、高等级不参与低等级的人数计算，例：A股东分红=（A总分红/A人数）B股东分红=（A总分红/A人数+B总分红/B人数）
                  <br />
                  3、与《股东加权分红》冲突，不可同时开启
                </div>
              </el-form-item>

              <el-form-item label="区域代理加权分红：" prop="areafenhong_jiaquan">
                <el-radio-group v-model="form.info.areafenhong_jiaquan">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  开启后上级区域的区域代理也会参与下级区域的区域分红
                </div>
              </el-form-item>

              <el-form-item label="区域判断方式：" prop="areafenhong_checktype">
                <el-radio-group v-model="form.info.areafenhong_checktype">
                  <el-radio :label="0">收货地址</el-radio>
                  <el-radio :label="1">手机号归属地</el-radio>
                </el-radio-group>
              </el-form-item>

              <el-form-item label="股东贡献量分红：" prop="partner_gongxian">
                <el-radio-group v-model="form.info.partner_gongxian">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  开启后可设置一定比例的分红金额按照股东的团队业绩量分红
                </div>
              </el-form-item>

              <el-form-item label="预计股东贡献量分红：" prop="gongxianfenhong_show">
                <el-radio-group v-model="form.info.gongxianfenhong_show">
                  <el-radio :label="1">显示</el-radio>
                  <el-radio :label="0">不显示</el-radio>
                </el-radio-group>
                <span style="color: #999; margin-left: 20px">自定义名称</span>
                <el-input v-model="form.info.gongxianfenhong_txt" style="width: 100px; margin-left: 20px" />
              </el-form-item>

              <el-form-item label="推荐商家结算方式：" prop="tjbusiness_jiesuan_type">
                <el-radio-group v-model="form.info.tjbusiness_jiesuan_type">
                  <el-radio :label="0">按结算金额</el-radio>
                  <el-radio :label="1">按平台抽成金额</el-radio>
                  <el-radio :label="2">按利润金额</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  结算金额为扣除平台抽成后商家所得金额，商家和平台结算完成后，推荐人获得佣金
                  ，按平台抽成金额：根据平台抽成金额*提成百分比，
                  按销售利润结算：（成交价格-商品成本）×提成百分比
                </div>
              </el-form-item>

              <el-form-item label="团队业绩：" prop="teamyeji_show">
                <el-radio-group v-model="form.info.teamyeji_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示团队业绩</div>
              </el-form-item>

              <el-form-item label="团队业绩包含自身：" prop="teamyeji_self">
                <el-radio-group v-model="form.info.teamyeji_self">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示团队业绩</div>
              </el-form-item>

              <el-form-item label="团队总人数：" prop="teamnum_show">
                <el-radio-group v-model="form.info.teamnum_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  前端我的佣金页面是否显示团队总人数
                </div>
              </el-form-item>
              <el-form-item label="推荐人：" prop="parent_show">
                <el-radio-group v-model="form.info.parent_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示推荐人</div>
              </el-form-item>
              <el-form-item label="推荐商家列表：" prop="tjbusiness_show">
                <el-radio-group v-model="form.info.tjbusiness_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  前端我的佣金页面是否显示推荐商家列表
                </div>
              </el-form-item>
              <el-form-item label="团队分红：" prop="teamfenhong_show">
                <el-radio-group v-model="form.info.teamfenhong_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示团队分红</div>
              </el-form-item>
              <el-form-item label="商家团队分红：" prop="business_teamfenhong_show">
                <el-radio-group v-model="form.info.business_teamfenhong_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  前端我的佣金页面是否显示商家团队分红
                </div>
              </el-form-item>

              <el-form-item label="佣金明细：" prop="commissionlog_show">
                <el-radio-group v-model="form.info.commissionlog_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示佣金明细</div>
              </el-form-item>
              <el-form-item label="佣金记录：" prop="commissionrecord_show">
                <el-radio-group v-model="form.info.commissionrecord_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示佣金记录</div>
              </el-form-item>
              <el-form-item label="佣金提现记录：" prop="commissionrecord_withdrawlog_show">
                <el-radio-group v-model="form.info.commissionrecord_withdrawlog_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  前端佣金提现页面是否显示佣金提现记录
                </div>
              </el-form-item>
              <el-form-item label="分红订单：" prop="fhorder_show">
                <el-radio-group v-model="form.info.fhorder_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示分红订单</div>
              </el-form-item>
              <el-form-item label="分红记录：" prop="fhlog_show">
                <el-radio-group v-model="form.info.fhlog_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示分红记录</div>
              </el-form-item>
              <el-form-item label="分销订单：" prop="fxorder_show">
                <el-radio-group v-model="form.info.fxorder_show">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <div style="color: #999">前端我的佣金页面是否显示分销订单</div>
              </el-form-item>

              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 8, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 10, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="全局文案" name="Fifth">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="130px" :model="form">
              <el-form-item label="余额：" prop="余额">
                <el-input v-model="form.textset.余额" style="width: 150px" />
              </el-form-item>
              <el-form-item label="积分：" prop="积分">
                <el-input v-model="form.textset.积分" style="width: 150px" />
              </el-form-item>
              <el-form-item label="佣金：" prop="佣金">
                <el-input v-model="form.textset.佣金" style="width: 150px" />
              </el-form-item>
              <el-form-item label="优惠券：" prop="优惠券">
                <el-input v-model="form.textset.优惠券" style="width: 150px" />
              </el-form-item>
              <el-form-item label="会员：" prop="会员">
                <el-input v-model="form.textset.会员" style="width: 150px" />
              </el-form-item>

              <el-form-item label="团队分红：" prop="团队分红">
                <el-input v-model="form.textset.团队分红" style="width: 150px" />
              </el-form-item>
              <el-form-item label="股东分红：" prop="股东分红">
                <el-input v-model="form.textset.股东分红" style="width: 150px" />
              </el-form-item>
              <el-form-item label="区域代理分红：" prop="区域代理分红">
                <el-input v-model="form.textset.区域代理分红" style="width: 150px" />
              </el-form-item>
              <el-form-item label="等级团队分红：" prop="等级团队分红">
                <el-input v-model="form.textset.等级团队分红" style="width: 150px" />
              </el-form-item>
              <el-form-item label="商品团队分红：" prop="商品团队分红">
                <el-input v-model="form.textset.商品团队分红" style="width: 150px" />
              </el-form-item>

              <el-form-item label="转账汇款：" prop="转账汇款">
                <el-input v-model="form.textset.转账汇款" style="width: 150px" />
              </el-form-item>
              <el-form-item label="扶持金：" prop="扶持金">
                <el-input v-model="form.textset.扶持金" style="width: 150px" />
              </el-form-item>
              <el-form-item label="团队分红共享奖：" prop="团队分红共享奖">
                <el-input v-model="form.textset.团队分红共享奖" style="width: 150px" />
              </el-form-item>
              <el-form-item label="门店：" prop="门店">
                <el-input v-model="form.textset.门店" style="width: 150px" />
              </el-form-item>
              <el-form-item label="我的团队：" prop="我的团队">
                <el-input v-model="form.textset.我的团队" style="width: 150px" />
              </el-form-item>

              <el-form-item label="分销订单：" prop="分销订单">
                <el-input v-model="form.textset.分销订单" style="width: 150px" />
              </el-form-item>
              <el-form-item label="自定义表单：" prop="自定义表单">
                <el-input v-model="form.textset.自定义表单" style="width: 150px" />
              </el-form-item>
              <el-form-item label="推荐人：" prop="推荐人">
                <el-input v-model="form.textset.推荐人" style="width: 150px" />
              </el-form-item>
              <el-form-item label="团队：" prop="团队">
                <el-input v-model="form.textset.团队" style="width: 150px" />
              </el-form-item>
              <el-form-item label="一级：" prop="一级">
                <el-input v-model="form.textset.一级" style="width: 150px" />
              </el-form-item>

              <el-form-item label="二级：" prop="二级">
                <el-input v-model="form.textset.二级" style="width: 150px" />
              </el-form-item>
              <el-form-item label="三级：" prop="三级">
                <el-input v-model="form.textset.三级" style="width: 150px" />
              </el-form-item>
              <el-form-item label="下级：" prop="一级">
                <el-input v-model="form.textset.一级" style="width: 150px" />
              </el-form-item>
              <el-form-item label="下二级：" prop="下二级">
                <el-input v-model="form.textset.下二级" style="width: 150px" />
              </el-form-item>
              <el-form-item label="下三级：" prop="三级">
                <el-input v-model="form.textset.三级" style="width: 150px" />
              </el-form-item>
              <el-form-item label="贡献值：" prop="贡献值">
                <el-input v-model="form.textset.贡献值" style="width: 150px" />
              </el-form-item>
              <el-form-item label="信用额度：" prop="信用额度">
                <el-input v-model="form.textset.信用额度" style="width: 150px" />
              </el-form-item>

              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="登录注册" name="Sixth">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="150px" :model="form">
              <el-form-item label="微信公众号：" prop="logintype_mp">
                <el-checkbox-group v-model="form.info.logintype_mp">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                  <el-checkbox border label="3">授权登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="微信小程序：" prop="logintype_wx">
                <el-checkbox-group v-model="form.info.logintype_wx">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                  <el-checkbox border label="3">授权登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="支付宝小程序：" prop="logintype_alipay">
                <el-checkbox-group v-model="form.info.logintype_alipay">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                  <el-checkbox border label="3">授权登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="百度小程序" prop="logintype_baidu">
                <el-checkbox-group v-model="form.info.logintype_baidu">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                  <el-checkbox border label="3">授权登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="抖音小程序" prop="logintype_toutiao">
                <el-checkbox-group v-model="form.info.logintype_toutiao">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                  <el-checkbox border label="3">授权登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="QQ小程序" prop="logintype_qq">
                <el-checkbox-group v-model="form.info.logintype_qq">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                  <el-checkbox border label="3">授权登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="手机H5" prop="logintype_h5">
                <el-checkbox-group v-model="form.info.logintype_h5">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item label="手机APP" prop="logintype_app">
                <el-checkbox-group v-model="form.info.logintype_app">
                  <el-checkbox border label="1">注册登录</el-checkbox>
                  <el-checkbox border label="2">手机号登录</el-checkbox>
                  <el-checkbox border label="3">授权登录</el-checkbox>
                </el-checkbox-group>
              </el-form-item>

              <el-form-item label="小程序设置头像昵称：" prop="resource">
                <el-radio-group v-model="form.wxkf1">
                  <el-radio :label="0">不需要设置</el-radio>
                  <el-radio :label="1">可选设置</el-radio>
                  <el-radio :label="2">强制设置</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  小程序端首次授权登录时是否提示设置头像昵称
                </div>
              </el-form-item>

              <el-form-item label="公众号设置头像昵称：" prop="resource">
                <el-radio-group v-model="form.wxkf1">
                  <el-radio :label="0">不需要设置</el-radio>
                  <el-radio :label="1">可选设置</el-radio>
                  <el-radio :label="2">强制设置</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  公众号端首次授权登录时是否提示设置头像昵称
                </div>
              </el-form-item>

              <el-form-item label="绑定手机号：" prop="resource">
                <el-radio-group v-model="form.wxkf1">
                  <el-radio :label="0">不绑定</el-radio>
                  <el-radio :label="1">可绑定</el-radio>
                  <el-radio :label="2">强制绑定</el-radio>
                </el-radio-group>
                <div style="color: #999">授权登录时是否提示绑定手机号</div>
              </el-form-item>

              <el-form-item label="强制登录：" prop="login_mast">
                <el-checkbox-group v-model="form.info.login_mast">
                  <el-checkbox label="wx">微信公众号</el-checkbox>
                  <el-checkbox label="mp">微信小程序</el-checkbox>
                  <el-checkbox label="支付宝小程序">支付宝小程序</el-checkbox>
                  <el-checkbox label="百度小程序">百度小程序</el-checkbox>
                  <el-checkbox label="抖音小程序">抖音小程序</el-checkbox>
                  <el-checkbox label="QQ小程序">QQ小程序</el-checkbox>
                  <el-checkbox label="手机H5">手机H5</el-checkbox>
                  <el-checkbox label="手机APP">手机APP</el-checkbox>
                </el-checkbox-group>
              </el-form-item>

              <el-form-item label="注册邀请码：" prop="resource">
                <el-radio-group v-model="form.wxkf1">
                  <el-radio :label="0">开启</el-radio>
                  <el-radio :label="1">关闭</el-radio>
                  <el-radio :label="2">强制邀请</el-radio>
                </el-radio-group>
                <div style="color: #999">
                  通过邀请链接注册时展示邀请人信息，不能输入邀请码，强制邀请时必须邀请才能注册
                </div>
              </el-form-item>

              <el-form-item label="邀请码类型：" prop="resource">
                <el-radio-group v-model="form.wxkf1">
                  <el-radio :label="0">手机号</el-radio>
                  <el-radio :label="1">邀请码</el-radio>
                </el-radio-group>
              </el-form-item>

              <el-form-item label="注册审核：" prop="resource">
                <el-radio-group v-model="form.wxkf1">
                  <el-radio :label="0">开启</el-radio>
                  <el-radio :label="1">关闭</el-radio>
                </el-radio-group>
              </el-form-item>

              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="注册协议" name="Seventh">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="150px" :model="form">
              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="附件设置" name="Eighth">
        <el-row :gutter="20">
          <el-col :lg="{ span: 14, offset: 0 }" :md="{ span: 20, offset: 0 }" :sm="{ span: 20, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="180px" :model="form">
              <el-form-item label="附件存储类型：" prop="region">
                <el-select v-model="form.rinfo.type" placeholder="请选择活动区域" style="width: 300px">
                  <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
                </el-select>
              </el-form-item>

              <div v-if="form.rinfo.type == '2'">
                <el-form-item label="Access Key ID：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                </el-form-item>
                <el-form-item label="Access Key Secret：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                </el-form-item>
                <el-form-item label="Bucket名称：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
                <el-form-item label="EndPoint（地域节点）：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
                <el-form-item label="Bucket域名：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
              </div>
              <div v-if="form.rinfo.type == '3'">
                <el-form-item label="Accesskey：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                </el-form-item>
                <el-form-item label="Secretkey：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                </el-form-item>
                <el-form-item label="Bucket名称：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
                <el-form-item label="Url：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
              </div>
              <div v-if="form.rinfo.type == '4'">
                <el-form-item label="APPID：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                </el-form-item>
                <el-form-item label="SecretID：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                </el-form-item>
                <el-form-item label="SecretKEY：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
                <el-form-item label="Bucket：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
                <el-form-item label="bucket所属地域：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
                <el-form-item label="Url：" prop="name">
                  <el-input v-model="form.name" style="width: 300px" />
                  <span style="color: #999; margin-left: 20px">
                    如设置0.5，表示1积分换0.5元余额
                  </span>
                </el-form-item>
              </div>

              <el-form-item>
                <el-button type="primary" @click="submitForm('form')">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
          <el-col :lg="{ span: 10, offset: 0 }" :md="{ span: 4, offset: 0 }" :sm="{ span: 4, offset: 0 }"
            :xl="{ span: 12, offset: 0 }" :xs="24">
            <el-card :body-style="{ padding: '20px' }" shadow="hover">
              <template #header>
                <div>
                  <span>预留占位广告图</span>
                </div>
              </template>
              广告
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="系统信息" name="shi">
        <el-row :gutter="20">
          <el-col :lg="{ span: 18, offset: 0 }" :md="{ span: 24, offset: 0 }" :sm="{ span: 24, offset: 0 }"
            :xl="{ span: 20, offset: 0 }" :xs="24">
            <el-form ref="form" class="demo-form" :label-position="labelPosition" label-width="150px" :model="form">
              <el-form-item label="" size="normal">
                <div style="border: 1px solid #ccc">
                  <Toolbar :default-config="toolbarConfig" :editor="editor" :mode="mode"
                    style="border-bottom: 1px solid #ccc" />
                  <Editor v-model="html" :default-config="editorConfig" :mode="mode"
                    style="height: 500px; overflow-y: hidden" @onCreated="onCreated" />
                </div>
              </el-form-item>

              <el-form-item>
                <el-button type="primary" @click="submitForm()">
                  立即保存
                </el-button>
              </el-form-item>
            </el-form>
          </el-col>
        </el-row>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { GetSysset, sysset } from '@/api/set'
// import WangEditor from 'wangeditor'
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import VabUpload from '@/extra/VabUpload' //上传组件
export default {
  name: 'Index',
  components: {
    VabUpload, //上传组件
    Editor,
    Toolbar,
  },
  data() {
    return {
      editor: null,
      html: '<p>hello</p>',
      toolbarConfig: {},
      editorConfig: { placeholder: '请输入内容...' },
      mode: 'default', // or 'simple'

      checked3: true,
      checked4: false,
      checked5: false,
      colorValue: '#409EFF', // 默认颜色值
      predefineColors: [
        // 预定义的颜色列表
        '#409EFF',
        '#FF4500',
        '#FFD700',
        '#40E0D0',
        '#EE82EE',
        '#00CED1',
        '#8B008B',
        '#00FF00',
        '#1E90FF',
      ],
      activeName: 'first',
      info: {
        count: 0,
        data: [],
      },
      labelPosition: 'right',

      form: {
        location: 0, // 商城定位模式
        loc_range_type: 0, //显示范围
        wxkf: 0, //微信小程序客服
        name: '',
        region: '',
        date: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        description: '',
        rate: 0,
        area: [],
        transfer: [],
      },
      options: [
        {
          value: '0',
          label: '跟随平台附件设置',
        },
        {
          value: '1',
          label: '本地存储',
        },
        {
          value: '2',
          label: '阿里云',
        },
        {
          value: '3',
          label: '七牛云',
        },
        {
          value: '4',
          label: '腾讯云',
        },
      ],
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.GetSysset().then((res) => {
      this.form = res.data
      this.form.info.gettj = res.data.info.gettj.map((item) => parseInt(item))
    })
  },
  mounted() {
    // 模拟 ajax 请求，异步渲染编辑器
    setTimeout(() => {
      this.html = '<p>模拟 Ajax 异步设置内容 HTML</p>'
    }, 1500)
  },
  beforeDestroy() {
    const editor = this.editor
    if (editor == null) return
    editor.destroy() // 组件销毁时，及时销毁编辑器
  },
  methods: {
    GetSysset,
    //提交设置
    submitForm() {
      console.log(this.form)
      sysset(this.form).then((res) => {
        console.log(res)
      })
    },

    handleShow() {
      this.$refs['vabUpload'].handleShow()
    }, //显示上传组件

    onCreated(editor) {
      //富文本
      this.editor = Object.seal(editor) // 一定要用 Object.seal() ，否则会报错
    },
  },
}
</script>

<style src="@wangeditor/editor/dist/css/style.css"></style>
<style lang="scss" scoped>
.demo-form {
  margin-top: 10px;
}

:deep() {
  .el-form-item__content {
    .el-rate {
      display: inline-block;
      font-size: 0;
      line-height: 1;
      vertical-align: middle;
    }

    .el-transfer__buttons {
      padding: 10px 10px 0 10px;
    }
  }
}
</style>
