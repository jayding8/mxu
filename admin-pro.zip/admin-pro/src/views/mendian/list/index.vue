<template>
  <div class="index-container">
    <el-alert
      :closable="false"
      show-icon
      title="用于自提订单选择自提门店进行到店自提"
      type="success"
    />
    <vab-query-form>
      <vab-query-form-top-panel>
        <el-form
          ref="form"
          class="box"
          :inline="true"
          label-width="66px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="商品名称">
            <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
          </el-form-item>
          <el-form-item label="分类">
            <el-select v-model="value1" filterable placeholder="请选择">
              <el-option
                v-for="item in options1"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item v-show="!fold" label="分组">
            <el-select v-model="value1" filterable placeholder="请选择分类">
              <el-option
                v-for="item in options2"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item v-show="!fold" label="状态">
            <el-select v-model="value1" filterable placeholder="请选择状态">
              <el-option
                v-for="item in options3"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
              @click="handleQuery"
            >
              查询
            </el-button>
            <el-button type="text" @click="handleFold">
              <span v-if="fold">展开</span>
              <span v-else>合并</span>
              <vab-icon
                class="vab-dropdown"
                :class="{ 'vab-dropdown-active': fold }"
                icon="arrow-up-s-line"
              />
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-top-panel>
      <vab-query-form-left-panel :span="24">
        <el-button icon="el-icon-plus" type="primary" @click="handleAdd">
          添加
        </el-button>
        <el-button
          icon="el-icon-delete"
          type="danger"
          @click="handleDelete($event)"
        >
          删除
        </el-button>
        <el-button type="primary" @click="handleAdd">导入</el-button>
        <el-button type="primary" @click="handleAdd">导出</el-button>
        <el-button type="primary" @click="handleAdd">开启</el-button>
        <el-button type="primary" @click="handleAdd">关闭</el-button>
        <el-button type="primary" @click="handleAdd">修改分组</el-button>
        <el-button type="primary" @click="handleAdd">修改等级</el-button>
      </vab-query-form-left-panel>
    </vab-query-form>

    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" sortable width="80" />
      <el-table-column label="小区名称" width="200">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span>{{ props.row.xqname }}</span>
            </el-form-item>
            <el-form-item>
              <a href="http://">推广二维码</a>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="门店信息" width="200">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <div style="height: 50px; width: 50px">
                <img :src="props.row.pic" style="height: 100%; width: 100%" />
              </div>
            </el-form-item>
            <el-form-item>
              <span>名称:{{ props.row.name }}</span>
            </el-form-item>
            <el-form-item>
              <span>昵称:{{ props.row.nickname }}</span>
            </el-form-item>
            <el-form-item>
              <span>当前会员数量:{{ props.row.tynum }}</span>
            </el-form-item>
            <el-form-item>
              <span>等级:{{ props.row.levelname }}</span>
            </el-form-item>
            <el-form-item>
              <span>{{ props.row.groupname }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column label="佣金" width="200">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span>可用佣金:{{ props.row.money }}</span>
            </el-form-item>
            <el-form-item>
              <span>已提现:{{ props.row.dkmoney }}</span>
            </el-form-item>
            <el-form-item>
              <span>总收入:{{ props.row.totalmoney }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="推荐信息" width="200">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span>上级门店:{{ props.row.parentname }}</span>
            </el-form-item>
            <el-form-item>
              <span>直推门店:{{ props.row.tjtotal }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="门店电话/地址" width="200">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span>{{ props.row.tel }}</span>
            </el-form-item>
            <el-form-item>
              <span>{{ props.row.address }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column
        label="申请时间"
        prop="createtime"
        sortable
        width="200"
      />
      <el-table-column label="审核状态" width="150">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span v-if="props.row.check_status == 0">待审核</span>
              <span v-if="props.row.check_status == 1">已通过</span>
              <span v-if="props.row.check_status == 2">已驳回</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="150">
        <template slot-scope="props">
          <el-form>
            <el-form-item>
              <span v-if="props.row.status == 0">已关闭</span>
              <span v-if="props.row.status == 1">已开启</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>

      <el-table-column fixed="right" label="操作" width="200">
        <template slot-scope="scope">
          <el-button size="small" type="text" @click="handleClick(scope.row)">
            编辑
          </el-button>
          <el-button size="small" type="text">删除</el-button>
          <el-button size="small" type="text">通过</el-button>
          <el-button size="small" type="text">驳回</el-button>
          <el-button size="small" type="text">推广订单</el-button>
          <el-button size="small" type="text">收益明细</el-button>
          <el-button size="small" type="text">查看在售商品</el-button>
          <el-button size="small" type="text">查看核销人员</el-button>
          <el-button size="small" type="text">充值佣金</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { mendianlist } from '@/api/mendian'

  export default {
    name: 'Mendianlist',

    data() {
      return {
        options1: [
          { value: '1', label: '全部' },
          { value: '2', label: '分类一' },
          { value: '3', label: '分类二' },
        ],
        options2: [
          { value: '1', label: '全部' },
          { value: '2', label: '最新' },
          { value: '3', label: '热卖' },
          { value: '3', label: '推荐' },
          { value: '3', label: '促销' },
        ],
        options3: [
          { value: '1', label: '全部' },
          { value: '2', label: '已上架' },
          { value: '3', label: '未上架' },
        ],

        value1: '',
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        layout: 'total, sizes, prev, pager, next, jumper',
        fold: false,
        height: this.$baseTableHeight(3) - 30,
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.mendianlist({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    methods: {
      mendianlist,
      handleAdd() {
        this.$refs['edit'].showEdit()
      },
      handleFold() {
        this.fold = !this.fold
        this.handleHeight()
      },
      handleHeight() {
        if (this.fold) this.height = this.$baseTableHeight(2) - 47
        else this.height = this.$baseTableHeight(3) - 30
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.page.limit = val
        this.mendianlist({
          page: this.page.current,
          limit: val,
        }).then((res) => {
          this.info = res
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.page.current = val
        this.mendianlist({
          page: val,
          limit: this.page.limit,
        }).then((res) => {
          this.info = res
        })
      },
      toggleSelection(rows) {
        if (rows) {
          rows.forEach((row) => {
            this.$refs.multipleTable.toggleRowSelection(row)
          })
        } else {
          this.$refs.multipleTable.clearSelection()
        }
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleClick(row) {
        console.log(row)
      },
    },
  }
</script>

<style lang="scss" scoped>
  .select-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .box {
    padding: 20px;
    background: #f2f5f8;
    border-radius: 6px;
    width: 100%;
  }
</style>
