<template>
  <div class="index-container">
    <el-alert
      :closable="false"
      show-icon
      title="商品库商品变更商品基础信息或将单规格商品调整成多规格商品将会自动同步至门店；如需修改门店商品价格或库存请在商品模板库调整"
      type="success"
    />
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 12, offset: 6 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form>
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="120px"
          :model="form"
          :rules="rules"
        >
          <el-form-item label="门店申请开关" prop="resource">
            <el-radio-group v-model="form.resource">
              <el-radio label="开启" />
              <el-radio label="关闭" />
            </el-radio-group>
          </el-form-item>
          <el-form-item label="活动名称" prop="name">
            <el-input v-model="form.name" />
          </el-form-item>

          <el-form-item label="前端添加核销员" prop="resource">
            <el-radio-group v-model="form.resource">
              <el-radio label="开启" />
              <el-radio label="关闭" />
            </el-radio-group>
          </el-form-item>

          <el-form-item label="显示详细地址" prop="resource">
            <el-radio-group v-model="form.resource">
              <el-radio label="开启" />
              <el-radio label="关闭" />
            </el-radio-group>
          </el-form-item>

          <el-form-item label="订单通知" prop="resource">
            <el-radio-group v-model="form.resource">
              <el-radio label="开启" />
              <el-radio label="关闭" />
            </el-radio-group>
          </el-form-item>
          <el-form-item label="显示门店等级" prop="resource">
            <el-radio-group v-model="form.resource">
              <el-radio label="开启" />
              <el-radio label="关闭" />
            </el-radio-group>
          </el-form-item>
          <el-form-item label="设置会员等级" prop="region">
            <el-select v-model="form.region" placeholder="选择等级">
              <el-option label="区域一" value="shanghai" />
              <el-option label="区域二" value="beijing" />
            </el-select>
          </el-form-item>

          <el-form-item label="分销权限" prop="resource">
            <el-radio-group v-model="selectedTab">
              <el-radio :label="0">无权限</el-radio>
              <el-radio :label="1">一级</el-radio>
              <el-radio :label="2">二级</el-radio>
              <el-radio :label="3">三级</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="" prop="status">
            <div v-if="selectedTab === 0">这是选项3的内容</div>
            <div v-else-if="selectedTab === 1">这是选项1的内容</div>
            <div v-else-if="selectedTab === 2">这是选项2的内容</div>
            <div v-else-if="selectedTab === 3">这是选项3的内容</div>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="submitForm('form')">
              提交
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { MendianSet } from '@/api/mendian'

  export default {
    name: 'Mendian',

    data() {
      return {
        selectedTab: 1, // 默认选中选项1
        labelPosition: 'right',
        form: {
          name: '',
          region: '',
          date: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          description: '',
          rate: 0,
          area: [],
          transfer: [],
        },
        info: {
          page: {
            current: 1,
            limit: 10,
            totle: 0,
          },
        },
        data: [],
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.MendianSet({
        page: this.info.page.current,
        limit: this.info.page.limit,
      }).then((res) => {
        this.info = res
      })
    },
    methods: {
      MendianSet,
      handleAdd() {
        this.$refs['edit'].showEdit()
      },
      handleFold() {
        this.fold = !this.fold
        this.handleHeight()
      },
      handleHeight() {
        if (this.fold) this.height = this.$baseTableHeight(2) - 47
        else this.height = this.$baseTableHeight(3) - 30
      },

      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.page.limit = val
        this.MendianSet({
          page: this.info.page.current,
          limit: val,
        }).then((res) => {
          this.info = res
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.page.current = val
        this.MendianSet({
          page: val,
          limit: this.info.page.limit,
        }).then((res) => {
          this.info = res
        })
      },
      toggleSelection(rows) {
        if (rows) {
          rows.forEach((row) => {
            this.$refs.multipleTable.toggleRowSelection(row)
          })
        } else {
          this.$refs.multipleTable.clearSelection()
        }
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleClick(row) {
        console.log(row)
      },
    },
  }
</script>

<style lang="scss" scoped>
  .select-container {
    padding: 0 !important;
    background: $base-color-background !important;
  }

  .box {
    padding: 20px;
    background: #f2f5f8;
    border-radius: 6px;
    width: 100%;
  }
  .demo-form {
    margin-top: 10px;
  }

  :deep() {
    .el-form-item__content {
      .el-rate {
        display: inline-block;
        font-size: 0;
        line-height: 1;
        vertical-align: middle;
      }

      .el-transfer__buttons {
        padding: 10px 10px 0 10px;
      }
    }
  }
</style>
