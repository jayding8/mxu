<template>
  <div class="index-container">
    <vab-query-form>
      <vab-query-form-left-panel :span="4">
        <el-button type="primary" @click="handleAdd">录入库存</el-button>
        <el-button type="primary" @click="handleAdd">导出EXCEL</el-button>
      </vab-query-form-left-panel>

      <vab-query-form-right-panel :span="20">
        <el-form
          ref="form"
          class=""
          :inline="true"
          label-width="76px"
          :model="queryForm"
          @submit.native.prevent
        >
          <el-form-item label="商品ID">
            <el-input v-model="queryForm.title" placeholder="请输入商品ID" />
          </el-form-item>
          <el-form-item label="商品名称">
            <el-input v-model="queryForm.title" placeholder="请输入商品名称" />
          </el-form-item>

          <el-form-item label="时间">
            <el-date-picker
              v-model="value2"
              end-placeholder="结束日期"
              range-separator="至"
              start-placeholder="开始日期"
              type="datetimerange"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              icon="el-icon-search"
              native-type="submit"
              type="primary"
              @click="handleQuery"
            >
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </vab-query-form-right-panel>
    </vab-query-form>
    <el-row class="box" :gutter="20" :span="24">
      <el-col :span="6">总销售数量：{{ totaldata.num }}</el-col>
      <el-col :span="6">总销售金额:{{ totaldata.totalprice }}</el-col>
      <el-col :span="6">平均单价：{{ totaldata.avgprice }}</el-col>
      <el-col :span="6">毛利润：{{ totaldata.lirun }}</el-col>
    </el-row>

    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column fixed label="排名" prop="ph" width="80" />

      <el-table-column label="商品信息">
        <template slot-scope="props">
          <el-form>
            <img :src="props.row.pic" style="height: 50px; width: 50px" />
            <div>{{ props.row.name }}</div>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="销售数量" prop="num" width="150" />
      <el-table-column label="销售金额" prop="totalprice" width="150" />
      <el-table-column label="平均单价" prop="avgprice" width="150" />
      <el-table-column label="商品成本价" prop="chengben" width="100" />

      <el-table-column label="毛利润" prop="lirun" width="200" />
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { mendian } from '@/api/mendian'
  export default {
    name: 'Mendianset',
    data() {
      return {
        queryForm: {
          pageNo: 1,
          pageSize: 10,
        },
        totaldata: [],
        info: {
          count: 0,
          data: [],
        },
        page: {
          current: 1,
          limit: 10,
        },
      }
    },
    computed: {
      ...mapGetters({
        title: 'settings/title',
      }),
    },
    created() {
      this.mendian({
        page: this.page.current,
        limit: this.page.limit,
      }).then((res) => {
        this.info.data = res.data
        this.info.count = res.count
        this.totaldata = res.totaldata
      })
    },
    methods: {
      mendian,
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.info.data.limit = val
        this.mendian({
          page: this.info.data.current,
          limit: val,
        })
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.info.data.current = val
        this.mendian({
          page: val,
          limit: this.info.page.limit,
        })
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
    },
  }
</script>

<style lang="scss" scoped>
  .box {
    padding: 20px;
    background: #f2f5f8;
    border-radius: 6px;
    width: 100%;
    margin-left: 0;
    margin-bottom: 10px;
    margin-right: 0;
  }
</style>
