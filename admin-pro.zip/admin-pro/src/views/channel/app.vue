<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 24, offset: 0 }"
        :md="{ span: 24, offset: 2 }"
        :sm="{ span: 24, offset: 2 }"
        :xl="{ span: 24, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card
            :body-style="{ padding: '20px' }"
            shadow="hover"
            style="border: none"
          >
            <template #header>
              <div>
                <span>手机 APP</span>
              </div>
            </template>
            <el-alert
              :closable="false"
              show-icon
              title="请先在微信开放平台(open.weixin.qq.com)创建移动应用
              用于微信登录、微信分享及微信支付"
              type="success"
            />

            <el-form-item label="AppID：" prop="appid">
              <el-input v-model="form.info.appid" style="width: 200px" />
            </el-form-item>
            <el-form-item label="AppSecret：" prop="appsecret">
              <el-input v-model="form.info.appsecret" style="width: 200px" />
            </el-form-item>
            <div style="margin: 40px 0">微信支付设置</div>
            <el-form-item label="微信支付状态：" prop="wxpay">
              <el-radio-group v-model="form.info.wxpay">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="微信支付模式：" prop="wxpay_type">
              <el-radio-group v-model="form.info.wxpay_type">
                <el-radio :label="0">普通模式</el-radio>
                <el-radio :label="1">服务商模式</el-radio>
              </el-radio-group>
            </el-form-item>

            <div v-if="form.info.wxpay_type == 0">
              <el-form-item label="支付商户号：" prop="wxpay_mchid">
                <el-input
                  v-model="form.info.wxpay_mchid"
                  style="width: 200px"
                />
              </el-form-item>
              <el-form-item label="支付密钥：" prop="wxpay_mchkey">
                <el-input
                  v-model="form.info.wxpay_mchkey"
                  style="width: 200px"
                />
                <span style="margin-left: 20px; color: #969696">
                  请在 微信支付商户平台 [账户中心]-[API安全]中设置[APIv2密钥]
                </span>
              </el-form-item>
              <el-form-item label="PEM证书：" prop="wxpay_apiclient_cert">
                <el-button>上传</el-button>
                <span style="margin-left: 20px; color: #969696">
                  apiclient_cert.pem 请在 微信支付商户平台
                  [账户中心]-[API安全]中设置[API证书]，设置完成后上传
                </span>
              </el-form-item>
              <el-form-item label="密钥证书：" prop="shipping_pagetitle">
                <el-button>上传</el-button>
                <span style="margin-left: 20px; color: #969696">
                  apiclient_key.pem 请在 微信支付商户平台
                  [账户中心]-[API安全]中设置[API证书]，设置完成后上传
                </span>
              </el-form-item>
            </div>
            <div v-if="form.info.wxpay_type == 1">
              <el-form-item label="支付商户号：" prop="wxpay_sub_mchid">
                <el-input
                  v-model="form.info.wxpay_sub_mchid"
                  style="width: 200px"
                />
                <span style="margin-left: 20px; color: #969696">
                  必须填子商户的商户号
                </span>
              </el-form-item>
            </div>

            <div style="margin: 40px 0">支付宝支付设置</div>
            <el-form-item label="支付状态：" prop="alipay">
              <el-radio-group v-model="form.info.alipay">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="APPID：" prop="ali_appid">
              <el-input v-model="form.info.ali_appid" style="width: 200px" />
              <span style="margin-left: 20px; color: #969696">
                支付宝分配给开发者的应用ID
              </span>
            </el-form-item>
            <el-form-item label="应用私钥：" prop="ali_privatekey">
              <el-input
                v-model="form.info.ali_privatekey"
                style="width: 200px"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写应用私钥去头去尾去回车，一行字符串
              </span>
            </el-form-item>
            <el-form-item label="支付宝公钥：" prop="ali_publickey">
              <el-input
                v-model="form.info.ali_publickey"
                style="width: 200px"
              />
              <span style="margin-left: 20px; color: #969696">
                请填写支付宝公钥，一行字符串
              </span>
            </el-form-item>
            <div style="margin: 40px 0">安装包地址</div>

            <el-form-item label="Android安装地址：" prop="androidurl">
              <el-input v-model="form.info.androidurl" style="width: 200px" />
              <span style="margin-left: 20px; color: #969696">
                可上传到站点根目录然后设置安装包地址https://game.demo.ranyun.online/安装包文件名.apk
              </span>
            </el-form-item>
            <el-form-item label="IOS安装地址：" prop="iosurl">
              <el-input v-model="form.info.iosurl" style="width: 200px" />
              <span style="margin-left: 20px; color: #969696">
                上架后在应用商店中复制链接地址
              </span>
            </el-form-item>
            <el-form-item label="用户下载地址：" prop="wxpay_serial_no">
              <span style="color: #969696">
                https://game.demo.ranyun.online/?s=/Index/downloadapp/aid/1
              </span>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" @click="submitForm('form')">
                提交
              </el-button>
            </el-form-item>
          </el-card>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { App } from '@/api/channel'
export default {
  name: 'Shopset',
  data() {
    return {
      labelPosition: 'right',
      form: {
        name: '',
        region: '',
        date: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        description: '',
        rate: 0,
        area: [],
        transfer: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.App().then((res) => {
      this.form = res.data
    })
  },
  methods: {
    App,
  },
}
</script>

<style lang="scss" scoped></style>
