<template>
  <div class="index-container">
    <el-card :body-style="{ padding: '20px' }" shadow="always">
      <template #header>
        <div>
          <span>微信公众号绑定</span>
        </div>
      </template>
      <div>
        <el-image fit="fill" :lazy="true" :src="info.data.mpappinfo.headimg" />
        <el-image fit="fill" :lazy="true" :src="info.data.mpappinfo.qrcode" />
        <div>{{ info.data.mpappinfo.nickname }}</div>
        <div
          v-if="
            info.data.mpappinfo.level == 2 || info.data.mpappinfo.level == 4
          "
        >
          服务号
        </div>
        <div v-else>订阅号</div>
        <div
          v-if="
            info.data.mpappinfo.level == 3 || info.data.mpappinfo.level == 4
          "
        >
          已认证
        </div>
        <div v-else>未认证</div>

        <div v-if="info.data.mpappinfo.authtype == 1">
          <span>已授权</span>
          <span>刷新授权信息</span>
          <span>APPID：{{ info.data.mpappinfo.appid }}</span>
          <span v-if="info.data.mpappinfo.open_appid != -1">
            开放平台APPID:{{
              info.data.mpappinfo.open_appid
                ? info.data.mpappinfo.open_appid
                : '未绑定'
            }}
          </span>
        </div>
        <div v-else>
          <span>已绑定</span>
          <span>APPID：{{ info.data.mpappinfo.appid }}</span>
        </div>

        <div>{{ info.data.mpappinfo.aid }}</div>
        <!-- <div>{{ info.data.mpappinfo.appid }}</div> -->
        <div>{{ info.data.mpappinfo.appsecret }}</div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Binding } from '@/api/channel'
export default {
  name: 'Shopstock',
  data() {
    return {
      info: {
        data: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Binding({}).then((res) => {
      this.info = res
    })
  },
  methods: {
    Binding,
  },
}
</script>

<style lang="scss" scoped></style>
