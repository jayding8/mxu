<template>
  <div class="index-container">
    <div class="selectBox">
      <img
        alt=""
        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAggAAAG4CAMAAAAXAO+5AAAClFBMVEUAAAAAuzgAw0Ep3GEZ1VkAyUoA0FEO3FgAvEMj4mCMv56Uw6MA1U8X1U+Rw6MAw0uMw6Qo3FiNw6CYwZkIyVKOw54AuUCOwp6Rv6GFvqGNxaAAuTWNwqKVwqCSw5yOxZoZzE0TzEMTyksIvkMCvj0AvkEX1FQi3V8AvDsl3l8b2lsf4GEd2Fsm3l4Ev0Yp4GEAuz8Auz0AwEEn32Aj318Ax0UJ0lEn3V8j32AEzUwS1VUm4GEO0VIR1FQj3F4AvTsAwD8AwEAAuzkAuzod21wCwkIZ2VoAvDsAwEAExEIAuzom4WEAuzkAwD4k4GAAvTwAvj0c01gAuzgn4WIAuzkAwT8AwUAAvj0AvDsAvjwAxEMAvDoi3VwAx0gCy04AwkAAy0oAwkEAx0cHzk8AzUoz3mcV0lYn4GEh21wDzlEa11gX2FcAyEkl3mEl318W2loAy0v///8AvDsAwD8i3V4d21wAuzkAw0Ij3l8AxEQc2VoAwUAg3F0Avj0W11gY2VoAwkEH01Mm3l8m32AZ2FgD0lIAxUUAxkUM01QAujcU1VYQ1FUA0VEAzE0S1lgAyUoo4GEb2lsh21wAz1AAy0wAyksAyEgX1lgp32IAzk0AyEcP1VYAzk8Ax0gAx0YM01UAvz0AvD0Ax0kAzEwK1FUR1FcA0VD9//30/fbj+ejv+/K/8Mr3/vno+uv6/vve9+PE8c6b56zr++6v7Lxs4IjZ9t+n67bL8tS07cCh6bGV56eF4ppm3IM8z2Um0lvR9dl83ZIp1l4uy1xG1mwS0lWs6biS4qRj1n9W23i47sQv2GEEx02N4qB24Y9y3Itt2odO0nFL2HBA2Gozz18iy1cWylOO56J/4pVd231a1Xk31mQNzlIwX8OsAAAAcXRSTlMAJiYmJiYmJiYmCAUmJhEmCyYXDiYfKBMbCg8nFRkdGgcECw4aFg0WJCI/DwgaEiQdIh/OhSIZExwcIx8UH0B+Y0L64tEuidZXNOzUs5KJakr+88rBoXM8y5q7q4eH/ff07dm+KB399HZJ5dzOoJFYOwe3SrYAABk9SURBVHja7NxBjpswFIBhJKxaSMkiNwAWWA6hXrQqtLQn6LJnqNpVD9FeoMs5bmOqiKYzSWAGgm3+bzMX+GXeM2QiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIDLDnlZ1qr62rb6yCSJsX/b9mul6rLMD1mEoKVFqZrWJDeZtlFlkUYITZbXlU5G01WdczyE4tiASV7ANHUewW+FapNJtKqI4KdD3SaTautDBM+USicz0KqM4I2yMnEcJ/MwDS14oavgJLFoYX2KvoJ5YzAVm4SzUqXj3uwxaMWNk4uKJr4qmUHDTumaWscDJJPTdQRnZMrEnSViMIpLaDekVdxbJIaKYWF5hz6DBVtouHMcxZkM/iKFQJweCm7EwANiIZmKO+7EwNi4hFrER261YFgm763Qcce1GDRvIe4pbeK/HIzhK6PC3ZwPB87FoCI8zf2nwrQtaN5M3sGlldGpGKoI8ypMfIU7MTA0nvP2OPgHh4JzchMP4kYLTAo9r5aFG1gfHJG2u90uHmXxGFruFCZXiJ3lWQyGmXFiSkq523nYAo+HKWWNtLyM4SuvJCdz+CAtT2PQfLIykVJIy9sYGBSmoaTldQsMChNopOV5DE2El8laaXkfQ8vI+CKpllYAMWjull7gYORwjrdgWB6eLRfyJICDwfCL2WcqhLTCiYE18lkK2QkpBkp4hlI+wfeRgRJGq+VJUAcDJYxUCiGkDDAGShilEFaQMVDC6A7OWwhmZGCLHCwXJyEeDIaPWgc6CCvcGLhjHCb9II5CjsHw3mGATItHQhsZNO8ib/skTgI+GNoIN7wXVvAx8KXKDUpYK4iBr9euei0eC3Rk4GJp0OK4goOBJfKirFsc1xIDq8ONhWE1MbA6XBsUXWjh8sjAwHgHhbBcieHSwcDAOLdUWOuKgbvmSwPC2mJgTHh6QHCzhf9GBsaEOeXixM0YZjsY+Djh3PkNwopi0BH+8U48spYY+H+MtzdHN1voY2CH7Lhxtez/wcDDYfCDIfAYeDiM2RhCjoEP3MdtDG620MfAw8HFqySvDgaulY7S7XYrRgkwBt45RNGn7dHaY+Bb1qjYWk7EMPHIwLw4yoettVwL++9fvn37/GM/z8HAvDhUvdlsrWVi2L/98vC78/Dl7X7Rp8THaNWyVxtru0QMfQVnLSwUg1j3p6zvNtYCMezfvnno/J63hT4G7hevSF9tzszdQl/BL+v378cxPLx5u59tl2CFvHog3DcGW0HneguzxcCR8NSBcHS7BWu6Cn5atoELMfQtzBcDP336w87drCQQhWEcd3F4Vy29gD6goEWbwFCqlQkhBNG2XVGmmBsFkRg3rgqC3Bi49j6b1xHGHhA/zjOO8M7/Gn6cZxxn5n8F0RLGgAq0lTCgBS6G7EiAA0HWwuCloBsFGMBCGFhI7mDIjoSookB7SWE4fVQFcSsfDGrh2iWJITsS4ECgrgQqaLe72mYY0AIfg/EfDgWBaBhQgQYW1lsJvgXEYPhIOBDND8NSBeX2fF4Hg1pI/GCweHvxRDDWJQMqoGFAC3wMFp9QyQvEXInTSvkjDA14rgRa4GNwOXOdiUbEgAo0wMA5GM7viBYQw0XOWiXRuBhmCoZhMQQyBrDAxlDKGetYMMYlQ6igow2ngQUChrmVqIIFFgZrjyoVRWNgQAWzEAPtkgEssDEYe3pxXzQaBlAQY0h0JZKxYOum0qVoLAyhgl7vR+tg/JVADGqBicHWL8iSeDevIAowJLsSaIGGwdRjrIfCSRX0+301EFvQtr4SaoGEwdI3VArC6KbS6EcBhnRW4qHlKBYs/eGQF0Kt+mAaWEhxJZp7jNdnDN1dPBJCb/dBECiEGEPqK9GkvEtl5xMqRfHvuRFoMQaPleBhqLmlZbcS4A9oz2qjYK7BjqzE6y3jJUsrf0ZTluFppAWzdmYl3t2KZdvAWQapf4ctwpDeSlTdGlnfBmH0ohDAgsclA2slfinv4udMdCyMPrVFGFJcCbd+Vv+CLNAgAAaPleBhcJtl8Z5SXhiNw8DCIgxbvf3oNs/Y4ymHQulrMoktEFaCdcnA+XyPhXeeLkkQtMlY26mV4HzLycL3U66IECIMO7USjtIfe2eT0zYQBWAWnhv4AIUWVlUXlYqERA/BUd62O0tYiorZNIsKKRILfpzEjmISJ4BBoKhBgkgsYEGl9jL1yG6mvNg4mXkLNNPvDJ/mzfuZeZ+X9MemEWH/8FC4IBklaGWgFMGAxtOazVEXobafImSQjBL0iaVFg/4J5KqdoypCSibDzquKEhYN+g+sfbT/QVGEXIZXFSUsaQy7JLAUm0AGx6kJFyRkIIsSlCIYdElYYRm2qgwOB8uw8/KVYRIn/ajbawKEzc4g6j9djshHGSwidJ9c3GQCJRecnHIZjp7JMLo/6/qA8QfD+BtplLCI0P0R5AbjEMjgCKqjxPc4CKGM9ln8hS5KWERsLOnNJ8YhkMF1HWdOGUZJC16m9TShGmWwiNC8Fb3MENJXBpdTIcMOZ5S0oZrm+YQmsbSI0Pxv5hUmUDsY3IzKg+G+A/PRvtimGGWwlDCmpLTJOBQyuJxKGR4jmJ/rW4ImlfX/tjgP7xiHQgbPc91KGeI2LEL4pF5+tKhYX9IZfFeUvzJ4x8celsFBnPiwIMFEtfxoqWBObZEJFA8Gj8NlKD0YxmewON1HxVEGSxkTaotvGIdEBu8vx16xDFsRyNB5UGtS0X0lr/OPGWuMQyJD3ROIKCEYByBH74dSk0r593Aj0oYPDCF/ZaineIKZKDEEWVq/VJpUyl/JG5E2rDNpsAt1jpABR4mfIM/ptsIog/JX8kakDRuMQyJDXVAQJR5CQITdlg9FtLsdQAwVRhnoFo7o/PBNZI/KMuw1GtgFIYN7Dc8ZxGPHmQx9wAS3afnxIUI9yVh+lEF1x4QZ+aPNKMhE4JTJgANDMM5yiXNAnGS16KNTdE24kp5rUV44YkL+uMzIsPdyGgUyXPVQR+nKzdhqoqJyLecWC4KmH+d/b6u+Y8KAttN7RkcqwF6xDJ6X4APBzcEhI5n2JUKkzkR2+pFw+4y+z51WGB27u42pCyhK/O4hEe48NweFgItpX6KJjwTZGXn1hSMGTKu9pRSB02gUHQz3gOi4eWJZQ4oETs4jIHpfK2bkyw4Gwh1l+n6cskksQokMEWCSPLHEivixkzEETCw5I7/QjglTK0qrxCIUyzAOAePfjLyUuDnbeN7i7anEB0xf8iUV4Y4yfV/CrjM6Dg4OSly4hALC6KY/gALawfCuA7O0JF9SyaylMq60+Ie9c2ltIooCcBhIt92Ia9+4EBHBhSCoKx8IKqio4FsEwYXXLEoJgm6SjSGLJoUGUzQumneTxiSNTWyaaGJtbatttY8/45w+vM3k3szcmePmTr5laXYf95x75p5zDjjxCAQ+gAsMGbLEPOl8ojTxo7xSnpu4aq6TyuyOMluJcBJTBOADS4YEMUmsVP7MfPAmEiWsrKWyTWnxOLIIbBnyxAzRwreNpwz1P6XpyVgqGk2NFnOfPk6BCCJRwuqOsq4IggQDlNYokSLijP2eUi34/icR16aZo4WVLyL9tgibLOUX4QSmCECAQg+GKBElWVJr0F8+ZtKESSq7ZjxKIK41lXekVi+yCECgTYYRIshk/c2b1xMxwic9/stovy3iJsuuCEbwBwGWDEkixEh2Xa0wxPSuE7kpY/22VnaU2UYEJyJ+lSBThrhYkvjxzZu1hJE04oehflurmyy7IpgQAWh3YZQIEP82MFA2qM701Gv9qQyYa00dsoItAluGjMh5oHrQMJxUjNb1pzIgbbLsimCUQT/AciErUEhceTtQEjo/dBvxEdeayitCby+iCABThjIxzMTQUE4so6AmcGTAXHHrkJVeAFEEtgzLSWKQ3NDQJyJG/KdOJz7iitseh6ycABGQZIhEBimtLiSIMVJX384JFx1iU7SrjiVDD4Ajg7y3hg0RkGQIhSIqTBfmiTHmfWtxIkyi81SGHhxsJAJgRQSALUMwRYxQ9PkyxAR/Ok5l6EFDYhGOKypILoTDIY0LVIYJQxXFVV9Z85fCry8LhXTrjbH8ZK062lpZ+txpREcPHvJ+dAIRAIyDIQyEmDL478aIPpMffJrS0+zGu5aVdEuny4DKkyLZSal9KkNXBCFOKgCODMPDw2GuDEayhGqgrEkD324+chrf+U8DG9Q1/TLMqQzoIsg7avGAAuDIMLxBmCNDjugRXdeWIBO+TWYJ5efWG/mk5lE0byoDqgjyPlXTimAlZfCqUBm0LizrBodE4HO6/UQAWk6EIeDtT02pucOIjq4IBjioUKweDF6AL8NCUq+oGKwSDVkfMD/SkiOACFe1zdV1xlQGfBHk3dlwSgFwZPDugBUl9EpF9eB4e/dDfXEl1/q72Nzir/Y3K7OsqQzoIsjb4LJfAXBk8Hg8XoB7MEx0NCHtC+aJacZZUxlABlQR5G15O6ToYtgFD8CXQc+EUb8/SUyTH6BoogSiCPI2wR5RKFYPBs8/vDwZ5tKES9G/RMwzxprKAKCKIG9b/F4FwJGhv7/fQ2G70IwTHgl/hZgnyZjKgC+CvIMyHL0KgCJDP6AnQyXPjfL+OrFA+1QGAFeEXQ55OaEIwnehn9IhSswUOInC9OAiMU+UPa4FwBPhhENeaI3Z2sFARdA7GHivVBKD68Q8MfaIDqBbYRYoLWLI0NfX129AhjnCZjIyOEZMk2GO6BgAuoVFIxxVABQZ+gB9GRKETTwUKRLTZPnjWmAuLA5HHfKyXwFQZLgHGui6sJwmHGqhEjHNKndcy12chceAzEO59ygAigsPwAFdGapki5HpT4kU2cF8qGkhRWCP6FC5DxbguCDzmH6HAqDIcO7VKzBAR4bMdhNrxauy1GyMT46NEKAQjsSJSRrsER3gwkOUfceAvG+Y6f0Rg9uvAB0XNiNDOlfxeCnhpUqlshQKh83GhuTnwAYsFx4JL6yz4+0Rrg1Y3AIP9GSoggZfFzkVp8qIyVQxwB/Xcl14YZ0dLw1wbcDihtvtfqUnQ0bVoMavMuSIGVLrrKkMW9xwAhguyDtcD9inYHHFvQnPBZBhKVqodSoy1KJEnJF5zogOH/BUeHmh/b49AnsVLHbfc2/BPxhqSzoVp1kiztcgwJHh/mPhhXU2/OSEnC26KTpRgitDuEhEyd/1q/BceCS+sM6Gn5yAYwoWp10ul7sF6oJRGbw10TpzbNEP8GS4I7zW1I5fGnCzxbOuTawdDAtiaUK84qcwZvc8FdpRZt9cEbJFNM65tnFbkGFVxISxBVYjPuWh+MI6e+aKKgpibKBYiBILcWKUVGUQ4Mtwx9z2QtvVFYHjChYX7rkoFqJEJW80T1ykXXVMGe4+N7/W1DZ9j7TJBY1LLsC6DDM5YoTcDLsRn/IIZ98xcNAhO/sVNM67KNaiRDNGdClym6//ccb6jls7fIPeQsHj5jsXgHAwzDR0M4XoTKdOfOAZ0sJjW6QIkCSgcf7ly3fggnUZQIUU6UyT34gP0AMBwYXjDvk5peBx7aXKO6YM4hdLT3OadZVMbwvydRjgy/CQlpctyyB7FQGzkgBcARH0ZBBwIdLMFnfKEM80Vme85VECpMK035YlAz0QrMsgfRUBOKzgcf0lBStK1Fars41StlFt1rYr0dUUUVno2Ih/24mH7B8acB+nABcuUhEQogS3Fh2ZjROS7dR8ff+sEw+5H6WgXyCByy9egAHWZOjTwHJhOZvMe7z85us7TkT2O2yBgsmlF4C4DOIHQ+1rjd9v++yxExGHPTimoAYHEIHK8N+jBFMGCAx4yP4JGj82AOffb5vw36MEv9/2tBMDm0WGv+ydS2rjQBCGowaBdtl5nSdkFZKBWduSEHZMhI3xMyYMmSN40XfoY+SmgxSHShzZLbX/1sjq+jY5QD7qr65qt84ug0AASTeEgQyIwvDiQ2n5LTXiIcgQKKZUE/5PSvxNfE4GE66DTzBtQn/z/k4y1J4Sb6HPyWCGCAKkC4u8YSQXak6JgY/BqWnSBzcBgZBhMNlkUGHQpARUhrmP5ebMHa4CAiJDL9psAaeEXoZXH4wTe4ZPHgMCIsOITEDKoHch9cG0+8evu9wGBMaF7obQpARySTXz0biwgSYugkMATKgpJWbCR9Pq9zGKRwlgGeaUDnWlxEpk73rxEAHQLiJlGEVSyk0BtlIipUfeYDhwa1XTLgJcGExkTqEL+PHj6znBraIp9wEBk2EcS0ku2G0Z/oxIA5wMbX5TTzNdhMqw6EtiT0pgZHgbFD4FylNFwAkSIUPyLAmLKdEPRQZahvb/wKloGU0gXUglYS0lXpLD78LyAroCN15AAGXoDSVhJyVSQSAKg1uXVne58DIsyBBSo2AlJd56goDK0N5vtmhKQg5ehmSmlCTAKbFcVHtKnodJJUoCgXVhNFSKZICmRNqp/pQ8F4SSJQFfGBZT9QE4JeKB6TcmuCBoSoItGboTtUUWYpQS66ejPjjCBUFfEvAyhEsp1RZMyzDsAb4+wzeTtCUB3TJ0uvnuQSlQSlA5OFIG3j//4NYjLBSGcCpzFCAl4h7ggyMEF4RvXN55hA0ZRkOZc2xKRKtEECAZeKhI3HuEFRmSWSTlMTLkf5ZjQUBlcPOGWgGP3g7wlmE8lV8xSIl4Lgi8DG7eQ9jl2iNsydCjmbNBYYjSRMA538GhXzft48EjLKVEdn5Q0lCG51AQtmRw4RU1kyMkXoanWUT/9AopsRwIe5AMTh8dNUdItAyLtcqoVBj6I2ERksHF+ygG/SJKhvBZqSoyxPOOqAXuFKlfrMeF8VaFMikRdzuiJrhTpJWDMdVVIA4UhribiLpwe6aomS/akyFcR0ppCgNVgxr47fhM0SAcQDIsVhOlDsjQ1/UGHAxEg8LBwIWkGyu1R4apbrnEwWATCod6ZOiMpqrAhWg9Fjr4xGCTKw9H2WZhNVTfmawWom6c+9ErYKwEl6HTe45IAzoo1AiPkn7wywNTbvScxipn2RNBhqgV3jH85ALQJqC2VHXBO4YDZ8hmyCD2wifHAhrdJjRfBm4QSrQJzXBhRwZuEA7QoFHzacnAo+VK04T2yuDUC6uYS83NkEFgcfC1pIY0jM0qDNwomt9lbZMMD2fMUUeHlsjAqyY9l4+ehmbIwAeGIho/a25UYbjjyXIprsqZcLIynPPBseEmGMvAHnzlBPZPjWgZeNN0MiaYFgb2YMvpjRjxMrAH/9i7m9UIYSgMw81OZmAoFFKms1GTQBZFEqG73v919YdSp5lEo7HjSfwe6BX4Yo5H25ZXwuIYsFgur4SlMaCDcuaE5BsDzoWVCM0IqRZBB5nvE9aMAR8glFdCwsig0UGC2jKCqgXe8H4hSdMzmqp5erxvzOlLlX+LAd+h5PT12v/FgO/SVtERHBnntIA10lpakiNjbAx2x/+QY20N4UFhgDHRa0+DwgDjgVex++bYFrBVXl9NdaMwEkOPLdK3nR4PP3AsOMp+9RBm8XLBQe3vMd4H/n6iY58zo8WU6NrlTQG3g4B97RkxHQTt6vEBDwt3UxNeORvsDu5JED0fMCTenSL4/KBxKmygITcqSLxo3EZN6lFSYjiIVnAKyGCeQlNABgRsnwIyIKLZ8glCK2RASGfZJiy+UKamNSzW5cJGcM5iGayPKKqVXicEnAnZa6X3wk/jY3wVSLxhJE7IIYB5+JShAhwJOWg6wy7L8AhGYJOcjUZIveSiT8WgJSrIzqvq/1z2z580fYffYsxUI5TlQwIJrMKtIHONUIbxBJVBBMWohTKaz6aNElgWlOdVdNJYHsEa2QlMBIWrW9G9K2l6q3VV8S9VpbW1vZHqvRMtbgJFOy7wAKU4eiCJHTkGHSIgiDJ4rn0CtJAf5/qvDD3kYTKB80wHL7RAW7CC86/HmYJJIAWqQhGEA3gKePTwxoAWyPFWcD64BTwt4PZwOKMFsnwVfBpJ4GXCSA7urQElUHGbwVUEN5f+NMNNFlcxIAVqhgzcCq4bOCW5rsHXAkrY3PHbbQVDAyfXc6STa6jhtwWkQMRHe/eO1DoQhGH0ruAGpigIwOx/l5TQSP+oxxhM4KGocwICUn3V7Yc0PnaQWTBG8FS8XPFUjDFkLijhN0gGmQbjNihX//RNpYlxT5SpoIQZMg5qBotUkAKSwE0OMyItPPQpGApTpYNsheNK2Bs4Va9fOFV7DRkL+4ZQwky1g88zGK//W+e589YZi7icghJmSgh1LZQMSgW59Ncli9JCSaFbD0KYpc6D2kHLIKNgiOB8Pi9/ov2rs82GkkJKqDNBCPeVeZDXB+kgGfQV9AXEY+cYxSYt9Cm0EvI6wXK4u/rG8XoHpYJc/mpMorRwvQRvIidICGUxpIOMg2RQE/hODkkhQyEl9MtBCDNcDqHMg7GDxxuVEsaZIIS5EkLdDAkhHbQMfhLCopaQEPrdIIQZLofw/84hLIRwEyGwshpYebHIyttHGh8osfARMxtfOrHwNTSNG1NYuVWNlZtXadzOzsoDLjQeeWPjIVg+eCyexkEZrBydw8ZhWmwcr0fjwE12juDlwKHc7BzTz5Ef7mDxK5L4BwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMCf9w4/Wddwv7RuvwAAAABJRU5ErkJggg=="
      />
      <div>
        <div class="title">微信公众号</div>
        <div class="subTitle">
          微信亿级平台引流，扩大自有私域流量、增加营收与影响力
        </div>
      </div>
    </div>
    <div class="noBox">
      <el-card class="card" shadow="hover">
        <div class="card-title">微信公众号</div>
        <img
          alt=""
          class="card-img"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAggAAAG4CAMAAAAXAO+5AAAClFBMVEUAAAAAuzgAw0Ep3GEZ1VkAyUoA0FEO3FgAvEMj4mCMv56Uw6MA1U8X1U+Rw6MAw0uMw6Qo3FiNw6CYwZkIyVKOw54AuUCOwp6Rv6GFvqGNxaAAuTWNwqKVwqCSw5yOxZoZzE0TzEMTyksIvkMCvj0AvkEX1FQi3V8AvDsl3l8b2lsf4GEd2Fsm3l4Ev0Yp4GEAuz8Auz0AwEEn32Aj318Ax0UJ0lEn3V8j32AEzUwS1VUm4GEO0VIR1FQj3F4AvTsAwD8AwEAAuzkAuzod21wCwkIZ2VoAvDsAwEAExEIAuzom4WEAuzkAwD4k4GAAvTwAvj0c01gAuzgn4WIAuzkAwT8AwUAAvj0AvDsAvjwAxEMAvDoi3VwAx0gCy04AwkAAy0oAwkEAx0cHzk8AzUoz3mcV0lYn4GEh21wDzlEa11gX2FcAyEkl3mEl318W2loAy0v///8AvDsAwD8i3V4d21wAuzkAw0Ij3l8AxEQc2VoAwUAg3F0Avj0W11gY2VoAwkEH01Mm3l8m32AZ2FgD0lIAxUUAxkUM01QAujcU1VYQ1FUA0VEAzE0S1lgAyUoo4GEb2lsh21wAz1AAy0wAyksAyEgX1lgp32IAzk0AyEcP1VYAzk8Ax0gAx0YM01UAvz0AvD0Ax0kAzEwK1FUR1FcA0VD9//30/fbj+ejv+/K/8Mr3/vno+uv6/vve9+PE8c6b56zr++6v7Lxs4IjZ9t+n67bL8tS07cCh6bGV56eF4ppm3IM8z2Um0lvR9dl83ZIp1l4uy1xG1mwS0lWs6biS4qRj1n9W23i47sQv2GEEx02N4qB24Y9y3Itt2odO0nFL2HBA2Gozz18iy1cWylOO56J/4pVd231a1Xk31mQNzlIwX8OsAAAAcXRSTlMAJiYmJiYmJiYmCAUmJhEmCyYXDiYfKBMbCg8nFRkdGgcECw4aFg0WJCI/DwgaEiQdIh/OhSIZExwcIx8UH0B+Y0L64tEuidZXNOzUs5KJakr+88rBoXM8y5q7q4eH/ff07dm+KB399HZJ5dzOoJFYOwe3SrYAABk9SURBVHja7NxBjpswFIBhJKxaSMkiNwAWWA6hXrQqtLQn6LJnqNpVD9FeoMs5bmOqiKYzSWAGgm3+bzMX+GXeM2QiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIDLDnlZ1qr62rb6yCSJsX/b9mul6rLMD1mEoKVFqZrWJDeZtlFlkUYITZbXlU5G01WdczyE4tiASV7ANHUewW+FapNJtKqI4KdD3SaTautDBM+USicz0KqM4I2yMnEcJ/MwDS14oavgJLFoYX2KvoJ5YzAVm4SzUqXj3uwxaMWNk4uKJr4qmUHDTumaWscDJJPTdQRnZMrEnSViMIpLaDekVdxbJIaKYWF5hz6DBVtouHMcxZkM/iKFQJweCm7EwANiIZmKO+7EwNi4hFrER261YFgm763Qcce1GDRvIe4pbeK/HIzhK6PC3ZwPB87FoCI8zf2nwrQtaN5M3sGlldGpGKoI8ypMfIU7MTA0nvP2OPgHh4JzchMP4kYLTAo9r5aFG1gfHJG2u90uHmXxGFruFCZXiJ3lWQyGmXFiSkq523nYAo+HKWWNtLyM4SuvJCdz+CAtT2PQfLIykVJIy9sYGBSmoaTldQsMChNopOV5DE2El8laaXkfQ8vI+CKpllYAMWjull7gYORwjrdgWB6eLRfyJICDwfCL2WcqhLTCiYE18lkK2QkpBkp4hlI+wfeRgRJGq+VJUAcDJYxUCiGkDDAGShilEFaQMVDC6A7OWwhmZGCLHCwXJyEeDIaPWgc6CCvcGLhjHCb9II5CjsHw3mGATItHQhsZNO8ib/skTgI+GNoIN7wXVvAx8KXKDUpYK4iBr9euei0eC3Rk4GJp0OK4goOBJfKirFsc1xIDq8ONhWE1MbA6XBsUXWjh8sjAwHgHhbBcieHSwcDAOLdUWOuKgbvmSwPC2mJgTHh6QHCzhf9GBsaEOeXixM0YZjsY+Djh3PkNwopi0BH+8U48spYY+H+MtzdHN1voY2CH7Lhxtez/wcDDYfCDIfAYeDiM2RhCjoEP3MdtDG620MfAw8HFqySvDgaulY7S7XYrRgkwBt45RNGn7dHaY+Bb1qjYWk7EMPHIwLw4yoettVwL++9fvn37/GM/z8HAvDhUvdlsrWVi2L/98vC78/Dl7X7Rp8THaNWyVxtru0QMfQVnLSwUg1j3p6zvNtYCMezfvnno/J63hT4G7hevSF9tzszdQl/BL+v378cxPLx5u59tl2CFvHog3DcGW0HneguzxcCR8NSBcHS7BWu6Cn5atoELMfQtzBcDP336w87drCQQhWEcd3F4Vy29gD6goEWbwFCqlQkhBNG2XVGmmBsFkRg3rgqC3Bi49j6b1xHGHhA/zjOO8M7/Gn6cZxxn5n8F0RLGgAq0lTCgBS6G7EiAA0HWwuCloBsFGMBCGFhI7mDIjoSookB7SWE4fVQFcSsfDGrh2iWJITsS4ECgrgQqaLe72mYY0AIfg/EfDgWBaBhQgQYW1lsJvgXEYPhIOBDND8NSBeX2fF4Hg1pI/GCweHvxRDDWJQMqoGFAC3wMFp9QyQvEXInTSvkjDA14rgRa4GNwOXOdiUbEgAo0wMA5GM7viBYQw0XOWiXRuBhmCoZhMQQyBrDAxlDKGetYMMYlQ6igow2ngQUChrmVqIIFFgZrjyoVRWNgQAWzEAPtkgEssDEYe3pxXzQaBlAQY0h0JZKxYOum0qVoLAyhgl7vR+tg/JVADGqBicHWL8iSeDevIAowJLsSaIGGwdRjrIfCSRX0+301EFvQtr4SaoGEwdI3VArC6KbS6EcBhnRW4qHlKBYs/eGQF0Kt+mAaWEhxJZp7jNdnDN1dPBJCb/dBECiEGEPqK9GkvEtl5xMqRfHvuRFoMQaPleBhqLmlZbcS4A9oz2qjYK7BjqzE6y3jJUsrf0ZTluFppAWzdmYl3t2KZdvAWQapf4ctwpDeSlTdGlnfBmH0ohDAgsclA2slfinv4udMdCyMPrVFGFJcCbd+Vv+CLNAgAAaPleBhcJtl8Z5SXhiNw8DCIgxbvf3oNs/Y4ymHQulrMoktEFaCdcnA+XyPhXeeLkkQtMlY26mV4HzLycL3U66IECIMO7USjtIfe2eT0zYQBWAWnhv4AIUWVlUXlYqERA/BUd62O0tYiorZNIsKKRILfpzEjmISJ4BBoKhBgkgsYEGl9jL1yG6mvNg4mXkLNNPvDJ/mzfuZeZ+X9MemEWH/8FC4IBklaGWgFMGAxtOazVEXobafImSQjBL0iaVFg/4J5KqdoypCSibDzquKEhYN+g+sfbT/QVGEXIZXFSUsaQy7JLAUm0AGx6kJFyRkIIsSlCIYdElYYRm2qgwOB8uw8/KVYRIn/ajbawKEzc4g6j9djshHGSwidJ9c3GQCJRecnHIZjp7JMLo/6/qA8QfD+BtplLCI0P0R5AbjEMjgCKqjxPc4CKGM9ln8hS5KWERsLOnNJ8YhkMF1HWdOGUZJC16m9TShGmWwiNC8Fb3MENJXBpdTIcMOZ5S0oZrm+YQmsbSI0Pxv5hUmUDsY3IzKg+G+A/PRvtimGGWwlDCmpLTJOBQyuJxKGR4jmJ/rW4ImlfX/tjgP7xiHQgbPc91KGeI2LEL4pF5+tKhYX9IZfFeUvzJ4x8celsFBnPiwIMFEtfxoqWBObZEJFA8Gj8NlKD0YxmewON1HxVEGSxkTaotvGIdEBu8vx16xDFsRyNB5UGtS0X0lr/OPGWuMQyJD3ROIKCEYByBH74dSk0r593Aj0oYPDCF/ZaineIKZKDEEWVq/VJpUyl/JG5E2rDNpsAt1jpABR4mfIM/ptsIog/JX8kakDRuMQyJDXVAQJR5CQITdlg9FtLsdQAwVRhnoFo7o/PBNZI/KMuw1GtgFIYN7Dc8ZxGPHmQx9wAS3afnxIUI9yVh+lEF1x4QZ+aPNKMhE4JTJgANDMM5yiXNAnGS16KNTdE24kp5rUV44YkL+uMzIsPdyGgUyXPVQR+nKzdhqoqJyLecWC4KmH+d/b6u+Y8KAttN7RkcqwF6xDJ6X4APBzcEhI5n2JUKkzkR2+pFw+4y+z51WGB27u42pCyhK/O4hEe48NweFgItpX6KJjwTZGXn1hSMGTKu9pRSB02gUHQz3gOi4eWJZQ4oETs4jIHpfK2bkyw4Gwh1l+n6cskksQokMEWCSPLHEivixkzEETCw5I7/QjglTK0qrxCIUyzAOAePfjLyUuDnbeN7i7anEB0xf8iUV4Y4yfV/CrjM6Dg4OSly4hALC6KY/gALawfCuA7O0JF9SyaylMq60+Ie9c2ltIooCcBhIt92Ia9+4EBHBhSCoKx8IKqio4FsEwYXXLEoJgm6SjSGLJoUGUzQumneTxiSNTWyaaGJtbatttY8/45w+vM3k3szcmePmTr5laXYf95x75p5zDjjxCAQ+gAsMGbLEPOl8ojTxo7xSnpu4aq6TyuyOMluJcBJTBOADS4YEMUmsVP7MfPAmEiWsrKWyTWnxOLIIbBnyxAzRwreNpwz1P6XpyVgqGk2NFnOfPk6BCCJRwuqOsq4IggQDlNYokSLijP2eUi34/icR16aZo4WVLyL9tgibLOUX4QSmCECAQg+GKBElWVJr0F8+ZtKESSq7ZjxKIK41lXekVi+yCECgTYYRIshk/c2b1xMxwic9/stovy3iJsuuCEbwBwGWDEkixEh2Xa0wxPSuE7kpY/22VnaU2UYEJyJ+lSBThrhYkvjxzZu1hJE04oehflurmyy7IpgQAWh3YZQIEP82MFA2qM701Gv9qQyYa00dsoItAluGjMh5oHrQMJxUjNb1pzIgbbLsimCUQT/AciErUEhceTtQEjo/dBvxEdeayitCby+iCABThjIxzMTQUE4so6AmcGTAXHHrkJVeAFEEtgzLSWKQ3NDQJyJG/KdOJz7iitseh6ycABGQZIhEBimtLiSIMVJX384JFx1iU7SrjiVDD4Ajg7y3hg0RkGQIhSIqTBfmiTHmfWtxIkyi81SGHhxsJAJgRQSALUMwRYxQ9PkyxAR/Ok5l6EFDYhGOKypILoTDIY0LVIYJQxXFVV9Z85fCry8LhXTrjbH8ZK062lpZ+txpREcPHvJ+dAIRAIyDIQyEmDL478aIPpMffJrS0+zGu5aVdEuny4DKkyLZSal9KkNXBCFOKgCODMPDw2GuDEayhGqgrEkD324+chrf+U8DG9Q1/TLMqQzoIsg7avGAAuDIMLxBmCNDjugRXdeWIBO+TWYJ5efWG/mk5lE0byoDqgjyPlXTimAlZfCqUBm0LizrBodE4HO6/UQAWk6EIeDtT02pucOIjq4IBjioUKweDF6AL8NCUq+oGKwSDVkfMD/SkiOACFe1zdV1xlQGfBHk3dlwSgFwZPDugBUl9EpF9eB4e/dDfXEl1/q72Nzir/Y3K7OsqQzoIsjb4LJfAXBk8Hg8XoB7MEx0NCHtC+aJacZZUxlABlQR5G15O6ToYtgFD8CXQc+EUb8/SUyTH6BoogSiCPI2wR5RKFYPBs8/vDwZ5tKES9G/RMwzxprKAKCKIG9b/F4FwJGhv7/fQ2G70IwTHgl/hZgnyZjKgC+CvIMyHL0KgCJDP6AnQyXPjfL+OrFA+1QGAFeEXQ55OaEIwnehn9IhSswUOInC9OAiMU+UPa4FwBPhhENeaI3Z2sFARdA7GHivVBKD68Q8MfaIDqBbYRYoLWLI0NfX129AhjnCZjIyOEZMk2GO6BgAuoVFIxxVABQZ+gB9GRKETTwUKRLTZPnjWmAuLA5HHfKyXwFQZLgHGui6sJwmHGqhEjHNKndcy12chceAzEO59ygAigsPwAFdGapki5HpT4kU2cF8qGkhRWCP6FC5DxbguCDzmH6HAqDIcO7VKzBAR4bMdhNrxauy1GyMT46NEKAQjsSJSRrsER3gwkOUfceAvG+Y6f0Rg9uvAB0XNiNDOlfxeCnhpUqlshQKh83GhuTnwAYsFx4JL6yz4+0Rrg1Y3AIP9GSoggZfFzkVp8qIyVQxwB/Xcl14YZ0dLw1wbcDihtvtfqUnQ0bVoMavMuSIGVLrrKkMW9xwAhguyDtcD9inYHHFvQnPBZBhKVqodSoy1KJEnJF5zogOH/BUeHmh/b49AnsVLHbfc2/BPxhqSzoVp1kiztcgwJHh/mPhhXU2/OSEnC26KTpRgitDuEhEyd/1q/BceCS+sM6Gn5yAYwoWp10ul7sF6oJRGbw10TpzbNEP8GS4I7zW1I5fGnCzxbOuTawdDAtiaUK84qcwZvc8FdpRZt9cEbJFNM65tnFbkGFVxISxBVYjPuWh+MI6e+aKKgpibKBYiBILcWKUVGUQ4Mtwx9z2QtvVFYHjChYX7rkoFqJEJW80T1ykXXVMGe4+N7/W1DZ9j7TJBY1LLsC6DDM5YoTcDLsRn/IIZ98xcNAhO/sVNM67KNaiRDNGdClym6//ccb6jls7fIPeQsHj5jsXgHAwzDR0M4XoTKdOfOAZ0sJjW6QIkCSgcf7ly3fggnUZQIUU6UyT34gP0AMBwYXjDvk5peBx7aXKO6YM4hdLT3OadZVMbwvydRjgy/CQlpctyyB7FQGzkgBcARH0ZBBwIdLMFnfKEM80Vme85VECpMK035YlAz0QrMsgfRUBOKzgcf0lBStK1Fars41StlFt1rYr0dUUUVno2Ih/24mH7B8acB+nABcuUhEQogS3Fh2ZjROS7dR8ff+sEw+5H6WgXyCByy9egAHWZOjTwHJhOZvMe7z85us7TkT2O2yBgsmlF4C4DOIHQ+1rjd9v++yxExGHPTimoAYHEIHK8N+jBFMGCAx4yP4JGj82AOffb5vw36MEv9/2tBMDm0WGv+ydS2rjQBCGowaBdtl5nSdkFZKBWduSEHZMhI3xMyYMmSN40XfoY+SmgxSHShzZLbX/1sjq+jY5QD7qr65qt84ug0AASTeEgQyIwvDiQ2n5LTXiIcgQKKZUE/5PSvxNfE4GE66DTzBtQn/z/k4y1J4Sb6HPyWCGCAKkC4u8YSQXak6JgY/BqWnSBzcBgZBhMNlkUGHQpARUhrmP5ebMHa4CAiJDL9psAaeEXoZXH4wTe4ZPHgMCIsOITEDKoHch9cG0+8evu9wGBMaF7obQpARySTXz0biwgSYugkMATKgpJWbCR9Pq9zGKRwlgGeaUDnWlxEpk73rxEAHQLiJlGEVSyk0BtlIipUfeYDhwa1XTLgJcGExkTqEL+PHj6znBraIp9wEBk2EcS0ku2G0Z/oxIA5wMbX5TTzNdhMqw6EtiT0pgZHgbFD4FylNFwAkSIUPyLAmLKdEPRQZahvb/wKloGU0gXUglYS0lXpLD78LyAroCN15AAGXoDSVhJyVSQSAKg1uXVne58DIsyBBSo2AlJd56goDK0N5vtmhKQg5ehmSmlCTAKbFcVHtKnodJJUoCgXVhNFSKZICmRNqp/pQ8F4SSJQFfGBZT9QE4JeKB6TcmuCBoSoItGboTtUUWYpQS66ejPjjCBUFfEvAyhEsp1RZMyzDsAb4+wzeTtCUB3TJ0uvnuQSlQSlA5OFIG3j//4NYjLBSGcCpzFCAl4h7ggyMEF4RvXN55hA0ZRkOZc2xKRKtEECAZeKhI3HuEFRmSWSTlMTLkf5ZjQUBlcPOGWgGP3g7wlmE8lV8xSIl4Lgi8DG7eQ9jl2iNsydCjmbNBYYjSRMA538GhXzft48EjLKVEdn5Q0lCG51AQtmRw4RU1kyMkXoanWUT/9AopsRwIe5AMTh8dNUdItAyLtcqoVBj6I2ERksHF+ygG/SJKhvBZqSoyxPOOqAXuFKlfrMeF8VaFMikRdzuiJrhTpJWDMdVVIA4UhribiLpwe6aomS/akyFcR0ppCgNVgxr47fhM0SAcQDIsVhOlDsjQ1/UGHAxEg8LBwIWkGyu1R4apbrnEwWATCod6ZOiMpqrAhWg9Fjr4xGCTKw9H2WZhNVTfmawWom6c+9ErYKwEl6HTe45IAzoo1AiPkn7wywNTbvScxipn2RNBhqgV3jH85ALQJqC2VHXBO4YDZ8hmyCD2wifHAhrdJjRfBm4QSrQJzXBhRwZuEA7QoFHzacnAo+VK04T2yuDUC6uYS83NkEFgcfC1pIY0jM0qDNwomt9lbZMMD2fMUUeHlsjAqyY9l4+ehmbIwAeGIho/a25UYbjjyXIprsqZcLIynPPBseEmGMvAHnzlBPZPjWgZeNN0MiaYFgb2YMvpjRjxMrAH/9i7m9UIYSgMw81OZmAoFFKms1GTQBZFEqG73v919YdSp5lEo7HjSfwe6BX4Yo5H25ZXwuIYsFgur4SlMaCDcuaE5BsDzoWVCM0IqRZBB5nvE9aMAR8glFdCwsig0UGC2jKCqgXe8H4hSdMzmqp5erxvzOlLlX+LAd+h5PT12v/FgO/SVtERHBnntIA10lpakiNjbAx2x/+QY20N4UFhgDHRa0+DwgDjgVex++bYFrBVXl9NdaMwEkOPLdK3nR4PP3AsOMp+9RBm8XLBQe3vMd4H/n6iY58zo8WU6NrlTQG3g4B97RkxHQTt6vEBDwt3UxNeORvsDu5JED0fMCTenSL4/KBxKmygITcqSLxo3EZN6lFSYjiIVnAKyGCeQlNABgRsnwIyIKLZ8glCK2RASGfZJiy+UKamNSzW5cJGcM5iGayPKKqVXicEnAnZa6X3wk/jY3wVSLxhJE7IIYB5+JShAhwJOWg6wy7L8AhGYJOcjUZIveSiT8WgJSrIzqvq/1z2z580fYffYsxUI5TlQwIJrMKtIHONUIbxBJVBBMWohTKaz6aNElgWlOdVdNJYHsEa2QlMBIWrW9G9K2l6q3VV8S9VpbW1vZHqvRMtbgJFOy7wAKU4eiCJHTkGHSIgiDJ4rn0CtJAf5/qvDD3kYTKB80wHL7RAW7CC86/HmYJJIAWqQhGEA3gKePTwxoAWyPFWcD64BTwt4PZwOKMFsnwVfBpJ4GXCSA7urQElUHGbwVUEN5f+NMNNFlcxIAVqhgzcCq4bOCW5rsHXAkrY3PHbbQVDAyfXc6STa6jhtwWkQMRHe/eO1DoQhGH0ruAGpigIwOx/l5TQSP+oxxhM4KGocwICUn3V7Yc0PnaQWTBG8FS8XPFUjDFkLijhN0gGmQbjNihX//RNpYlxT5SpoIQZMg5qBotUkAKSwE0OMyItPPQpGApTpYNsheNK2Bs4Va9fOFV7DRkL+4ZQwky1g88zGK//W+e589YZi7icghJmSgh1LZQMSgW59Ncli9JCSaFbD0KYpc6D2kHLIKNgiOB8Pi9/ov2rs82GkkJKqDNBCPeVeZDXB+kgGfQV9AXEY+cYxSYt9Cm0EvI6wXK4u/rG8XoHpYJc/mpMorRwvQRvIidICGUxpIOMg2RQE/hODkkhQyEl9MtBCDNcDqHMg7GDxxuVEsaZIIS5EkLdDAkhHbQMfhLCopaQEPrdIIQZLofw/84hLIRwEyGwshpYebHIyttHGh8osfARMxtfOrHwNTSNG1NYuVWNlZtXadzOzsoDLjQeeWPjIVg+eCyexkEZrBydw8ZhWmwcr0fjwE12juDlwKHc7BzTz5Ef7mDxK5L4BwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMCf9w4/Wddwv7RuvwAAAABJRU5ErkJggg=="
        />
        <div class="card-info">
          <el-image
            fit="fill"
            :lazy="true"
            :src="info.data.mpappinfo.headimg"
            style="width: 50px; margin-bottom: 10px; border-radius: 50%"
          />
          <div>{{ info.data.mpappinfo.nickname }}</div>
        </div>
        <div class="btn">
          <el-button size="default" @click="">查看二维码</el-button>
          <el-button size="default" @click="">重新绑定</el-button>
        </div>
        <!-- <template #header>
        <div>
          <span>微信公众号绑定</span>
        </div>
      </template>
      <div>
        <el-image fit="fill" :lazy="true" :src="info.data.mpappinfo.headimg" />
        <el-image fit="fill" :lazy="true" :src="info.data.mpappinfo.qrcode" />
        <div>{{ info.data.mpappinfo.nickname }}</div>
        <div
          v-if="
            info.data.mpappinfo.level == 2 || info.data.mpappinfo.level == 4
          "
        >
          服务号
        </div>
        <div v-else>订阅号</div>
        <div
          v-if="
            info.data.mpappinfo.level == 3 || info.data.mpappinfo.level == 4
          "
        >
          已认证
        </div>
        <div v-else>未认证</div>

        <div v-if="info.data.mpappinfo.authtype == 1">
          <span>已授权</span>
          <span>刷新授权信息</span>
          <span>APPID：{{ info.data.mpappinfo.appid }}</span>
          <span v-if="info.data.mpappinfo.open_appid != -1">
            开放平台APPID:{{
              info.data.mpappinfo.open_appid
                ? info.data.mpappinfo.open_appid
                : '未绑定'
            }}
          </span>
        </div>
        <div v-else>
          <span>已绑定</span>
          <span>APPID：{{ info.data.mpappinfo.appid }}</span>
        </div>

        <div>{{ info.data.mpappinfo.aid }}</div>
        <div>{{ info.data.mpappinfo.appsecret }}</div>
      </div> -->
      </el-card>
    </div>
    <div class="noCard">
      <span>注意：小程序主体必须是企业（包含个体工商户）</span>
      <div>
        将公众号授权给本系统，系统将会自动帮您生成店铺公众号，并提交到微信官方微信审核，您不需要做复杂操作，即可管理您的公众号平台。
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Binding } from '@/api/channel'
export default {
  name: 'Shopstock',
  data() {
    return {
      info: {
        data: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Binding({}).then((res) => {
      this.info = res
    })
  },
  methods: {
    Binding,
  },
}
</script>

<style lang="scss" scoped>
.noCard {
  margin: 40px 0;
}
.noBox {
  margin: 60px 0;
  text-align: center;
}
.selectBox {
  display: flex;
  align-items: center;
  padding: 0 20px;
  background-color: #f2f5f8;
  border-radius: 6px;
  img {
    width: 120px;
    margin-top: 17px;
  }
  .title {
    margin-bottom: 12px;
    font-size: 20px;
    font-weight: 700;
  }
  .subTitle {
    font-size: 14px;
    line-height: 16px;
    color: #333;
  }
}
.card {
  position: relative;
  box-sizing: border-box;
  display: inline-block;
  width: 307px;
  height: 500px;
  padding-top: 30px;
  padding-bottom: 27px;
  margin: 60px 0;
  text-align: center;
  vertical-align: top;
  border-radius: 10px;
  .card-title {
    padding: 0 0 30px 0;
    font-size: 22px;
    font-weight: 700;
    color: #333;
    text-align: center;
  }
  .card-img {
    display: block;
    height: 200px;
    margin: 20px auto 0px;
  }
  .card-info {
    margin-bottom: 30px;
    font-size: 14px;
    color: 666;
    text-align: center;
  }

  .btn {
    position: relative;
    box-sizing: border-box;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>
