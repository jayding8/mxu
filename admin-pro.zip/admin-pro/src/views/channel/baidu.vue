<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 18, offset: 0 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card
            :body-style="{ padding: '20px' }"
            shadow="hover"
            style="border: none"
          >
            <template #header>
              <div>
                <span>绑定百度小程序</span>
              </div>
            </template>

            <el-form-item label="小程序ID：" prop="appid">
              <el-input v-model="form.info.appid" style="width: 300px" />
            </el-form-item>
            <el-form-item label="App Key：" prop="appkey">
              <el-input v-model="form.info.appkey" style="width: 300px" />
            </el-form-item>
            <el-form-item label="小程序密钥：" prop="appsecret">
              <el-input v-model="form.info.appsecret" style="width: 300px" />
            </el-form-item>
            <el-form-item label="小程序名称：" prop="nickname">
              <el-input v-model="form.info.nickname" style="width: 300px" />
            </el-form-item>

            <el-form-item label="小程序头像：" prop="shipping_pagetitle">
              <el-button>上传</el-button>
              <el-image fit="fill" :lazy="true" :src="form.info.headimg" />
            </el-form-item>

            <el-form-item label="小程序码：" prop="shipping_pagetitle">
              <el-button>上传</el-button>
              <el-image fit="fill" :lazy="true" :src="form.info.qrcode" />
            </el-form-item>

            <div style="margin: 30px 0">微信支付设置</div>

            <el-form-item label="支付状态：" prop="baidupay">
              <el-radio-group v-model="form.info.baidupay">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item label="APP ID：" prop="pay_appid">
              <el-input v-model="form.info.pay_appid" style="width: 300px" />
            </el-form-item>

            <el-form-item label="APP KEY：" prop="pay_appkey">
              <el-input v-model="form.info.pay_appkey" style="width: 300px" />
            </el-form-item>
            <el-form-item label="dealld：" prop="pay_dealId">
              <el-input
                v-model="form.info.pay_dealId"
                style="width: 300px"
                type="text"
              />
            </el-form-item>
            <el-form-item label="平台公钥：" prop="pay_publickey">
              <el-input
                v-model="form.info.pay_publickey"
                style="width: 300px"
                type="text"
              />
              <span style="margin-right: 20px; color: #969696">
                在[支付中心-支付管理]中查找
              </span>
            </el-form-item>
            <el-form-item label="RSA公钥：" prop="pay_privatekey">
              <el-input
                v-model="form.info.pay_privatekey"
                style="width: 300px"
                type="text"
              />
              <span style="margin-right: 20px; color: #969696">
                请填写RSA私钥，一行字符串
              </span>
            </el-form-item>

            <el-form-item label="支付回调地址：" prop="shipping_pagetitle">
              <span style="color: #969696">
                https://game.demo.ranyun.online/notify.php
              </span>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" @click="submitForm('form')">
                提交
              </el-button>
            </el-form-item>
          </el-card>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Baidu } from '@/api/channel'
export default {
  name: 'Shopset',
  data() {
    return {
      labelPosition: 'right',
      form: {
        name: '',
        region: '',
        date: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        description: '',
        rate: 0,
        area: [],
        transfer: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Baidu().then((res) => {
      this.form = res.data
    })
  },
  methods: {
    Baidu,
  },
}
</script>

<style lang="scss" scoped></style>
