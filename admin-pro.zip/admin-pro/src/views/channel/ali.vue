<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 18, offset: 0 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>填写支付宝小程序信息</span>
              </div>
            </template>

            <el-form-item label="小程序ID：" prop="appid">
              <el-input v-model="form.info.appid" style="width: 300px" />
            </el-form-item>
            <el-form-item label="应用私钥：" prop="appsecret">
              <el-input v-model="form.info.appsecret" style="width: 300px" />
            </el-form-item>
            <el-form-item label="支付宝密钥：" prop="publickey">
              <el-input v-model="form.info.publickey" style="width: 300px" />
            </el-form-item>
            <el-form-item label="小程序名称：" prop="nickname">
              <el-input v-model="form.info.nickname" style="width: 300px" />
            </el-form-item>

            <el-form-item label="小程序头像：" prop="shipping_pagetitle">
              <el-button>上传</el-button>
              <el-image fit="fill" :lazy="true" :src="form.info.headimg" />
            </el-form-item>

            <el-form-item label="小程序码：" prop="shipping_pagetitle">
              <el-button>上传</el-button>
              <el-image fit="fill" :lazy="true" :src="form.info.qrcode" />
            </el-form-item>

            <el-form-item label="小程序支付状态：" prop="alipay">
              <el-radio-group v-model="form.info.alipay">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="open_appid配置：" prop="openid_set">
              <el-radio-group v-model="form.info.openid_set">
                <el-radio :label="'userid'">uid标准</el-radio>
                <el-radio :label="'openid'">openid标准</el-radio>
              </el-radio-group>
              <!-- {{ form.info.openid_set }}111 -->
            </el-form-item>
            <el-form-item label="随行付支付：" prop="sxpay">
              <el-radio-group v-model="form.info.sxpay">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>

            <div v-if="form.info.sxpay == 1">
              <el-form-item label="商户编号：" prop="sxpay_mno">
                <el-input v-model="form.info.sxpay_mno" style="width: 300px" />
              </el-form-item>
              <el-form-item label="支付密钥：" prop="sxpay_mchkey">
                <el-input
                  v-model="form.info.sxpay_mchkey"
                  style="width: 300px"
                />
              </el-form-item>
            </div>
          </el-card>
          <el-card :body-style="{ padding: '20px' }" shadow="hover">
            <template #header>
              <div>
                <span>设置IP白名单及域名</span>
              </div>
            </template>
            <el-form-item label="IP白名单：" prop="shipping_pagetitle">
              <div style="color: #333">39.99.248.90</div>
              <span style="color: #969696">
                [开发]-[开发设置]-[开发信息]-[服务器IP白名单]中设置
              </span>
            </el-form-item>
            <el-form-item label="域名白名单：" prop="shipping_pagetitle">
              <div style="color: #333">game.demo.ranyun.online</div>
              <span style="color: #969696">
                [开发]-[开发设置]-[服务器域名白名单]中设置
              </span>
            </el-form-item>
          </el-card>

          <el-form-item>
            <el-button type="primary" @click="submitForm('form')">
              提交
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Alipay } from '@/api/channel'
export default {
  name: 'Shopset',
  data() {
    return {
      labelPosition: 'right',
      form: {
        name: '',
        region: '',
        date: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        description: '',
        rate: 0,
        area: [],
        transfer: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Alipay().then((res) => {
      this.form = res.data
    })
  },
  methods: {
    Alipay,
  },
}
</script>

<style lang="scss" scoped></style>
