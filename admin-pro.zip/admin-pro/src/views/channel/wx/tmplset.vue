<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 18, offset: 0 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card
            :body-style="{ padding: '20px' }"
            shadow="hover"
            style="border: none"
          >
            <template #header>
              <div>
                <span>订阅消息设置</span>
              </div>
            </template>

            <el-form-item label="发货通知：" prop="tmpl_orderfahuo_new">
              <el-input
                v-model="form.info.tmpl_orderfahuo_new"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：商品名称、快递公司、快递单号、收货地址
              </div>
            </el-form-item>
            <el-form-item label="退款成功通知：" prop="tmpl_tuisuccess_new">
              <el-input
                v-model="form.info.tmpl_tuisuccess_new"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：退款金额、退货商品、订单编号
              </div>
            </el-form-item>
            <el-form-item label="退款拒绝通知：" prop="tmpl_tuierror_new">
              <el-input
                v-model="form.info.tmpl_tuierror_new"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：退款金额、商品名称、订单编号
              </div>
            </el-form-item>
            <el-form-item label="提现到账通知：" prop="tmpl_tixiansuccess_new">
              <el-input
                v-model="form.info.tmpl_tixiansuccess_new"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：提现金额、打款方式、到账时间
              </div>
            </el-form-item>
            <el-form-item label="提现结果通知：" prop="tmpl_tixianerror_new">
              <el-input
                v-model="form.info.tmpl_tixianerror_new"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：提现状态、提现金额、提现时间、失败原因
              </div>
            </el-form-item>
            <el-form-item label="拼团成功通知：" prop="tmpl_collagesuccess_new">
              <el-input
                v-model="form.info.tmpl_collagesuccess_new"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：商品名称、团长昵称、成团人数
              </div>
            </el-form-item>
            <el-form-item label="审核结果通知：" prop="tmpl_shenhe_new">
              <el-input
                v-model="form.info.tmpl_shenhe_new"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：审核内容、审核结果、备注
              </div>
            </el-form-item>
            <el-form-item label="服务到期通知：" prop="tmpl_use_expire">
              <el-input
                v-model="form.info.tmpl_use_expire"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：服务名称、到期时间、温馨提示
              </div>
            </el-form-item>

            <div style="margin: 40px 0">
              管理员通知(需要在管理员手机端点击增加接收次数)
            </div>
            <el-form-item label="订单下单提醒：" prop="tmpl_orderconfirm">
              <el-input
                v-model="form.info.tmpl_orderconfirm"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：商品名称、订单编号、订单状态、订单金额、客户名称
              </div>
            </el-form-item>
            <el-form-item label="收货结果通知：" prop="tmpl_ordershouhuo">
              <el-input
                v-model="form.info.tmpl_ordershouhuo"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：订单商品、订单编号、买家信息、收货时间
              </div>
            </el-form-item>
            <el-form-item label="申请退款通知：" prop="tmpl_ordertui">
              <el-input
                v-model="form.info.tmpl_ordertui"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：订单商品、订单编号、订单金额、退款金额、退款原因
              </div>
            </el-form-item>
            <el-form-item label="提现申请通知：" prop="tmpl_withdraw">
              <el-input
                v-model="form.info.tmpl_withdraw"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：用户昵称、提现金额、发起时间、备注
              </div>
            </el-form-item>
            <el-form-item label="收到留言通知：" prop="tmpl_kehuzixun">
              <el-input
                v-model="form.info.tmpl_kehuzixun"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：留言者、留言内容、留言时间
              </div>
            </el-form-item>
            <el-form-item label="库存不足提醒：" prop="tmpl_stockwarning">
              <el-input
                v-model="form.info.tmpl_stockwarning"
                style="width: 400px; margin-right: 20px"
              />
              <el-button>添加</el-button>
              <div style="color: #969696">
                配置关键字：商品名称、库存数量、温馨提示 添加类目 商家自营 >
                服饰内衣
              </div>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm('form')">
                提交
              </el-button>
            </el-form-item>
          </el-card>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Wxtmpl } from '@/api/channel'
export default {
  name: 'Shopset',
  data() {
    return {
      labelPosition: 'right',
      form: {
        name: '',
        region: '',
        date: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        description: '',
        rate: 0,
        area: [],
        transfer: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Wxtmpl().then((res) => {
      this.form = res.data
    })
  },
  methods: {
    Wxtmpl,
  },
}
</script>

<style lang="scss" scoped></style>
