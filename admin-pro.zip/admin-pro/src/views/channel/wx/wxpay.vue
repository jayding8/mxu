<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 18, offset: 0 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card
            :body-style="{ padding: '20px' }"
            shadow="hover"
            style="border: none"
          >
            <template #header>
              <div>
                <span>支付设置</span>
              </div>
            </template>

            <el-form-item label="微信支付状态：" prop="wxpay">
              <el-radio-group v-model="form.info.wxpay">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="微信支付模式：" prop="wxpay_type">
              <el-radio-group v-model="form.info.wxpay_type">
                <el-radio :label="0">普通模式</el-radio>
                <el-radio :label="1">服务商模式</el-radio>
                <el-radio :label="2">二级商户模式</el-radio>
                <el-radio :label="3">随行付</el-radio>
              </el-radio-group>
            </el-form-item>

            <div v-if="form.info.wxpay_type == 0">
              <!-- 普通模式 -->
              <el-form-item label="支付商户号：" prop="wxpay_mchid">
                <el-input
                  v-model="form.info.wxpay_mchid"
                  style="width: 200px"
                />
              </el-form-item>
              <el-form-item label="支付密钥：" prop="wxpay_mchkey">
                <el-input
                  v-model="form.info.wxpay_mchkey"
                  style="width: 200px"
                />
                <span style="margin-left: 20px; color: #969696">
                  请在 微信支付商户平台 [账户中心]-[API安全]中设置[APIv2密钥]
                </span>
              </el-form-item>
              <el-form-item label="PEM证书：" prop="shipping_pagetitle">
                <el-button>上传</el-button>
                <span style="margin-left: 20px; color: #969696">
                  apiclient_cert.pem 请在 微信支付商户平台
                  [账户中心]-[API安全]中设置[API证书]，设置完成后上传
                </span>
              </el-form-item>
              <el-form-item label="密钥证书：" prop="shipping_pagetitle">
                <el-button>上传</el-button>
                <span style="margin-left: 20px; color: #969696">
                  apiclient_key.pem 请在 微信支付商户平台
                  [账户中心]-[API安全]中设置[API证书]，设置完成后上传
                </span>
              </el-form-item>
              <el-form-item label="证书序列号：" prop="wxpay_serial_no">
                <el-input
                  v-model="form.info.wxpay_serial_no"
                  style="width: 200px"
                />
                <span style="margin-left: 20px; color: #969696">
                  使用商家转账到零钱功能时填写此项，否则不需要填写请在
                  微信支付商户平台 [账户中心]-[API安全]-[管理证书]中查看
                </span>
              </el-form-item>
            </div>
            <div v-if="form.info.wxpay_type == 1">
              <!-- 服务商模式 -->
              <el-form-item label="支付商户号：" prop="wxpay_sub_mchid">
                <el-input
                  v-model="form.info.wxpay_sub_mchid"
                  style="width: 200px"
                />
              </el-form-item>
            </div>
            <div v-if="form.info.wxpay_type == 2">
              <!-- 二级商户模式 -->
              <el-form-item label="支付商户号：" prop="wxpay_sub_mchid2">
                <el-input
                  v-model="form.info.wxpay_sub_mchid2"
                  style="width: 200px"
                />
              </el-form-item>
            </div>
            <div v-if="form.info.wxpay_type == 3">
              <!-- 随行付 -->
              <el-form-item label="商户编号：" prop="sxpay_mno">
                <el-input v-model="form.info.sxpay_mno" style="width: 200px" />
              </el-form-item>
              <el-form-item label="支付密钥：" prop="sxpay_mchkey">
                <el-input
                  v-model="form.info.sxpay_mchkey"
                  style="width: 200px"
                />
              </el-form-item>
              <el-form-item label="随行付小程序收银台：" prop="sxpay_embedded">
                <el-radio-group v-model="form.info.sxpay_embedded">
                  <el-radio :label="1">开启</el-radio>
                  <el-radio :label="0">关闭</el-radio>
                </el-radio-group>
                <span style="margin-left: 20px; color: #969696">
                  调用随行付（半屏）小程序支付
                </span>
              </el-form-item>
            </div>

            <el-form-item>
              <el-button type="primary" @click="submitForm('form')">
                提交
              </el-button>
            </el-form-item>
          </el-card>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Wxpay } from '@/api/channel'
export default {
  name: 'Shopset',
  data() {
    return {
      labelPosition: 'right',
      form: {
        name: '',
        region: '',
        date: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        description: '',
        rate: 0,
        area: [],
        transfer: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Wxpay().then((res) => {
      this.form = res.data
    })
  },
  methods: {
    Wxpay,
  },
}
</script>

<style lang="scss" scoped></style>
