<template>
  <div class="index-container">
    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column fixed label="id" prop="id" width="80" />
      <el-table-column label="链接名称" prop="name" width="200" />
      <el-table-column label="小程序路径" prop="path" width="200" />
      <el-table-column label="链接地址" prop="code" />
      <el-table-column label="创建时间" prop="createtime" width="150" />
      <el-table-column label="过期时间" prop="endtime" width="150" />
      <el-table-column label="状态" prop="status">
        <template slot-scope="props">
          <el-form>
            <el-form-item v-if="props.row.status == 1">
              <span>正常</span>
            </el-form-item>
            <el-form-item v-else-if="props.row.status == 2">
              <span>已过期</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="操作" prop="status">
        <el-button>编辑</el-button>
        <el-button>删除</el-button>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Wxurl } from '@/api/channel'

export default {
  name: 'Fuchilog',

  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Wxurl({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    Wxurl,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Wxurl({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Wxurl({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
}
</style>
