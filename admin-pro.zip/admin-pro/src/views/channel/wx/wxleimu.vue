<template>
  <div class="index-container">
    <el-table
      border
      :data="info.data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column label="类目" prop="first_class" width="200" />
      <el-table-column label="内容" prop="second_class" />
      <el-table-column label="状态" prop="audit_status" width="400">
        <template slot-scope="props">
          <el-form>
            <el-form-item v-if="props.row.audit_status == 1">
              <span>审核中</span>
            </el-form-item>
            <el-form-item v-else-if="props.row.audit_status == 2">
              <span>审核未通过</span>
            </el-form-item>

            <el-form-item v-else="props.row.audit_status == 3">
              <span>已通过</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="page.current"
        layout="total, sizes, prev, pager, next, jumper"
        :page-size="page.limit"
        :page-sizes="[10, 20, 1, 2]"
        :total="info.count"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Wxleimu } from '@/api/channel'

export default {
  name: 'Fuchilog',

  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 10,
      },
      layout: 'total, sizes, prev, pager, next, jumper',
      info: {
        count: 0,
        data: [],
      },
      page: {
        current: 1,
        limit: 10,
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Wxleimu({
      page: this.page.current,
      limit: this.page.limit,
    }).then((res) => {
      this.info.data = res.data
      this.info.count = res.count
    })
  },
  methods: {
    Wxleimu,
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.info.data.limit = val
      this.Wxleimu({
        page: this.info.data.current,
        limit: val,
      })
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.info.data.current = val
      this.Wxleimu({
        page: val,
        limit: this.info.page.limit,
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style lang="scss" scoped>
.select-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.box {
  width: 100%;
  padding: 20px;
  background: #f2f5f8;
  border-radius: 6px;
}
</style>
