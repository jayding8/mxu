<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col
        :lg="{ span: 18, offset: 0 }"
        :md="{ span: 20, offset: 2 }"
        :sm="{ span: 20, offset: 2 }"
        :xl="{ span: 12, offset: 6 }"
        :xs="24"
      >
        <!-- <vab-query-form>
          <vab-query-form-left-panel>
            <el-radio-group v-model="labelPosition">
              <el-radio-button label="left">左对齐</el-radio-button>
              <el-radio-button label="right">右对齐</el-radio-button>
              <el-radio-button label="top">顶部对齐</el-radio-button>
            </el-radio-group>
          </vab-query-form-left-panel>
        </vab-query-form> -->
        <el-form
          ref="form"
          class="demo-form"
          :label-position="labelPosition"
          label-width="180px"
          :model="form"
          :rules="rules"
        >
          <el-card
            :body-style="{ padding: '20px' }"
            shadow="hover"
            style="border: none"
          >
            <template #header>
              <div>
                <span>绑定抖音小程序</span>
              </div>
            </template>

            <el-form-item label="AppID：" prop="appid">
              <el-input v-model="form.info.appid" style="width: 300px" />
            </el-form-item>
            <el-form-item label="AppSecret：" prop="appsecret">
              <el-input v-model="form.info.appsecret" style="width: 300px" />
            </el-form-item>

            <el-form-item label="小程序名称：" prop="nickname">
              <el-input v-model="form.info.nickname" style="width: 300px" />
            </el-form-item>

            <el-form-item label="小程序头像：" prop="shipping_pagetitle">
              <el-button>上传</el-button>
              <el-image fit="fill" :lazy="true" :src="form.info.headimg" />
            </el-form-item>

            <el-form-item label="小程序码：" prop="shipping_pagetitle">
              <el-button>上传</el-button>
              <el-image fit="fill" :lazy="true" :src="form.info.qrcode" />
            </el-form-item>

            <div style="margin: 30px 0">支付设置</div>

            <el-form-item label="支付状态：" prop="toutiaopay">
              <el-radio-group v-model="form.info.toutiaopay">
                <el-radio :label="1">开启</el-radio>
                <el-radio :label="0">关闭</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item label="Token(令牌)：" prop="pay_token">
              <el-input v-model="form.info.pay_token" style="width: 300px" />
            </el-form-item>

            <el-form-item label="商户号：" prop="pay_mchid">
              <el-input v-model="form.info.pay_mchid" style="width: 300px" />
            </el-form-item>
            <el-form-item label="SALT：" prop="pay_salt">
              <el-input v-model="form.info.pay_salt" style="width: 300px" />
            </el-form-item>

            <el-form-item label="服务器地址：" prop="shipping_pagetitle">
              <span style="color: #969696">
                https://game.demo.ranyun.online
              </span>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" @click="submitForm('form')">
                提交
              </el-button>
            </el-form-item>
          </el-card>
        </el-form>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Toutiao } from '@/api/channel'
export default {
  name: 'Shopset',
  data() {
    return {
      labelPosition: 'right',
      form: {
        name: '',
        region: '',
        date: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        description: '',
        rate: 0,
        area: [],
        transfer: [],
      },
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
  },
  created() {
    this.Toutiao().then((res) => {
      this.form = res.data
    })
  },
  methods: {
    Toutiao,
  },
}
</script>

<style lang="scss" scoped></style>
