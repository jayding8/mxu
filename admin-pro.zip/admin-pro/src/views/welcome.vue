<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col :span="19">
        <div class="col">
          <div class="shopinfo">
            <div class="head">
              <div class="logo">
                <h1 class="title">欢迎登录系统</h1>
                <p class="goal">一个能够升起月亮的身体，必然驮住了无数次日落</p>
              </div>
              <p class="date">上次登录：{{ lastLoginInfo }}</p>
            </div>
            <div class="detail noNotice">
              <el-row align="middle" class="top" justify="center" type="flex">
                <el-col :span="6">
                  <div class="avator">
                    <img alt="avator" class="img" height="72" :src="avatorSrc" width="72" />
                    <p class="menu">合作版本</p>
                  </div>
                </el-col>
                <el-col class="flex1" :span="18">
                  <p class="shop-name">头号美妆</p>
                  <p class="date">到期时间：{{ expireDate }}</p>
                  <div class="channel flex-center">
                    <vab-icon class="icon" icon="mini-program-fill" />
                    <vab-icon class="icon" icon="wechat-2-fill" />
                    <vab-icon class="icon" icon="qq-fill" />
                    <vab-icon class="icon" icon="alipay-fill" />
                    <vab-icon class="icon" icon="html5-fill" />
                    <vab-icon class="icon" icon="baidu-fill" />
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>

          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                实时收入概况
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="dataItems">
                <el-col v-for="(item, index) in dataItems" :key="item + index" class="grid" :span="8">
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                      <p class="yesterday">昨日</p>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                      <p class="p2">{{ item.yesterday }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>

        <div class="col" style="margin-top: 20px">
          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                常用入口
                <!-- <span>更新于 {{ updateTimestamp }}</span> -->
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="datarightItems">
                <el-col class="grid card" :span="4">
                  <!-- <el-card class="data-block-item" shadow="hover"> -->

                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAABwlBMVEUAAAD/lxj/lxn/nB//fQH/pif/ixD/pSf/kRP/ry//fQL/ry//lxn/lxn/fQH/ry//lxn/lxn/lhn/sDD/fAH/mh3/kRT/ry3/nB7/fQL/lhj/sDD/ry//mx3/kxX/fQP/rzD/fAL/sC//fgL/iAn/lBb/iw7/nR7/iQz/khT/hwr/kBL/mxz/pyf/pCT/nyD/lxn/hQj/lhj/qSn/oCH/jRD/oiP/mRv/gQX/qyv/pSb/gwf/jhH/fwP/ri7/rS3/fQH/9en/5sr/48P/8uT/6tL/8eL/8+b/+O//9Of/797/7dj/+fH/9+3/4L//3LP/587/5cb/7Nb/6dD///7/+vP/37z/16r/8OD//fn/+/b/9uz/9ur/5cj/5sz/1ab/+/T/7tv/6tT//vv/1KT/4sD/3rn/3Lb/48X/4sH/2az/xIH/3rf/0Jv/yo3/vnX/2rD/16f/0Z7/2rL/2a7/06H/zJL/wXz/z5r/zZb/6c7/yon/xYT/t3D/z5D/xH//7dr/6Mz/pz//vnv/uXT/yo7/4bz/1Zv/0ZT/yIX/vHj/tmv/7NT/1Jf/zYz/2J7/5cX/u3D/oTT/xoj/r0r/sFPjC/QIAAAAJXRSTlMA4moY4CYkD/rx8eLc0czKxpZ2cnLx8fj4+PHZubm5uZaWZ2cPgnbU7AAACk1JREFUaN6Mle1qwkAQRdc0jRI0qFiphVbE+hGTHxoQAyr4/k/V3cnGw7pZ6H2Ac+/emUyUQsl6tczidHEX1aKr6NTocDoY7a22Vmetm1YxGMx7o59JlMBEv7P4YXR/3DHQEvy1wQf4YnC+FVZ5ng+n/Vf+LH1YuflrXmDg8Ld7N39xg681jxz8WwbdzU8/Fn+AT3wj8EabzfgNfhK3ePL7A2hEPSLqaWTxRr33Z37Dp3/BY8B4wdN/g2/jwxeH9g0ZeOH7CwS+EXjqIb41qKqxnS98rx/qwQH+c8DEx6DSimQ/0874tRM/uJ7B+GLw1ecBjgHbKWJ/gnwMwFfHaqoNYuhO/535MRA6/Xj9G/7xOFQqcfJ39MMH4OQXefnpR/ONErUmf818w58vdD5fpkt+axCplQxY8KH1xMDybUH0Uwg+d/Ciy0QtvfWs/XrA0/9r/fQD/nL5VhkFcX3Y//D6s5/+fHEYqZj4fj9Ml/4Nn/45bh14rZ5Kvf0Pf75ct3MoP3jDL8sPtSA//dA/55P44HM7APKLhN4YfKra5YfnGz5v8Mlv+eVOOeOVB1AP+XlAYLzUX7X1lyL1xIsD8f95fsCLA/FL66DqVqH15O8o4u9LPSLy8wBj0Hn+iY9BW48YED/v2E/wu516XR/6/6O77HbTBoIozNPksokqRO+hqBeJbCMQViPZVpDBYGzjPyCQRIikpEpJkaDp+/bM2MnINZwofzfn2zM7O7ucBUqrMVIUpdsdOI6qhqmr23bsB9vHzzI+S/ZwF38GlF8nrEOj0RiNRn0CdAEIQ1ePbNv3F4tg9XYh/mSfEWT5uT8BTtXnrJGJCApHSFxXt+z4djEDYX8g91KALxKA/RmQH19ZPxMCts8SADBwklCH/9QHAITx5MABZPrL+sWfAPI6LD4+R40hxFVSMkCi63oOmN0Gq8njR/9I++f9I4DzCuxZhfoAYcC+NeQQSp8AasIJYh+AjeUHYxCkPOIv9uSPBOIu9pDRIg0J0SeA56jcRQwIEiEU2hMSewKcV049DlsCwD7wLqcpAWICKInFVZL6yPGFPQPYHwCZD4XhZpCA4CKhUz0GRNaU2mhTV/IM5eVDH/6coLx+AdQ5w6hBAM9JQwBiABabS1NRkYEJFwIo2rMqxdtLHid1yKgbBmegGnlOSI065QjfLuvvhJL9f4BT462eCwTsA3eqquIwUx/dzq5A6CdCOLa/rGrlxOtHAET4AKR81vxF5yrL4G+YwO4SgKsvADm+Yg+AaZo5YtjCPndpn5M0tawptqFDBJN6iQjF8gugel4FgNunfLmbmqlpGkMM72n7sJ9M5nc6Gkm346l/DcJX2unID5hwrPywF0Dp9l1rLMphPG23D/Cfr3ZJ6PI+33TeCdyth2J/Zu7kXwNAbsfC7bvUhJCtf7V6uXOoV63ITr93sir11QhV2ld5/aXlg0AAsZfHGwHa7TYRNHP78OPXfHX/crejXnVpJoU310zgKm3Gf8sNxOuv1SqnXifLNklj3WP97P+bRhIIEXoJhYp934/pj824BvtSfUiVYgB5e7bbTXyRlqbyZ74av+x2Pwf9Z89Tk8QlRhRFNsuKrNnb8QIBcOqzbxME+sZPbblcmxjfPPYGINBcdXUALMuyAcI/e/EXd+gTAKW3Oasp0ijGeo3BxIOVEZh8LnLougulieoX6iP+AKA+cr7kddXsvQoCQZACY4Muh+cBTT41ASWE8MvxvOS4PQBHP1zngB7ptddrNl+b6+WyXkcIHq2YG8SAEvYfdJ+PFkgA5cfhPzrMbTdtIAzCfqG0VaMqCuLGxcbYGClxSuVgNwJzE6VSpF5Vag4CQUOShoOaPnDnH+/yG6yMzUEJ+mZ21jZ4i5ckSQrshbz6RXlITadyacIw+GsGevj6gF8d+AIXvNINngasp752Aq6oi01cYOGfnZyd/MIlnFdwOKAtCGatzWYDPkU8dvDVwOJpYH6cJ90u8EZweXlJfDms5OpEj8tNa9MSXZ5++zy9MHTskNDFoNGAgU7vzr0Rw0MjeZqISQILevASKDYQ3+Ck97V/1iN8Ojian6KDiPDJaCSP0+9/7nC1eJ79xAl3+/R0c3N9f/+4btFoiumHr04A+QYPg/rNtTUAmYom4M/n8+fZTPjAr1bgL5c/fKoopMutgcaHwcGBU703rd4bdScT0qHRHQwwAPLF4Df4j8vFuoCIx+eq+W09MMAIiNelsaa5uRZ+JEqj6I4FYQAl/5r5F4t1ItHNB2185cNBR1BfOiQdeNluYYD8wn8ln/nXV5OIn0rTtO3RwNAVTwPid9feoGhrkKYXr/P5zBhcsx/Jf+WX/2+nqed5Wg/xalC7t0M9NLDZRJ555itolb9BQZDn+f70kk8DTkB96QfwSPBpSQ7aAsJDwHwfhkEIuTnU63Xk7NX6QQffGlSOH105SUWkg1buoVBLGy+kcteFQdaBqgNoKP/Q2Vsb2FqgWhNWeEC7bujCIw8DNw8BztzczbO8h/RxJ+5XT1/I8g8d7X938aQsWMowVchG5dyyDGjAO3Ec96FqP4qnQbNekDVgMWjGokFm6Aw76RD4cX84sPG1H0gMmk2d3+raCbsBnnQMAHVI6A6esqzTEy40hAaDwfn5ueJBt3gafKrXQwPisQGeMz7QAAMuvUCkG/5YDZRPOfV+qI9pAEn3hPcEbjuBhsO+7IRTQ81v6NaghNeXfqae5SN/xvlkclZDNkT+WBTtxbf8Y8yBtl9dHFhJ+eRnLEcnFNLoY6MF8JTWYw10ehUPgyOf+e3cMr5J32f2Ev6lVNDQAVTiHx4fO7X66QD99RUPWbwIdMWT/0/xIhsfct5cGv5wdH/WdsFnP7Ft37azpY+H6eKA+fXw1wHAQNtXuq497N87vq98ue9cfd7p/Gp+M4Ld/Ionv2ZAPGUN9PJZ5/+vy1x2GwRiKGqIKEFJRB5KUzVpFWXfbtpNNvD/f1UDDidjd65mfcZzxzZgenHpz+whjmY4wASf+dH/+4N/l2AQ/oTZgNExiO6G/cSv6ntZ4g6/RtwBCJ/408cX5QV95HeydPnP6AG+4blfleJd94evy/j9SV5nPP6YPYZ3/uB/pr2BVzVSMLp1k6vov+LTr4s5/Qkf+weD+pVs0j9fcTQTv+1SvPHx/8fwA79r5ZP8AZ/JH/jx6RXjV3XdRXYPPP48lVfAh7c3yovwVSNedZUyHf3H++V6yU+T0WP85o/qJi/hzwJ48p/4aQ+K15W3Z1Qlsjb7daXVG9ube7mK7cfw8M8isic/Y3nl0+cb/JfrDvC7g4jU775+J1G+tB8NP3RP6vfJf1NTi6oM3ef/4U8sX+i0z3AA1XakswH4fPqzgeHZgAO0MmlReP8TOt92sfvjP/bMWi3EVBVxcs4Wxs+83Qb7+5lfyazFVvn4n6PjTmxvuGNqh/hReRwm5+ApX+WbQbTPCe/5urrHAZqDONX7NfGTPfif6274gz3nQw0ZVeXuY1Mc37xBv8H+3P2emlV7ud4qQX/bU/j0eBclQAAAAABJRU5ErkJggg==">
                    <div>订单列表</div>
                  </div>
                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAABTVBMVEUAAAD/Y2P/Y2P/Zmb/XV3/dnb/YWH/YmL/dnb/YmL/W1v/SEj/SEj/SUn/X1//dnb/X1//YGD/X1//R0f/eHj/U1P/ZGT/ZGT/dHT/ZGT/WVn/SUn/dXX/Y2P/XFz/SEj/SUn/dnb/R0f/eHj/aGj/ZWX/b2//WFj/YmL/X1//T0//VVX/amr/bGz/UVH/U1P/TEz/cnL/Wlr/XFz/SUn/5eX/wcH/dXX/4OD/29v/7u7/6en/5+f/ra3/4uL/3d3/2dn/dHT/r6//19f/v7//SEj/8PD/w8P/qan/09P/0dH/1dX/z8//8vL/y8v/6+v/9PT/zc3/+/v/oqL/9vb/ycn/q6v/vLz/+Pj/srL/x8f/tbX/s7P/pqb/paX/ubn//f3/xcX/////t7f/eHj/n5//mJj/lJT/eXn/j4//m5v/fn7/gYH/g4P/ioo38ZQGAAAAJHRSTlMAIxgP4eBs3/Hx8fHi18bAuZZ2cmpnKfz4+Pj40dHRxrmWlnbqv6ZDAAAH6UlEQVRo3q2a7VcSQRSHx9dSy9TS3t9rI3PLrQRK3gQSBCPJdEVUIlRC0///Y/fuzO6dZbicU4dfnlOfnufO3dm745yElqH5Z0+uX5u6v/zx43KQxUX4UXm7+BbzTuUN5tUr+FF5f29y9NHM7PyQ6JGRm9e/QD6qkGCZ8MDHEN9LgIcfLx8+jM6NdPNvToXxFKpfxqdLAfEJj5kcD+GHH3/x+F88ut4gisL7gncG/pWHB4HM9DDxF65JvNEe+OEWwNSvDK8howtB/cjHSHzv/hNeK5/pDwhQMeqvQfaHbz8m1J+g/RSq3uPLTKvnq5dPhkWzPd182kBBg4iPGff255T+AEL1U/T6qf2UEJ4yMYILkHiGzy+gC08CMkRez4FAvl+SbvaH6Ez/qT3GAiKRyBWYD70XQHx6AZj+KHoPPvwMiXkQsHTa/fQA6OkSXeeTADMunhFfS8AnRf8FMPzIrHgC/eEHxFsOT3Qej5kR17n5SXzsP9MgesEYw0NxDdj/Pf/DA8Kge9toagDzX0bDB4aXE+L+YOY/jrcgxH95VywPav4bdM9wWwxq/lM0PEQMcP4TXxf0m/+R887pyfb29tHR0SGk6GUXk8xiarVadne7Y33g6kcBP//fXCC8Fz+ZTCp+7eDgoF5vR3qVLw2Cnf9v2v34hMccRvz5rOOlgO3PxYkUID7Exkg44jGt1inxDQEzHiIevpYv7EN2diqVSrW6ublZKpU2NjbK5Vwul8l8gmQqjVar0XDMx6sE3Pw/R0Gj2US85KNA4iUfBel0PJ5xG41GR73ApoCb/x3gZ5sgoPJV/YQHPgjiGyA4DO0fygvBzf9TEOSxfiqf2oMChce4Dbem8yPEBwEz/0/g6Rb09khB2ag/lUpFXbfRE48Cbv7j9sH+VLT2QwBP/LjHX1lpuq7bu0Eg4OY/bs8diMKHHy/hga8ERCc8Crj5j9sf8Aaf2qPqh+xrK9D4UsDNf09AeNr9YTwmAYK8okcCvC/g5j++v6G3y92lt6voEj+RAEE+b/ZfCbj5j9NH253l5LFz4b9cl7HjBtWfWN3Jg4DwVD8KuPmPAwjx/vbpWJbTzn3CtC3Lakt+Avn9Bdz5vwjxny62vxgDw8VBs1k/dywrlg3KX139VgGB2R4SmMdnEkB/1O5pOxYojo+9vzo6Xwr0FyzI0pLgzv8oADztztwloGVipykN/+0zCKI6nvgvQGAuIBAQ39s9tfOYZdtW7Lwu8UrwWQkoGh8EzPkfvzDdL9enfLHdLkbjWD/iJR8F0Wiv/mAEd/7HD5g+HDYKTTm85fxI+eVD1qtKQPuHFII7/+PnEfGq/px1jPmtcmzHib9ejQaCMB0FzPlfCmg2Fx0rFKcGeMX/igKTrwTc+R/4SW345O2wwK5I/jrwlQDbQ3gVW3Dn/yQK/C8vpNE5hTi27ZxBTqKI9wWbUmAuwIYVcOd/PJ/4fJr9fyzrj3y6hP+6pVag0xXftgV3/keB/ukq56OQc8ta87bTSsDf2trCFYT4vsIGAXf+x9MV4eMZO4Zx4PF6/7Dj3uNF/o8fKND6T3gUcOf/bA0E9G1JWuE4Lb/+H1IQfr5kENz5H0+HWvt3bC/I9v62M7J84O/tocCsX0Zw5/8aRD85VLaLEGwRviHZkt8eQ7AkBX5Bgrv/weOtOvhA/NmJu0g+Xqr/+3cUmBtIrlRw9z94ekY8Cmg2S8G6xkdBCQUK/4LwcgXc/c8BRMdLwYVlnUs+4TWBxFODIIK7/0EBtQfifVuSMeeMds+eLiA+4knA3P+goA58WT/N5mYV8MRH/M+fUgB0gw8C7voEf3kx+Nh+4iv8z1/UInoAFvJRwN3/AL9l4qn9VP8vEBQKzAIswd3/1Fv1elzx1ein3Un1I//XJgqIT3gUcPc/+Ktdul97VPmY/UKh0LX/gwju/gf4rU2JlwvQdyfEw0vBegGi8H7/ScDc/6Cg4cZBQHjiU3sg3yvAj4bfryCO4O5/DlqNRsNNgyCxkoqn05lMuVwqbVarpXImHU8lVj+vb+3tgWUL+QW36/0iAXe/sQt4193PyXmXwj8rQRLeoRd+QF8qYOqI90N4xxHc/c8ZCCAl+Ohg0hA1mjAkSxe8HAUL0MtHAXf/c1lHfj5fzfTl5yTfbQfttwmPEdz9j7XbAjwk2tz3sxOkIrNTkMnXfiu8Hilg7/87yVY+lKiRgopbOw3mP+FlBHv/HznZzdZdjZ83+GiI5t2D7JFFj9cQsPf/kY683OpO1sipZeJJ0Of+37k8OyyigVcki9vt37aKgUdBv/t/5npAxRyfJKCI/vf/fjQ+Gcz5by5gTfD3/0z9/7KANRDck4K+fDLw/BCdDHfE5L/gSbDEzP9wf9bWropR6s8/NYiZ/0gnfmxtTDyi7cnQmf3DzH9dAIYHYqbv/T8ZjPM/M//D/NgNMdv//j/CbU9m/hMd8JCnYr7//T8lTCcDU74jDbfEUN/7f75+mv9c+70MCXGFv//XBcz5X49evuKPCSHm/uv9ZeY/bVBpeA6CkUl9f7LvL3f+7yWQeMjVEQEZ1/ivebx5/uffX8nHR+xlWueTgNLNZ+c/hvDwEsgMjw5w/jvEHxsWKgujg5v//vM9jo0tiCDD0wOb/xDVH6yfMj4xkPkf4K/eMv7zzNyVAcx/JRh7PiJ6ZGh8dubhlYm7t/97/t+5OvbgxtNbQ4LyF8fu9bKCZ4ZqAAAAAElFTkSuQmCC">
                    <div>售后订单</div>
                  </div>
                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAPKADAAQAAAABAAAAPAAAAACL3+lcAAAEF0lEQVRoBe2bz0sWQRjHvzO7vmmEFFJBBxHUkqLAo8eKgiCDfthf4CFv/bAOdikoT1JdoktQd3svFgQJQaeOQWYXlcKDUKJGFJq+u9M8U+86vr27q+++M2+u+xx0fjwzz3yeZ3Zm33nfYSiRX+fPH/KE6BWCnWQMzUKIHSUq/3WWMfZDCEwzJl45jD3els+P6wNmxYzo6ckt+v49CPRJSF4s38z/JbwPhkcNnF9lw8PLxKKAFaznvZSeObaZAcPGLmfq6wbHOUXQKpIU2bTCkhOITc1emWZ/nlm8T8s0Do8y8x2GI+6fBQqpeGbDYKmcAuoBvZxW4yjFNNURK6etJ01QUSzEKiO8ufbZKKC4OmJN/bNb6oQtB+yWesBonnPwtlawPXuVGfH1C/zJKcD3jZrVO7cDnMvB7e5GXfdpsMZG3T7E9+9Yef4ChZERYGVlTZ2JDPt59pww0XHQ566dqB8YAG9tDYrKJfypKSwNDgIL38pVV63MLLCMbP3dOwGsXCXhv3sHf2JCAfD2dvDOTsiXfJVX0AM3jUba6JSmaVyMrD83h+X7D+B//LgmWvzgQeSuXAZvalK67pkzKOTza3SqmTG3SssFip5ZEopsOViqIwdQHemQqDayrSkx1rNajf8uUGoal0RWByJo0iGhRY3amhJjwMWthwZefGajIHQdvW1Um0rqzAE3NATjEfMLQTosoeswrW2YfqXlxoArHZDpdom3JSZX11x/P3h7G5ihxUbINzF/YhLLQ0MQcrVPIokjXHexB86B/cZgCY4cSTbIVlJJvA9ThIvif/4MePJcgYRW2927VdKfnQXkK2SkhOk7DnhLi2qq24rsK6IyMbDe99Kt2wGYe+IEcn2XVHXhWR6F0VFd9Z90qL50xPanT/7Rr7Qg8ZSu1HCt2hkD9iYnAyY9HRSWJHQdPV2iljhb1Smtj0Z8+oTFa/2qiNJxslH9uP7C6o0Bk8H1gOoD26i+3na9aWNTer0DsK2XAdv2uG17WYRte9y2vSzCtj1u214WYdset20vi7Btj9u2l0V4ox4XC6snkk5Hx0abx+rrfYr5+Vj9OIXEn5a8D+Nwjx9XdnI3rkNMT68e88RZj6uXxzusefUXGd742q9p4pqXq08O/OYNvGNH4Rw+rA7b2N/zp3LGkpR5Y2PwpK2kkviYVg3AdVHXcwFOVxfYvn1VO8Gk41kxMwPv7VusDD8DCoWkvKgOcOJh2OsgW6Xt+bo2lrII18bv9qxmEbbn69pYkj8uZT9qY9q+VWKVPy6FfBfcGkKsMsLi1dbAld8zS1ZOV13U7Y+UUxMjsXJ1r0dedUk5rwwvHhGr2pbUvR551SWt0Ooaj7y7RHwKmO7zqHs9nD1M0/QmFiaZineWCJjRH13SfhXvN5I3bTFAf5P9AAAAAElFTkSuQmCC">
                    <div>添加商品</div>
                  </div>
                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAB9VBMVEUAAAAAk/8AgP8Ab/8Ajf8Aif8AnP8AcP8ApP8ApP8Aiv8Apf8Aiv8Aiv8Aiv8Aiv8AoP8AgP8Ahf8Aj/8AiP8Ah/8Ao/8Aov8AkP8ApP8Abv8Ao/8Acf8Ajv8Ahv8Ab/8Abf8AcP8ApP8Ab/8Apf8Abv8Ap/8Ab/8Apv8Ab/8Agv8Akf8Aff8AgP8Ah/8Aif8Ahf8AkP8AhP8Agf8Akv8AlP8Aev8AjP8Ajf8Alv8AeP8Amv8Adv8AnP8Acv8AdP8Aof8Anv8Aj/8AmP8Amf8Ab/8Ao//U8P/h9P/w+v/y+//t+f/r+P/p+P/P7v+q2v/n9//R7/+q3P+n2v/l9v/j9f/W8f/0+//L7f/E5f+k2P/3/P+84/+g2P/2/P/J7P/H6P+i2P/v+f/Y8f/N7f/6/v/4/f/B5v/B4/+54v+o2//T7/+33/+k2v+Iy/+03v+g1f+GyP89pf/I6/+14v+Kzf+d1f+Y0/9HsP+74f9muv9it/9Hrv9BqP/8//++5f+Q0P9Hsv9Csv86of8mmv++4/+b1f8mlv8Fif/k9v+q3v+Mz/9mwf9qvP8el/8ekv8Pjf/b8v+w3v+Axv9vwP8vpf8VkP/E5/+s2v97xf9Tsf86q/8iov8pnP8VmP+04P91wf9ctP9Iqv8SlP9Otv9Prv8ZnP9ZKr7WAAAALHRSTlMADyPg8eIm+uLXxsCWdm5nGBjx4Ny5/Pj48fHw8NHR0ca5lpZ2dm5uZ2fjuVYVfrAAAAlVSURBVGjejJWLasJAFERXoxXEB4pCEVsrIsWiMSRgJIiC4P//Unevlx3W2aU9H3DmdnYajQHt3Wa9ypa93uPquQmXJ82lcZyE/WnvOQhVVU1/PueDcdtEaG2zh5LSW+AP9eIXyqosy9mw9er/Xnj9w+tdACICP1+vAVUpTEeBfvJFegfkFtUrXq8B6i+Voij6E/jb0g71o4id7qf6RV+JvSwc3Td/P/yx+hGQ7McHQJ/bhIkGxPq5oR+qH/0oQT2Fkud5X98X/dDzhv4m0g/8mqB6YST7XHg7IL0F57MdevgtHbfWbaQfJVY/7QcBOF85Hoc2IFM/1/ME7cCfeF59X/iPMzvR1H70fp5nuh/1F2K3fkvb7KCHnT4+AuzwCzQfSRDGZvMyn6u/H/5G9PwHQJ/y1wOzjtUTq5/16AfrCfV1PTcrng/WkyqIvz6oH/3Xlg+TwY91OtRO+qe/4vrhd2hA1yyvcX/yfuyT9IG/FjqmR/NP3Y/zsU4l8rrC+fwuAfy+6d/GdD9Uj0u4G9gF0lM9/LzavhDqLQb1pP57AenxdSjIjwAL9PD/uX4JiNXvH0AD4OcAPv9AHx/4cw2A/343/zxf1//Ld/m1phEFUdyPZFKLto++bJ4qq7iIdFmDQqFicHepgWiIoGSFoqvYP1pqSdIvmjNzsztMlpuT4IvwO3PPjLN3k8UiOScHjS+OZ63KfDRZ4i+29xU+PX4O4ji426d6/eh8BA8+TlCYTutynsZBHARBpxPENwov6ah4QK+faQO1PF/z9xkfGoTSXj0+ig+DMzYQun07TAHP8IPBp5tztXz0+MgBYCB8Ox5K46DDeMBJg1Tlw/g8HqkfBmivHS8Ge0MHnuW6ocKrfATPBjr+j5btc2eKpz+X+O5v2Q4Fft301xio4bE+2xPgkQsXT3IcZ1kWusJDwL+oUmI8/rl863ZYMPuFPxw6Q8eJVP2F8akzvgIDkn35sGBAaMAzuuN5kdA1Pq+/wgbFm61ItlviZnimg+8tZXyqur+ST8HA/mzsEd0FnfhQP17J+Kj4axwP442Brb362RiCzniP8X0vtPx6Bc8O70v26efqk6fbX7Q8U1eK7/d3nrsh+P/b2Un4Ej/nz/xK6c2bc7ofj8f+dIXVtgae6cx31qi/Np34vr/f5PFQOnXBkwGdQJazyNS/mIz9S2i+hcMVDAy+7znfqPzvPunSj4xDnSTtZTwMbA8vaHs9Br0LPdB2Xrt8CHy4a8r/AXTyH93/U91lvBjYpge9nYLOarWiMrQJew7UCzn/n0QfdUfQWk+n4MlA+IUX3znDWT/KrNUyipYrMz6wZzq+vdbzY8bHGHwovfFal+MbjSvenWq7HbujLuhfSZy/qh58MeCbv/DFwNDBhwHzt6coOm3N+B9bI0NvNlu1nC8Whs8Gtve6eQN4oz/grx67uwto13qsQrMm00lz4AvxMx4G9qvbu4TZh8OhMcEBnr5cGLXb7d4MDvfNTH8lIMVng2c6zG2nbSAIw34iigQoIMQFWksNBASC0AjiIEhFIBWKEyAxZ8KxpQeEooS2hEIPwHN2/tm1R/bCJ275/tnxeL1Ze2+To9WeqX+WNrbfWg4u57LZn6nU2azx7yVeX6PnACUBMj1ydjtdgL9509tbYz/bL7Ogkhr814R+oRvqrfqBEzv5g/jJ/NftE+l7/oTVZ5lpYo9m8/72tmPaYz1doJRy5PmK3Toa3rxPm94Y++T0ZPrefr1YLwFqSLmO8cf7L/qPVwiosTyyg4mJOvTPd2IHcT3hJMZT9PR3vTvVwpfx0zvyz0EPWE+ksXV2Wh/a9/2Jt1cDv8srEH38h8tZ1fdb1xSwkY3bQSaTOcDeMPOwNdNNlC96BMj4J9p/2vJ9v9pDtG09UWyj/8EW0dXlJwJc5Q4PO7Bbevhvpnx/fb2OrafGciayF8fGKuh+s0y0nmX6jZ3rH3YRwHp7er6tgxpWEET6TKQnLhBQQYDXToznkPZjBbFLtz7x9/yAv1zD3hmwnNywjxW1fnw8DPA87yHZHvYDx15ALyeckb1c3qm9IS5M44GxAwT0VzzmTvwq8kvAC9cap+UdUEFAg4snIA/1ucULTGfd847Oj466sBtgDwNGHHs8NRtkp8oQkGqwvojuaH2O9LnFBqa/TvbV1dUT8sv0KOjZTwHcH/tWacMD53oFXLyRww/9Yr6B2a+THgFD0h/RI6DPkLyWOSD7+dpaBUe3Knfe+Emeg75kAqCfn9crUFgAT49JQIC2W7/bD6CngBRRFTu52V7K50sIGPgC/fz3E5lOV/QIsPTwI2CNqXNA1HmuPZ8n/crKSoEDoEeAjKf4ZQX2z2oE0P/qgLB4baf6S+Q/LNDLhYAlAgGwq+jpRgEyPaJHANnDgGVTfB5+2KE/PCwMIAB6BCgQtd/4R0dpBWy3rgV0wBICBpd1a8RO/ljA5iYFuNJ/2Fk/QgHSf/ETf33wEODeIUhbzNFfgIBgi3lUifHkAMJ5of0c8ERfe/qkVweJ4O2LNBFQ+Mw8ytOV+jngtVvJq11mHyfzzj6xvb8dcqzpYHs4/srcxccffp3gRHpjt65lgHUyj33agavEbvTM/77MZTdhGIiiEwQRIbxUWihC7QIhhFSpq1bddhHl2/rZjceEQ3Id7gecGd8ZO2Pn13r9w8URPpOzjg6uBo8/4AO/CRDp8FP3Xu51yvf8pbxODzJ9tYIf5elHRf6X01u+p6/+tCHsM9LB67MJ9utoyO4i/db+oK398csCe/An1Pcxv2J7QQ98186e9FkGPOWF3sF3/Mcfx7sONhE+3eN8sT/4Dx/7ZQFBU3sHL/707NfR0PGV49V+V2EvBOi1j+KVT/4dPCptLvgfXk3wR6pL+tKdhKjro614cpb66ukwNDt0txf8+mIj8mcB2N/I6Yn8h8oLvlFu9iz2J59lhN8IvNpfe4TCzBbwac/oP/zuZJvufg9AiDroZGbZ+GZP53DW05PZivR7pyd41z6zRktfAHT8193L7MACkgZFnc01w5/hdxn80dNNyxtVWtR6ot0JHnewh+yT9lwjTNd2Vb7R7Tv0canS3U954ed203oW8WQv99L06En24n8Z8kfLceQT4t6fbybn/rdL29O1P1tP2WLz0H7HByXskfSLU2YJjVbzj7fN+FW+XanjIWXQdneYFuXxkhv6B3LzWGS2bJyKAAAAAElFTkSuQmCC">
                    <div>视频号</div>
                  </div>
                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAB9VBMVEUAAAAAk/8AgP8Ab/8Ajf8Aif8AnP8AcP8ApP8ApP8Aiv8Apf8Aiv8Aiv8Aiv8Aiv8AoP8AgP8Ahf8Aj/8AiP8Ah/8Ao/8Aov8AkP8ApP8Abv8Ao/8Acf8Ajv8Ahv8Ab/8Abf8AcP8ApP8Ab/8Apf8Abv8Ap/8Ab/8Apv8Ab/8Agv8Akf8Aff8AgP8Ah/8Aif8Ahf8AkP8AhP8Agf8Akv8AlP8Aev8AjP8Ajf8Alv8AeP8Amv8Adv8AnP8Acv8AdP8Aof8Anv8Aj/8AmP8Amf8Ab/8Ao//U8P/h9P/w+v/y+//t+f/r+P/p+P/P7v+q2v/n9//R7/+q3P+n2v/l9v/j9f/W8f/0+//L7f/E5f+k2P/3/P+84/+g2P/2/P/J7P/H6P+i2P/v+f/Y8f/N7f/6/v/4/f/B5v/B4/+54v+o2//T7/+33/+k2v+Iy/+03v+g1f+GyP89pf/I6/+14v+Kzf+d1f+Y0/9HsP+74f9muv9it/9Hrv9BqP/8//++5f+Q0P9Hsv9Csv86of8mmv++4/+b1f8mlv8Fif/k9v+q3v+Mz/9mwf9qvP8el/8ekv8Pjf/b8v+w3v+Axv9vwP8vpf8VkP/E5/+s2v97xf9Tsf86q/8iov8pnP8VmP+04P91wf9ctP9Iqv8SlP9Otv9Prv8ZnP9ZKr7WAAAALHRSTlMADyPg8eIm+uLXxsCWdm5nGBjx4Ny5/Pj48fHw8NHR0ca5lpZ2dm5uZ2fjuVYVfrAAAAlVSURBVGjejJWLasJAFERXoxXEB4pCEVsrIsWiMSRgJIiC4P//Unevlx3W2aU9H3DmdnYajQHt3Wa9ypa93uPquQmXJ82lcZyE/WnvOQhVVU1/PueDcdtEaG2zh5LSW+AP9eIXyqosy9mw9er/Xnj9w+tdACICP1+vAVUpTEeBfvJFegfkFtUrXq8B6i+Voij6E/jb0g71o4id7qf6RV+JvSwc3Td/P/yx+hGQ7McHQJ/bhIkGxPq5oR+qH/0oQT2Fkud5X98X/dDzhv4m0g/8mqB6YST7XHg7IL0F57MdevgtHbfWbaQfJVY/7QcBOF85Hoc2IFM/1/ME7cCfeF59X/iPMzvR1H70fp5nuh/1F2K3fkvb7KCHnT4+AuzwCzQfSRDGZvMyn6u/H/5G9PwHQJ/y1wOzjtUTq5/16AfrCfV1PTcrng/WkyqIvz6oH/3Xlg+TwY91OtRO+qe/4vrhd2hA1yyvcX/yfuyT9IG/FjqmR/NP3Y/zsU4l8rrC+fwuAfy+6d/GdD9Uj0u4G9gF0lM9/LzavhDqLQb1pP57AenxdSjIjwAL9PD/uX4JiNXvH0AD4OcAPv9AHx/4cw2A/343/zxf1//Ld/m1phEFUdyPZFKLto++bJ4qq7iIdFmDQqFicHepgWiIoGSFoqvYP1pqSdIvmjNzsztMlpuT4IvwO3PPjLN3k8UiOScHjS+OZ63KfDRZ4i+29xU+PX4O4ji426d6/eh8BA8+TlCYTutynsZBHARBpxPENwov6ah4QK+faQO1PF/z9xkfGoTSXj0+ig+DMzYQun07TAHP8IPBp5tztXz0+MgBYCB8Ox5K46DDeMBJg1Tlw/g8HqkfBmivHS8Ge0MHnuW6ocKrfATPBjr+j5btc2eKpz+X+O5v2Q4Fft301xio4bE+2xPgkQsXT3IcZ1kWusJDwL+oUmI8/rl863ZYMPuFPxw6Q8eJVP2F8akzvgIDkn35sGBAaMAzuuN5kdA1Pq+/wgbFm61ItlviZnimg+8tZXyqur+ST8HA/mzsEd0FnfhQP17J+Kj4axwP442Brb362RiCzniP8X0vtPx6Bc8O70v26efqk6fbX7Q8U1eK7/d3nrsh+P/b2Un4Ej/nz/xK6c2bc7ofj8f+dIXVtgae6cx31qi/Np34vr/f5PFQOnXBkwGdQJazyNS/mIz9S2i+hcMVDAy+7znfqPzvPunSj4xDnSTtZTwMbA8vaHs9Br0LPdB2Xrt8CHy4a8r/AXTyH93/U91lvBjYpge9nYLOarWiMrQJew7UCzn/n0QfdUfQWk+n4MlA+IUX3znDWT/KrNUyipYrMz6wZzq+vdbzY8bHGHwovfFal+MbjSvenWq7HbujLuhfSZy/qh58MeCbv/DFwNDBhwHzt6coOm3N+B9bI0NvNlu1nC8Whs8Gtve6eQN4oz/grx67uwto13qsQrMm00lz4AvxMx4G9qvbu4TZh8OhMcEBnr5cGLXb7d4MDvfNTH8lIMVng2c6zG2nbSAIw34iigQoIMQFWksNBASC0AjiIEhFIBWKEyAxZ8KxpQeEooS2hEIPwHN2/tm1R/bCJ275/tnxeL1Ze2+To9WeqX+WNrbfWg4u57LZn6nU2azx7yVeX6PnACUBMj1ydjtdgL9509tbYz/bL7Ogkhr814R+oRvqrfqBEzv5g/jJ/NftE+l7/oTVZ5lpYo9m8/72tmPaYz1doJRy5PmK3Toa3rxPm94Y++T0ZPrefr1YLwFqSLmO8cf7L/qPVwiosTyyg4mJOvTPd2IHcT3hJMZT9PR3vTvVwpfx0zvyz0EPWE+ksXV2Wh/a9/2Jt1cDv8srEH38h8tZ1fdb1xSwkY3bQSaTOcDeMPOwNdNNlC96BMj4J9p/2vJ9v9pDtG09UWyj/8EW0dXlJwJc5Q4PO7Bbevhvpnx/fb2OrafGciayF8fGKuh+s0y0nmX6jZ3rH3YRwHp7er6tgxpWEET6TKQnLhBQQYDXToznkPZjBbFLtz7x9/yAv1zD3hmwnNywjxW1fnw8DPA87yHZHvYDx15ALyeckb1c3qm9IS5M44GxAwT0VzzmTvwq8kvAC9cap+UdUEFAg4snIA/1ucULTGfd847Oj466sBtgDwNGHHs8NRtkp8oQkGqwvojuaH2O9LnFBqa/TvbV1dUT8sv0KOjZTwHcH/tWacMD53oFXLyRww/9Yr6B2a+THgFD0h/RI6DPkLyWOSD7+dpaBUe3Knfe+Emeg75kAqCfn9crUFgAT49JQIC2W7/bD6CngBRRFTu52V7K50sIGPgC/fz3E5lOV/QIsPTwI2CNqXNA1HmuPZ8n/crKSoEDoEeAjKf4ZQX2z2oE0P/qgLB4baf6S+Q/LNDLhYAlAgGwq+jpRgEyPaJHANnDgGVTfB5+2KE/PCwMIAB6BCgQtd/4R0dpBWy3rgV0wBICBpd1a8RO/ljA5iYFuNJ/2Fk/QgHSf/ETf33wEODeIUhbzNFfgIBgi3lUifHkAMJ5of0c8ERfe/qkVweJ4O2LNBFQ+Mw8ytOV+jngtVvJq11mHyfzzj6xvb8dcqzpYHs4/srcxccffp3gRHpjt65lgHUyj33agavEbvTM/77MZTdhGIiiEwQRIbxUWihC7QIhhFSpq1bddhHl2/rZjceEQ3Id7gecGd8ZO2Pn13r9w8URPpOzjg6uBo8/4AO/CRDp8FP3Xu51yvf8pbxODzJ9tYIf5elHRf6X01u+p6/+tCHsM9LB67MJ9utoyO4i/db+oK398csCe/An1Pcxv2J7QQ98186e9FkGPOWF3sF3/Mcfx7sONhE+3eN8sT/4Dx/7ZQFBU3sHL/707NfR0PGV49V+V2EvBOi1j+KVT/4dPCptLvgfXk3wR6pL+tKdhKjro614cpb66ukwNDt0txf8+mIj8mcB2N/I6Yn8h8oLvlFu9iz2J59lhN8IvNpfe4TCzBbwac/oP/zuZJvufg9AiDroZGbZ+GZP53DW05PZivR7pyd41z6zRktfAHT8193L7MACkgZFnc01w5/hdxn80dNNyxtVWtR6ot0JHnewh+yT9lwjTNd2Vb7R7Tv0canS3U954ed203oW8WQv99L06En24n8Z8kfLceQT4t6fbybn/rdL29O1P1tP2WLz0H7HByXskfSLU2YJjVbzj7fN+FW+XanjIWXQdneYFuXxkhv6B3LzWGS2bJyKAAAAAElFTkSuQmCC">
                    <div>会员管理</div>
                  </div>
                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAABblBMVEUAAAD/lhj/lhn/nB//niH/ry//pif/ixD/ri7/fQL/fgH/fQH/lxn/ry//lxn/lxn/lxn/sDD/fQH/lxn/lxr/mh3/kRT/fwP/kRT/fQL/ry//ri//nB3/fAD/ry//fQP/rzD/fAL/rzD/fAH/iQz/jA//mBn/kxX/pSX/mhv/oyP/kRP/hwr/nR7/jRD/lhj/pyf/hQj/oSL/lBb/nyD/qir/jxL/mx3/gwf/nh//qCn/gAT/gQX/ri3/rCz/fQH/69T/fgL/5sn/7Nb/6Mv/5cX/6M3/79z/7dj/37j/8N7/6tH/+fL/6c//7tr/9+3/48T/8eD/4sH/27D/5cf/8+X/+/b/37T/9ur//Pn/8uL/+PD/3bT/2q3/3bb/2Kr/9Of/4bz/3LP/4b7/ry//4Lv/47//37r/27H/2aX/05f/1qT/58b/6Mj/5MH/1qf//vz/1Jv/ri//lyT/0ZD/xof/xH3/wnr/tU//rk1NxX+XAAAAJHRSTlMA4HIYD+AmJPrx4tfRzMa5lmpqZ/Tx8fz4+PHw48a5uZaWdnYJZ2U9AAAIy0lEQVRo3o2Zd0MTQRDFNwjYe+8dREVUwIKiGAgQNEoQURFDJyiKRqzf3nk7c5ndmxz6PPnz92bfzpa7uEBbD5w/u3PH9uNHnzzweki653WLdf3WdeiS6jLrhteda8eO5Hbt3Xdwq2ug5os7H0NPnhBe+JDH32O84Qte+HfuXPNqb881Naf5B7YTXBzEwtN5CFw/y+AvM53wMBCLI00RfstppUcDCPIRvBlAUr4OgLVnSxD+jgQPB09vMAEspZsBiEDvpifXWq9f+J5O/NhApzedj5Z/g/Ds0A4+DLq7u3PJGE4LPog/Vb/iU/ULXvMXPtTVtUfmN+DH8Ws8ojpeDbR/gvw9n9Tk+3N7w/K9gUnfBCTTa8v3BofQrReDCWAxHnyR9o/i1SCYXhHwUJsfwk6h23wyusfmL9J4hN/WlqMWlfIfZOVjFoDgtX5tH5Lm0wZtxRTb+r027X7ma/6mfjE46M4bfoC37aMWGXzFQx373FnTng9tPGYAmr8tv1vxbR173c50/sD/a3uwyzdjAB273A5tz4zlaxrILN8sPOmU2678uH1s/iLd/i2f20f40GF3XOjpfK5n5WPwQm8HnhUYHHJH7fL69/Zp25/5Qhc+1OlM/Hw8Jspavtnt2cV00V3Huz/h6dlk9WZsb1p+Fz1B+W2e3nFXDKD/ak/l2/aU+qGkfJKLAjK7Z9b2A2X3J9PB7+x0ZnlltefGj9Xx8fECNPNjIzgdDV4EvhjY24k9HzcqgEOTpCocxAD4qIGUDwPtz81Plx/MhvKT+fwPnd7sfMTgXrS+suZ3gciM9ypKQLr7d5l82CB1O7TpyOwqfCg/RI8OQPmkhJ4Y3HfAQ2E+jfYfgjMe/KHhYV2+Nh9YdDKfDJSejScxHWyWNtAmeBhE/KyASD6aYcGXSiWJx+YPvBgQnwx0f2C6Kjp9EzTBoadh+SKNX/CkHmfqz9g+uXChk9qVb9qfBXwPGcSXz+t1+iWPr5/uw4wmODQwYLqf6R3IR/Lv8QZZ21v68p/ABwgO8QC0fJbGIwO47TLj2fi1trCwuvpSpHCvQdDtAHiCJX4vl3V53pitVGYChzp7kB5ShBeDsPweHgBGcL3h7f9nsUJaqFsI3Wt0cHQ0yse2Zw/j1cC0/2y1KBar3oLxTIe4/dP7g/YP+HBwWXfb+WqVLWYoKHJgOOv56PPnqc2Z20fwwoeukkHj02txcZkcSHAgiwDvVa9f8JCWL/XDIGt5TSwuzpMFPPwoAvYIlJ5eXV/C5wGQgTlexGDCWyx7B7JI4IwfG4vixwRr/UFAZJC1vMbJYcVbLBerZBHCoTXWF9Js7Vcf83l5KZ4NLlk+DMbZYp6CgoXABV8uK570fq1P+wcCnh2cyUd2z3E4qEW1Di+zGD/r8aSfitf8Idfo5Q6aLBRkEBOwWA7g0+Xp6ekI//Llmiyv+4SXgIxBvLvlJ2FB4tmeV7jXK8mG8aurC7J9ErwnwF+5EhiwGE8GpIJYwMPTRa9Iggd/dWFhZobqDwMSPgxs/bC4Rod7PhxFmdGiuVdaPeFJjCcFeGMQvpsOwwEWk+xAcOCFPzc3W8eD//q1bm/giwMbKD58eSmVhkg6CiHjP/QGdOLPEL5SeV0s2vpZjvH25e4pHZDDPAzvwPQ5ps+9ecNT6/EVWuxVT+f+D/g3bzruT/tuRwdYaRgWklPCTkR4ZEPFA7+8rOVL/myAEaQ+nYjBwIC3ILGFVM568eIF4yseX12en0/Kvy14HUHjT2/tA6TQ4k1Cf8ECvggRnfgr8fwmeDYgvH35Ghz0DiVYYCo8G3gRNU5S/PziysqKxu/xaqDxxO/uo4NkAQ+ZbaBF76AKRw888dfXuXrDZwNPD/OBwahaYLYTOOGhZ8XichXZLBJ/fYIMoGB+bzK/zzHfftqj/Z8teCpKCn/27hk9dE744kmELxQCuvDFQPHKh0ZGYDFYtwjhEPFRPNIBv5AOSPhkYPD86XZkDBaj9VEQnB4V4yeoeno5/PSpIPQUngyyvs0Mjo1FgwjoU8+mpqaITvgJooP/eV35mj8bQCk8rubr5TFYjPhBkBTOquM/Ef7z54Vw+YrA73W6fL2YT8/76bJaiMGU6O3U27cT64QnOvi0K9aAN/zeXjKI+lNEN/OPeXJgC99QU3U6C9Ejm09DUPG75qPViwFkP+39+TAwnQwCHkr3+ur5n0ngr9R+C1/LhwMMaACSf3v8aaP2If9qWj2YznBI6cOl4seGA/By9tOwvLvfnf3wMj9aLouF0lng+3QKxbWPtb6rEf4m4ekRA8VrQFBn7UOg1yl9DPS9z+SD/I2B4PXl8U9tdvZfBrXa93r+VwID1qNHLqHLTy9C18s5i++25nJuVi/Tld9LBulfXhSvl/Pw8mwvb8npqOUrXwx0etlA+PGnH3P7bLS5RXzISfk6vfblSw00Hz29rtr1FfD7XTs5hP0JZb7a2dtzo/xFwD/a5o4pXr/Mm28zyhe6OX3N/PIAtrkjpj27Up8GTD6b4vtCfH//SZcz8ZiAYr7eHrR9Usv3keRPanG7onxS3d+hdJLGH+KZ3xctX4/3BrvdXs0njffyeHoM3ixfUhS/1xm3TwKy+TBd49F8otuhwdOT4JeWzrmDWr8ZgL6b2uVlTy9b/7f+pf1uq/1lQV+tWXH8t8N4NH/dfhL8Uv/St/5W53ISf8an4frLHT1avrk9mPLZosU51yT9mb07cD62PTOWV7/ks0QGF8ig+VB3jBcDwdNjXr7s7t/AAPwTzQ5DsOXr/NrlZbonFZCkQyP4RlPstUenNz5ewvLN+ZK1vTGe/mGVsbbkQn6wfUb5sxpermz+voNatjhRa47olk8KTse4ftv+vWE+sGhpdXVt2WP7h+PR+u3yirqnNykfcFL/btSvajrMfMXHy/d2yJflJdunl9ZPcPp7Yr9LqbkpZ79MQhmHO+Oj/CUfelouNLsGaj24b++uU4fvs4MuX23/rICkf7ZtO9my+8y5/a1O9Rd3LmggWKunjwAAAABJRU5ErkJggg==">
                    <div>会员数据</div>
                  </div>
                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAPKADAAQAAAABAAAAPAAAAACL3+lcAAADLElEQVRoBe2bMWsUQRTH34xngmByoARFJAQFuXgSsFELIypiIikUwcY2NsFOLMQPYBUsAjGN+QQptDAYg0TBFCpW4hkRhJBClEPhTECicdf5j+yxrrd32dm9mbtxprnZnZ35v997s29gucco0g7ODRX9DbpCjJ0l3+/1ibZHHmnpS0a0JmxfEbbPsxzdfTv8qBQ2WIz/acXSpQ5vefW279MYkc+D++39yzzGaIr3dV0rFWd+gEUCA/bX8upD4ZXT7Q0YYz1jC1v6us4BWkYSkbUWFj4QgZSMosvwznob7LU92zgmysQ8nvMHuExQ1ryzcbC470tWLrNxvedsGhMnDxf7u9cmprosgpW32zlbF6jBIFgtOW8bkIaGHXDIGVZ2XYStDGsIykU45Awruy7CVoY1BJUL9RN17w3eoUL3vkRzsnp4qfKBLi5eVVpOeUubggVlf36/EiwmKQMrKxqe6IANB6Dp8i7CTXexYQHlY6mR3d9+rtGTz89p3ZOfgxs9Xh3v5B10atcx6t7anO//ysAnHl+mIzsH6HphlHZv66kaHHRGX9ykN5X3wWWi30P5AzRzfOKfOZ++l2n83TS9/CI+sio2ZeDy+lea/fiUFsuv6P7gVE1oRZtqTgPshWdjVBE7J01TBg5EYQC8Pn74RnBL/k4fvZVqS/+1mLiARlpYrJkaGIvU2mJ4B8/vPYPhTFotDZWF/7tjKZMII3lFW6MsnTQbQwM5I21LDZwXWxeZOto2k6XjsnF0LVxDAwky7XusvKV7OnfQyJ6TWjI0gHH04TSAJrRVGys8GBIf5JO3pZG5upOy3tJRsf7Z4eitTV2n3tJxKlln6TidpPeVt3RSoVZ53gG3SiSaZYeLcLM82yrrKkcYn0pNtTTayuewKdi0usoRTitsar4DNuV5Xbouwro8bUrHRdiU53Xpugjr8rQpHS5rBEypa9YFK/4+vKJZ15ycYMXfh+fNWaBZWbBylLqISgBPs7QBOVHhIlg56npQ6mLAAq2SYASrPJZQ1yPe5QWtFugUE2ySUWhKYNTzoK6HMTZp1/ZGoRabDGqW4ONqZVrgcNtL8X4DIWb0AjGHfRYAAAAASUVORK5CYII=">
                    <div>优惠券</div>
                  </div>
                  <div class="card-item">
                    <img
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAPKADAAQAAAABAAAAPAAAAACL3+lcAAARqUlEQVRoBY1bW6xdVRVd+9xHoRTQAoIUCkEFpdqCRny/ioBEJBANiSHGGPnxt/+YRr5MDF8SPkSNEoyfBGJMitYnQkGBACUgtIRaikiVh1W5j3OO4zHnWnufe0FX273XmnOMMR9r7332uRe6MjNuvHFp2/JkekM3LZeXrmydTCabCibT6bQiPe+8hpme6g9YotPeowc2+MGt/v+bz/DWYIzMqevKsTLtDsGyZ2E0uu2WW07cT2SOGnX37uni8urSzYj3jclkOnIZ/UJjzoTAUoI6wK6SKWmMkzcwC05fBl4fY931fZnLrG7kEsLi4iBU103KpNx65ttP2rV7d7fsDHFksUurSz9HcjuNtAi7QWJ2j4Q2d1cZoENbaVcwgjhIjJM5XGXSnIeWM1ufH41tfHKoYvlmD134olTpO4aOe7eccfKVLBo7WcryZOlmiOxk4vzH4SMmiGAb1Tinl1m60IoXlza5fAhsYho/3AQHgZjesp8A7E2UU0d3/IwmjOQSmyieu51HXnjtZmK7G7+1tG2yMn0Utaj4QdfYr+QBXOeYyBw+cxyo8pEZ55UjvoJLqMpiEmpMRxxMNMhdl6+8QgvIGnMdPgWwTWzaZGHUbR9Nxt0NWKlYRqndZP7QrGtFJtUjO8pVN4IVTzk6NQ+MfElQWEHkJV8ucgY7WAmBSzHHTqj4AW18XoF9vgqAjY2fjFYmkxv4cLqclSWOffMiyfY5ALOjP5NocwcCG43JeWryLJsmyfG+plRyxI8Aa/m9uJhyDxomlVot1iQnblV88nBvtlYZJdZEWmG41ETDQTs9c79VAYIo0jfEksnRzIYIZg3qDsZ6fBJUnCeC4MCz0hkKYEWcB2fEUQDX8dZ5MDaBio8uwrj19DEpk5wQu4Y1nQwkSGB4KQskgcZ3FKytIDrjpi5jCGO/NLA2PH0KJH3edAoPPhnUHfApTZ/k0kdqxpdvk+9d1QYH/jKH3i0da5VoSWGJIVAmnZswlrxuHFl8HhyWPHJaQqEw8A8KIb7Jab4uPwI4f5JoyKiYaconMxDWxNnZCJjTtAnDQmJoJhXyyY1c6Id45UmIBfZsgW9NCX6TD35rzLp8BCKFseyP5MLGVcvD8xGB2p04M3kONcRTrwR0xzjVwCT55NGbLiMDZzCOYSVIYPJ5qTFxXXLSE1zQVJNlyMeKHBLy8mb/mU+NYwQNdcxzVpM1Wk6JQUF5URhjCn8Xu0pPTbYGJYpYF8Czkqhm+7j0MwNnJemkTz+9Kx/98ELZcuaobN7clZNO6sq//j0tr7wyLU8/My6PPT4uzz47Jl08huIjhGcXTQ9yzDAzdnpVsIhcgUyih8/kSpBnZxfiSJIEDGN0HPLhlhW3AqnC1+a4SFrPfPuoXH3VhnL++XPS6x9ORtEnn1TKOVvnymd3lnLgwLjceddSee7QpGrmZUse868lQDt9ae++uXuJ1jKdOHmRMmIkWQUIQQW5VnOqjeAo+o34Yc+mUufjH50vX7hqoczPm5vUNzuPx9Ny98+Wy969K9FyF2pONtKrzJUrxsVDSzNfBrQqLqvgfvAMk64RTkjimlb7jA8M7dXX5xMfAwKpt/Mz8+XaaxbfsFgWtt6Ym+vKNVdvKFdcsVDdqVkNmMwWy+TmCaQsq2chnMuGiQqDXbZUIkZKca/QDsCEfE9dUPBzN5NOUWLffcFcubKXMP34Wloe3z8u9+9bLYcPT8qxY6UsLE7L1rNG5ROfWCjb3+c7MLU+f+WGcuTIFPf2auTP3XX+TMp1MHsO7UTcw3LayIeSITy6GbNkdRPubAXPag7wZDBo+qjK4cbaN8I9fc3VC4XnHK+9Ni2337FUDj4b9yZEqLa8VMozByblmYPL5YLzV8v1X14sJ57o1wdyv3jtYnnyydWyvEI0Bg5qsorQgVblx7z4/qJkZI1iSWSCLIKfWxJKW5yrsc+PYvt8NcfioFjrwveMyqmntqRXVqblBz9sxTKueDyzKRSE9lN/Hpcf3b6kK0GSOGzePCo7dswL4hqjHou02oB1PVaLACxS6qnHEsLGGSTpVvcpkCXk3KKVTGjywUv+ju3Dp/G+B8blMC5NSs+E125lTtwh7vavfr3SD1EuvgiXOnMZCKj8NXw/tFhIDeaiMkj/rAKpquQjJoMEv2ZLSGSuc6xFxeG009rukv2nh1atERzahNVZAaSX/Af+SHwb/FhzDsbSo1x15irWcCvy8N25kQRkdfir3cnC4NClHlAXl02b4cey//A69ZQh5uhL5mZijhslrMM/erThieULikdejUpZOWduGR95E0xgcHBqNj2C5LDN92CF8mKIRXKs1TR5GXLQnzfAQvs0kW8ZV+gsn7RIjf0Ovm2b8P2uP44da4X2a4n3ZnMZHzR+PexzJZ4GBeUCSHaIBHWKkxwAcZUqbkk6cQ6owiS/5+5PDQ1COOJdxgEij/PfNfx4yh0XM3LzFdlXdzW6h9V9ALMOP1xiLZXWQe8UhcJGP/7Rro5invwqSIh0jCN7MMQP3//gH3dch1fM4SVy4OBY+vnjJV++DBhBOYsE2tMjdpr2/j3NxLRr6acBY81Owp9XhMVzz4fYloJ1rOX5enylHaR5bOzXv7ahnH56S3t1dVr+cJ8fYkyR+avxygabwlyDz63AGyxW+EsX7e4Od49zguUUphZOIAcA2TmWa75dtFc+g6cWJ7MjgvGUbvNFkvG92+bKZZculLPw1tUf+x5YLf/EGxlH8hnBeZvvrUAj8JmOV0vm7cT5BaIGIokqGC7GDzCJyZaiPb50uBbNCRA7MVbNDJ8ReezF7RXNl4rLLp0v5503KqdgPjuOvDApd93Nz+RZfmSpDsitXJiX735VHQVQVZVGgeK69LgGDGBx+DPNL6QIOoec+D12BZfZK69E4RFbsoiT3ea6DVfpsJ7T99WvLOq7ccO1GYv93veXECttLJpzHWxE7Iyn3OFSwVGvQG0XmCmboJN3LYvsdxSws8/qyiUfnCvbLhyVhQUT9v56tfxyL76sY6nGUI78FLSsjjLhccwnsm8pO087NYL3sJw+iBePO+9aLq//h6vQVHFcOm97OEd0yoTdL6HqioGZkKEGas5khIMEk4Pr+ONK+dwVc3i1G74qwlU+9pG5svdXuJYRaJZPf38wH3xlkKnee1j95nerum/p4Pv2o4+N9YDil3+LwoFcVE/wWZ2zI4sepYApC9BDi1xfDmzCgOwcYIMEnPZZ58QTpuUr188PnphSj8M//kFyFoEZ72NZQrQHpiWfHcqLPhjv+cVqefghfOSgn0eP4heBE+eRSoRFHZrox0+uK0MTEhhfCfo+TKMKiopyl5lh/xITGYf5EYtdQLEkDMfLL0/LgYMT7A4/G9nrKDCg3o8hJ5P27rIc8IAn5agaxzwskI2hs2khinarh0Hc3ChHs88Prdg9SvAhRK4PBmFRd4D5X3753Jpi//oiivztpDzxBHZCNfKQfMxYPIXlcwr9I4vmqNQZYOXD3p+bZf0UaJvUgkkfy3lfzt6JTMjBM9lIFGoMtBGX8vsvHn5EPPfcpPz4jlXcZw5v8eBj4QQi0ZlCyKgFZH6g8jmR/Wp87kPsa+qC0+frioIvs6d+bQCM/vIgbYB45qE/uPuyQRnzD35gVPgzpRwv4ZvOT346LuNx8tOT5+RjLa20D8+KofhhryF6fLiYSu2LEja+8ZOYqCHfP2ThpUYx9QUAzrPwOFsQ/9HH1hQUpfz+3nFZwg8+mYX4OmNef1JhPPmWGvKtwviRGPmARNjIiWtnx6N95NjuFrTCzI+4xASOZ12btbgqEKj+mruDpE7Bi0V/HHwWdrXNleYLfGIyce4ux5Bt1CC+t8COIJhjfu5vNkCQFkSNaeRsArnOz5c0lpWjOUKwQBp1jk5ivXFjk+Ps9de9dtIQTZ52LH3ga8e7MofH5Kj3COCPYtmLAT/aUnNCGvKz8mpUCbWB5jMe8864fjbRkH58wLhyQ3CU6PDsi8mufFFP/FvemrM4M1oETI+WEeaUzcy5AfgxNhgzfCIrXzwURBvmXM6wAy2GZJm7aGoEv8IKQiP+Zee5S/ojDg6x25i99LdhiIu2+8diTiACxS73NRy0lIt2DN/Kjv7dO6I8EhTx+o1JFzVdqXOivf2Tt+Y75Du3LBEhUAj+mmwny9UMRvmxfuLJYcEf+fConHtu+JPPNvI65aCA+KW87W1d+dAlNaTc+/G5zZGqLX6f3/xOKAKJ6UOGo9+Fkk9c35+/HyaIfxgt4wQwu8Ql78Mnn8I3oVcDBBu/Y37x2rnyzneQb3HFUeYt+NlbOr2KLi4mqOA3C/itwWOTiF1zk0gmXeODVufKFTBdiba7UREfp4qNpOyf+T6sX5fA0/+glgTbRwbOq/g6tueeSbnuS+3SPOGEDr8RmEczJuXBByflL4enegnZeHwpZ5zRlYvxorINP3zv/6aBunvuwec334/xhw3X2WGi8bTWPWgzGjFYFFvPfDXX93mv9W4qVfNTx18PFazXFYoQDCEKOqwiUK08/TS+yfx2XD71yVY0vPh90Uj/OOfTt/+CQlt/3L9vXB55lLuLkU32wtlEUS5GoMjcVxfSYGL198PMK8S0N2Rw9PmUrN+HVVkAQpL41JCeyo/kfn9vh90el898eu3OkfdGxfIquvfeib86Ape7m1kyQceXUztHPdZTPawN2adNVweLF05AUjC885pRFy7/VjbZ8OS1TxAHgxBISP0K4zaU+/ZNy6FD43LppXNl69kEvPl44a9TXcb8hRmHGThK24nqatJPUQxgbKRgrAi+9CtfiRFDIPPs+zGvfMZBA779HX7yC2sn7OwybWGmjG2EVWylyXbWloLf4OOJfQ7/UwX8cAD3L3/d+SoecC/io+zhR6blyAsUxT8mhbOScWgdFXcmVuaQvlm+ehUaifHZuZJPDK8szur3YT+wXE/ussRms4IxH25QqOPw89Ny+Pn8uQXMkWkGpwz1WKz4WHFzBIPTfu4OIeEQARaBsNDazeLUu4mz+PHgAtb5SwkokU3FSh+K3CvG4EGawNBmKOzyyyNbNiTFhEy+YQM2FcSBT2komGPQpwEfzeGCiUglYnd8fDtXApPvLKkPU/CTZx8FMmfItBubbSbEgb0DCUySRR2QtuTTrhQg0Mc0PuLoT+qLIA4DkqP0yLeAJn4HN3agG1r0ZAzzox4XUX3GYYdbEmsLJKh2VLOoBo1hcP6EP/mZtJIlMUbjW6tV9iZ8ZZ4CbhRXNDOuO+NCMx6L5jyLJ8jYaABpEBihg3jfiQhiY94jsiAOC0Z5MJEhluZ9PsGBD57WbG3YuV7LhwWA1BQWfJNCDzylwzOQjkqO/9Bpm5tJlPA8QRAvPsdGQBxqXbGjh1M8ri3PpLiK3enNo3wJ008XgwcE3c1U6F2PbyyvGg7zuTtaruF7A+zzlUYO3pWTIFfuLrL37XoIO1z2ULOPoxgL9Nk+BYCksI6jipJHv0tsQapP+r46Wiw3oGKCn3EZQslHjx2fufhKUSLSJdJ2ns3nLGy6/fybTezunhH+v4/b4PKbAEHr/KvdgJOCCYocqa1hrptCA9eJ5ZRz8TUP3HDjAWn85EgjOHmlrMEJjBBqCAIpOIxMknN8Gpb5udtGu3Z1+2G7lUDcZhouqgJhy10jP0LxEm1iLZDQ6QtB2AjlqAmpcS2GpELPu0TfG/MzRyF4IDwKYFNk6vHxrf3Wb9+0Yb8+3c7eUnaBspfNroExz6Ges0AMBeC5JyYb/Mn3fdTw5otuvhKS1YnZZT7m5FvN8TImYRkr2i5m9SMk0zKfrih81O3dsLiBNfrF47rruuWtW8qVAN4CiC7vrKcWFkIktSy581zjwL+cY7hwL8xnJnFP0hx475LXae7zWbb4lvI9nUCcZ/nKy30WD9wJnsy3HDe/Qf/PErVDilOPm7873TZeKf5f8fD/Q+Dy2OT7JroegnFSdfKjCONgSifPTIy/ikh/+BLCqFU/iJXvlIIfuqnZE+jzUeQxrPG/4o324D9gue0mXMYho9N/ARE1BvQzqQ/HAAAAAElFTkSuQmCC">
                    <div>小程序</div>
                  </div>


                  <!-- </el-card> -->
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>
        <div class="col" style="margin-top: 20px">
          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                交易数据
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="datarightItems">
                <el-col v-for="(item, index) in datarightItems" :key="item + index" class="grid" :span="4">
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>

        <div class="col2" style="margin-top: 20px">
          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                商品数据
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="goodsItems">
                <el-col v-for="(item, index) in goodsItems" :key="item + index" class="grid" :span="4">
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>
      </el-col>

      <el-col :span="5">
        <div class="taocan">
          <div class="taocan-header">
            <div class="taocan-title">试用版</div>
            <div class="taocan-time taocan-expired">
              <span class="surplus-days">
                剩余
                <span class="day-num">0</span>
                天
              </span>
              <span class="taocan-status">(已到期)</span>
            </div>
          </div>
          <div class="taocan-info">
            <div class="item-text" title="当前为免费试用版本">
              当前为免费试用版本
            </div>
            <div class="item-text" title="升级解锁享受更多服务">
              升级解锁享受更多服务
            </div>
          </div>
          <div class="taocan-footer">
            <div><a class="taocan-update update-danger">立即升级</a></div>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { welcome } from '@/api/user'
export default {
  name: 'Welcome',
  data() {
    return {
      avatorSrc: 'https://yw.yftsm.com/static/dist/shop/image/shopdefault.png',
      lastLoginInfo: '2024-04-28 00:11:21 IP: 183.213.83.84',
      expireDate: '2024-12-01 00:00:00',
      updateTimestamp: '2024-04-28 12:07:01',
      headStyle: {
        backgroundImage: 'url(/static/dist/shop/image/homepage/day-bg.png)',
        backgroundSize: '100% 100%',
      },
      dataItems: [
        {
          title: '支付订单数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-持平',
        },
        {
          title: '支付人数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '支付商品数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '余额支付',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '微信支付',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '支付总金额',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
      ],
      datarightItems: [
        {
          title: '今日佣金',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-持平',
        },
        {
          title: '已提现佣金',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '已提现余额',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '已提现积分',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '已退款金额',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '其他支出',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
      ],
      goodsItems: [
        {
          title: '今日商品浏览量',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-持平',
        },
        {
          title: '今日被访问商品数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日动销商品数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日加购件数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日下单件数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日支付件数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
      ],
      order0Count: '',
      operateItems: [
        {
          href: 'ShopProduct/edit',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '添加商品',
        },
        {
          href: 'DesignerPage/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '店铺装修',
        },
        {
          href: 'ShopOrder/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '订单管理',
        },
        {
          href: 'Member/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '会员管理',
        },
        {
          href: 'Member/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '代客下单',
        },
        {
          href: 'Coupon/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '优惠券',
        },
      ],
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
    dragOptions() {
      return {
        animation: 600,
        group: 'description',
      }
    },
  },
  created() {
    welcome().then((res) => {
      this.welcome = res

      console.log(res)
    })
  },
  methods: {
    welcome,
  },
}
</script>

<style lang="scss" scoped>
.taocan {
  padding: 20px 10px 10px 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);

  .taocan-title {
    position: relative;
    padding-left: 10px;
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    line-height: 22px;
    color: rgba(0, 0, 0, 0.8);
  }

  .taocan-title::after {
    position: absolute;
    top: 5px;
    bottom: 0;
    left: 5px;
    width: 3px;
    height: 13px;
    margin-left: -5px;
    content: '';
    background: var(--primary, #fb6638);
    border-radius: 10px;
  }

  .taocan-time {
    margin-top: 20px;

    line-height: 20px;
  }

  .surplus-days {
    font-weight: 500;
    color: #ff5050;
  }

  .taocan-info {
    margin-top: 20px;
    line-height: 20px;
  }

  .item-text {
    line-height: 30px;
  }

  .taocan-footer {
    margin-top: 20px;
    line-height: 20px;
  }

  .taocan-update {
    display: block;
    width: 100%;
    height: 40px;
    line-height: 40px;
    color: #fff;
    text-align: center;
    background: #ff5050;
    border-radius: 6px;
  }
}

.echarts,
.trend-echart {
  width: 900px !important;
  height: 300px !important;
}

.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.card {
  border: none;
}

.col {
  display: flex;
  padding: 20px 10px 10px 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
}

.col1 {
  padding: 20px 10px 10px 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
}

.col2 {
  padding: 20px 10px 10px 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
}

.el-card {
  margin-bottom: 0 !important;
}

.flex-center {
  display: flex;
  align-items: center;
}

.flex-between {
  display: flex;
  justify-content: space-between;
}

.shopinfo {
  min-width: 313px;
  /* 最小宽度 */
  max-width: 346px;
  /* 最大宽度 */
  overflow: hidden;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;

  .head {
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 137px;
    padding: 17px 17px 29px;
    font-size: 12px;
    line-height: 17px;
    color: hsla(0, 0%, 98%, 0.9);
    background-image: url(https://yw.yftsm.com/static/dist/shop/image/homepage/day-bg.png);
    background-size: 100% 100%;

    .date {
      color: hsla(0, 0%, 100%, 0.63);
    }

    .logo {
      padding-right: 55px;
    }

    .title {
      padding-bottom: 4px;
      margin: 0;
      font-size: 19px;
      font-weight: 600;
      line-height: 28px;
      color: #fff;
    }

    .goal {
      display: -webkit-box;
      margin: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
  }

  .detail {
    height: 170px;
    margin-top: -15px;
    background: linear-gradient(180deg, #d6e6ff, #fdfdff);
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;

    .img {
      border: 2px solid #ebf4ff;
      border-radius: 50%;
    }

    .top {
      padding: 45px 15px 10px;

      .avatar {
        position: relative;
        width: 74px;
      }

      .menu {
        position: absolute;
        bottom: 0;
        box-sizing: border-box;
        width: 72px;
        padding: 0 7px;
        overflow: hidden;
        font-size: 12px;
        line-height: 20px;
        color: #eed8a0;
        text-align: center;
        -ms-text-overflow: ellipsis;
        text-overflow: ellipsis;
        white-space: nowrap;
        background: #2d2e31;
        border-radius: 4px;
      }

      .flex1 {
        flex: 1;
        width: 0px;
        min-width: 0;
        min-height: 0;
        margin-left: 17px;

        .date {
          margin: 0;
          font-size: 12px;
          line-height: 20px;
          color: rgba(0, 0, 0, 0.4);
        }

        .shop-name {
          width: 100%;
          margin: 0;
          margin-bottom: 2px;
          overflow: hidden;
          font-size: 18px;
          font-weight: 600;
          line-height: 20px;
          color: rgba(0, 0, 0, 0.8);
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
    }

    .icon {
      display: inline-block;
      margin-right: 8px;
      font-size: 20px;
      color: rgb(97, 92, 175);
    }
  }
}

.overview {
  width: 100%;
  margin-left: 10px;

  // border: #fb6638 1px solid;
  .tip-title {
    position: relative;
    padding-left: 10px;
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    line-height: 22px;
    color: rgba(0, 0, 0, 0.8);

    span {
      padding-left: 10px;
      font-size: 12px;
      font-weight: 400;
      line-height: 17px;
      color: rgba(0, 0, 0, 0.4);
    }
  }

  .yesterday {
    margin: 0;
  }

  .tip-title::after {
    position: absolute;
    top: 5px;
    bottom: 0;
    left: 5px;
    width: 3px;
    height: 13px;
    margin-left: -5px;
    content: '';
    background: var(--primary, #fb6638);
    border-radius: 10px;
  }
}

.grid {
  // margin: -10px;
  padding: 10px !important;
}

.data-block-item {
  // padding: 10px 20px;
  padding: 0 !important;
  font-size: 14px;
  background: #f7f9fe;
  border-radius: 10px;
  // margin: 20px;

  .middle {
    margin: 0;
    font-size: 14px;
    line-height: 20px;
    color: #666;
  }

  .middle .p1 {
    margin: 0px;
    font-size: 30px;
    font-weight: 600;
    line-height: 20px;
    color: #000;
  }

  .p2 {
    margin: 0px;
  }

  .top {
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 10px;
    color: rgba(0, 0, 0, 0.4);
  }

  .top p:first-child {
    margin: 0px;
    font-size: 14px;
    line-height: 20px;
    color: rgba(0, 0, 0, 0.8);
  }

  .bottom {
    margin-top: 14px;
    font-size: 12px;

    p {
      margin: 0 0 0 0;
    }
  }
}

.card-item {
  img {
    width: 52px;
    height: 52px;
    margin: 0 auto;
    display: block;
    transition: all .3s;
  }

  div {
    padding-top: 15px;
    color: #333;
    font-weight: 700;
    font-size: 14px;
    text-align: center;
  }
}

.card-item:hover img {
  transform: translateY(-10px)
}

.card {

  justify-content: space-around;
  align-items: center;
  background: #fff;
  cursor: pointer;
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  position: relative;
  box-sizing: border-box;
}
</style>
