<template>
  <div class="index-container">
    <el-row :gutter="20">
      <el-col :span="19">
        <div class="col">
          <div class="shopinfo">
            <div class="head">
              <div class="logo">
                <h1 class="title">欢迎登录系统</h1>
                <p class="goal">一个能够升起月亮的身体，必然驮住了无数次日落</p>
              </div>
              <p class="date">上次登录：{{ lastLoginInfo }}</p>
            </div>
            <div class="detail noNotice">
              <el-row align="middle" class="top" justify="center" type="flex">
                <el-col :span="6">
                  <div class="avator">
                    <img alt="avator" class="img" height="72" :src="avatorSrc" width="72" />
                    <p class="menu">合作版本</p>
                  </div>
                </el-col>
                <el-col class="flex1" :span="18">
                  <p class="shop-name">头号美妆</p>
                  <p class="date">到期时间：{{ expireDate }}</p>
                  <div class="channel flex-center">
                    <vab-icon class="icon" icon="mini-program-fill" />
                    <vab-icon class="icon" icon="wechat-2-fill" />
                    <vab-icon class="icon" icon="qq-fill" />
                    <vab-icon class="icon" icon="alipay-fill" />
                    <vab-icon class="icon" icon="html5-fill" />
                    <vab-icon class="icon" icon="baidu-fill" />
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>

          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                实时收入概况
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="dataItems">
                <el-col v-for="(item, index) in dataItems" :key="item + index" class="grid" :span="8">
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                      <p class="yesterday">昨日</p>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                      <p class="p2">{{ item.yesterday }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>
        <div class="col" style="margin-top: 20px">
          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                交易数据
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="datarightItems">
                <el-col v-for="(item, index) in datarightItems" :key="item + index" class="grid" :span="4">
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>

        <div class="col2" style="margin-top: 20px">
          <div class="overview">
            <el-row align="middle" justify="space-between" type="flex">
              <p class="tip-title">
                商品数据
                <span>更新于 {{ updateTimestamp }}</span>
              </p>
            </el-row>
            <el-row>
              <vab-draggable v-bind="dragOptions" :list="goodsItems">
                <el-col v-for="(item, index) in goodsItems" :key="item + index" class="grid" :span="4">
                  <el-card class="data-block-item" shadow="hover">
                    <div class="flex-center flex-between top">
                      <div>
                        <p class="today">
                          {{ item.title }}
                          <span>({{ item.unit }})</span>
                        </p>
                      </div>
                    </div>
                    <div class="flex-center flex-between middle">
                      <p class="p1">{{ item.today }}</p>
                    </div>
                    <div class="flex-center flex-between bottom">
                      <p>
                        <span>较昨日</span>
                        <span class="flex1">{{ item.difference }}</span>
                      </p>
                    </div>
                  </el-card>
                </el-col>
              </vab-draggable>
            </el-row>
          </div>
        </div>
      </el-col>

      <el-col :span="5">
        <div class="taocan">
          <div class="taocan-header">
            <div class="taocan-title">试用版</div>
            <div class="taocan-time taocan-expired">
              <span class="surplus-days">
                剩余
                <span class="day-num">0</span>
                天
              </span>
              <span class="taocan-status">(已到期)</span>
            </div>
          </div>
          <div class="taocan-info">
            <div class="item-text" title="当前为免费试用版本">
              当前为免费试用版本
            </div>
            <div class="item-text" title="升级解锁享受更多服务">
              升级解锁享受更多服务
            </div>
          </div>
          <div class="taocan-footer">
            <div><a class="taocan-update update-danger">立即升级</a></div>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { welcome } from '@/api/user'
export default {
  name: 'Welcome',
  data() {
    return {
      avatorSrc: 'https://yw.yftsm.com/static/dist/shop/image/shopdefault.png',
      lastLoginInfo: '2024-04-28 00:11:21 IP: 183.213.83.84',
      expireDate: '2024-12-01 00:00:00',
      updateTimestamp: '2024-04-28 12:07:01',
      headStyle: {
        backgroundImage: 'url(/static/dist/shop/image/homepage/day-bg.png)',
        backgroundSize: '100% 100%',
      },
      dataItems: [
        {
          title: '支付订单数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-持平',
        },
        {
          title: '支付人数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '支付商品数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '余额支付',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '微信支付',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '支付总金额',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
      ],
      datarightItems: [
        {
          title: '今日佣金',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-持平',
        },
        {
          title: '已提现佣金',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '已提现余额',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '已提现积分',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '已退款金额',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '其他支出',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
      ],
      goodsItems: [
        {
          title: '今日商品浏览量',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-持平',
        },
        {
          title: '今日被访问商品数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日动销商品数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日加购件数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日下单件数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
        {
          title: '今日支付件数',
          unit: '笔',
          today: '0',
          yesterday: '0',
          difference: '-',
        },
      ],
      order0Count: '',
      operateItems: [
        {
          href: 'ShopProduct/edit',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '添加商品',
        },
        {
          href: 'DesignerPage/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '店铺装修',
        },
        {
          href: 'ShopOrder/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '订单管理',
        },
        {
          href: 'Member/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '会员管理',
        },
        {
          href: 'Member/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '代客下单',
        },
        {
          href: 'Coupon/index',
          icon: 'https://yw.yftsm.com/static/dist/shop/image/icon/decorate.png',
          text: '优惠券',
        },
      ],
    }
  },
  computed: {
    ...mapGetters({
      title: 'settings/title',
    }),
    dragOptions() {
      return {
        animation: 600,
        group: 'description',
      }
    },
  },
  created() {
    welcome().then((res) => {
      this.welcome = res

      console.log(res)
    })
  },
  methods: {
    welcome,
  },
}
</script>

<style lang="scss" scoped>
.taocan {
  padding: 20px 10px 10px 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);

  .taocan-title {
    position: relative;
    padding-left: 10px;
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    line-height: 22px;
    color: rgba(0, 0, 0, 0.8);
  }

  .taocan-title::after {
    position: absolute;
    top: 5px;
    bottom: 0;
    left: 5px;
    width: 3px;
    height: 13px;
    margin-left: -5px;
    content: '';
    background: var(--primary, #fb6638);
    border-radius: 10px;
  }

  .taocan-time {
    margin-top: 20px;

    line-height: 20px;
  }

  .surplus-days {
    font-weight: 500;
    color: #ff5050;
  }

  .taocan-info {
    margin-top: 20px;
    line-height: 20px;
  }

  .item-text {
    line-height: 30px;
  }

  .taocan-footer {
    margin-top: 20px;
    line-height: 20px;
  }

  .taocan-update {
    display: block;
    width: 100%;
    height: 40px;
    line-height: 40px;
    color: #fff;
    text-align: center;
    background: #ff5050;
    border-radius: 6px;
  }
}

.echarts,
.trend-echart {
  width: 900px !important;
  height: 300px !important;
}

.index-container {
  padding: 0 !important;
  background: $base-color-background !important;
}

.card {
  border: none;
}

.col {
  display: flex;
  padding: 20px 10px 10px 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
}

.col1 {
  padding: 20px 10px 10px 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
}

.col2 {
  padding: 20px 10px 10px 20px;
  margin-bottom: 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(223, 227, 235, 0.45);
}

.el-card {
  margin-bottom: 0 !important;
}

.flex-center {
  display: flex;
  align-items: center;
}

.flex-between {
  display: flex;
  justify-content: space-between;
}

.shopinfo {
  min-width: 313px;
  /* 最小宽度 */
  max-width: 346px;
  /* 最大宽度 */
  overflow: hidden;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;

  .head {
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 137px;
    padding: 17px 17px 29px;
    font-size: 12px;
    line-height: 17px;
    color: hsla(0, 0%, 98%, 0.9);
    background-image: url(https://yw.yftsm.com/static/dist/shop/image/homepage/day-bg.png);
    background-size: 100% 100%;

    .date {
      color: hsla(0, 0%, 100%, 0.63);
    }

    .logo {
      padding-right: 55px;
    }

    .title {
      padding-bottom: 4px;
      margin: 0;
      font-size: 19px;
      font-weight: 600;
      line-height: 28px;
      color: #fff;
    }

    .goal {
      display: -webkit-box;
      margin: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
  }

  .detail {
    height: 170px;
    margin-top: -15px;
    background: linear-gradient(180deg, #d6e6ff, #fdfdff);
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;

    .img {
      border: 2px solid #ebf4ff;
      border-radius: 50%;
    }

    .top {
      padding: 45px 15px 10px;

      .avatar {
        position: relative;
        width: 74px;
      }

      .menu {
        position: absolute;
        bottom: 0;
        box-sizing: border-box;
        width: 72px;
        padding: 0 7px;
        overflow: hidden;
        font-size: 12px;
        line-height: 20px;
        color: #eed8a0;
        text-align: center;
        -ms-text-overflow: ellipsis;
        text-overflow: ellipsis;
        white-space: nowrap;
        background: #2d2e31;
        border-radius: 4px;
      }

      .flex1 {
        flex: 1;
        width: 0px;
        min-width: 0;
        min-height: 0;
        margin-left: 17px;

        .date {
          margin: 0;
          font-size: 12px;
          line-height: 20px;
          color: rgba(0, 0, 0, 0.4);
        }

        .shop-name {
          width: 100%;
          margin: 0;
          margin-bottom: 2px;
          overflow: hidden;
          font-size: 18px;
          font-weight: 600;
          line-height: 20px;
          color: rgba(0, 0, 0, 0.8);
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
    }

    .icon {
      display: inline-block;
      margin-right: 8px;
      font-size: 20px;
      color: rgb(97, 92, 175);
    }
  }
}

.overview {
  width: 100%;
  margin-left: 10px;

  // border: #fb6638 1px solid;
  .tip-title {
    position: relative;
    padding-left: 10px;
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    line-height: 22px;
    color: rgba(0, 0, 0, 0.8);

    span {
      padding-left: 10px;
      font-size: 12px;
      font-weight: 400;
      line-height: 17px;
      color: rgba(0, 0, 0, 0.4);
    }
  }

  .yesterday {
    margin: 0;
  }

  .tip-title::after {
    position: absolute;
    top: 5px;
    bottom: 0;
    left: 5px;
    width: 3px;
    height: 13px;
    margin-left: -5px;
    content: '';
    background: var(--primary, #fb6638);
    border-radius: 10px;
  }
}

.grid {
  // margin: -10px;
  padding: 10px !important;
}

.data-block-item {
  // padding: 10px 20px;
  padding: 0 !important;
  font-size: 14px;
  background: #f7f9fe;
  border-radius: 10px;
  // margin: 20px;

  .middle {
    margin: 0;
    font-size: 14px;
    line-height: 20px;
    color: #666;
  }

  .middle .p1 {
    margin: 0px;
    font-size: 30px;
    font-weight: 600;
    line-height: 20px;
    color: #000;
  }

  .p2 {
    margin: 0px;
  }

  .top {
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 10px;
    color: rgba(0, 0, 0, 0.4);
  }

  .top p:first-child {
    margin: 0px;
    font-size: 14px;
    line-height: 20px;
    color: rgba(0, 0, 0, 0.8);
  }

  .bottom {
    margin-top: 14px;
    font-size: 12px;

    p {
      margin: 0 0 0 0;
    }
  }
}

.col2 {}
</style>
