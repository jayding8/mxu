<template>
  <div id="app">
    <router-view v-if="isRouterAlive" />
  </div>
</template>

<script>
import { MemberLevel } from "@/api/member";

export default {
  name: 'App',
  provide() {
    return {
      reload: this.reload
    }
  },
  data() {
    return {
      isRouterAlive: true
    }
  },
  methods: {
    reload() {
      this.isRouterAlive = false
      this.$nextTick(function () {
        this.isRouterAlive = true
      })
    }
  },
  created() {
    MemberLevel({ page: 1, limit: 10 }).then(res => {
      localStorage.setItem('memberLevel', JSON.stringify(res.data.map(v => ({ id: v.id, name: v.name }))));
    })
  }
}
</script>

<style>
.el-dialog .el-dialog__body {
  padding: 16px;
}

.el-color-picker__panel {
  z-index: 1010 !important;
}
</style>