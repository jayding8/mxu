import Vue from 'vue'
import App from './App'
import i18n from './i18n'
import store from './store'
import router from './router'
import '@/vab'
import './assets/iconfont/iconfont.css'
import './assets/iconfont/iconfontMobal.css'
import './assets/iconfont/iconfont.js'
import './styles/font/iconfont.css'
import './styles/font/iconfont.js'

Vue.config.productionTip = false
new Vue({
  el: '#app',
  i18n,
  store,
  router,
  render: (h) => h(App),
})
