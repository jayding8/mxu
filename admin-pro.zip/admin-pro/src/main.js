import Vue from 'vue'
import App from './App'
import i18n from './i18n'
import store from './store'
import router from './router'
import '@/vab'
import './assets/iconfont/iconfont.css'
import './assets/iconfont/iconfontMobal.css'
import './assets/iconfont/iconfont.js'
import './styles/font/iconfont.css'
import './styles/font/iconfont.js'
import './styles/index.scss'
import './mockData/index'
import { modalSure, getFileType, HandlePrice } from '@/utils/public'
import UploadImg from '@/components/uploadImg'
import VueLazyload from 'vue-lazyload'

Vue.prototype.$modalSure = modalSure
Vue.prototype.$getFileType = getFileType
Vue.prototype.$HandlePrice = HandlePrice
Vue.prototype.$UploadImg = UploadImg

Vue.use(VueLazyload, {
  preLoad: 1.3,
  error: require('./assets/images/no.png'),
  loading: require('./assets/images/moren.jpg'),
  attempt: 1,
  listenEvents: [
    'scroll',
    'wheel',
    'mousewheel',
    'resize',
    'animationend',
    'transitionend',
    'touchmove',
  ],
})

Vue.config.productionTip = false
new Vue({
  el: '#app',
  i18n,
  store,
  router,
  render: (h) => h(App),
})
