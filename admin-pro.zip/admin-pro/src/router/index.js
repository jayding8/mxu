/**
 * @description router全局配置，如有必要可分文件抽离，其中asyncRoutes只有在intelligence模式下才会用到，pro版只支持remixIcon图标，具体配置请查看vip群文档
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
import Layout from '@/vab/layouts'
import { publicPath, routerMode } from '@/config'

Vue.use(VueRouter)
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login'),
    meta: {
      hidden: true,
    },
  },
  {
    path: '/register',
    component: () => import('@/views/register'),
    meta: {
      hidden: true,
    },
  },
  {
    path: '/403',
    name: '403',
    component: () => import('@/views/403'),
    meta: {
      hidden: true,
    },
  },
  {
    path: '/404',
    name: '404',
    component: () => import('@/views/404'),
    meta: {
      hidden: true,
    },
  },
]

export const asyncRoutes = [
  {
    path: '/',
    name: 'Welcome',
    component: Layout,
    meta: {
      title: '概况',
      icon: 'home-2-line',
      guard: ['Admin'],
      breadcrumbHidden: true,
    },
    children: [
      {
        path: '/welcome',
        name: 'Welcome',
        component: () => import('@/views/welcome'),
        meta: {
          title: '概况',
          icon: 'home-2-line',
          noColumn: true,
        },
      },
    ],
  },
  {
    path: 'shop',
    name: 'Shop',
    component: Layout,
    meta: {
      title: '商城',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'shopproduct',
        name: 'Shopproduct',
        component: () => import('@/views/shop/shopproduct/index'),
        meta: {
          title: '商品管理',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'productEdit',
        name: 'productEdit',
        component: () => import('@/views/shop/shopproduct/edit'),
        meta: {
          title: '商品编辑',
          icon: 'home-2-line',
          hidden: true,
        },
      },
      {
        path: 'shoporder',
        name: 'Shoporder',
        component: () => import('@/views/shop/shoporder/index'),
        meta: {
          title: '商品订单',
          icon: 'home-2-line',
          noClosable: true,
        },
      },

      {
        path: 'shoprefundorder',
        name: 'Shoprefundorder',
        component: () => import('@/views/shop/shoprefundorder/index'),
        meta: {
          title: '退款申请',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
      // {
      //   path: 'shopComment',
      //   name: 'shopComment',
      //   component: () => import('@/views/shop/shopcomment/index'),
      //   meta: {
      //     title: '评价管理',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      {
        path: 'shopCategory',
        name: 'ShopCategory',
        component: () => import('@/views/shop/shopcategory/index'),
        meta: {
          title: '商品分类',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      // {
      //   path: 'shopgroup',
      //   name: 'Shopgroup',
      //   component: () => import('@/views/shop/shopgroup/index'),
      //   meta: {
      //     title: '商品分组',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'shopparam',
      //   name: 'shopparam',
      //   component: () => import('@/views/shop/shopparam/index'),
      //   meta: {
      //     title: '商品参数',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'shopfuwu',
      //   name: 'shopfuwu',
      //   component: () => import('@/views/shop/shopfuwu/index'),
      //   meta: {
      //     title: '商品服务',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      {
        path: 'shopposter',
        name: 'shopposter',
        component: () => import('@/views/shop/shopposter/index'),
        meta: {
          title: '商品海报',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      // {
      //   path: 'shoporderlr',
      //   name: 'ShopOrderlr',
      //   component: () => import('@/views/shop/shoporderlr/index'),
      //   meta: {
      //     title: '录入订单',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'shopstock',
      //   name: 'shopstock',
      //   component: () => import('@/views/shop/shopstock/index'),
      //   meta: {
      //     title: '录入库存',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'shoptaobao',
      //   name: 'shoptaobao',
      //   component: () => import('@/views/shop/shoptaobao'),
      //   meta: {
      //     title: '商品采集',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'tongji',
      //   name: 'tongji',
      //   component: () => import('@/views/shop/shoporder/tongji'),
      //   meta: {
      //     title: '销售统计',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      {
        path: 'shopset',
        name: 'shopset',
        component: () => import('@/views/shop/shopset'),
        meta: {
          title: '系统设置',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
    ],
  },
  {
    path: 'mode',
    name: 'mode',
    component: Layout,
    meta: {
      title: '分销',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'list',
        name: 'list',
        component: () => import('@/views/mode/index'),
        meta: {
          title: '门店列表',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
    ],
  },
  {
    path: 'member',
    name: 'Member',
    component: Layout,
    meta: {
      title: '会员',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'memberlist',
        name: 'memberlist',
        component: () => import('@/views/member/memberlist/index'),
        meta: {
          title: '会员列表',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'memberlevel',
        name: 'memberlevel',
        component: () => import('@/views/member/memberlevel/index'),
        meta: {
          title: '等级设置',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      // {
      //   path: 'applyorder',
      //   name: 'applyorder',
      //   component: () => import('@/views/member/applyorder/index'),
      //   meta: {
      //     title: '升级列表',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'changepid',
      //   name: 'changepid',
      //   component: () => import('@/views/member/changepid/index'),
      //   meta: {
      //     title: '脱离记录',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      {
        path: 'charts',
        name: 'charts',
        component: () => import('@/views/member/charts/index'),
        meta: {
          title: '会员关系网',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'memberposter',
        name: 'memberposter',
        component: () => import('@/views/member/memberposter/index'),
        meta: {
          title: '分享海报',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
      // {
      //   path: 'largearea',
      //   name: 'largearea',
      //   component: () => import('@/views/member/largearea/index'),
      //   meta: {
      //     title: '大区设置',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'memberset',
      //   name: 'memberset',
      //   component: () => import('@/views/member/memberset/index'),
      //   meta: {
      //     title: '资料设置',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'registerform',
      //   name: 'registerform',
      //   component: () => import('@/views/member/registerform/index'),
      //   meta: {
      //     title: '自定义设置',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'memberproduct',
      //   name: 'memberproduct',
      //   component: () => import('@/views/member/memberproduct/index'),
      //   meta: {
      //     title: '一客一价',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
    ],
  },
  // {
  //   path: 'mendian',
  //   name: 'Mendian',
  //   component: Layout,
  //   meta: {
  //     title: '门店',
  //     icon: 'home-2-line',
  //     breadcrumbHidden: true,
  //   },
  //   children: [
  //     {
  //       path: 'list',
  //       name: 'list',
  //       component: () => import('@/views/mendian/list/index'),
  //       meta: {
  //         title: '门店列表',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'group',
  //       name: 'group',
  //       component: () => import('@/views/mendian/group/index'),
  //       meta: {
  //         title: '门店分组',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'level',
  //       name: 'level',
  //       component: () => import('@/views/mendian/level/index'),
  //       meta: {
  //         title: '门店等级',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //     {
  //       path: 'mendianset',
  //       name: 'mendianset',
  //       component: () => import('@/views/mendian/mendianset/index'),
  //       meta: {
  //         title: '门店管理',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //     {
  //       path: 'set',
  //       name: 'set',
  //       component: () => import('@/views/mendian/set/index'),
  //       meta: {
  //         title: '门店设置',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //   ],
  // },
  {
    path: 'money',
    name: 'Money',
    component: Layout,
    meta: {
      title: '财务',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'payorder',
        name: 'payorder',
        component: () => import('@/views/money/payorder/index'),
        meta: {
          title: '消费明细',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'moneylog',
        name: 'moneylog',
        component: () => import('@/views/money/moneylog/index'),
        meta: {
          title: '余额明细',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'rechargelog',
        name: 'rechargelog',
        component: () => import('@/views/money/rechargelog/index'),
        meta: {
          title: '充值记录',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
      // {
      //   path: 'withdrawlog',
      //   name: 'withdrawlog',
      //   component: () => import('@/views/money/withdrawlog/index'),
      //   meta: {
      //     title: '余额提现',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'cmm-record',
      //   name: 'cmm-record',
      //   component: () => import('@/views/money/cmm-record/index'),
      //   meta: {
      //     title: '佣金记录',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      {
        path: 'commissionlog',
        name: 'commissionlog',
        component: () => import('@/views/money/commissionlog/index'),
        meta: {
          title: '佣金明细',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
      {
        path: 'cmm-withdrawlog',
        name: 'cmm-withdrawlog',
        component: () => import('@/views/money/cmm-withdrawlog/index'),
        meta: {
          title: '佣金提现',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'scorelog',
        name: 'scorelog',
        component: () => import('@/views/money/scorelog/index'),
        meta: {
          title: '积分明细',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'fenhonglog',
        name: 'fenhonglog',
        component: () => import('@/views/money/fenhonglog/index'),
        meta: {
          title: '分红记录',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
      // {
      //   path: 'men-moneylog',
      //   name: 'men-moneylog',
      //   component: () => import('@/views/money/men-moneylog/index'),
      //   meta: {
      //     title: '门店佣金明细',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'men-withdrawlog',
      //   name: 'men-withdrawlog',
      //   component: () => import('@/views/money/men-withdrawlog/index'),
      //   meta: {
      //     title: '门店佣金提现',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'fuchirecord',
      //   name: 'fuchirecord',
      //   component: () => import('@/views/money/fuchirecord/index'),
      //   meta: {
      //     title: '扶持金记录',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'fuchilog',
      //   name: 'fuchilog',
      //   component: () => import('@/views/money/fuchilog/index'),
      //   meta: {
      //     title: '扶持金明细',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'hexiao',
      //   name: 'hexiao',
      //   component: () => import('@/views/money/hexiao/index'),
      //   meta: {
      //     title: '核销记录',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'invoice',
      //   name: 'invoice',
      //   component: () => import('@/views/money/invoice/index'),
      //   meta: {
      //     title: '发票管理',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'bonuspool',
      //   name: 'bonuspool',
      //   component: () => import('@/views/money/bonuspool/index'),
      //   meta: {
      //     title: '奖金池',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'pool-record',
      //   name: 'pool-record',
      //   component: () => import('@/views/money/pool-record/index'),
      //   meta: {
      //     title: '贡献值记录',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'pool-commissionlog',
      //   name: 'pool-commissionlog',
      //   component: () => import('@/views/money/pool-commissionlog/index'),
      //   meta: {
      //     title: '贡献值明细',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'pool-withdrawlog',
      //   name: 'pool-withdrawlog',
      //   component: () => import('@/views/money/pool-withdrawlog/index'),
      //   meta: {
      //     title: '贡献值提现记录',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      // {
      //   path: 'overdraftmoney',
      //   name: 'overdraftmoney',
      //   component: () => import('@/views/money/overdraftmoney/index'),
      //   meta: {
      //     title: '信用额度明细',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
    ],
  },
  // {
  //   path: 'extend',
  //   name: 'Extend',
  //   component: Layout,
  //   meta: {
  //     title: '扩展',
  //     icon: 'home-2-line',
  //     breadcrumbHidden: true,
  //   },
  //   children: [
  //     {
  //       path: 'index',
  //       name: 'Index',
  //       component: () => import('@/views/extend/index'),
  //       meta: {
  //         title: '文章列表',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'welcome',
  //       name: 'welcome',
  //       component: () => import('@/views/extend/index'),
  //       meta: {
  //         title: '用户论坛',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'member',
  //       name: 'member',
  //       component: () => import('@/views/extend/index'),
  //       meta: {
  //         title: '积分签到',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //   ],
  // },
  // {
  //   path: 'marketing',
  //   name: 'Marketing',
  //   component: Layout,
  //   meta: {
  //     title: '营销',
  //     icon: 'home-2-line',
  //     breadcrumbHidden: true,
  //   },
  //   children: [
  //     {
  //       path: 'index',
  //       name: 'Index',
  //       component: () => import('@/views/marketing/index'),
  //       meta: {
  //         title: '优惠券',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'welcome',
  //       name: 'welcome',
  //       component: () => import('@/views/marketing/index'),
  //       meta: {
  //         title: '注册赠送',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'member',
  //       name: 'member',
  //       component: () => import('@/views/marketing/index'),
  //       meta: {
  //         title: '充值赠送',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //   ],
  // },
  // {
  //   path: 'food',
  //   name: 'Food',
  //   component: Layout,
  //   meta: {
  //     title: '餐饮',
  //     icon: 'home-2-line',
  //     breadcrumbHidden: true,
  //   },
  //   children: [
  //     {
  //       path: 'index',
  //       name: 'Index',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '首页',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'welcome',
  //       name: 'welcome',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '菜品',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'member',
  //       name: 'member',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '外卖',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //     {
  //       path: 'index',
  //       name: 'Index',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '点擦',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'welcome',
  //       name: 'welcome',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '预定',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'member',
  //       name: 'member',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '排队',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //     {
  //       path: 'index',
  //       name: 'Index',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '寄存',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'welcome',
  //       name: 'welcome',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '餐桌',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'member',
  //       name: 'member',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '营销',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //     {
  //       path: 'index',
  //       name: 'Index',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '收银台',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'welcome',
  //       name: 'welcome',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '餐厅区域打印',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'member',
  //       name: 'member',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '备注预置',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //     {
  //       path: 'member',
  //       name: 'member',
  //       component: () => import('@/views/food/index'),
  //       meta: {
  //         title: '设置',
  //         icon: 'home-2-line',
  //         noClosable: false,
  //       },
  //     },
  //   ],
  // },
  {
    path: 'diy',
    name: 'Diy',
    component: Layout,
    meta: {
      title: '装修',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'page',
        name: 'page',
        component: () => import('@/views/diy/page/index'),
        meta: {
          title: '页面装修',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'Diyedit',
        name: 'Diyedit',
        component: () => import('@/views/diy/page/edit'),
        meta: {
          title: '页面装修',
          icon: 'home-2-line',
          hidden: true,
        },
      },
      {
        path: 'category',
        name: 'category',
        component: () => import('@/views/diy/category/index'),
        meta: {
          title: '页面分类',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'menu',
        name: 'menu',
        component: () => import('@/views/diy/menu/index'),
        meta: {
          title: '底部导航',
          icon: 'home-2-line',
          noClosable: false,
        },
      },

      {
        path: 'menu2',
        name: 'menu2',
        component: () => import('@/views/diy/menu2/index'),
        meta: {
          title: '内页导航',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'shopdetail',
        name: 'shopdetail',
        component: () => import('@/views/diy/shopdetail/index'),
        meta: {
          title: '商品详情',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
      {
        path: 'login',
        name: 'login',
        component: () => import('@/views/diy/login/index'),
        meta: {
          title: '登录页面',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'mobile',
        name: 'mobile',
        component: () => import('@/views/diy/mobile/index'),
        meta: {
          title: '移动端后台',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'share',
        name: 'share',
        component: () => import('@/views/diy/share/index'),
        meta: {
          title: '分享设置',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'chooseurl',
        name: 'chooseurl',
        component: () => import('@/views/diy/chooseurl/index'),
        meta: {
          title: '链接地址',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
    ],
  },
  {
    path: 'diyNew',
    name: 'DiyNew',
    component: Layout,
    meta: {
      title: '装修-新',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'pageNew',
        name: 'pageNew',
        component: () => import('@/views/diyNew/devise/index'),
        meta: {
          title: '页面装修',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
    ],
  },
  {
    path: 'channel',
    name: 'Channel',
    component: Layout,
    meta: {
      title: '渠道',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'index',
        name: 'index',
        component: () => import('@/views/channel/index'),
        meta: {
          title: '全部',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      // {
      //   path: 'mp',
      //   name: 'mp',
      //   meta: {
      //     title: '微信公众号',
      //     guard: ['Admin'],
      //     icon: 'file-list-2-line',
      //   },
      //   children: [
      //     {
      //       path: 'binding',
      //       name: 'binding',
      //       component: () => import('@/views/channel/mp/binding'),
      //       meta: {
      //         title: '公众号绑定',
      //       },
      //     },
      //     {
      //       path: 'mpmenu',
      //       name: 'mpmenu',
      //       component: () => import('@/views/channel/mp/mpmenu'),
      //       meta: {
      //         title: '菜单设置',
      //       },
      //     },
      //     {
      //       path: 'mppay',
      //       name: 'mppay',
      //       component: () => import('@/views/channel/mp/mppay'),
      //       meta: {
      //         title: '支付设置',
      //       },
      //     },
      //     {
      //       path: 'mptmpl',
      //       name: 'mptmpl',
      //       component: () => import('@/views/channel/mp/mptmpl'),
      //       meta: {
      //         title: '模版消息设置',
      //       },
      //     },

      //     {
      //       path: 'tmplsetnew',
      //       name: 'tmplsetnew',
      //       component: () => import('@/views/channel/mp/tmplsetnew'),
      //       meta: {
      //         title: '类目模板消息',
      //       },
      //     },
      //     {
      //       path: 'addmytmpl',
      //       name: 'addmytmpl',
      //       component: () => import('@/views/channel/mp/addmytmpl'),
      //       meta: {
      //         title: '已添加的模板',
      //       },
      //     },
      //     {
      //       path: 'subscribe',
      //       name: 'subscribe',
      //       component: () => import('@/views/channel/mp/subscribe'),
      //       meta: {
      //         title: '被关注回复',
      //       },
      //     },
      //     {
      //       path: 'mpkeyword',
      //       name: 'mpkeyword',
      //       component: () => import('@/views/channel/mp/mpkeyword'),
      //       meta: {
      //         title: '关键字回复',
      //       },
      //     },
      //     {
      //       path: 'fanslist',
      //       name: 'fanslist',
      //       component: () => import('@/views/channel/mp/fanslist'),
      //       meta: {
      //         title: '粉丝列表',
      //       },
      //     },
      //     {
      //       path: 'tmplsend',
      //       name: 'tmplsend',
      //       component: () => import('@/views/channel/mp/tmplsend'),
      //       meta: {
      //         title: '模板消息群发',
      //       },
      //     },
      //   ],
      // },
      // {
      //   path: 'card',
      //   name: 'card',
      //   meta: {
      //     title: '微信会员卡',
      //     guard: ['Admin'],
      //     icon: 'file-list-2-line',
      //   },
      //   children: [
      //     {
      //       path: 'record',
      //       name: 'record',
      //       component: () => import('@/views/channel/card/record'),
      //       meta: {
      //         title: '领取记录',
      //       },
      //     },
      //     {
      //       path: 'index',
      //       name: 'index',
      //       component: () => import('@/views/channel/card/index'),
      //       meta: {
      //         title: '会员卡/创建',
      //       },
      //     },
      //   ],
      // },
      {
        path: 'wx',
        name: 'wx',
        meta: {
          title: '微信小程序',
          guard: ['Admin'],
          icon: 'file-list-2-line',
        },
        children: [
          {
            path: 'binding',
            name: 'binding',
            component: () => import('@/views/channel/wx/binding'),
            meta: {
              title: '小程序绑定',
            },
          },
          {
            path: 'wxpay',
            name: 'wxpay',
            component: () => import('@/views/channel/wx/wxpay'),
            meta: {
              title: '支付设置',
            },
          },

          {
            path: 'tmplset',
            name: 'tmplset',
            component: () => import('@/views/channel/wx/tmplset'),
            meta: {
              title: '订阅消息设置',
            },
          },
          {
            path: 'wxleimu',
            name: 'wxleimu',
            component: () => import('@/views/channel/wx/wxleimu'),
            meta: {
              title: '服务类目',
            },
          },
          {
            path: 'wxurl',
            name: 'wxurl',
            component: () => import('@/views/channel/wx/wxurl'),
            meta: {
              title: '外部链接',
            },
          },
          // {
          //   path: 'wxembedded',
          //   name: 'wxembedded',
          //   component: () => import('@/views/channel/wx/wxembedded'),
          //   meta: {
          //     title: '半屏小程序',
          //   },
          // },
        ],
      },

      // {
      //   path: 'ali',
      //   name: 'ali',
      //   component: () => import('@/views/channel/ali'),
      //   meta: {
      //     title: '支付宝小程序',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'baidu',
      //   name: 'baidu',
      //   component: () => import('@/views/channel/baidu'),
      //   meta: {
      //     title: '百度小程序',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'douyin',
      //   name: 'douyin',
      //   component: () => import('@/views/channel/douyin'),
      //   meta: {
      //     title: '抖音小程序',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'qq',
      //   name: 'qq',
      //   component: () => import('@/views/channel/qq'),
      //   meta: {
      //     title: 'QQ小程序',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'h5',
      //   name: 'h5',
      //   component: () => import('@/views/channel/h5'),
      //   meta: {
      //     title: '手机H5',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'app',
      //   name: 'app',
      //   component: () => import('@/views/channel/app'),
      //   meta: {
      //     title: '手机APP',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
    ],
  },
  {
    path: 'setup',
    name: 'Setup',
    component: Layout,
    meta: {
      title: '系统',
      icon: 'home-2-line',
      breadcrumbHidden: true,
    },
    children: [
      {
        path: 'sysset',
        name: 'sysset',
        component: () => import('@/views/setup/sysset'),
        meta: {
          title: '系统设置',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      // {
      //   path: 'mendian',
      //   name: 'mendian',
      //   component: () => import('@/views/setup/mendian'),
      //   meta: {
      //     title: '门店管理',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      {
        path: 'user',
        name: 'user',
        component: () => import('@/views/setup/user'),
        meta: {
          title: '管理员',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
      {
        path: 'freight',
        name: 'freight',
        component: () => import('@/views/setup/freight'),
        meta: {
          title: '配送方式',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      // {
      //   path: 'expressdata',
      //   name: 'expressdata',
      //   component: () => import('@/views/setup/expressdata'),
      //   meta: {
      //     title: '快递设置',
      //     icon: 'home-2-line',
      //     noClosable: true,
      //   },
      // },
      // {
      //   path: 'shdset',
      //   name: 'shdset',
      //   component: () => import('@/views/setup/shdset'),
      //   meta: {
      //     title: '配送单设置',
      //     icon: 'home-2-line',
      //     noClosable: false,
      //   },
      // },
      {
        path: 'wifiprint',
        name: 'wifiprint',
        component: () => import('@/views/setup/wifiprint'),
        meta: {
          title: '小票打印机',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'sms',
        name: 'sms',
        component: () => import('@/views/setup/sms'),
        meta: {
          title: '短信设置',
          icon: 'home-2-line',
          noClosable: true,
        },
      },
      {
        path: 'plog',
        name: 'plog',
        component: () => import('@/views/setup/plog'),
        meta: {
          title: '操作日志',
          icon: 'home-2-line',
          noClosable: false,
        },
      },
    ],
  },
  // {
  //   path: 'system',
  //   name: 'system',
  //   component: Layout,
  //   meta: {
  //     title: '后管',
  //     icon: 'home-2-line',
  //     breadcrumbHidden: true,
  //   },
  //   children: [
  //     {
  //       path: 'index',
  //       name: 'index',
  //       component: () => import('@/views/system/index'),
  //       meta: {
  //         title: '用户列表',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '服务商',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '支付记录',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '开放平台',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '系统设置',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '附件',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '帮助中心',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },

  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '系统公告',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //     {
  //       path: 'wxpayset',
  //       name: 'wxpayset',
  //       component: () => import('@/views/system/wxpayset'),
  //       meta: {
  //         title: '升级',
  //         icon: 'home-2-line',
  //         noClosable: true,
  //       },
  //     },
  //   ],
  // },
  {
    path: '*',
    redirect: '/404',
    meta: {
      hidden: true,
    },
  },
]

const router = createRouter()

function fatteningRoutes(routes) {
  return routes.flatMap((route) => {
    return route.children ? fatteningRoutes(route.children) : route
  })
}

export function resetRouter(routes = constantRoutes) {
  routes.map((route) => {
    if (route.children) {
      route.children = fatteningRoutes(route.children)
    }
  })
  router.matcher = createRouter(routes).matcher
}

function createRouter(routes = constantRoutes) {
  return new VueRouter({
    base: publicPath,
    mode: routerMode,
    scrollBehavior: () => ({
      y: 0,
    }),
    routes: routes,
  })
}

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err)
}

export default router
