import { FILE_STATUS } from "../constant/device";

export interface UploadFile {
  name: string;
  url: string;
  status: FILE_STATUS;
  extension?: string;
  sn?: string;
  total_page?: number;
}

export enum UploadType {
  PHOTO,
  DOC_WX,
  DOC_PIC,
}

export class UploadUtil {
  private static instance: UploadUtil;

  private uploadFiles: UploadFile[] = [];

  constructor() { }

  public static getInstance(): UploadUtil {
    if (!this.instance) {
      this.instance = new UploadUtil();
    }
    return this.instance;
  }

  /**
   * @description 添加文件
   * @returns 已添加文件总数
  */
  public addFile(file: UploadFile): number {
    this.uploadFiles.push(file);
    return this.uploadFiles.length;
  }

  /**
   * @description 清空文件记录
  */
  public clearFiles(): void {
    this.uploadFiles = [];
  }

  /**
   * @description 获取已添加文件
   * @returns 所有文件信息
  */
  public getAllFiles(): UploadFile[] {
    return this.uploadFiles;
  }

}