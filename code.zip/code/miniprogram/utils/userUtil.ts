import storageUtil from "./storageUtil";
import { USER_INFO } from "../constant/user";

class UserUtil {
  /**
   * @description 判断用户是否登录
   * @returns {boolean}
   */
  checkLogin() {
    const userInfo = storageUtil.getStorageSync(USER_INFO);
    if (userInfo) {
      return true;
    }
    return false;
  }

  /**
   * @description 判断手机号格式
   */
  checkPhone(phone: string) {
    if (phone && phone.length === 11) {
      return true;
    }
    return false;
  }

  /**
   * @description 判断密码
   */
  checkPwd(pwd: string) {
    if (pwd && pwd.length >= 8) {
      return true;
    }
    return false;
  }
}

export default new UserUtil();
