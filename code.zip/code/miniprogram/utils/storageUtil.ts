class Storage {
  getStorageSync(key: string) {
    try {
      return wx.getStorageSync(key);
    } catch (error) {
      console.log(`获取storage失败，key为${key},错误信息为${error}`);
      return false;
    }
  }

  setStorageSync(key: string, data: any) {
    try {
      wx.setStorageSync(key, data);
      console.log(`设置storage成功，key为${key}`);
      return true;
    } catch (error) {
      console.log(`设置storage失败，key为${key},错误信息为${error}`);
      return false;
    }
  }

  removeStorageSync(key: string) {
    try {
      wx.removeStorageSync(key);
      console.log(`删除storage成功，key为${key}`);
      return true;
    } catch (error) {
      console.log(`删除storage失败，key为${key},错误信息为${error}`);
      return false;
    }
  }

  clearStorageSync() {
    try {
      wx.clearStorageSync();
      console.log("删除storage成功");
      return true;
    } catch (error) {
      console.log(`删除storage失败，错误信息为${error}`);
      return false;
    }
  }

  getStorageInfoSync() {
    try {
      return wx.getStorageInfoSync();
    } catch (error) {
      console.log(`获取storage失败, 错误信息为${error}`);
      return false;
    }
  }
}

export default new Storage();
