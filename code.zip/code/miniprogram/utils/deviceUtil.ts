import { COLOR_MODE, COLOR_MODE_TRANSLATE, DUPLEX_SIZE, DUPLEX_SIZE_TRANSLATE, MEDIA_SIZE, MEDIA_SIZE_TRANSLATE, MEDIA_TYPE, PRINTER_ABILITY_KEY, QUALITY_MODE, QUALITY_MODE_TRANSLATE } from "../constant/device";
import { PrinterMediaSize } from "../interface/deviceInterface";
import storageUtil from "./storageUtil";
const Base64 = require("../assets/js/base64.js");

export class DeviceUtil {
  private static instance: DeviceUtil;

  constructor() { }

  public static getInstance(): DeviceUtil {
    if (!this.instance) {
      this.instance = new DeviceUtil();
    }
    return this.instance;
  }

  /**
   * @description 处理接口返回的打印机能力
   * 
   * @param {PrinterMediaSize[]} data PrinterMediaSize数组
  */
  public dealAbilityData(data: PrinterMediaSize[]) {
    const fileMediaSize = this.dealMediaSize(data, MEDIA_TYPE.GCP_MT_PLAIN);
    const photoMediaSize = this.dealMediaSize(data, MEDIA_TYPE.GCP_MT_PHOTO);
    // 发票类型单独处理
    const invoiceMediaSize = fileMediaSize.filter(v => [MEDIA_SIZE.GCP_MS_241_2, MEDIA_SIZE.GCP_MS_241_3].includes(v.media_size));
    const docMediaSize = fileMediaSize.filter(v => ![MEDIA_SIZE.GCP_MS_241_2, MEDIA_SIZE.GCP_MS_241_3].includes(v.media_size))

    const printerAbility = {
      file: {
        ability: docMediaSize,
        mediaSize: this.getMediaSize(docMediaSize)
      },
      invoice: {
        ability: invoiceMediaSize,
        mediaSize: this.getMediaSize(invoiceMediaSize)
      },
      photo: {
        ability: photoMediaSize,
        mediaSize: this.getMediaSize(photoMediaSize)
      },
    }
    storageUtil.setStorageSync(PRINTER_ABILITY_KEY, printerAbility);
    return printerAbility;
  }

  /**
   * @description 获取指定media size
   * 
   * @param {PrinterMediaSize[]} data PrinterMediaSize数组
   * @param {MEDIA_TYPE} type 打印类型：文档/照片
   * @returns {PrinterMediaSize[]} 
   */
  private dealMediaSize(data: PrinterMediaSize[], type: MEDIA_TYPE): PrinterMediaSize[] {
    const mediaSizesClone: PrinterMediaSize[] = JSON.parse(JSON.stringify(data));
    const target = mediaSizesClone.filter(({ media_size, media_types }) => {
      if (!(media_size in MEDIA_SIZE)) {
        return false;
      }
      return media_types.find(({ media_type }) => media_type === type)
    });
    return target.map(mediaSize => {
      mediaSize.media_types = mediaSize.media_types.filter(({ media_type }) => media_type === type)
      return mediaSize;
    }).sort((a, b) => {
      if (a.media_size === MEDIA_SIZE.GCP_MS_A4) {
        return -1;
      }
      return a.media_size_option - b.media_size_option;
    })

  }

  /**
   * @description 处理数据打印机属性，便于页面展示
   * 
   * @param {PrinterMediaSize[]} data PrinterMediaSize数组
   * @param {MEDIA_TYPE} type 打印类型：文档/照片
   */
  public dealAttr(data: PrinterMediaSize[], type: MEDIA_TYPE, idx: number) {
    const mediaType = data[idx].media_types.find(({ media_type }) => media_type === type)
    return {
      mediaSizeOption: data[idx]?.media_size_option,
      mediaTypeOption: mediaType?.media_type_option,
      colorMode: this.getColorMode(data[idx]),
      duplexSize: this.getDuplexSize(data[idx]),
      qualityMode: this.getQualityMode(data[idx]),
      highQuality: mediaType?.high_quality,
      qualityModeOption: mediaType?.quality_mode_option,
      borderless: mediaType?.borderless,
    }
  }

  /**
   * @description 获取纸张大小
   */
  private getMediaSize(mediaSizes: PrinterMediaSize[]) {
    const ret: typeof MEDIA_SIZE_TRANSLATE = []
    mediaSizes.forEach(
      ({ media_size }: PrinterMediaSize) => {
        let tmp = MEDIA_SIZE_TRANSLATE.find((v) => v.value == media_size)
        if (tmp) {
          ret.push(tmp);
        }
      }
    );
    return ret;
  }

  /**
   * @description 获取色彩选择
   */
  private getColorMode(data: PrinterMediaSize) {
    const ret: typeof COLOR_MODE_TRANSLATE = []
    data.media_types[0].color_mode.forEach(
      (v: COLOR_MODE) => {
        const tmp = COLOR_MODE_TRANSLATE.find((vv) => vv.value == v)
        if (tmp) {
          ret.push(tmp)
        }
      }
    )
    return ret;
  }

  /**
   * @description 获取单双面打印
   */
  private getDuplexSize(data: PrinterMediaSize) {
    const ret: typeof DUPLEX_SIZE_TRANSLATE = []
    data.media_types[0].duplex.forEach(
      (v: DUPLEX_SIZE) => {
        const tmp = DUPLEX_SIZE_TRANSLATE.find((vv) => vv.value == v)
        if (tmp) {
          ret.push(tmp)
        }
      }
    )
    return ret;
  }

  /**
   * @description 获取打印质量
   */
  private getQualityMode(data: PrinterMediaSize) {
    const ret: typeof QUALITY_MODE_TRANSLATE = []
    if (data.media_types[0].high_quality) {
      data.media_types[0].quality_mode.forEach(
        (v: QUALITY_MODE) => {
          const tmp = QUALITY_MODE_TRANSLATE.find((vv) => vv.value == v)
          if (tmp) {
            ret.push(tmp)
          }
        }
      )
    }
    if (ret.length) {
      ret.sort((a, b) => {
        if (a.value === QUALITY_MODE.GCP_QM_DRAFT) {
          return -1
        } else if (b.value === QUALITY_MODE.GCP_QM_DRAFT) {
          return 1;
        } else {
          return 0;
        }
      })
    }
    return ret;
  }

  public JIA(message: string) {
    var asciiArray = [];
    for (var i = 0; i < message.length; i++) {
      asciiArray.push(String.fromCharCode(message.charCodeAt(i) + 18));
    }
    return Base64.encode(asciiArray.join(""));
  }

  public JIE(ciphertext: string) {
    const str = Base64.decode(ciphertext);
    var asciiArray = [];
    for (var i = 0; i < str.length; i++) {
      asciiArray.push(String.fromCharCode(str.charCodeAt(i) - 18));
    }
    return asciiArray.join("");
  }

}