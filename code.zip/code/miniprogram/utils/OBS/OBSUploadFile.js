const config = require('./Configuration.js');
const getPolicyEncode = require('./getPolicy.js');
const getSignature = require('./GetSignature.js');

export const getFileName = (filePath) => {
  const pathArr = filePath.split("/");
  const tmpFilename = pathArr[pathArr.length - 1];
  const fileArr = tmpFilename.split(".");
  const ext = fileArr.pop();
  const pre = fileArr.join(".");
  const fileName = pre + "-" + Date.now() + "." + ext; //指定上传到OBS桶中的对象名   
  return fileName;
}

const getExpirationTime = () => {
  let datetime = new Date();
  let timezoneOffset = datetime.getTimezoneOffset() * 60000; // 获取当前时区与UTC的时间差（以毫秒为单位）
  let localDatetime = new Date(datetime - timezoneOffset); // 调整时间，得到当前时区时间
  return localDatetime.toISOString();
}

export const OBSupload = (filePath, fileName, callback) => {
  if (!filePath) {
    wx.showToast({
      title: '文件路径不能为空',
      icon: 'error',
    });
  } else {
    // console.log("expiration", getExpirationTime());
    const OBSPolicy = { //设定policy内容
      "expiration": getExpirationTime(),
      "conditions": [{
          "bucket": "wtcloud-file"
          // "bucket": "wtcloud-driver"
        }, //Bucket name
        {
          'key': fileName
        }
      ]
    }

    const policyEncoded = getPolicyEncode(OBSPolicy); //计算policy编码值
    const signature = getSignature(policyEncoded, config.SecretKey); //计算signature


    wx.uploadFile({
      url: config.EndPoint,
      filePath: filePath,
      name: 'file',
      header: {
        'content-type': 'multipart/form-data; boundary=-9431149156168',
      },
      formData: {
        'AccessKeyID': config.AccessKeyId,
        'policy': policyEncoded,
        'signature': signature,
        'key': fileName,
      },

      success: function (res) {
        if (res.statusCode == '204') {
          console.log('上传图片成功', fileName, res)
          // wx.showToast({
          //   title: '解析成功',
          //   icon: 'success'
          // });
          callback(true);
        } else {
          console.log('上传图片失败', fileName, res)
          // wx.showToast({
          //   title: '解析失败',
          //   icon: 'error'
          // });
          callback(false);
        }
      },
      fail: function (e) {
        console.log(e);
        callback(false);
      }
    })

  }
}