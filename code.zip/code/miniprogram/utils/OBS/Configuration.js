var Configuration = {
  AccessKeyId: 'KEEONREQOLVRPHOLPVYO',      //AK
  SecretKey: 'cxMBxCSkL4s9PNpP7CsTkF0XBHLnA6CHTQFjnqeN',        //SK
  // EndPoint: 'https://wtcloud-driver.obs.cn-east-3.myhuaweicloud.com/',         //上传文件的路径
  EndPoint: 'https://wtcloud-file.obs.cn-east-3.myhuaweicloud.com/',         //上传文件的路径
};

module.exports = Configuration;