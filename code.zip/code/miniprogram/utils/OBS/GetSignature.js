require('../../assets/js/hmac.js');
require('../../assets/js/sha1.js');
const Crypto = require('../../assets/js/crypto.js');
const Base64 = require('../../assets/js/base64.js');

//利用SK计算Signature信息
function getSignature(policyEncoded, SecretKey) {
  const bytes = Crypto.HMAC(Crypto.SHA1, policyEncoded, SecretKey, {
    asBytes: true
  });

  const signature = Crypto.util.bytesToBase64(bytes);
  return signature;
}

module.exports = getSignature;