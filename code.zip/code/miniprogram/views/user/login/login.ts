// views/user/login.ts
import userApi from "../../../apis/userApi";
import { SUCESS_CODE } from "../../../constant/common"
import StorageUtil from "../../../utils/storageUtil";
import { USER_INFO } from "../../../constant/user";
import userUtil from "../../../utils/userUtil";
import { BOX_INFO_KEY } from "../../../constant/device";

Component({

  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    phone: "",
    pwd: "",
    showPwd: false,
    focus: false,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /**
     * @description 登录
     */
    login() {
      if (!this.data.phone) {
        wx.showToast({ icon: "error", title: "账号不能为空" })
        return
      }
      if (!userUtil.checkPhone(this.data.phone)) {
        wx.showToast({ icon: "error", title: "手机号格式错误" })
        return
      }
      if (!this.data.pwd) {
        wx.showToast({ icon: "error", title: "密码不能为空" })
        return
      }
      if (!userUtil.checkPwd(this.data.pwd)) {
        wx.showToast({ icon: "error", title: "密码最短为8位" })
        return
      }
      wx.showLoading({ title: "登录中" })
      userApi.login({ phone_number: this.data.phone, password: this.data.pwd }).then(res => {
        console.log('login-sucess', res);
        if (res.code !== SUCESS_CODE) {
          wx.showToast({ icon: "error", title: "账号密码错误" })
          return
        }
        wx.showToast({ title: "登陆成功" })
        StorageUtil.setStorageSync(USER_INFO, res.data);
        const device_id = res.data.dev_info?.device_id;
        if (device_id) {
          StorageUtil.setStorageSync(BOX_INFO_KEY, {
            device_id,
            title: "智印云盒-" + device_id.substring(device_id.length - 4),
          });
        }

        wx.navigateBack()
      }).catch(err => {
        wx.showToast({ icon: "error", title: "登录失败" })
        console.log('login-err', err);
      })
    },

    /**
     * @description 忘记密码
     */
    forgetPwd() {
      this.triggerEvent('goForgetPwd')
    },

    /**
     * @description 去注册
     */
    register() {
      this.triggerEvent('goRegister')
    },

    /**
     * @description 切换密码 显示/隐藏
     */
    togglePwd() {
      this.setData({
        showPwd: !this.data.showPwd,
        focus: true,
      })
    },
  }
})