// views/user/user.ts
import storageUtil from "../../utils/storageUtil"
import { USER_INFO } from "../../constant/user";

const enum PAGE_STEP {
  LOGIN,
  REGISTER,
  FORGET_PWD,
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    step: PAGE_STEP.LOGIN,
    title: "用户登录"
  },

  /**
 * @description 用户登录
 */
  goLogin() {
    this.setData({ step: PAGE_STEP.LOGIN, title: "用户登录" });
  },

  /**
   * @description 忘记密码
   */
  goForgetPwd() {
    this.setData({ step: PAGE_STEP.FORGET_PWD, title: "忘记密码" });
  },

  /**
   * @description 去注册
   */
  goRegister() {
    this.setData({ step: PAGE_STEP.REGISTER, title: "用户注册" });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    const userInfo = storageUtil.getStorageSync(USER_INFO)
    if (userInfo) {
      wx.switchTab({
        url: '/pages/index/index'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    const userInfo = storageUtil.getStorageSync(USER_INFO)
    if (userInfo) {
      wx.switchTab({
        url: '/pages/index/index'
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})