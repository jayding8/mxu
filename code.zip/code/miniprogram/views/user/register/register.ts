// views/user/register/register.ts
import userApi from "../../../apis/userApi";
import { SUCESS_CODE } from "../../../constant/common"
import userUtil from "../../../utils/userUtil";

Component({

  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    phone: "",
    verificationCode: "",
    pwd: "",
    pwdConfirm: "",
    showPwd: false,
    times: 60,
    showTimes: false,
    focusPwd: false,
    focusPwdC: false,
    privacyAgreementStatus: false,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /**
     * @description 获取验证码
     */
    getCode() {
      if (!this.data.phone) {
        wx.showToast({ icon: "error", title: "请先填写手机号" })
        return
      }
      if (!userUtil.checkPhone(this.data.phone)) {
        wx.showToast({ icon: "error", title: "手机号格式错误" })
        return
      }
      wx.showLoading({ title: "正在获取验证码" })
      this.setData({ showTimes: true })
      const timer = setInterval(() => {
        if (this.data.times <= 0) {
          this.setData({ showTimes: false, times: 60 })
          clearInterval(timer);
          return;
        }
        this.setData({ times: this.data.times - 1 });
      }, 1000)
      userApi.getCode({ phone_number: this.data.phone }).then(res => {
        console.log('getCode-sucess', res);
        if (res.code !== SUCESS_CODE) {
          wx.showModal({ showCancel: false, title: "获取验证码失败", content: res.msg })
          return
        }
      }).catch(err => {
        console.log('getCode-err', err);
      }).finally(() => {
        wx.hideLoading()
      })
    },

    /**
     * @description 注册
     */
    register() {
      if (!this.data.phone) {
        wx.showToast({ icon: "error", title: "账号不能为空" })
        return
      }
      if (!userUtil.checkPhone(this.data.phone)) {
        wx.showToast({ icon: "error", title: "手机号格式错误" })
        return
      }
      if (!this.data.verificationCode) {
        wx.showToast({ icon: "error", title: "验证码不能为空" })
        return
      }
      if (!this.data.pwd || !this.data.pwdConfirm) {
        wx.showToast({ icon: "error", title: "密码不能为空" })
        return
      }
      if (this.data.pwd !== this.data.pwdConfirm) {
        wx.showToast({ icon: "error", title: "两次输入密码不一致" })
        return
      }
      if (!userUtil.checkPwd(this.data.pwd)) {
        wx.showToast({ icon: "error", title: "密码最短为8位" })
        return
      }
      if (!this.data.privacyAgreementStatus) {
        wx.showToast({ icon: "error", title: "请先勾选隐私协议" })
        return
      }
      wx.showLoading({ title: "注册中" })
      userApi.register({ phone_number: this.data.phone, password: this.data.pwd, code: this.data.verificationCode }).then(res => {
        console.log('register-sucess', res);
        if (res.code !== SUCESS_CODE) {
          wx.showModal({ showCancel: false, title: "注册失败", content: res.msg })
          return
        }
        wx.showToast({ title: "注册成功" })
        // wx.navigateBack()
        this.login();
      }).catch(err => {
        wx.showToast({ icon: "error", title: "注册失败" })
        console.log('register-err', err);
      }).finally(() => {
        wx.hideLoading()
      })
    },

    /**
     * @description 登录
     */
    login() {
      this.triggerEvent('goLogin')
    },

    /**
     * @description 切换密码 显示/隐藏
     */
    togglePwd() {
      this.setData({ showPwd: !this.data.showPwd, focusPwd: true, focusPwdC: false })
    },

    /**
     * @description 切换确认密码 显示/隐藏
     */
    togglePwdC() {
      this.setData({ showPwd: !this.data.showPwd, focusPwd: false, focusPwdC: true })
    },

    changeAgreementStatus() {
      this.setData({ privacyAgreementStatus: !this.data.privacyAgreementStatus })
    },

    /**
     * @description 隐私协议
     */
    privacyAgreement() {
      wx.navigateTo({
        url: "/views/user/privacyAgreement/privacyAgreement",
        success: (res) => {
          console.log('success', res);
        },
        fail: (err) => {
          console.log('error', err);
        }
      })
    },
  }
})