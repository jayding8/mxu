import deviceApi from "../../../apis/deviceApi"
import { SUCESS_CODE } from "../../../constant/common";
import { BOX_INFO_KEY, PRINTER_ABILITY_KEY, PRINTER_INFO_KEY } from "../../../constant/device";
import { USER_INFO } from "../../../constant/user";
import { DeviceInfoResult, DeviceStatusResult } from "../../../interface/deviceInterface";
import storageUtil from "../../../utils/storageUtil";

// views/device/detail/detail.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    deviceInfo: <DeviceInfoResult>{},
    deviceStatus: <DeviceStatusResult>{},
    title: "",
  },

  /**
   * @description 获取设备状态
   */
  getDeviceStatus(): void {
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    if (!boxInfo) {
      console.log("无法获取boxinfo，请先蓝牙连接", boxInfo);
      return;
    }
    const param = {
      device_id: boxInfo.device_id,
    };
    deviceApi
      .getDeviceStatus(param)
      .then((res) => {
        console.log("getDeviceStatus-sucess", res);
        if (res.code !== SUCESS_CODE) {
          return;
        }
        this.setData({
          deviceStatus: res.data,
        });
      })
      .catch((err) => {
        console.log("getDeviceStatus-err", err);
      });
  },

  /**
   * @description 获取设备信息
   */
  getDeviceInfo(): void {
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    if (!boxInfo) {
      console.log("无法获取boxinfo，请先蓝牙连接", boxInfo);
      return;
    }
    const param = {
      device_id: boxInfo.device_id,
      force_mqtt: false,
    };
    deviceApi
      .getDeviceInfo(param)
      .then((res) => {
        console.log("getDeviceInfo-sucess", res);
        if (res.code !== SUCESS_CODE) {
          return;
        }
        if (res.data.device_id) {
          const tmpArr = res.data.device_id.split("_");
          res.data.device_id = tmpArr[tmpArr.length - 1];
        }
        this.setData({ deviceInfo: res.data, title: boxInfo?.title });
        storageUtil.setStorageSync(PRINTER_INFO_KEY, {
          make: res.data.printer_make,
          model: res.data.printer_model,
        });
      })
      .catch((err) => {
        console.log("getDeviceInfo-err", err);
      });
  },

  /**
   * @description 解绑设备
   */
  unbindDev() {
    const param = {
      device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
      user_id: storageUtil.getStorageSync(USER_INFO)?.userId,
    };
    if (!param.device_id || !param.user_id) {
      console.log("unbindDev", param);
      return
    }
    deviceApi.unbindDev(param).then(res => {
      console.log("unbindDev-sucess", res);
      if (res.code !== SUCESS_CODE) {
        wx.showToast({ icon: "error", title: "解绑失败" });
        return;
      }
      storageUtil.removeStorageSync(BOX_INFO_KEY);
      storageUtil.removeStorageSync(PRINTER_INFO_KEY);
      storageUtil.removeStorageSync(PRINTER_ABILITY_KEY);
      wx.switchTab({
        url: "/pages/index/index",
      });
    }).catch(err => {
      wx.showToast({ icon: "error", title: "解绑失败" });
      console.log("unbindDev-err", err);
    })
  },

  /**
   * @description 重新配网
   * @returns {void}
   */
  reConnectWifi(): void {
    wx.navigateTo({
      url: "/views/checkBlueToothAuth/checkBlueToothAuth?reConnectWifi=1",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getDeviceStatus();
    this.getDeviceInfo();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})