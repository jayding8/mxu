import deviceApi from "../../../apis/deviceApi";
import { SUCESS_CODE } from "../../../constant/common";
import { BOX_INFO_KEY } from "../../../constant/device";
import { PrintHistoryResult } from "../../../interface/deviceInterface";
import storageUtil from "../../../utils/storageUtil";

// views/device/history/history.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    history: <PrintHistoryResult[]>[],
  },

  /**
   * @description 获取历史记录
   */
  getPrintHistory() {
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    if (!boxInfo) {
      console.log("无法获取boxinfo，请先蓝牙连接", boxInfo);
      return;
    }
    wx.showLoading({ title: "加载中" });
    const param = {
      device_id: boxInfo.device_id,
      limit: 100,
      page: 1
    };
    deviceApi.getPrintHistory(param).then(res => {
      console.log("getPrintHistory-sucess", res);
      this.setData({ history: res.data.data });
      wx.hideLoading()

    }).catch((err) => {
      console.log("getPrintHistory-err", err);
    }).finally(() => {
      wx.hideLoading()
    })
  },

  del(e: any) {
    deviceApi.delPrintHistory(e.currentTarget.dataset.id).finally(() => {
      this.getPrintHistory();
    })
  },

  delAll() {
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    deviceApi.delAllPrintHistory({ device_id: boxInfo.device_id }).finally(() => {
      this.getPrintHistory();
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.getPrintHistory();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})