// views/searchDevice/searchDevice.ts
import deviceApi from "../../apis/deviceApi";
import {
  stringToArrayBuffer,
  arrayBufferToString,
} from "../../utils/arrayBuffer";
import storageUtil from "../../utils/storageUtil";
import { BOX_INFO_KEY, MOBILE_INFO_KEY } from "../../constant/device";
import { SUCESS_CODE } from "../../constant/common";
import { USER_INFO } from "../../constant/user";
import { BindDeviceParam } from "../../interface/deviceInterface";

const READ_INTERVAL_TIME = 2000;
const MAX_READ_TIMES = 15;
const SUCESS = "1";
const enum PAGE_STEP {
  GET_DEVICE,
  GET_WIFI,
  CONNECT_WIFI,
}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    step: PAGE_STEP.GET_DEVICE, // 页面切换
    percent: 0, // 进度条百分比
    showResearch: false, // 是否展示【重新搜索】按钮
    deviceId: "", // 设备uuid
    serviceId: "", // 服务uuid
    characteristicId: "", // 特征值uuid
    timer: 0, // 定时器
    times: 0, // 读取特征值的次数，定时器2秒一次，最多读15次
    wifiName: "", // wifi名
    wifiPwd: "", // wifi密码
    showPwd: false, // 显示输入的wifi密码
    wifiNames: <{ text: string; value: string }[]>[], // 获取附近的所有wifi信息
    showBack: false, // 配网失败时，展示【返回】按钮
    focusPwd: false, // 聚焦密码框
    wifiConnected: false, // 盒子是否已联网
    reConnectWifi: 0, // 重连wifi
  },

  searchDevice() {
    this.openBluetoothAdapter();
    const timer = setInterval(() => {
      if (this.data.percent >= 100) {
        clearInterval(timer);
        this.activeend();
        return
      }
      this.setData({ percent: this.data.percent + 2 });
    }, 200)
  },

  research() {
    wx.closeBluetoothAdapter({
      success: (res) => {
        console.log(res);
      },
    });

    this.setData({
      percent: 0,
      showResearch: false,
    });
    this.searchDevice();
  },

  activeend() {
    if (this.data.percent) {
      this.setData({
        showResearch: true,
      });
    }
  },

  /**
   * @description 初始化蓝牙
   */
  openBluetoothAdapter() {
    wx.openBluetoothAdapter({
      success: (res) => {
        console.log("openBluetoothAdapter-success", res);
        this.startBluetoothDevicesDiscovery();
      },
      fail: (err) => {
        console.log("openBluetoothAdapter-fail", err);
        // 1500102为系统报错，手机蓝牙未开启
        if (err.errno === 1500102) {
          wx.showModal({
            showCancel: false,
            content: "微信无法使用蓝牙，请到系统设置中启用",
          });
        }
      },
    });
  },

  /**
   * @description 开始搜寻附近的蓝牙外围设备。
   */
  startBluetoothDevicesDiscovery() {
    wx.startBluetoothDevicesDiscovery({
      success: (res) => {
        console.log("startBluetoothDevicesDiscovery-sucess", res);
        this.onBluetoothDeviceFound();
      },
      fail: (err) => {
        console.log("startBluetoothDevicesDiscovery-fail", err);
      },
    });
  },

  /**
   * @description 停止搜寻附近的蓝牙外围设备。
   */
  stopBluetoothDevicesDiscovery() {
    wx.stopBluetoothDevicesDiscovery({
      success: (res) => {
        console.log("stopBluetoothDevicesDiscovery-sucess", res);
      },
      fail: (err) => {
        console.log("stopBluetoothDevicesDiscovery-fail", err);
      },
    });
  },

  /**
   * @description 监听搜索到新设备的事件
   */
  onBluetoothDeviceFound() {
    wx.onBluetoothDeviceFound((result) => {
      console.log("found devices", result.devices);
      const device = result.devices.find((v) => v.name.startsWith("A100"));
      if (!device) {
        return;
      }
      this.data.deviceId = device.deviceId;
      this.stopBluetoothDevicesDiscovery();
      this.createBLEConnection();
    });
  },

  /**
   * @description 连接蓝牙低功耗设备。
   */
  createBLEConnection() {
    wx.createBLEConnection({
      deviceId: this.data.deviceId, // 搜索到设备的 deviceId
      success: () => {
        // 连接成功，获取服务
        this.getBLEDeviceServices();
      },
      fail: (err) => {
        console.log(err);
      },
    });
  },

  /**
   * @description 获取蓝牙低功耗设备所有服务 (service)。
   */
  getBLEDeviceServices() {
    wx.getBLEDeviceServices({
      deviceId: this.data.deviceId,
      success: (res) => {
        console.log("getBLEDeviceServices-sucess", res);
        for (let i = 0; i < res.services.length; i++) {
          if (
            res.services[i].uuid.startsWith("00001800") ||
            res.services[i].uuid.startsWith("00001801")
          ) {
            // 安卓上，部分机型获取设备服务时会多出 00001800 和 00001801 UUID 的服务，这是系统行为，注意不要使用这两个服务。
            continue;
          }
          if (res.services[i].isPrimary) {
            this.data.serviceId = res.services[i].uuid;
            this.getBLEDeviceCharacteristics();
          }
        }
      },
      fail: (err) => {
        console.log("getBLEDeviceServices-fail", err);
      },
    });
  },

  /**
   * @description 获取蓝牙低功耗设备某个服务中所有特征 (characteristic)。
   */
  getBLEDeviceCharacteristics() {
    wx.getBLEDeviceCharacteristics({
      deviceId: this.data.deviceId,
      serviceId: this.data.serviceId,
      success: (res) => {
        console.log("getBLEDeviceCharacteristics-sucess", res);
        const target = res.characteristics.find((v) =>
          v.uuid.startsWith("00002BA3")
        );
        if (!target) {
          return;
        }
        this.data.characteristicId = target.uuid;
        this.showAndInitWifi();
      },
      fail: (err) => {
        console.log("getBLEDeviceCharacteristics-fail:", err);
      },
    });
  },

  /**
   * @description 启用蓝牙低功耗设备特征值变化时的 notify 功能，订阅特征。
   */
  notifyBLECharacteristicValueChange() {
    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      deviceId: this.data.deviceId,
      serviceId: this.data.serviceId,
      characteristicId: this.data.characteristicId,
      success: (res) => {
        console.log("notifyBLECharacteristicValueChange-success", res.errMsg);
      },
      fail: (err) => {
        console.log("notifyBLECharacteristicValueChange-fail", err);
      },
      complete: () => {
        this.onBLECharacteristicValueChange();
      },
    });
  },

  /**
   * @description 监听蓝牙低功耗设备的特征值变化事件。
   * 必须先调用 wx.notifyBLECharacteristicValueChange 接口才能接收到设备推送的 notification。
   */
  onBLECharacteristicValueChange() {
    wx.onBLECharacteristicValueChange((res) => {
      const resString = arrayBufferToString(res.value);
      console.log("onBLECharacteristicValueChange", resString, this.data.reConnectWifi);
      const arr = resString.split(",");
      if (arr[arr.length - 1] === SUCESS && !this.data.wifiConnected) {
        wx.showToast({
          title: "WiFi连接成功",
          icon: "success",
          duration: 2000,
        });

        const device_id = arr[0] + "_" + arr[1];
        const boxInfo = {
          title: "智印云盒-" + device_id.substring(device_id.length - 4),
          device_id,
        }
        storageUtil.setStorageSync(BOX_INFO_KEY, boxInfo);

        this.setData({ wifiConnected: true })
        this.clearReadInterval();
        let mobileInfo = storageUtil.getStorageSync(MOBILE_INFO_KEY);
        if (!mobileInfo) {
          mobileInfo = wx.getDeviceInfo();
        }


        const timer = setTimeout(() => {
          if (this.data.reConnectWifi) {
            wx.switchTab({
              url: "/pages/index/index",
            });
          } else {
            wx.showLoading({ title: "设备绑定中，请稍后", mask: true });

            const param: BindDeviceParam = {
              device_id: boxInfo.device_id,
              phone_model: mobileInfo.model as string,
              phone_brand: mobileInfo.brand as string,
              phone_system: mobileInfo.system as string,
              user_id: storageUtil.getStorageSync(USER_INFO)?.userId as number,
            };

            deviceApi
              .bindDev(param)
              .then((bindres) => {
                console.log("bindDev-sucess", param, bindres);

                if (bindres.code !== SUCESS_CODE) {
                  wx.showToast({ icon: "error", title: "设备绑定失败" });
                  this.setData({ showBack: true });
                  storageUtil.removeStorageSync(BOX_INFO_KEY);
                  return;
                }

                wx.showToast({
                  title: "绑定成功",
                  icon: "success",
                  duration: 3000,
                  complete: () => {
                    const timer = setTimeout(() => {
                      wx.switchTab({
                        url: "/pages/index/index",
                      });
                      clearTimeout(timer);
                    }, 3000);

                  },
                });
              })
              .catch((err) => {
                console.log("bindDev-err", err);
                wx.hideLoading();
              });
          }
          clearTimeout(timer);
        }, 2000);
      }
    });
  },

  /**
   * @description 向蓝牙低功耗设备特征值中写入二进制数据。
   */
  writeBLECharacteristicValue() {
    const wifiInfo = { ssid: this.data.wifiName, passwd: this.data.wifiPwd };
    const buffer = stringToArrayBuffer(JSON.stringify(wifiInfo));
    console.log("writeBLECharacteristicValue", buffer, buffer.byteLength);
    const bufferArr: ArrayBuffer[] = [];
    if (buffer.byteLength > 20) {
      const len = Math.ceil(buffer.byteLength / 20);
      for (let i = 0; i < len; i++) {
        bufferArr.push(buffer.slice(i * 20, i * 20 + 20));
      }
    } else {
      bufferArr.push(buffer);
    }
    wx.showLoading({ title: "wifi连接中，请稍后", mask: true });

    for (let ii = 0; ii < bufferArr.length; ii++) {
      const timer = setTimeout(() => {
        wx.writeBLECharacteristicValue({
          deviceId: this.data.deviceId,
          serviceId: this.data.serviceId,
          characteristicId: this.data.characteristicId,
          value: bufferArr[ii],
          success: (res) => {
            console.log("writeBLECharacteristicValue success" + ii, res);
          },
          fail: (err) => {
            console.log("writeBLECharacteristicValue fail" + ii, err);
            if (err.errCode === 10006 && err.errno === 1509003) {
              // wx.showModal({ showCancel: false, title: "配网失败", content: "请检查盒子通电状态" })
            }
          },
          complete: () => {
            clearTimeout(timer);
          },
        });
      }, ii * 200);
    }
  },

  /**
   * @description 读取蓝牙低功耗设备特征值的二进制数据。
   */
  readBLECharacteristicValue() {
    wx.readBLECharacteristicValue({
      deviceId: this.data.deviceId,
      serviceId: this.data.serviceId,
      characteristicId: this.data.characteristicId,
      success: (res) => {
        console.log("readBLECharacteristicValue-sucess", res);
      },
    });
  },

  /**
   * @description 清除定时器
   */
  clearReadInterval() {
    if (this.data.timer) {
      this.data.times = 0;
      clearInterval(this.data.timer);
    }
  },

  showAndInitWifi() {
    this.setData({ step: PAGE_STEP.GET_WIFI });
    this.getConnectedWifi();
  },

  /**
   * @description 查看wifi权限
   */
  _checkWifiAuth() {
    // 检查系统wifi是否已开启
    const systemSetting = wx.getSystemSetting();
    console.log("systemSetting", systemSetting);
    if (!systemSetting.wifiEnabled) {
      wx.showModal({
        showCancel: false,
        content: "您的手机未开启wifi功能，请先开启wifi",
      });
      return false;
    }
    return true;
  },

  /**
   * @description 获取当前设备连接的wifi信息
   */
  getConnectedWifi() {
    if (!this._checkWifiAuth()) {
      return;
    }
    wx.startWifi({
      success: (resStartWifi) => {
        console.log(resStartWifi.errMsg);
        wx.getConnectedWifi({
          partialInfo: true,
          success: ({ wifi }) => {
            console.log(wifi);
            this.setData({ wifiName: wifi.SSID });
          },
          fail: (err) => {
            console.log(err);
          },
        });
      },
      fail: (err) => {
        console.log(err);
      },
    });
  },

  /**
   * @description 确认选择wifi后的回调处理
   */
  selectedWifi(res: any) {
    this.setData({ wifiName: res.detail.value, wifiNames: [] });
  },

  /**
   * @description 获取wifi列表
   */
  _getWifiList() {
    wx.showLoading({ title: "获取附近wifi列表中", mask: true })
    wx.getWifiList({
      success: (res) => {
        console.log(res);
      },
      fail: (err) => {
        console.log(err);
      },
    });
    wx.onGetWifiList(({ wifiList }) => {
      console.log(wifiList);
      this.setData({
        wifiNames: wifiList.map((v) => {
          if (!v.SSID) {
            v.SSID = "未知";
          }
          return { text: `${v.SSID}`, value: v.SSID };
        }),
      });
      wx.hideLoading();
      wx.offGetWifiList();
    });
  },

  /**
   * @description 用户自定义选择wifi时，触发的方法
   */
  chooseWifi() {
    // 校验用户是否授权了小程序使用位置信息
    wx.getSetting({
      success: ({ authSetting }) => {
        if (!authSetting["scope.userLocation"]) {
          // 设置界面只会出现小程序已经向用户请求过的权限。所以需要先调用authorize
          wx.authorize({
            scope: "scope.userLocation",
            success: (res) => {
              console.log("authorize-success", res);
              this._getWifiList();
            },
            fail: (err) => {
              console.log("authorize-fail", err);
              wx.showModal({
                title: "请先授权小程序获取位置信息,否则功能无法使用",
                success: (res) => {
                  if (res.confirm) {
                    wx.openSetting({
                      success: ({ authSetting }) => {
                        console.log(authSetting);
                        this._getWifiList();
                      },
                    });
                  } else if (res.cancel) {
                    console.log("用户取消位置信息授权");
                  }
                },
                fail: () => {
                  console.log("授权提示弹窗打开失败");
                },
              });
            },
          });
        } else {
          this._getWifiList();
        }
      },
    });
  },

  /**
   * @description 切换密码 显示/隐藏
   */
  togglePwd() {
    this.setData({ showPwd: !this.data.showPwd, focusPwd: true });
  },

  /**
   * @description 设备配网
   */
  nextStep() {
    this.setData({ step: PAGE_STEP.CONNECT_WIFI });
    this.deviceConnectWifi();
  },

  /**
   * @description 蓝牙设备连接wifi
   */
  deviceConnectWifi() {
    this.notifyBLECharacteristicValueChange();
    this.writeBLECharacteristicValue();
    wx.nextTick(() => {
      this.data.timer = setInterval(() => {
        if (this.data.times >= MAX_READ_TIMES) {
          this.clearReadInterval();
          this.setData({ showBack: true });
          wx.showModal({
            title: "提示",
            content: "配网失败，请返回检查wifi密码是否正确",
            success: (res) => {
              if (res.confirm) {
                this.goBack();
              }
            },
            complete: () => {
              wx.hideLoading();
            }
          });
          return;
        }
        this.readBLECharacteristicValue();
        this.data.times++;
      }, READ_INTERVAL_TIME);
    });
  },

  /**
   * @description 蓝牙设备连接wifi
   */
  goBack() {
    this.setData({ step: PAGE_STEP.GET_WIFI, wifiConnected: false });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    if (option && option.reConnectWifi) {
      this.setData({
        reConnectWifi: parseInt(option.reConnectWifi)
      })
    }
    wx.getSetting({
      success: ({ authSetting }) => {
        if (!authSetting["scope.userLocation"]) {
          // 设置界面只会出现小程序已经向用户请求过的权限。所以需要先调用authorize
          wx.authorize({
            scope: "scope.userLocation",
            success: (res) => {
              console.log("authorize-success", res);
              // this._getWifiList()
            },
            fail: (err) => {
              console.log("authorize-fail", err);
              wx.showModal({
                title: "请先授权小程序获取位置信息,否则功能无法使用",
                success: (res) => {
                  if (res.confirm) {
                    wx.openSetting({
                      success: ({ authSetting }) => {
                        console.log(authSetting);
                      },
                    });
                  } else if (res.cancel) {
                    console.log("用户取消位置信息授权");
                  }
                },
                fail: () => {
                  console.log("授权提示弹窗打开失败");
                },
              });
            },
          });
        } else {
          // this._getWifiList()
        }
      },
    });
    this.searchDevice();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() { },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() { },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() { },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    wx.closeBluetoothAdapter({
      success: (res) => {
        console.log("closeBluetoothAdapter-sucess", res);
      },
    });
    this.clearReadInterval();
    wx.stopWifi();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() { },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() { },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() { },
});
