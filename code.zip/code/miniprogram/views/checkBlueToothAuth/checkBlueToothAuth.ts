// views/checkBlueToothAuth/checkBlueToothAuth.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bluetoothAuth: false,
    reConnectWifi: 0,
  },

  searchBluetooth() {
    this._checkBluetoothAuth()
    if (!this.data.bluetoothAuth) {
      return
    }
    wx.navigateTo({
      url: `/views/searchDevice/searchDevice?reConnectWifi=${this.data.reConnectWifi}`,
      success: (res) => {
        console.log('success', res);
      },
      fail: (err) => {
        console.log('error', err);
      }
    })
  },

  /**
   * @description 校验蓝牙权限
   */
  _checkBluetoothAuth() {
    // 检查系统蓝牙是否已开启
    const systemSetting = wx.getSystemSetting()
    console.log('systemSetting', systemSetting);
    if (!systemSetting.bluetoothEnabled) {
      wx.showModal({
        showCancel: false,
        content: '您的手机未开启蓝牙功能，请到系统设置中启用'
      })
      return
    }
    // 校验用户是否授权了小程序使用蓝牙权限
    wx.getSetting({
      success: ({ authSetting }) => {
        if (!authSetting['scope.bluetooth']) {
          // 设置界面只会出现小程序已经向用户请求过的权限。所以需要先调用authorize
          wx.authorize({
            scope: 'scope.bluetooth',
            success: (res) => {
              console.log('authorize-success', res);
              this.data.bluetoothAuth = true
            },
            fail: (err) => {
              console.log('authorize-fail', err);
              wx.showModal({
                title: "请先授权小程序使用蓝牙功能,否则功能无法使用",
                success: (res) => {
                  if (res.confirm) {
                    wx.openSetting({
                      success: ({ authSetting }) => {
                        this.data.bluetoothAuth = !!authSetting["scope.bluetooth"]
                      }
                    })
                  } else if (res.cancel) {
                    console.log('用户取消蓝牙授权')
                  }
                },
                fail: () => {
                  console.log("授权提示弹窗打开失败");
                },
              })
            }
          })
        } else {
          this.data.bluetoothAuth = true
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    if (option && option.reConnectWifi) {
      this.setData({
        reConnectWifi: parseInt(option.reConnectWifi)
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    this._checkBluetoothAuth()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})