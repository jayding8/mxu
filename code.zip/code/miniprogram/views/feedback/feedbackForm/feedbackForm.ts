import deviceApi from "../../../apis/deviceApi"
import { SUCESS_CODE } from "../../../constant/common"
import { BOX_INFO_KEY, PRINTER_INFO_KEY } from "../../../constant/device"
import { USER_INFO } from "../../../constant/user"
import { FeedbackParam } from "../../../interface/deviceInterface"
import storageUtil from "../../../utils/storageUtil"

// views/feedback/feedbackForm/feedbackForm.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    category: [
      { value: 1, label: "账号与登录问题" },
      { value: 2, label: "盒子设备问题" },
      { value: 3, label: "打印问题" },
      { value: 4, label: "系统问题" },
      { value: 5, label: "其他" },
    ],
    categoryIndex: 0,
    content: "",
  },

  /**
   * @description 选择分类
   */
  changeCategory(e: any) {
    this.setData({ categoryIndex: e.detail.value })
  },

  /**
   * @description 提交反馈意见
   */
  submitFeedback() {
    if (!this.data.content) {
      wx.showToast({ title: "请先填写内容", icon: "error" })
      return
    }
    const print = storageUtil.getStorageSync(PRINTER_INFO_KEY);
    const param: FeedbackParam = {
      user: storageUtil.getStorageSync(USER_INFO)?.userId,
      name: this.data.category[this.data.categoryIndex].label,
      content: this.data.content,
      device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
      printer_make: print?.make,
      printer_model: print?.model,
    };
    deviceApi.feedback(param).then(res => {
      console.log("submitFeedback-sucess", res);
      if (res.code !== SUCESS_CODE) {
        wx.showToast({ icon: "error", title: "问题提交失败" });
        return;
      }
      wx.showToast({
        title: "提交成功", duration: 3000, complete: () => {
          const timer = setTimeout(() => {
            clearTimeout(timer);
            wx.navigateBack();
          }, 3000)
        }
      });
      return
    }).catch(err => {
      console.log("submitFeedback-err", err);
      wx.showToast({ icon: "error", title: "问题提交失败" });
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})