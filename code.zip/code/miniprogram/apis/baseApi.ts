import { USER_INFO } from "../constant/user";
import storageUtil from "../utils/storageUtil";

enum METHOD {
  GET = "GET",
  POST = "POST",
  PUT = "PUT",
  DELETE = "DELETE",
}

class BaseApi {
  protected host = "https://wtcloudbox.cn";
  protected path = "/app/api";
  protected version = "/v1";
  protected url = "";

  constructor() { }

  private service<T>(
    method: METHOD,
    url: string,
    data?: {},
    header?: any
  ): Promise<T> {
    console.log("service", url, data);
    if (!header) {
      header = { "content-type": "application/json" }
    }
    Object.assign(header, { "x-token": storageUtil.getStorageSync(USER_INFO)?.access })
    return new Promise((resolve, reject) => {
      wx.request({
        method,
        url,
        data,
        timeout: 15000,
        header: header ?? {
          "content-type": "application/json",
        },
        success(res) {
          resolve(res.data);
        },
        fail(err) {
          reject(err);
        },
      });
    });
  }

  protected get<T>(url: string) {
    return this.service<T>(METHOD.GET, url);
  }

  protected delete<T extends {}, U>(url: string, data?: T) {
    return this.service<U>(METHOD.DELETE, url, data);
  }

  protected post<T extends {}, U>(url: string, data?: T) {
    return this.service<U>(METHOD.POST, url, data);
  }

  protected put<T extends {}, U>(url: string, data?: T) {
    return this.service<U>(METHOD.PUT, url, data);
  }

  protected getQueryString(param: any) {
    let str = "";
    for (const key in param) {
      if (Object.prototype.hasOwnProperty.call(param, key)) {
        str += `${key}=${param[key]}&`;
      }
    }
    return encodeURI(str.replace(/&$/, ""));
  }
}

export default BaseApi;
