import BaseApi from "./baseApi";
import { CommonResult, CommonResultWithPage } from "../interface/commonInterface";
import {
  BindDeviceParam,
  BindDeviceResult,
  DeviceInfoParam,
  DeviceInfoResult,
  PrinterAbilityParam,
  PrinterAbilityResult,
  CreateJobParam,
  CreateJobResultItem,
  UnBindDeviceParam,
  UnBindDeviceResult,
  DeviceStatusParam,
  DeviceStatusResult,
  PrintHistoryParam,
  PrintHistoryResult,
  FeedbackParam,
  FeedbackResult,
  PrintStatusParam,
  PrintStatusResult,
  CreateConvertJobParam,
} from "../interface/deviceInterface";
import storageUtil from "../utils/storageUtil";
import { BIN_OPTION, PRINTER_ABILITY_GROUP_KEY } from "../constant/device";
import { DeviceUtil } from "../utils/deviceUtil";

class DeviceApi extends BaseApi {
  constructor() {
    super();
    this.url = this.host + this.path + this.version;
  }

  /**
   * @description 设备绑定
   */
  bindDev(data: BindDeviceParam) {
    return this.post<BindDeviceParam, CommonResult<BindDeviceResult>>(
      `${this.url}/dev_bind/`,
      data
    );
  }

  /**
   * @description 查询设备状态
   */
  getDeviceStatus(data: DeviceStatusParam) {
    return this.get<CommonResult<DeviceStatusResult>>(
      `${this.url}/device_heartbeat/?${this.getQueryString(data)}`
    );
  }

  /**
   * @description 查询设备信息详情
   */
  getDeviceInfo(data: DeviceInfoParam) {
    return this.get<CommonResult<DeviceInfoResult>>(
      `${this.url}/client_info/?${this.getQueryString(data)}`
    );
  }

  /**
   * @description 查询打印机能力
   */
  getPrinterAbility(data: PrinterAbilityParam) {
    return this.get<PrinterAbilityResult>(
      `${this.url}/capability/?${this.getQueryString(data)}`
    );
  }

  /**
   * @description 上传文件
   */
  uploadJobFile() {
    return this.post(`${this.url}/upload_job_files/`, "");
  }

  /**
   * @description 创建转化任务
   */
  createConvertJob(data: CreateConvertJobParam) {
    return this.post<CreateConvertJobParam, CommonResult<CreateJobResultItem>>(`${this.url}/upload_convert_file/`, data);
  }

  /**
   * @description 创建打印任务
   */
  createJob(data: CreateJobParam) {
    data.win_json.bin_option = storageUtil.getStorageSync(BIN_OPTION);
    const group = storageUtil.getStorageSync(PRINTER_ABILITY_GROUP_KEY);
    data.group = group ? group : 1;
    console.log("createJob-createJob", data);
    return this.post<{ key: string }, CommonResult<CreateJobResultItem>>(
      `${this.url}/create_job/`,
      { key: DeviceUtil.getInstance().JIA(JSON.stringify(data)) }
    );
  }

  /**
   * @description 查询打印任务信息
   */
  getPrintStatus(data: PrintStatusParam) {
    return this.get<CommonResult<PrintStatusResult>>(`${this.url}/print_status/?${this.getQueryString(data)}`);
  }

  /**
   * @description 解绑设备
  */
  unbindDev(data: UnBindDeviceParam) {
    return this.post<UnBindDeviceParam, CommonResult<UnBindDeviceResult>>(`${this.url}/dev_unbind/`, data);
  }

  /**
   * @description 打印记录
  */
  getPrintHistory(data: PrintHistoryParam) {
    return this.get<CommonResultWithPage<PrintHistoryResult[]>>(`${this.url}/print_history/?${this.getQueryString(data)}`);
  }

  /**
   * @description 删除单条打印记录
  */
  delPrintHistory(id: string) {
    return this.delete<{}, CommonResult<PrintHistoryResult[]>>(`${this.url}/delete_job/${id}/`);
  }

  /**
   * @description 删除全部打印记录
  */
  delAllPrintHistory(data: { device_id: string }) {
    return this.delete<{}, CommonResult<PrintHistoryResult[]>>(`${this.url}/job_clear/`, data);
  }

  /**
   * @description 意见反馈
  */
  feedback(data: FeedbackParam) {
    return this.post<FeedbackParam, CommonResult<FeedbackResult>>(`${this.url}/feedback/`, data);
  }
}

export default new DeviceApi();
