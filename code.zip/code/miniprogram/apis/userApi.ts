import BaseApi from "./baseApi";
import { CommonResult } from "../interface/commonInterface";
import {
  ForgetParam,
  GetCodeParam,
  LoginParam,
  LoginResultItem,
  RegisterParam,
  RegisterResultItem,
} from "../interface/userInterface";

class UserApi extends BaseApi {
  constructor() {
    super();
    this.path = "/login/api";
    this.url = this.host + this.path + this.version;
  }

  /**
   * @description 用户登录
   * @returns CommonResult<LoginResultItem>
   */
  login(data: LoginParam) {
    return this.post<LoginParam, CommonResult<LoginResultItem>>(
      `${this.url}/passwordLogin/`,
      data
    );
  }

  /**
   * @description 获取验证码
   * @returns CommonResult<GetCodeResultItem>
   */
  getCode(data: GetCodeParam) {
    return this.post<GetCodeParam, CommonResult<null>>(
      `${this.url}/send_code/`,
      data
    );
  }

  /**
   * @description 用户注册
   * @returns CommonResult<RegisterResultItem>
   */
  register(data: RegisterParam) {
    return this.post<RegisterParam, CommonResult<RegisterResultItem>>(
      `${this.url}/user/`,
      data
    );
  }

  /**
   * @description 重置密码
   * @returns CommonResult<RegisterResultItem>
   */
  forgetpwd(data: ForgetParam) {
    return this.put<ForgetParam, CommonResult<RegisterResultItem>>(
      `${this.url}/user/`,
      data
    );
  }
}

export default new UserApi();
