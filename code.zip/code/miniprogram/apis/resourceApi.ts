import BaseApi from "./baseApi";
import { CommonResultWithPage } from "../interface/commonInterface";
import {
  ResourceCategoryParam,
  ResourceCategoryResultItem,
  ResourceParam,
  ResourceResultItem
} from "../interface/resourceInterface";

class ResourceApi extends BaseApi {
  constructor() {
    super();
    this.url = this.host + this.path + this.version;
  }

  /**
   * @description 查询资源库分类
   */
  getResourceCategory(data: ResourceCategoryParam) {
    return this.get<CommonResultWithPage<ResourceCategoryResultItem[]>>(
      `${this.url}/material_category/?${this.getQueryString(data)}`
    );
  }

  /**
   * @description 查询指定资源库资源
   */
  getResource(data: ResourceParam) {
    return this.get<CommonResultWithPage<ResourceResultItem[]>>(
      `${this.url}/material/?${this.getQueryString(data)}`
    );
  }
}

export default new ResourceApi();
