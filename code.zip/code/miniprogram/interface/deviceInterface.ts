import { COLOR_MODE, DUPLEX_SIZE, MEDIA_SIZE, MEDIA_TYPE, QUALITY_MODE } from "../constant/device";

// 设备绑定：入参
export interface BindDeviceParam {
  device_id: string;
  phone_model?: string;
  phone_brand?: string;
  phone_system?: string;
  user_id: number;
}

// 设备绑定：返回值
export interface BindDeviceResult {
  uid: string;
  device_secret: string;
  bind_time: string;
}

// 查询设备状态：入参
export interface DeviceStatusParam {
  device_id: string;
}

// 查询设备状态：返回值
export interface DeviceStatusResult {
  dev_online: boolean;
  printer_connect: boolean;
}

// 查询设备信息：入参
export interface DeviceInfoParam {
  device_id: string;
  force_mqtt?: boolean;
}

// 查询设备信息：返回值
export interface DeviceInfoResult {
  device_id?: string;
  alive: boolean;
  printer_connect: boolean;
  printer_support: boolean;
  printer_make: string;
  printer_model: string;
  device_version: string;
  local_ip?: string;
  wifi_ssid?: string;
  network_proto?: string;
  mqtt?: boolean;
  use_ipp_driver?: boolean;
  printer_state?: number;
  printer_state_reasons?: string;
  escl?: boolean;
}

export interface DeviceInfoResult {
  alive_name?: string;
}

// 查询打印机能力：入参
export interface PrinterAbilityParam {
  make: string;
  model: string;
  ipp?: boolean;
}

// 查询打印机能力：返回值
export interface PrinterAbilityResult {
  code: number;
  msg: string;
  capability: PrinterAbilityResultItem[];
}

export interface PrinterAbilityResultItem {
  id: number;
  auto_cap: string;
  raw_cap: string;
  manual_cap: string;
  group: number;
}

export interface PrinterMediaSize {
  media_size: MEDIA_SIZE;
  media_size_option: number;
  media_types: PrinterMediaType[];
}

export interface PrinterMediaType {
  borderless: false;
  color_mode: COLOR_MODE[];
  duplex: DUPLEX_SIZE[];
  high_quality: boolean;
  media_type: MEDIA_TYPE;
  media_type_option: number;
  quality_mode: QUALITY_MODE[];
  quality_mode_option: { [prop: string]: string }
}

// 创建转化任务：入参
export interface CreateConvertJobParam {
  file_url: string;
  filen_ame: string;
  paper_size: string;
  sn: string;
  // [property: string]: any;
}

// 创建转化任务：返回值
export interface CreateConvertJobResult {

}

// 创建打印任务
export interface CreateJobParam {
  benchmark?: boolean;
  borderless?: boolean;
  callback_url?: string;
  color_mode?: string;
  device_id: string;
  device_secret: string;
  duplex?: string;
  end_page?: number;
  file_type: string;
  high_quality?: boolean;
  make?: string;
  media_size: string;
  media_type: string;
  model?: string;
  number: number;
  out_sn: string;
  quality_mode?: string;
  reverse_order?: boolean;
  start_page?: number;
  timeout?: number;
  url: string;
  win_driver?: boolean;
  group?: number;
  win_json: {
    media_size_option?: number;
    media_type_option?: number;
    quality_mode_option?: number;
    fitToWidth?: number;
    fitToHeight?: number;
    is_all?: boolean;
    is_image_to_pdf?: boolean;
    bin_option?: any;
    rotate?: number; // 图片特有，旋转
    odd_or_even?: number;
    dm_orientation?: number;
    stretchMode?: number;
    exposureValue?: boolean;
  };
  file_name: string;
}

export interface CreateJobResultItem {
  sn: string;
  out_sn: string;
  state: string;
}

// 打印状态：入参
export interface PrintStatusParam {
  sn: string;
}

// 打印状态：返回值
export interface PrintStatusResult {
  id: number;
  out_sn: string;
  sn: string;
  state: string;
}

// 设备解绑：入参
export interface UnBindDeviceParam {
  device_id: string;
  user_id: number;
}

// 设备解绑：返回值
export interface UnBindDeviceResult {
  // uid: string;
  // device_secret: string;
  // bind_time: string;
}

// 打印记录：入参
export interface PrintHistoryParam {
  device_id: string;
  limit: number;
  page: number;
  // user_id: number;
}

// 打印记录：返回值
export interface PrintHistoryResult {
  id: number;
  created_at: string;
  file_name: string;
  file_type: string;
  media_size: MEDIA_SIZE;
  media_type: MEDIA_TYPE;
  number: number;
  url: string;
  color_mode: COLOR_MODE;
  duplex: DUPLEX_SIZE;
  borderless: boolean;
  state: string;
}

// 意见反馈：入参
export interface FeedbackParam {
  user: string;
  name: string;
  content: string;
  device_id?: string;
  printer_make?: string;
  printer_model?: string;
}

// 意见反馈：返回值
export interface FeedbackResult {
  // uid: string;
  // device_secret: string;
  // bind_time: string;
}