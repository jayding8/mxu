import { DeviceInfoResult } from "./deviceInterface";

export interface LoginParam {
  phone_number: string;
  password: string;
}

export interface LoginResultItem {
  access: string;
  dev_info: DeviceInfoResult;
  phone_number: string;
  refresh: string;
  user_id: number;
}

export interface GetCodeParam {
  phone_number: string;
}

export interface RegisterParam {
  phone_number: string;
  code: string;
  password: string;
}

export interface RegisterResultItem {
  // phone_number: number,
}

export interface ForgetParam {
  phoneNumber: string;
  code: string;
  newPassword: string;
  newPassword2: string;
}

export interface ServiceInfo {
  logo?: string;
  name?: string;
  status?: number;
  status_name?: string;
}
