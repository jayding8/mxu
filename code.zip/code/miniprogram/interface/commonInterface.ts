export interface CommonResult<T> {
  code: number;
  msg: string;
  data: T;
}

export interface CommonResultWithPage<T> {
  code: number;
  msg: string;
  data: {
    data: T;
    limit: number;
    page: number;
    total: number;
  };

}
