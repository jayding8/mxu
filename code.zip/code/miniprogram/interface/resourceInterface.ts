// 资源库分类：入参
export interface ResourceCategoryParam {
  page?: number;
  limit?: number;
}

// 资源库分类：返回值
export interface ResourceCategoryResultItem {
  id: number;
  name: string;
}

// 资源库：入参
export interface ResourceParam {
  category: number;
  page?: number;
  limit?: number;
}

// 资源库：返回值
export interface ResourceResultItem {
  id: string;
  name: string;
  url: string;
  description: string;
  thumbnail: string;
  extension?: string;
}