// pages/index/uploadDoc/invoice.ts
import deviceApi from "../../../apis/deviceApi";
import { SUCESS_CODE } from "../../../constant/common";
import {
  PRINTER_INFO_KEY,
  MEDIA_TYPE,
  MEDIA_SIZE,
  BOX_INFO_KEY,
  DUPLEX_SIZE,
  PRINTER_ABILITY_KEY,
  DUPLEX_SIZE_TRANSLATE,
} from "../../../constant/device";
import { USER_INFO } from "../../../constant/user";
import { CreateJobParam } from "../../../interface/deviceInterface";
import { DeviceUtil } from "../../../utils/deviceUtil";
import storageUtil from "../../../utils/storageUtil";

Page({
  /**
   * 页面的初始数据
   */
  data: {
    docUrl: "",
    docName: "",
    extension: "",
    printerAbility: <any[]>[],
    num: 1,
    mediaSize: <{ value: MEDIA_SIZE; label: string; }[]>[],
    mediaSizeIndex: 0,
    mediaSizeOption: 0,
    mediaTypeOption: 0,
    duplexSize: <{ value: DUPLEX_SIZE; label: string; }[]>[],
    duplexSizeIndex: 0,
  },

  /**
   * @description 获取打印能力
   */
  getPrinterAbility(idx: number) {
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY);
    if (!printerAbility || !printerAbility.invoice || !printerAbility.invoice.ability) {
      wx.showToast({ icon: "error", title: "获取能力失败" });
      return
    }
    const attr = DeviceUtil.getInstance().dealAttr(printerAbility.invoice.ability, MEDIA_TYPE.GCP_MT_PLAIN, idx);
    this.setData({
      mediaSizeIndex: idx,
      duplexSizeIndex: 0,
      printerAbility: printerAbility.invoice.ability,
      mediaSize: printerAbility.invoice.mediaSize,
      mediaSizeOption: attr.mediaSizeOption,
      mediaTypeOption: attr.mediaTypeOption,
      duplexSize: DUPLEX_SIZE_TRANSLATE.filter(v => [DUPLEX_SIZE.FIT_TO_WIDTH, DUPLEX_SIZE.FIT_TO_HEIGHT].includes(v.value)),
    });
  },

  /**
   * @description 纸张大小变更时，重置页面参数
   */
  changeMediaSize(e: any) {
    const index = e.detail.value;
    console.log('changeMediaSize', index);
    this.getPrinterAbility(index);
  },

  /**
   * @description 双面打印
   */
  changeDuplexSize(e: any) {
    this.setData({
      duplexSizeIndex: e.detail.value,
    });
  },

  /**
   * @description 点击按钮，上传文件，创建打印任务
   */
  createPrintJob() {
    const num = Number(this.data.num)
    if (Number.isNaN(num) || num < 1 || num > 50) {
      wx.showModal({ icon: "error", title: "打印份数错误", content: "请输入1 ~ 50之间的数字", showCancel: false })
      return
    }
    let deviceInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
    const param: CreateJobParam = {
      url: this.data.docUrl,
      file_name: this.data.docName ? this.data.docName : "",
      device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
      file_type: this.data.extension,
      media_size: this.data.mediaSize[this.data.mediaSizeIndex].value,
      media_type: "GCP_MT_PLAIN",
      number: this.data.num,
      device_secret: Date.now() + "",
      out_sn: Date.now() + "",
      make: deviceInfo?.make,
      model: deviceInfo?.model,
      win_json: {
        media_size_option: this.data.mediaSizeOption,
        media_type_option: this.data.mediaTypeOption,
      },
    };

    const curDuplexSize = this.data.duplexSize[this.data.duplexSizeIndex].value;
    if (param.win_json) {
      if (curDuplexSize == DUPLEX_SIZE.FIT_TO_WIDTH) {
        param.win_json.fitToWidth = 1
      } else if (curDuplexSize == DUPLEX_SIZE.FIT_TO_HEIGHT) {
        param.win_json.fitToHeight = 1
      }
    }

    deviceApi
      .createJob(param)
      .then((createRes) => {
        console.log("createJob-res", createRes);
        if (createRes.code !== SUCESS_CODE) {
          wx.showToast({ icon: "error", title: "打印失败" })
          return;
        }
        wx.showToast({
          title: "提交打印成功", complete: () => {
            wx.navigateTo({
              url: "/pages/index/uploadResult/uploadResult?sn=" + createRes.data.sn,
              success: (res) => {
                console.log("success", res);
              },
              fail: (err) => {
                console.log("error", err);
              },
            });
          }
        })

      })
      .catch((err) => {
        console.log("createJob-err", err);
      });

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    this.getPrinterAbility(0);
    if (option.file) {
      const ext: string[] = option.file.split(".");
      this.setData({
        docUrl: option.file,
        docName: option.name,
        extension: ext[ext.length - 1],
      });
    }
  },

});

