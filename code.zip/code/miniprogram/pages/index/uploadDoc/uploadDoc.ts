// pages/index/uploadDoc/uploadDoc.ts
import deviceApi from "../../../apis/deviceApi";
import { SUCESS_CODE } from "../../../constant/common";
import {
  PRINTER_INFO_KEY,
  MEDIA_TYPE,
  COLOR_MODE,
  MEDIA_SIZE,
  BOX_INFO_KEY,
  DUPLEX_SIZE,
  QUALITY_MODE,
  PRINTER_ABILITY_KEY,
  MEDIA_SIZE_TRANSLATE,
  DM_ORIENTATION_TRANSLATE,
  ODD_OR_EVEN_TRANSLATE,
  ODD_OR_EVEN,
  DUPLEX_SIZE_TRANSLATE,
  HISTORY_PARAM,
} from "../../../constant/device";
import { USER_INFO } from "../../../constant/user";
import { CreateJobParam } from "../../../interface/deviceInterface";
import { DeviceUtil } from "../../../utils/deviceUtil";
import storageUtil from "../../../utils/storageUtil";

Page({
  /**
   * 页面的初始数据
   */
  data: {
    docUrl: "",
    docName: "",
    extension: "",
    printerAbility: <any[]>[],
    num: 1,
    mediaSize: <{ value: MEDIA_SIZE; label: string; }[]>[],
    mediaSizeIndex: 0,
    mediaSizeOption: 0,
    mediaTypeOption: 0,
    colorMode: <{ value: COLOR_MODE; label: string; checked: boolean }[]>[],
    colorModeIndex: COLOR_MODE.GCP_CM_GRAY, // 颜色 - COLOR_MODE
    duplexAndOddeven: <{ value: DUPLEX_SIZE | ODD_OR_EVEN; label: string; }[]>[],
    duplexAndOddevenIndex: 0,
    duplexSize: <{ value: DUPLEX_SIZE; label: string; }[]>[],
    duplexSizeIndex: 0,
    dmOrientation: DM_ORIENTATION_TRANSLATE,
    dmOrientationIndex: 0,
    highQuality: false,
    qualityMode: <{ value: QUALITY_MODE; label: string; }[]>[],
    qualityModeOption: <{ [prop: string]: string }>{},
    qualityModeIndex: 0,
    borderless: false,
    borderlessArr: [{ value: "on", label: "开" }, { value: "off", label: "关" }],
    borderlessIndex: "off",
    printRange: [
      { label: '全部', value: 1, checked: true },
      { label: '部分', value: 2, checked: false },
    ],
    startPage: 1,
    endPage: '',
    isAll: true,
    isResource: false,
  },

  /**
   * @description 获取打印能力
   */
  getPrinterAbility(idx?: number) {
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY);
    if (!printerAbility || !printerAbility.file || !printerAbility.file.ability) {
      wx.showToast({ icon: "error", title: "获取能力失败" });
      return
    }
    if (idx === undefined) {
      const target = (printerAbility.file.mediaSize as typeof MEDIA_SIZE_TRANSLATE).findIndex((v) => v.value == "GCP_MS_A4")
      idx = target == -1 ? 0 : target
    }
    const attr = DeviceUtil.getInstance().dealAttr(printerAbility.file.ability, MEDIA_TYPE.GCP_MT_PLAIN, idx);
    let tmp: { value: DUPLEX_SIZE | ODD_OR_EVEN; label: string; }[] = [...ODD_OR_EVEN_TRANSLATE];
    tmp.push(...attr.duplexSize)
    const targetDuplex = tmp.findIndex(v => v.value === DUPLEX_SIZE.GCP_DP_NONE)
    const history_param = storageUtil.getStorageSync(HISTORY_PARAM);
    const isAll = history_param ? history_param?.isAll : true;
    this.setData({
      mediaSizeIndex: history_param ? history_param?.mediaSizeIndex : idx,
      duplexAndOddevenIndex: history_param ? history_param?.duplexAndOddevenIndex : targetDuplex == -1 ? 0 : targetDuplex,
      duplexSizeIndex: history_param ? history_param?.duplexSizeIndex : 0,
      qualityModeIndex: history_param ? history_param?.qualityModeIndex : 0,
      colorModeIndex: history_param ? history_param?.colorModeIndex : COLOR_MODE.GCP_CM_GRAY,
      borderlessIndex: "off",
      printerAbility: printerAbility.file.ability,
      mediaSize: printerAbility.file.mediaSize,
      mediaSizeOption: attr.mediaSizeOption,
      mediaTypeOption: attr.mediaTypeOption,
      colorMode: attr.colorMode,
      duplexAndOddeven: tmp,
      duplexSize: DUPLEX_SIZE_TRANSLATE.filter(v => [DUPLEX_SIZE.FIT_TO_WIDTH, DUPLEX_SIZE.FIT_TO_HEIGHT].includes(v.value)),
      highQuality: attr.highQuality,
      qualityMode: attr.qualityMode,
      qualityModeOption: attr.qualityModeOption,
      borderless: attr.borderless,
      isAll,
      printRange: this.data.printRange.map(v => {
        if (v.value == 1) {
          v.checked = isAll;
        } else {
          v.checked = !isAll;
        }
        return v;
      }),
      startPage: history_param ? history_param?.startPage : 1,
      endPage: history_param ? history_param?.endPage : '',
      dmOrientationIndex: history_param ? history_param?.dmOrientationIndex : 0,
    });
  },

  /**
   * @description 纸张大小变更时，重置页面参数
   */
  changeMediaSize(e: any) {
    const index = e.detail.value;
    console.log('changeMediaSize', index);
    this.getPrinterAbility(index);
  },

  /**
   * @description 范围选择
   */
  changeRange(e: any) {
    const val = e.detail.value;
    this.setData({ isAll: val == 1 })
  },

  /**
   * @description 色彩选择
   */
  changeColor(e: any) {
    this.setData({
      colorModeIndex: e.detail.value,
    });
  },

  /**
   * @description 双面打印
   */
  changeDuplexAndOddeven(e: any) {
    this.setData({
      duplexAndOddevenIndex: e.detail.value,
    });
  },

  /**
   * @description 打印方向
   */
  changeDmOrientation(e: any) {
    this.setData({
      dmOrientationIndex: e.detail.value,
    });
  },

  /**
   * @description 打印质量
   */
  changeQualityMode(e: any) {
    this.setData({
      qualityModeIndex: e.detail.value,
    });
  },

  /**
   * @description 抗锯齿
   */
  changeBorderless(e: any) {
    this.setData({
      borderlessIndex: e.detail.value,
    });
  },

  /**
   * @description 点击按钮，上传文件，创建打印任务
   */
  createPrintJob() {
    const num = Number(this.data.num)
    if (Number.isNaN(num) || num < 1 || num > 50) {
      wx.showModal({ icon: "error", title: "打印份数错误", content: "请输入1 ~ 50之间的数字", showCancel: false })
      return
    }
    const startPage = Number(this.data.startPage);
    const endPage = Number(this.data.endPage);
    if (!this.data.isAll && ((startPage > endPage && endPage > 0) || startPage < 0 || endPage < 0)) {
      wx.showModal({ icon: "error", title: "打印范围错误", content: "请输入正确的打印范围", showCancel: false })
      return
    }
    wx.showLoading({ title: '文件处理中', mask: true });
    if (this.data.isResource) {
      let deviceInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
      const param: CreateJobParam = {
        url: this.data.docUrl,
        file_name: this.data.docName,
        device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
        file_type: this.data.extension,
        media_size: this.data.mediaSize[this.data.mediaSizeIndex].value,
        media_type: "GCP_MT_PLAIN",
        number: this.data.num,
        device_secret: Date.now() + "",
        out_sn: Date.now() + "",
        make: deviceInfo?.make,
        model: deviceInfo?.model,
        color_mode: this.data.colorModeIndex,
        duplex: this.getDuplexAndOddeven()[0] as string,
        win_json: {
          media_size_option: this.data.mediaSizeOption,
          media_type_option: this.data.mediaTypeOption,
          is_all: true,
          odd_or_even: this.getDuplexAndOddeven()[1] as number,
          dm_orientation: this.data.dmOrientation[this.data.dmOrientationIndex].value,
        },
      };
      if (this.data.highQuality) {
        param.high_quality = this.data.highQuality;
        param.quality_mode = this.data.qualityModeOption[this.data.qualityMode[this.data.qualityModeIndex].value];
      }
      if (this.data.borderless) {
        param.borderless = this.data.borderlessIndex === "on";
      }
      if (!this.data.isAll) {
        param.win_json.is_all = false;
        param.start_page = startPage;
        param.end_page = endPage;
      }
      const curDuplexSize = this.data.duplexSize[this.data.duplexSizeIndex].value;
      if (curDuplexSize == DUPLEX_SIZE.FIT_TO_WIDTH) {
        param.win_json.fitToWidth = 1
      } else if (curDuplexSize == DUPLEX_SIZE.FIT_TO_HEIGHT) {
        param.win_json.fitToHeight = 1
      }
      storageUtil.setStorageSync(HISTORY_PARAM, {
        mediaSizeIndex: this.data.mediaSizeIndex,
        isAll: this.data.isAll,
        startPage: this.data.startPage,
        endPage: this.data.endPage,
        colorModeIndex: this.data.colorModeIndex,
        duplexAndOddevenIndex: this.data.duplexAndOddevenIndex,
        dmOrientationIndex: this.data.dmOrientationIndex,
        qualityModeIndex: this.data.qualityModeIndex,
        duplexSizeIndex: this.data.duplexSizeIndex,
      });
      deviceApi
        .createJob(param)
        .then((createRes) => {
          console.log("createJob-res", createRes);
          if (createRes.code !== SUCESS_CODE) {
            wx.showToast({ icon: "error", title: "打印失败" })
            return;
          }
          wx.showToast({
            title: "提交打印成功", complete: () => {
              wx.navigateTo({
                url: "/pages/index/uploadResult/uploadResult?sn=" + createRes.data.sn,
                success: (res) => {
                  console.log("success", res);
                },
                fail: (err) => {
                  console.log("error", err);
                },
              });
            }
          })
        })
        .catch((err) => {
          console.log("createJob-err", err);
        });
      return
    } else {
      wx.uploadFile({
        url: "https://wtcloudbox.cn/app/api/v1/upload_job_files/",
        filePath: this.data.docUrl,
        name: "files",
        formData: {
          token: storageUtil.getStorageSync(USER_INFO)?.access,
        },
        success: (res) => {
          console.log("uploadFile-sucess", res.data);
          const data = JSON.parse(res.data);
          if (data.code !== SUCESS_CODE) {
            return;
          }
          let deviceInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
          const param: CreateJobParam = {
            url: data.data.package_path,
            file_name: this.data.docName ? this.data.docName : data.data.old_job_filename,
            device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
            file_type: this.data.extension,
            media_size: this.data.mediaSize[this.data.mediaSizeIndex].value,
            media_type: "GCP_MT_PLAIN",
            number: this.data.num,
            device_secret: Date.now() + "",
            out_sn: Date.now() + "",
            make: deviceInfo?.make,
            model: deviceInfo?.model,
            color_mode: this.data.colorModeIndex,
            duplex: this.getDuplexAndOddeven()[0] as string,
            win_json: {
              media_size_option: this.data.mediaSizeOption,
              media_type_option: this.data.mediaTypeOption,
              is_all: true,
              odd_or_even: this.getDuplexAndOddeven()[1] as number,
              dm_orientation: this.data.dmOrientation[this.data.dmOrientationIndex].value,
            },
          };
          if (this.data.highQuality) {
            param.high_quality = this.data.highQuality;
            param.quality_mode = this.data.qualityModeOption[this.data.qualityMode[this.data.qualityModeIndex].value];
          }
          if (this.data.borderless) {
            param.borderless = this.data.borderlessIndex === "on";
          }
          if (!this.data.isAll) {
            param.win_json.is_all = false;
            param.start_page = startPage;
            param.end_page = endPage;
          }
          deviceApi
            .createJob(param)
            .then((createRes) => {
              console.log("createJob-res", createRes);
              if (createRes.code !== SUCESS_CODE) {
                wx.showToast({ icon: "error", title: "打印失败" })
                return;
              }
              wx.showToast({
                title: "提交打印成功", complete: () => {
                  wx.navigateTo({
                    url: "/pages/index/uploadResult/uploadResult?sn=" + createRes.data.sn,
                    success: (res) => {
                      console.log("success", res);
                    },
                    fail: (err) => {
                      console.log("error", err);
                    },
                  });
                }
              })

            })
            .catch((err) => {
              console.log("createJob-err", err);
            });
        },
        fail: (err) => {
          console.log("uploadFile-err", err);
        },
        complete: () => {
          wx.hideLoading()
        },
      });
    }

  },

  /**
   * @description 缩放排版
   */
  changeDuplexSize(e: any) {
    this.setData({
      duplexSizeIndex: e.detail.value,
    });
  },

  getDuplexAndOddeven() {
    if (this.data.duplexAndOddevenIndex == 0 || this.data.duplexAndOddevenIndex == 1) {
      // 选择奇偶页时固定返回单面打印
      return [DUPLEX_SIZE.GCP_DP_NONE, ODD_OR_EVEN_TRANSLATE[this.data.duplexAndOddevenIndex].value];
    }
    return [this.data.duplexAndOddeven[this.data.duplexAndOddevenIndex].value, ODD_OR_EVEN.DEFAULT]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    this.getPrinterAbility();
    if (option.file) {
      const ext: string[] = option.file.split(".");
      this.setData({
        docUrl: option.file,
        docName: option.name,
        extension: ext[ext.length - 1],
        isResource: !!option.isResource,
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() { },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() { },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() { },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() { },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() { },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() { },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() { },
});
