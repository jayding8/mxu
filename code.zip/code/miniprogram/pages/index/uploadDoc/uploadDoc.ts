// pages/index/uploadDoc/uploadDoc.ts
import deviceApi from "../../../apis/deviceApi";
import { SUCESS_CODE } from "../../../constant/common";
import {
  PRINTER_INFO_KEY,
  MEDIA_TYPE,
  COLOR_MODE,
  MEDIA_SIZE,
  BOX_INFO_KEY,
  DUPLEX_SIZE,
  QUALITY_MODE,
  PRINTER_ABILITY_KEY,
  MEDIA_SIZE_TRANSLATE,
  DM_ORIENTATION_TRANSLATE,
  ODD_OR_EVEN_TRANSLATE,
  ODD_OR_EVEN,
  DUPLEX_SIZE_TRANSLATE,
  HISTORY_PARAM,
  FILE_STATUS,
} from "../../../constant/device";
import { USER_INFO } from "../../../constant/user";
import { CreateJobParam } from "../../../interface/deviceInterface";
import { DeviceUtil } from "../../../utils/deviceUtil";
import storageUtil from "../../../utils/storageUtil";
import { UploadFile, UploadUtil } from "../../../utils/UploadUtil";

class DocModel {
  public docName: string = "";
  public extension: string = "";
  public num: number = 1;
  public mediaSizeIndex: number = 0;
  public isAll: boolean = true;
  public startPage: number = 1;
  public endPage: number = 1;
  public colorModeIndex: number = 0;
  public duplexAndOddevenIndex: number = 0;
  public dmOrientationIndex: number = 0;
  public qualityModeIndex: number = 0;
  public url: string = "";
  public status: FILE_STATUS = FILE_STATUS.SUCESS;
  public sn: string = "";
  public mediaSize: any = "";
  public mediaSizeOption: number = 0;
  public mediaTypeOption: number = 0;
  public duplexAndOddeven: { value: DUPLEX_SIZE | ODD_OR_EVEN; label: string; }[] = [];
  public highQuality: boolean = false;
  public qualityMode: { value: QUALITY_MODE; label: string; }[] = [];
  public qualityModeOption: { [prop: string]: string } = {};
  public borderless: boolean = false;
  public borderlessIndex: "on" | "off" = "off";
  public duplexSize: { value: DUPLEX_SIZE; label: string; }[] = [];
  public duplexSizeIndex: number = 0;
}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    allDocs: <DocModel[]>[],
    colorMode: <{ value: COLOR_MODE; label: string; checked: boolean }[]>[],
    colorModeIndex: COLOR_MODE.GCP_CM_GRAY, // 颜色 - COLOR_MODE
    duplexAndOddeven: <{ value: DUPLEX_SIZE | ODD_OR_EVEN; label: string; }[]>[],
    duplexAndOddevenIndex: 0,
    dmOrientation: DM_ORIENTATION_TRANSLATE,
    dmOrientationIndex: 0,
    borderlessArr: [{ value: "on", label: "开" }, { value: "off", label: "关" }],
    printRange: [
      { label: '全部', value: 1, checked: true },
      { label: '部分', value: 2, checked: false },
    ],
  },

  /**
   * @description 获取打印能力
   */
  getPrinterAbility(idx?: number) {
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY);
    if (!printerAbility || !printerAbility.file || !printerAbility.file.ability) {
      wx.showToast({ icon: "error", title: "获取能力失败" });
      return
    }
    if (idx === undefined) {
      const target = (printerAbility.file.mediaSize as typeof MEDIA_SIZE_TRANSLATE).findIndex((v) => v.value == "GCP_MS_A4")
      idx = target == -1 ? 0 : target
    }
    const attr = DeviceUtil.getInstance().dealAttr(printerAbility.file.ability, MEDIA_TYPE.GCP_MT_PLAIN, idx);
    let tmp: { value: DUPLEX_SIZE | ODD_OR_EVEN; label: string; }[] = [...ODD_OR_EVEN_TRANSLATE];
    tmp.push(...attr.duplexSize)
    const targetDuplex = tmp.findIndex(v => v.value === DUPLEX_SIZE.GCP_DP_NONE)
    const history_param = storageUtil.getStorageSync(HISTORY_PARAM);
    const isAll = history_param ? history_param?.isAll : true;

    return {
      mediaSizeIndex: history_param ? history_param?.mediaSizeIndex : idx,
      duplexAndOddevenIndex: history_param ? history_param?.duplexAndOddevenIndex : targetDuplex == -1 ? 0 : targetDuplex,
      duplexSizeIndex: history_param ? history_param?.duplexSizeIndex : 0,
      qualityModeIndex: history_param ? history_param?.qualityModeIndex : 0,
      colorModeIndex: history_param ? history_param?.colorModeIndex : COLOR_MODE.GCP_CM_GRAY,
      borderlessIndex: "off",
      printerAbility: printerAbility.file.ability,
      mediaSize: printerAbility.file.mediaSize,
      mediaSizeOption: attr.mediaSizeOption,
      mediaTypeOption: attr.mediaTypeOption,
      colorMode: attr.colorMode,
      duplexAndOddeven: tmp,
      duplexSize: DUPLEX_SIZE_TRANSLATE.filter(v => [DUPLEX_SIZE.FIT_TO_WIDTH, DUPLEX_SIZE.FIT_TO_HEIGHT].includes(v.value)),
      highQuality: attr.highQuality,
      qualityMode: attr.qualityMode,
      qualityModeOption: attr.qualityModeOption,
      borderless: attr.borderless,
      isAll,
      printRange: this.data.printRange.map(v => {
        if (v.value == 1) {
          v.checked = isAll;
        } else {
          v.checked = !isAll;
        }
        return v;
      }),
      startPage: history_param ? history_param?.startPage : 1,
      endPage: history_param ? history_param?.endPage : '',
      dmOrientationIndex: history_param ? history_param?.dmOrientationIndex : 0,
    };
  },

  /**
   * @description 打印份数
   */
  changeNum(e: any) {
    const val = e.detail.value;
    const fileIndex = e.target.dataset?.idx;
    const type = e.target.dataset?.type;
    const tmpDocs = this.data.allDocs;
    Object.assign(tmpDocs[fileIndex], { [type]: val });
    this.setData({ allDocs: tmpDocs })
  },

  /**
   * @description 纸张大小变更时，重置页面参数
   */
  changeMediaSize(e: any) {
    const index = e.detail.value;
    const fileIndex = e.target.dataset?.idx;
    console.log('changeMediaSize', e);
    const currentAbility = this.getPrinterAbility(index);
    const tmpDocs = this.data.allDocs;
    Object.assign(tmpDocs[fileIndex], currentAbility);
    this.setData({ allDocs: tmpDocs })
  },

  /**
   * @description 范围选择
   */
  changeRange(e: any) {
    const val = e.detail.value;
    const fileIndex = e.target.dataset?.idx;
    const tmpDocs = this.data.allDocs;
    const isAll = val == 1;
    const printRange = JSON.parse(JSON.stringify(this.data.printRange))
    Object.assign(tmpDocs[fileIndex], {
      isAll,
      printRange: printRange.map((v: any) => {
        if (v.value == 1) {
          v.checked = isAll;
        } else {
          v.checked = !isAll;
        }
        return v;
      })
    });
    this.setData({ allDocs: tmpDocs })
  },

  /**
   * @description 色彩选择
   */
  changeColor(e: any) {
    const fileIndex = e.target.dataset?.idx;
    const tmpDocs = this.data.allDocs;
    Object.assign(tmpDocs[fileIndex], { colorModeIndex: e.detail.value });
    this.setData({ allDocs: tmpDocs })
  },

  /**
   * @description 双面打印
   */
  changeDuplexAndOddeven(e: any) {
    const fileIndex = e.target.dataset?.idx;
    const tmpDocs = this.data.allDocs;
    Object.assign(tmpDocs[fileIndex], { duplexAndOddevenIndex: e.detail.value });
    this.setData({ allDocs: tmpDocs })
  },

  /**
   * @description 打印方向
   */
  changeDmOrientation(e: any) {
    const fileIndex = e.target.dataset?.idx;
    const tmpDocs = this.data.allDocs;
    Object.assign(tmpDocs[fileIndex], { dmOrientationIndex: e.detail.value });
    this.setData({ allDocs: tmpDocs })
  },

  /**
   * @description 打印质量
   */
  changeQualityMode(e: any) {
    const fileIndex = e.target.dataset?.idx;
    const tmpDocs = this.data.allDocs;
    Object.assign(tmpDocs[fileIndex], { qualityModeIndex: e.detail.value });
    this.setData({ allDocs: tmpDocs })
  },

  /**
   * @description 抗锯齿
   */
  changeBorderless(e: any) {
    const fileIndex = e.target.dataset?.idx;
    const tmpDocs = this.data.allDocs;
    Object.assign(tmpDocs[fileIndex], { borderlessIndex: e.detail.value });
    this.setData({ allDocs: tmpDocs });
  },

  /**
   * @description 缩放排版
   */
  async changeDuplexSize(e: any) {
    console.log("changeDuplexSize", e);
    const fileIndex = e.target.dataset?.idx;
    const tmpDocs = this.data.allDocs;
    // 重新提交转化
    wx.showLoading({ title: "文件解析中！" });
    await deviceApi.createConvertJob({
      file_url: tmpDocs[fileIndex].url,
      file_name: tmpDocs[fileIndex].docName,
      sn: tmpDocs[fileIndex].sn as string,
      fit_width: e.detail.value == 0 ? 1 : 0,
      fit_height: e.detail.value,
    });

    deviceApi.getConvertJob({ sn: tmpDocs[fileIndex].sn })
      .then(res => {
        console.log("getConvertStatus-sucess", res);
        // TODO 返回结构待定
        wx.hideLoading();
        Object.assign(tmpDocs[fileIndex], {
          duplexSizeIndex: e.detail.value,
          url: res?.data?.convert_url,
          endPage: res?.data?.total_page,
        });
        this.setData({ allDocs: tmpDocs });
      }).catch(err => {
        console.log("getConvertStatus-err", err);
      })

  },

  /**
   * @description 点击按钮，上传文件，创建打印任务
   */
  createPrintJob() {
    let promiseAll: CreateJobParam[] = [];
    let errorFlag = false;
    for (let i = 0; i < this.data.allDocs.length; i++) {
      const v = this.data.allDocs[i];
      const num = Number(v.num);
      if (Number.isNaN(num) || num < 1 || num > 50) {
        wx.showModal({ icon: "error", title: "打印份数错误", content: "请输入1 ~ 50之间的数字", showCancel: false });
        errorFlag = true;
        break;
      }

      const startPage = Number(v.startPage);
      const endPage = Number(v.endPage);
      if (!v.isAll && ((startPage > endPage && endPage > 0) || startPage < 0 || endPage < 0)) {
        wx.showModal({ icon: "error", title: "打印范围错误", content: "请输入正确的打印范围", showCancel: false })
        errorFlag = true;
        break;
      }

      // wx.showLoading({ title: '文件处理中', mask: true });
      let deviceInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
      const param: CreateJobParam = {
        url: v.url,
        file_name: v.docName,
        device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
        file_type: v.extension,
        media_size: v.mediaSize[v.mediaSizeIndex].value,
        media_type: "GCP_MT_PLAIN",
        number: num,
        device_secret: Date.now() + "",
        out_sn: v.sn,
        make: deviceInfo?.make,
        model: deviceInfo?.model,
        color_mode: v.colorModeIndex + '',
        duplex: this.getDuplexAndOddeven(v)[0] as string,
        win_json: {
          media_size_option: v.mediaSizeOption,
          media_type_option: v.mediaTypeOption,
          is_all: true,
          odd_or_even: this.getDuplexAndOddeven(v)[1] as number,
          dm_orientation: this.data.dmOrientation[v.dmOrientationIndex].value,
        },
      };
      if (v.highQuality) {
        param.high_quality = v.highQuality;
        param.quality_mode = v.qualityModeOption[v.qualityMode[v.qualityModeIndex].value];
      }
      if (v.borderless) {
        param.borderless = v.borderlessIndex === "on";
      }
      if (!v.isAll) {
        param.win_json.is_all = false;
        param.start_page = startPage;
        param.end_page = endPage;
      }
      const curDuplexSize = v.duplexSize[v.duplexSizeIndex].value;
      if (curDuplexSize == DUPLEX_SIZE.FIT_TO_WIDTH) {
        param.win_json.fitToWidth = 1
      } else if (curDuplexSize == DUPLEX_SIZE.FIT_TO_HEIGHT) {
        param.win_json.fitToHeight = 1
      }

      storageUtil.setStorageSync(HISTORY_PARAM, {
        mediaSizeIndex: v.mediaSizeIndex,
        isAll: v.isAll,
        startPage: v.startPage,
        endPage: v.endPage,
        colorModeIndex: v.colorModeIndex,
        duplexAndOddevenIndex: v.duplexAndOddevenIndex,
        dmOrientationIndex: v.dmOrientationIndex,
        qualityModeIndex: v.qualityModeIndex,
        duplexSizeIndex: v.duplexSizeIndex,
      });

      promiseAll.push(param);
    }

    if (errorFlag) {
      return
    }

    Promise.all(promiseAll.map(v => deviceApi.createJob(v)))
      .then((createRes) => {
        console.log("createJob-res", createRes);
        // if (createRes.code !== SUCESS_CODE) {
        //   wx.showToast({ icon: "error", title: "打印失败" })
        //   return;
        // }
        wx.showToast({
          title: "提交打印成功", complete: () => {
            wx.navigateTo({
              url: "/pages/index/uploadResult/uploadResult?sn=" + createRes.map(v => v?.data?.sn).join(","),
              success: (res) => {
                console.log("success", res);
              },
              fail: (err) => {
                console.log("error", err);
              },
            });
          }
        })
      })
      .catch((err) => {
        console.log("createJob-err", err);
      });

  },

  getDuplexAndOddeven(item: DocModel) {
    if (item.duplexAndOddevenIndex == 0 || item.duplexAndOddevenIndex == 1) {
      // 选择奇偶页时固定返回单面打印
      return [DUPLEX_SIZE.GCP_DP_NONE, ODD_OR_EVEN_TRANSLATE[item.duplexAndOddevenIndex].value];
    }
    return [item.duplexAndOddeven[item.duplexAndOddevenIndex].value, ODD_OR_EVEN.DEFAULT]
  },

  /**
   * @description 初始化文件信息
  */
  initFiles() {
    const allFiles = UploadUtil.getInstance().getAllFiles();
    console.log('initFiles-DocModel', allFiles);
    const initAbility = this.getPrinterAbility();

    const tmpFiles = <DocModel[]>[]
    allFiles.forEach(v => {
      const tmp = new DocModel();
      tmp.docName = v.name;
      tmp.extension = v.extension as string;
      tmp.url = v.url as string;
      tmp.status = v.status;
      tmp.sn = v.sn as string;
      Object.assign(tmp, initAbility);
      tmpFiles.push(tmp);
    })
    this.setData({
      allDocs: tmpFiles,
    });

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.initFiles();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() { },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() { },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() { },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() { },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() { },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() { },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() { },
});
