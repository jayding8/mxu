import deviceApi from "../../../apis/deviceApi";
import { SUCESS_CODE } from "../../../constant/common";
import { BOX_INFO_KEY, COLOR_MODE, DM_ORIENTATION_TRANSLATE, EXPOSURE_MODE, EXPOSURE_MODE_TRANSLATE, MEDIA_SIZE, MEDIA_SIZE_TRANSLATE, MEDIA_TYPE, PRINTER_ABILITY_KEY, PRINTER_INFO_KEY, QUALITY_MODE, STRETCH_MODE_TRANSLATE } from "../../../constant/device";
import { USER_INFO } from "../../../constant/user";
import { CreateJobParam } from "../../../interface/deviceInterface";
import { DeviceUtil } from "../../../utils/deviceUtil";
import storageUtil from "../../../utils/storageUtil";

// pages/index/uploadDoc/uploadPic.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    picUrl: "", // 图片地址
    extension: "", // 图片后缀
    showDialog: false, // 是否展示参数弹窗
    buttons: [
      {
        type: "primary",
        className: "",
        text: "确认",
        value: 1,
      },
    ], // 弹窗按钮配置
    printerAbility: <any[]>[], // 打印机能力
    num: 1, // 打印数量
    mediaSize: <{ value: MEDIA_SIZE; label: string; }[]>[], // 纸张大小
    mediaSizeIndex: 0, // 纸张大小 - 索引
    mediaSizeOption: 0, // 纸张大小 - 数字枚举，打印机解析使用
    mediaTypeOption: 0, // 打印类型 - 数字枚举（照片/文档），打印机解析使用
    colorMode: <{ value: COLOR_MODE; label: string; checked: boolean }[]>[],
    colorModeIndex: COLOR_MODE.GCP_CM_GRAY, // 颜色 - COLOR_MODE
    exposureMode: EXPOSURE_MODE_TRANSLATE,
    exposureModeIndex: EXPOSURE_MODE.DEFAULT,
    highQuality: false, // 是否支持高质量打印
    qualityMode: <{ value: QUALITY_MODE; label: string; }[]>[], // 质量类型
    qualityModeOption: <any>{}, // 质量类型 - 字符串枚举，打印机解析使用
    qualityModeIndex: 0, // 质量类型 - 索引
    dmOrientation: DM_ORIENTATION_TRANSLATE, // 打印方向
    dmOrientationIndex: 0, // 打印方向 - 索引
    stretchMode: STRETCH_MODE_TRANSLATE, // 图片缩放模式
    stretchModeIndex: 0, // 打印方向 - 索引
  },

  /**
 * @description 获取打印能力
 */
  getPrinterAbility(idx?: number) {
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY);
    if (!printerAbility || !printerAbility.file || !printerAbility.file.ability) {
      wx.showToast({ icon: "error", title: "获取能力失败" });
      return;
    }
    if (idx === undefined) {
      const target = (printerAbility.file.mediaSize as typeof MEDIA_SIZE_TRANSLATE).findIndex((v) => v.value == "GCP_MS_4X6")
      idx = target == -1 ? 0 : target
    }
    const attr = DeviceUtil.getInstance().dealAttr(printerAbility.file.ability, MEDIA_TYPE.GCP_MT_PLAIN, idx);
    this.setData({
      mediaSizeIndex: idx,
      qualityModeIndex: 0,
      colorModeIndex: COLOR_MODE.GCP_CM_GRAY,
      printerAbility: printerAbility.file.ability,
      mediaSize: printerAbility.file.mediaSize,
      mediaSizeOption: attr.mediaSizeOption,
      mediaTypeOption: attr.mediaTypeOption,
      colorMode: attr.colorMode,
      highQuality: attr.highQuality,
      qualityMode: attr.qualityMode,
      qualityModeOption: attr.qualityModeOption,
    });
  },

  /**
   * @description 选择打印参数
   */
  chooseParam() {
    this.setData({ showDialog: true });
  },

  /**
   * @description 纸张大小变更时，重置页面参数
   */
  changeMediaSize(e: any) {
    const index = e.detail.value;
    this.getPrinterAbility(index);
  },

  /**
   * @description 色彩选择
   */
  changeColor(e: any) {
    this.setData({
      colorModeIndex: e.detail.value,
    });
  },

  /**
   * @description 曝光度选择
   */
  changeExposure(e: any) {
    this.setData({
      exposureModeIndex: e.detail.value,
    });
  },

  /**
   * @description 打印质量
   */
  changeQualityMode(e: any) {
    this.setData({
      qualityModeIndex: e.detail.value,
    });
  },

  /**
   * @description 打印方向
   */
  changeDmOrientation(e: any) {
    this.setData({
      dmOrientationIndex: e.detail.value,
    });
  },

  /**
   * @description 缩放模式
   */
  changeStretchMode(e: any) {
    this.setData({
      stretchModeIndex: e.detail.value,
    });
  },

  /**
   * @description 点击按钮，上传文件，创建打印任务
   */
  createPrintJob() {
    const num = Number(this.data.num)
    if (Number.isNaN(num) || num < 1 || num > 50) {
      wx.showModal({ icon: "error", title: "打印份数错误", content: "请输入1 ~ 50之间的数字", showCancel: false })
      return
    }

    let deviceInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
    const param: CreateJobParam = {
      url: this.data.picUrl,
      file_name: (this.data.mediaSize[this.data.mediaSizeIndex]?.label
        ? this.data.mediaSize[this.data.mediaSizeIndex].label
        : "") + "图片",
      device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
      file_type: 'pdf',
      media_size: this.data.mediaSize[this.data.mediaSizeIndex].value,
      media_type: "GCP_MT_PLAIN",
      number: this.data.num,
      device_secret: Date.now() + "",
      out_sn: Date.now() + "",
      make: deviceInfo?.make,
      model: deviceInfo?.model,
      color_mode: this.data.colorModeIndex,
      win_json: {
        exposureValue: !!this.data.exposureModeIndex,
        is_image_to_pdf: true,
        media_size_option: this.data.mediaSizeOption,
        media_type_option: this.data.mediaTypeOption,
        dm_orientation: this.data.dmOrientation[this.data.dmOrientationIndex].value,
        stretchMode: this.data.stretchMode[this.data.stretchModeIndex].value,
      },
    };
    if (this.data.highQuality) {
      param.high_quality = this.data.highQuality;
      param.quality_mode = this.data.qualityModeOption[this.data.qualityMode[this.data.qualityModeIndex].value];
    }
    deviceApi
      .createJob(param)
      .then((createRes) => {
        console.log("createJob-res", createRes);
        if (createRes.code !== SUCESS_CODE) {
          wx.showToast({ icon: "error", title: "打印失败" })
          return;
        }
        wx.showToast({
          title: "提交打印成功", complete: () => {
            wx.navigateTo({
              url: "/pages/index/uploadResult/uploadResult?sn=" + createRes.data.sn,
              success: (res) => {
                console.log("success", res);
              },
              fail: (err) => {
                console.log("error", err);
              },
            });
          }
        });
      })
      .catch((err) => {
        console.log("createJob-err", err);
      });


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    this.getPrinterAbility();
    if (option.file) {
      const ext: string[] = option.file.split(".");
      this.setData({
        picUrl: option.file,
        extension: ext[ext.length - 1],
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})