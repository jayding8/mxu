// pages/index/uploadResult/uploadResult.ts

import deviceApi from "../../../apis/deviceApi";
import { SUCESS_CODE } from "../../../constant/common";

const READ_INTERVAL_TIME = 2000;
const MAX_READ_TIMES = 30;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    sn: "",
    printComplete: false,
    timer: 0, // 定时器
    times: 0, // 读取的次数，定时器2秒一次，最多读30次  
  },

  /**
   * @description 获取当前打印任务的状态
   */
  getPrintStatus() {
    this.data.timer = setInterval(() => {
      if (this.data.times >= MAX_READ_TIMES) {
        this.clearPrintInterval();
        return;
      }
      this.data.times++;
      deviceApi.getPrintStatus({ sn: this.data.sn }).then(res => {
        console.log("getPrintStatus-sucess", res);
        if (res.code !== SUCESS_CODE) {
          return;
        }
        if (res.data.state === "printed") {
          this.setData({ printComplete: true });
        }
      }).catch(err => {
        console.log("getPrintStatus-err", err);
      })
    }, READ_INTERVAL_TIME);
  },

  /**
   * @description 清除定时器
   */
  clearPrintInterval() {
    if (this.data.timer) {
      this.data.times = 0;
      clearInterval(this.data.timer);
    }
  },

  /**
   * @description 返回首页
   */
  goHome() {
    wx.switchTab({
      url: "/pages/index/index",
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    if (option.sn) {
      this.setData({ sn: option.sn });
    }
    this.getPrintStatus();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    this.clearPrintInterval();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})