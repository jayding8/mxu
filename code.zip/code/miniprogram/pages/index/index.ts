import storageUtil from "../../utils/storageUtil";
import { USER_INFO } from "../../constant/user";
import deviceApi from "../../apis/deviceApi";
import { BOX_INFO_KEY, PRINTER_INFO_KEY, PRINTER_ABILITY_KEY, BIN_OPTION, PRINTER_ABILITY_GROUP_KEY, FILE_STATUS } from "../../constant/device";
import { FILE_LIMIT, FILE_SIZE_LIMIT, SUCESS_CODE } from "../../constant/common";
import { DeviceUtil } from "../../utils/deviceUtil";
import { getFileName, OBSupload } from "../../utils/OBS/OBSUploadFile";

const enum PIC_SOURCE {
  WX = "wx",
  CAMERA = "camera",
  ALBUM = "album"
}

const config = require('../../utils/OBS/Configuration.js');

// 获取应用实例
Page({
  data: {
    tabs: [
      {
        name: "文档打印",
      },
      {
        name: "照片打印",
      },
      {
        name: "发票打印",
      },
    ],
    activeTab: 0,
    loginStatus: false, // 用户登录状态
    boxBindStatus: false, // 是否绑定了盒子
    devStatus: false, // 盒子状态：true/false
    title: "", // 盒子名称
    printStatus: false, // 打印机状态
    titlePrint: "打印机未识别", // 打印机
    showActionsheet: false,
    photoGroups: [
      { text: '微信聊天记录', value: PIC_SOURCE.WX },
      { text: '拍摄', value: PIC_SOURCE.CAMERA },
      { text: '从相册选择', value: PIC_SOURCE.ALBUM }
    ],
    showPicActionsheet: false,
    picGroups: [
      { text: '微信聊天记录', value: PIC_SOURCE.WX },
      { text: '从相册选择', value: PIC_SOURCE.ALBUM }
    ],
  },

  /**
   * @description 跳转登录页
   * @returns {void}
   */
  goLogin(): void {
    wx.navigateTo({
      url: "/views/user/user",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 跳转设备详情
   * @returns {void}
   */
  goDevDetail(): void {
    wx.navigateTo({
      url: "/views/device/detail/detail",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 添加设备
   * @returns {void}
   */
  addDevice(): void {
    wx.navigateTo({
      url: "/views/checkBlueToothAuth/checkBlueToothAuth",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 首页tab切换
   * @returns {void}
   */
  changeTab(e: WechatMiniprogram.BaseEvent): void {
    this.setData({
      activeTab: e.currentTarget.dataset.idx,
    });
  },

  /**
   * @description 关闭上传sheet
   * 
   * @returns {Promise<void>}
   */
  closeActionSheet() {
    this.setData({ showActionsheet: false });
  },

  closePicActionSheet() {
    this.setData({ showPicActionsheet: false });
  },

  /**
   * @description 上传微信聊天记录文档
   * 
   * @returns {Promise<void>}
   */
  async uploadInvoice(): Promise<void> {
    if (!this._checkAuth()) {
      return;
    }
    if (!(await this.checkDeviceInfo())) {
      return;
    }

    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.invoice || !printerAbility.invoice.mediaSize || !printerAbility.invoice.mediaSize.length) {
      wx.showToast({ icon: "error", title: "仅支持针式打印机" });
      return;
    }
    wx.chooseMessageFile({
      count: 1,
      type: "file",
      success: (res) => {
        console.log('chooseMessageFile', res);

        const tempFilePaths = res.tempFiles;
        const ext: string[] = tempFilePaths[0].path.split(".");
        const extension = ext[ext.length - 1];
        if (!['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(extension.toLowerCase())) {
          wx.showModal({ title: "文件类型错误", content: "当前只支持pdf, doc, docx, xls, xlsx, ppt, pptx类型", showCancel: false });
          return
        }
        if (tempFilePaths[0].size > FILE_SIZE_LIMIT) {
          wx.showModal({ title: "文件过大", content: "文件大小不能超过20M", showCancel: false });
          return
        }
        const fileName = getFileName(tempFilePaths[0].path);
        const fileUrl = config.EndPoint + fileName;
        OBSupload(tempFilePaths[0].path, fileName, (status: boolean) => {
          if (!status) {
            return
          }
          wx.navigateTo({
            url: `/pages/index/uploadDoc/invoice?file=${fileUrl}&name=${tempFilePaths[0].name}`,
          });
        })

      },
      fail(err) {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 上传微信聊天记录文档
   * 
   * @returns {Promise<void>}
   */
  async uploadWxDoc(): Promise<void> {
    if (!this._checkAuth()) {
      return;
    }
    if (!(await this.checkDeviceInfo())) {
      return;
    }

    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.file || !printerAbility.file.mediaSize || !printerAbility.file.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持文档打印" });
      return;
    }
    wx.chooseMessageFile({
      count: 1,
      type: "file",
      success: (res) => {
        console.log('chooseMessageFile', res);

        const tempFilePaths = res.tempFiles;
        const ext: string[] = tempFilePaths[0].path.split(".");
        const extension = ext[ext.length - 1];
        if (!['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(extension.toLowerCase())) {
          wx.showModal({ title: "文件类型错误", content: "当前只支持pdf, doc, docx, xls, xlsx, ppt, pptx类型", showCancel: false });
          return
        }
        const fileName = getFileName(tempFilePaths[0].path);
        const fileUrl = config.EndPoint + fileName;
        if (tempFilePaths[0].size > FILE_SIZE_LIMIT) {
          wx.showModal({
            title: "文件过大",
            content: " 文件超过20M可能会打印失败，建议分页打印！",
            showCancel: false,
            success: (res) => {
              if (res.confirm) {
                OBSupload(tempFilePaths[0].path, fileName, (status: boolean) => {
                  if (!status) {
                    return
                  }
                  wx.navigateTo({
                    url: `/pages/index/uploadDoc/uploadDoc?file=${fileUrl}&name=${tempFilePaths[0].name}&isResource=1`,
                  });
                })
              }
            }
          });
          return
        } else {
          OBSupload(tempFilePaths[0].path, fileName, (status: boolean) => {
            if (!status) {
              return
            }
            wx.navigateTo({
              url: `/pages/index/uploadDoc/uploadDoc?file=${fileUrl}&name=${tempFilePaths[0].name}&isResource=1`,
            });
          })
        }
      },
      fail(err) {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 展示图片上传actionSheet 照片打印 => 照片打印
   * @returns {void}
   */
  async choosePicSource(): Promise<void> {
    if (!this._checkAuth()) {
      return;
    }
    if (!(await this.checkDeviceInfo())) {
      return;
    }
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.photo || !printerAbility.photo.mediaSize || !printerAbility.photo.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持照片打印" });
      return;
    }
    this.setData({ showActionsheet: true });
  },

  /**
   * 文档打印 => 图片打印
  */
  async choosePicSource2(): Promise<void> {
    if (!this._checkAuth()) {
      return;
    }
    if (!(await this.checkDeviceInfo())) {
      return;
    }
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.file || !printerAbility.file.mediaSize || !printerAbility.file.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持图片打印" });
      return;
    }
    this.setData({ showPicActionsheet: true });
  },

  /**
   * @description 上传手机图片、拍照上传 照片打印 => 照片打印
   * @returns {void}
   */
  uploadPic(e: any): void {
    if (!this._checkAuth()) {
      return;
    }
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.photo || !printerAbility.photo.mediaSize || !printerAbility.photo.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持照片打印" });
      return;
    }
    console.log('uploadPic', e);
    if (e.detail.value === PIC_SOURCE.WX) {
      wx.chooseMessageFile({
        count: FILE_LIMIT,
        type: "image",
        success: (res) => {
          console.log("tempFilePaths-wx", res);
          const tmpFiles = [];
          const filesNum = res.tempFiles.length;
          for (let i = 0; i < filesNum; i++) {
            const v = res.tempFiles[i];
            if (v.size > FILE_SIZE_LIMIT) {
              // wx.showModal({ title: "文件过大", content: "文件大小不能超过20M", showCancel: false });
              tmpFiles.push({ fileName: v.name, status: FILE_STATUS.SIZE_LIMIT });
              if (tmpFiles.length >= filesNum) {
                
              }
              continue;
            }
            const fileName = getFileName(v.path);
            const fileUrl = config.EndPoint + fileName;
            OBSupload(v.path, fileName, (status: boolean) => {
              if (!status) {
                tmpFiles.push({ fileName: v.name, status: FILE_STATUS.UPLOAD_FAIL });
                return
              }

              // wx.navigateTo({
              //   url: `/pages/index/uploadPic/uploadPic?file=${fileUrl}&name=${v.name}`,
              // });
            })
          }

        },
        fail(err) {
          console.log("uploadPic-error", err);
        },
      });
    } else {
      wx.chooseMedia({
        count: FILE_LIMIT,
        mediaType: ["image"],
        sourceType: [e.detail.value],
        success: (res) => {
          console.log("chooseMedia-sceuss", res);
          if (res.tempFiles[0].size > FILE_SIZE_LIMIT) {
            wx.showModal({ title: "文件过大", content: "文件大小不能超过20M", showCancel: false });
            return
          }
          const fileName = getFileName(res.tempFiles[0].tempFilePath);
          const fileUrl = config.EndPoint + fileName;
          OBSupload(res.tempFiles[0].tempFilePath, fileName, (status: boolean) => {
            if (!status) {
              return
            }
            wx.navigateTo({
              url: `/pages/index/uploadPic/uploadPic?file=${fileUrl}`,
            });
          })
        },
      });
    }

    this.setData({ showActionsheet: false });
  },

  /**
   * 文档打印 => 图片打印
  */
  uploadPic2(e: any): void {
    if (!this._checkAuth()) {
      return;
    }
    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.file || !printerAbility.file.mediaSize || !printerAbility.file.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持图片打印" });
      return;
    }
    if (e.detail.value === PIC_SOURCE.WX) {
      wx.chooseMessageFile({
        count: 1,
        type: "image",
        success: (res) => {
          const tempFilePaths = res.tempFiles;
          console.log("tempFilePaths-wx", tempFilePaths);
          if (tempFilePaths[0].size > FILE_SIZE_LIMIT) {
            wx.showModal({ title: "文件过大", content: "文件大小不能超过20M", showCancel: false });
            return
          }
          const fileName = getFileName(tempFilePaths[0].path);
          const fileUrl = config.EndPoint + fileName;
          OBSupload(tempFilePaths[0].path, fileName, (status: boolean) => {
            if (!status) {
              return
            }
            wx.navigateTo({
              url: `/pages/index/uploadDoc/uploadPic?file=${fileUrl}&name=${tempFilePaths[0].name}`,
            });
          })
        },
        fail(err) {
          console.log("uploadPic-error", err);
        },
      });
    } else {
      wx.chooseMedia({
        count: 1,
        mediaType: ["image"],
        sourceType: [e.detail.value],
        success: (res) => {
          console.log("chooseMedia-sceuss", res);
          if (res.tempFiles[0].size > FILE_SIZE_LIMIT) {
            wx.showModal({ title: "文件过大", content: "文件大小不能超过20M", showCancel: false });
            return
          }
          const fileName = getFileName(res.tempFiles[0].tempFilePath);
          const fileUrl = config.EndPoint + fileName;
          OBSupload(res.tempFiles[0].tempFilePath, fileName, (status: boolean) => {
            if (!status) {
              return
            }
            wx.navigateTo({
              url: `/pages/index/uploadDoc/uploadPic?file=${fileUrl}`,
            });
          })
        },
      });
    }

    this.setData({ showPicActionsheet: false });
  },

  /**
   * @description 操作权限判断
   * @returns {boolean}
   */
  _checkAuth(): boolean {
    if (!this.data.loginStatus) {
      wx.showToast({ icon: "error", title: "请先登录" });
      return false;
    }
    if (!this.data.boxBindStatus) {
      wx.showToast({ icon: "error", title: "请先绑定设备" })
      return false
    }
    if (!this.data.devStatus) {
      wx.showToast({ icon: "error", title: "请检查设备状态" })
      return false
    }
    if (!this.data.printStatus) {
      wx.showToast({ icon: "error", title: "请检查打印机状态" })
      return false
    }
    return true;
  },

  /**
   * @description 获取设备状态
   */
  getDeviceStatus(): void {
    if (!this.data.loginStatus) {
      console.log("用户未登录", this.data.loginStatus);
      this.setData({ deviceStatus: false });
      return;
    }
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    if (!boxInfo) {
      console.log("无法获取boxinfo，请先蓝牙连接", boxInfo);
      this.setData({ deviceStatus: false });
      return;
    }
    const param = { device_id: boxInfo.device_id };
    deviceApi
      .getDeviceStatus(param)
      .then((res) => {
        console.log("getDeviceStatus-sucess", res);
        if (res.code !== SUCESS_CODE) {
          return;
        }
        const printerInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
        this.setData({
          devStatus: res.data.dev_online,
          title: boxInfo.title,
          printStatus: res.data.printer_connect,
          titlePrint: printerInfo?.make ? printerInfo?.make : "打印机未识别",
        });
        if (printerInfo && printerInfo.make) {
          const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
          if (!printerAbility) {
            this.getPrinterAbility(printerInfo);
          }
          return
        }
        this.getDeviceInfo(boxInfo.device_id);
      })
      .catch((err) => {
        console.log("getDeviceStatus-err", err);
      });
  },

  /**
   * @description 获取设备信息
   */
  getDeviceInfo(device_id: string): void {
    const param = {
      device_id,
      force_mqtt: false,
      user_id: storageUtil.getStorageSync(USER_INFO)?.userId,
    };
    deviceApi
      .getDeviceInfo(param)
      .then((res) => {
        console.log("getDeviceInfo-sucess", res);
        if (res.code !== SUCESS_CODE) {
          return;
        }
        if (!res.data.printer_make || !res.data.printer_model) {
          return
        }
        const printerInfo = {
          make: res.data.printer_make,
          model: res.data.printer_model,
        }

        if (res.data && res.data.printer_make) {
          this.setData({ titlePrint: res.data.printer_make });
        }
        storageUtil.setStorageSync(PRINTER_INFO_KEY, printerInfo);
        this.getPrinterAbility(printerInfo);
      })
      .catch((err) => {
        console.log("getDeviceInfo-err", err);
      });
  },

  /**
   * @description 获取打印能力
   */
  getPrinterAbility({ make, model }: { make: string; model: string }) {
    deviceApi.getPrinterAbility({ make, model })
      .then((res) => {
        console.log("getPrinterAbility-sucess", res);
        if (res.code !== SUCESS_CODE || !res.capability.length) {
          console.error("获取打印机能力失败");
          return;
        }

        const ability = DeviceUtil.getInstance().JIE(res.capability[0].auto_cap);
        const autoCap = JSON.parse(ability);
        console.log("PrinterAbility-auto_cap", autoCap);
        if (autoCap.bin_option) {
          storageUtil.setStorageSync(BIN_OPTION, autoCap.bin_option);
        }
        DeviceUtil.getInstance().dealAbilityData(autoCap.media_sizes);
        storageUtil.setStorageSync(PRINTER_ABILITY_GROUP_KEY, res.capability[0].group);
      })
      .catch((err) => {
        console.log("getPrinterAbility-err", err);
        wx.showToast({ icon: "error", title: "请重试" });
      });
  },

  /**
   * @description 检查盒子绑定的定义及是否改变了
   */
  async checkDeviceInfo() {
    const param = {
      device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
      force_mqtt: false,
      user_id: storageUtil.getStorageSync(USER_INFO)?.userId,
    };
    const deviceInfo = await deviceApi.getDeviceInfo(param);
    if (deviceInfo.code !== SUCESS_CODE) {
      console.error("获取设备信息失败");
      return false;
    }
    const printInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
    console.log("printInfo", deviceInfo);
    if (deviceInfo.data.printer_make === printInfo.make && deviceInfo.data.printer_model === printInfo.model) {
      return true;
    }
    const printerInfo = {
      make: deviceInfo.data.printer_make,
      model: deviceInfo.data.printer_model,
    }
    storageUtil.setStorageSync(PRINTER_INFO_KEY, printerInfo);
    const printAbility = await deviceApi.getPrinterAbility(printInfo);
    console.log("PrinterAbility", printAbility);
    if (printAbility.code !== SUCESS_CODE || !printAbility.capability.length) {
      console.error("获取打印机能力失败");
      return false;
    }
    try {
      const ability = DeviceUtil.getInstance().JIE(printAbility.capability[0].auto_cap);
      const autoCap = JSON.parse(ability);
      console.log("PrinterAbility-auto_cap", autoCap);
      if (autoCap.bin_option) {
        storageUtil.setStorageSync(BIN_OPTION, autoCap.bin_option);
      }
      DeviceUtil.getInstance().dealAbilityData(autoCap.media_sizes);
      storageUtil.setStorageSync(PRINTER_ABILITY_GROUP_KEY, printAbility.capability[0].group);
    } catch (error) {
      return false
    }
    return true;
  },

  /**
   * @description 跳转本地文档
   */
  async goLocalDoc() {
    if (!this._checkAuth()) {
      return;
    }
    if (!(await this.checkDeviceInfo())) {
      return;
    }

    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.file || !printerAbility.file.mediaSize || !printerAbility.file.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持文档打印" });
      return;
    }

    wx.navigateTo({
      url: `/views/localDoc/localDoc`,
    });
  },

  /**
   * @description 跳转腾讯文档
   */
  async goTxDoc() {
    if (!this._checkAuth()) {
      return;
    }
    if (!(await this.checkDeviceInfo())) {
      return;
    }

    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.file || !printerAbility.file.mediaSize || !printerAbility.file.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持文档打印" });
      return;
    }

    // wx.navigateToMiniProgram({
    //   appId: 'wxd45c635d754dbf59',
    //   path: 'pages/list/list',
    // });

    const clientId = "21e6d9fe4cec40aca7567da37256199d";
    // const state = "填写您自定义的状态参数，可留空";

    wx.navigateToMiniProgram({
      appId: 'wxd45c635d754dbf59',
      path: 'packages/miniapp-open/open-auth/open-auth?client_id=' + encodeURIComponent(clientId),
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.setData({
      loginStatus: !!storageUtil.getStorageSync(USER_INFO),
      boxBindStatus: !!storageUtil.getStorageSync(BOX_INFO_KEY),
    });
    this.getDeviceStatus();
  },
});
