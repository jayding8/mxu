// pages/resource/resource.ts
import {
  ResourceCategoryResultItem, ResourceResultItem
} from "../../interface/resourceInterface";
import resourceApi from "../../apis/resourceApi";
import { SUCESS_CODE } from "../../constant/common";
import storageUtil from "../../utils/storageUtil";
import { USER_INFO } from "../../constant/user";
import { BIN_OPTION, BOX_INFO_KEY, PRINTER_ABILITY_GROUP_KEY, PRINTER_ABILITY_KEY, PRINTER_INFO_KEY } from "../../constant/device";
import deviceApi from "../../apis/deviceApi";
import { DeviceUtil } from "../../utils/deviceUtil";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    category: <ResourceCategoryResultItem[]>[],
    list: <ResourceResultItem[]>[],
    devStatus: false, // 盒子状态：true/false
    printStatus: false, // 打印机状态
  },

  /**
   * @description 获取资源库分类
   * @returns {void}
   */
  getResourceCategory() {
    wx.showLoading({ title: '分类加载中' });
    resourceApi.getResourceCategory({ limit: 100 }).then((res) => {
      if (res.code !== SUCESS_CODE) {
        wx.showToast({ title: '获取分类失败！', icon: 'error' })
        return;
      }
      this.setData({ category: res.data.data });
      this.getResource(res.data.data[this.data.currentTab]?.id);
    }).finally(() => {
      wx.hideLoading();
    })
  },

  /**
   * @description 获取资源库资源
   * @param cid 分类id
   * @returns {void}
   */
  getResource(cid: number) {
    wx.showLoading({ title: '数据加载中' });
    resourceApi.getResource({ category: cid, limit: 100 }).then((res) => {
      if (res.code !== SUCESS_CODE) {
        wx.showToast({ title: '获取数据失败！', icon: 'error' })
        return;
      }
      let list = res.data.data.map(v => {
        const ext: string[] = v.url.split(".");
        v.extension = ext[ext.length - 1].toLowerCase();
        return v;
      })
      this.setData({ list})
    }).finally(() => {
      wx.hideLoading();
    })
  },

  /**
   * tab切换
   */
  handleClick(e: any) {
    const currentTab = e.currentTarget.dataset.index
    this.setData({ currentTab })
    this.getResource(this.data.category[currentTab]?.id);
  },

  preview(e: any) {
    wx.downloadFile({
      // 示例 url，并非真实存在
      url: e.currentTarget.dataset.url,
      success: function (res) {
        const filePath = res.tempFilePath
        wx.openDocument({
          filePath: filePath,
          success: function (res: any) {
            console.log('打开文档成功')
          }
        })
      }
    })
  },

  async createPrintJob(e:any): Promise<void> {
    if (!this._checkAuth()) {
      return;
    }
    if (!(await this.checkDeviceInfo())) {
      return;
    }

    const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
    if (!printerAbility || !printerAbility.file || !printerAbility.file.mediaSize || !printerAbility.file.mediaSize.length) {
      wx.showToast({ icon: "error", title: "不支持文档打印" });
      return;
    }
    wx.navigateTo({
      url: `/pages/index/uploadDoc/uploadDoc?file=${e.currentTarget.dataset.url}&name=${e.currentTarget.dataset.name}&isResource=1`,
    });
  },

    /**
   * @description 操作权限判断
   * @returns {boolean}
   */
  _checkAuth(): boolean {
    if (!storageUtil.getStorageSync(USER_INFO)) {
      wx.showToast({ icon: "error", title: "请先登录" });
      return false;
    }
    if (!storageUtil.getStorageSync(BOX_INFO_KEY)) {
      wx.showToast({ icon: "error", title: "请先绑定设备" })
      return false
    }
    if (!this.data.devStatus) {
      wx.showToast({ icon: "error", title: "请检查设备状态" })
      return false
    }
    if (!this.data.printStatus) {
      wx.showToast({ icon: "error", title: "请检查打印机状态" })
      return false
    }
    return true;
  },

  /**
   * @description 检查盒子绑定的定义及是否改变了
   */
  async checkDeviceInfo() {
    const param = {
      device_id: storageUtil.getStorageSync(BOX_INFO_KEY)?.device_id,
      force_mqtt: false,
      user_id: storageUtil.getStorageSync(USER_INFO)?.userId,
    };
    const deviceInfo = await deviceApi.getDeviceInfo(param);
    if (deviceInfo.code !== SUCESS_CODE) {
      console.error("获取设备信息失败");
      return false;
    }
    const printInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
    console.log("printInfo", deviceInfo);
    if (deviceInfo.data.printer_make === printInfo.make && deviceInfo.data.printer_model === printInfo.model) {
      return true;
    }
    const printerInfo = {
      make: deviceInfo.data.printer_make,
      model: deviceInfo.data.printer_model,
    }
    storageUtil.setStorageSync(PRINTER_INFO_KEY, printerInfo);
    const printAbility = await deviceApi.getPrinterAbility(printInfo);
    console.log("PrinterAbility", printAbility);
    if (printAbility.code !== SUCESS_CODE || !printAbility.capability.length) {
      console.error("获取打印机能力失败");
      return false;
    }
    try {
      const ability = DeviceUtil.getInstance().JIE(printAbility.capability[0].auto_cap);        
      const autoCap = JSON.parse(ability);
      console.log("PrinterAbility-auto_cap", autoCap);
      if (autoCap.bin_option) {
        storageUtil.setStorageSync(BIN_OPTION, autoCap.bin_option);
      }
      DeviceUtil.getInstance().dealAbilityData(autoCap.media_sizes);
      storageUtil.setStorageSync(PRINTER_ABILITY_GROUP_KEY, printAbility.capability[0].group);
    } catch (error) {
      return false
    }
    return true;
  },

  /**
   * @description 获取设备状态
   */
  getDeviceStatus(): void {
    if (!storageUtil.getStorageSync(USER_INFO)) {
      this.setData({ deviceStatus: false });
      return;
    }
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    if (!boxInfo) {
      console.log("无法获取boxinfo，请先蓝牙连接", boxInfo);
      this.setData({ deviceStatus: false });
      return;
    }
    const param = { device_id: boxInfo.device_id };
    deviceApi
      .getDeviceStatus(param)
      .then((res) => {
        console.log("getDeviceStatus-sucess", res);
        if (res.code !== SUCESS_CODE) {
          return;
        }
        const printerInfo = storageUtil.getStorageSync(PRINTER_INFO_KEY);
        this.setData({
          devStatus: res.data.dev_online,
          printStatus: res.data.printer_connect,
        });
        if (printerInfo && printerInfo.make) {
          const printerAbility = storageUtil.getStorageSync(PRINTER_ABILITY_KEY)
          if (!printerAbility) {
            this.getPrinterAbility(printerInfo);
          }
          return
        }
        this.getDeviceInfo(boxInfo.device_id);
      })
      .catch((err) => {
        console.log("getDeviceStatus-err", err);
      });
  },

  /**
   * @description 获取设备信息
   */
  getDeviceInfo(device_id: string): void {
    const param = {
      device_id,
      force_mqtt: false,
      user_id: storageUtil.getStorageSync(USER_INFO)?.userId,
    };
    deviceApi
      .getDeviceInfo(param)
      .then((res) => {
        console.log("getDeviceInfo-sucess", res);
        if (res.code !== SUCESS_CODE) {
          return;
        }
        if (!res.data.printer_make || !res.data.printer_model) {
          return
        }
        const printerInfo = {
          make: res.data.printer_make,
          model: res.data.printer_model,
        }
        storageUtil.setStorageSync(PRINTER_INFO_KEY, printerInfo);
        this.getPrinterAbility(printerInfo);
      })
      .catch((err) => {
        console.log("getDeviceInfo-err", err);
      });
  },

  /**
   * @description 获取打印能力
   */
  getPrinterAbility({ make, model }: { make: string; model: string }) {
    deviceApi.getPrinterAbility({ make, model })
      .then((res) => {
        console.log("getPrinterAbility-sucess", res);
        if (res.code !== SUCESS_CODE || !res.capability.length) {
          console.error("获取打印机能力失败");
          return;
        }
        const ability = DeviceUtil.getInstance().JIE(res.capability[0].auto_cap);        
        const autoCap = JSON.parse(ability);
        console.log("PrinterAbility-auto_cap", autoCap);
        if (autoCap.bin_option) {
          storageUtil.setStorageSync(BIN_OPTION, autoCap.bin_option);
        }
        DeviceUtil.getInstance().dealAbilityData(autoCap.media_sizes);
        storageUtil.setStorageSync(PRINTER_ABILITY_GROUP_KEY, res.capability[0].group);
      })
      .catch((err) => {
        console.log("getPrinterAbility-err", err);
        wx.showToast({ icon: "error", title: "请重试" });
      });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getDeviceStatus();
    this.getResourceCategory();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})