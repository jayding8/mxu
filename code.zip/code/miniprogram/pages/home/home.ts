// pages/home/home.ts
import { BOX_INFO_KEY } from "../../constant/device";
import { USER_INFO } from "../../constant/user";
import storageUtil from "../../utils/storageUtil";

Page({
  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: "../../assets/imgs/logo.png",
    nickName: "未登录",
  },

  manageUserInfo() { },

  /**
   * @description 跳转登录页
   */
  goLogin() {
    const userInfo = storageUtil.getStorageSync(USER_INFO);
    if (userInfo) {
      return;
    }
    wx.navigateTo({
      url: "/views/user/user",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 跳转设备详情
   */
  goDevDetail() {
    if (!storageUtil.getStorageSync(USER_INFO)) {
      wx.showToast({ icon: 'error', title: "请先登录" })
      return;
    }
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    if (!boxInfo) {
      wx.showToast({ icon: 'error', title: "请先绑定设备" })
      return;
    }
    wx.navigateTo({
      url: "/views/device/detail/detail",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 跳转打印记录
   */
  goPrintHistory() {
    if (!storageUtil.getStorageSync(USER_INFO)) {
      wx.showToast({ icon: 'error', title: "请先登录" })
      return;
    }
    let boxInfo = storageUtil.getStorageSync(BOX_INFO_KEY);
    if (!boxInfo) {
      wx.showToast({ icon: 'error', title: "请先绑定设备" })
      return;
    }
    wx.navigateTo({
      url: "/views/device/history/history",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 跳转意见反馈
   */
  goFeedbackForm() {
    wx.navigateTo({
      url: "/views/feedback/feedbackForm/feedbackForm",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 跳转意见反馈
   */
  goConnectUs() {
    wx.navigateTo({
      url: "/views/feedback/connectUs/connectUs",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * @description 跳转设置详情
   */
  goSettingDetail() {
    wx.navigateTo({
      url: "/views/setting/setting",
      success: (res) => {
        console.log("success", res);
      },
      fail: (err) => {
        console.log("error", err);
      },
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() { },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() { },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    const userInfo = storageUtil.getStorageSync(USER_INFO);
    if (userInfo && userInfo.phone_number) {
      this.setData({ nickName: userInfo?.phone_number });
    } else {
      this.setData({ nickName: "未登录" });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() { },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() { },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() { },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() { },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() { },
});
