export const SUCESS_CODE = 200;

// 文件大小限制20M
export const FILE_SIZE_LIMIT = 20 * 1024 * 1024;

// 批量上传文件上限
export const FILE_LIMIT = 5;