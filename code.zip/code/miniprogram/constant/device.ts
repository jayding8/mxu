// 手机信息
export const MOBILE_INFO_KEY = "mobileInfo";

// 盒子信息
export const BOX_INFO_KEY = "boxInfo";

// 设备信息
export const PRINTER_INFO_KEY = "printerInfo";

// 打印机能力
export const PRINTER_ABILITY_KEY = "printerAbility";

// 打印机能力分组
export const PRINTER_ABILITY_GROUP_KEY = "printerAbilityGroup";

// 打印机进纸口
export const BIN_OPTION = 'bin_option';

export const HISTORY_PARAM = 'history_param';

// 能力类型，photo照片，plain文档
export enum MEDIA_TYPE {
  GCP_MT_PLAIN = "GCP_MT_PLAIN",
  GCP_MT_PHOTO = "GCP_MT_PHOTO",
}

export enum COLOR_MODE {
  GCP_CM_COLOR = "GCP_CM_COLOR",
  GCP_CM_GRAY = "GCP_CM_GRAY",
}

export const COLOR_MODE_TRANSLATE = [
  { value: COLOR_MODE.GCP_CM_GRAY, label: "黑白", checked: true },
  { value: COLOR_MODE.GCP_CM_COLOR, label: "彩色", checked: false },
];

export enum EXPOSURE_MODE {
  DEFAULT,
  GROWTH,
}

export const EXPOSURE_MODE_TRANSLATE = [
  { value: EXPOSURE_MODE.DEFAULT, label: "默认", checked: true },
  { value: EXPOSURE_MODE.GROWTH, label: "增强", checked: false },
];

/*    
key      名称   尺寸(mm)    
GCP_MS_A4  A4  210*297    
GCP_MS_A5  A5  148*210    
GCP_MS_A6  A6  105*148    
GCP_MS_A3  A3  297*420    
GCP_MS_2L  7寸  127*178    
GCP_MS_4X6 6寸  102*152    
GCP_MS_L   5寸  89*127    
GCP_MS_POSTCARD 明信片 100*148    
GCP_MS_JIS_B4 JIS_B4 257*364    
GCP_MS_JIS_B5 JIS_B5 182*257    
GCP_MS_ISO_B4 ISO_B4 250*353    
GCP_MS_ISO_B5 ISO_B5 176*250    
GCP_MS_241_1  215.9*279.4    
GCP_MS_241_2  215.9*139.7    
GCP_MS_241_3  215.9*93.1    
*/
export enum MEDIA_SIZE {
  GCP_MS_A4 = "GCP_MS_A4",
  GCP_MS_A5 = "GCP_MS_A5",
  GCP_MS_A6 = "GCP_MS_A6",
  GCP_MS_A3 = "GCP_MS_A3",
  GCP_MS_2L = "GCP_MS_2L",
  GCP_MS_4X6 = "GCP_MS_4X6",
  GCP_MS_L = "GCP_MS_L",
  GCP_MS_POSTCARD = "GCP_MS_POSTCARD",
  GCP_MS_JIS_B4 = "GCP_MS_JIS_B4",
  GCP_MS_JIS_B5 = "GCP_MS_JIS_B5",
  GCP_MS_ISO_B4 = "GCP_MS_ISO_B4",
  GCP_MS_ISO_B5 = "GCP_MS_ISO_B5",
  GCP_MS_241_2 = "GCP_MS_241_2",
  GCP_MS_241_3 = "GCP_MS_241_3",
}

export const MEDIA_SIZE_TRANSLATE = [
  { value: MEDIA_SIZE.GCP_MS_A4, label: "A4" },
  { value: MEDIA_SIZE.GCP_MS_A5, label: "A5" },
  { value: MEDIA_SIZE.GCP_MS_A6, label: "A6" },
  { value: MEDIA_SIZE.GCP_MS_A3, label: "A3" },
  { value: MEDIA_SIZE.GCP_MS_2L, label: "7寸" },
  { value: MEDIA_SIZE.GCP_MS_4X6, label: "6寸" },
  { value: MEDIA_SIZE.GCP_MS_L, label: "5寸" },
  { value: MEDIA_SIZE.GCP_MS_POSTCARD, label: "明信片" },
  { value: MEDIA_SIZE.GCP_MS_JIS_B4, label: "JIS_B4" },
  { value: MEDIA_SIZE.GCP_MS_JIS_B5, label: "JIS_B5" },
  { value: MEDIA_SIZE.GCP_MS_ISO_B4, label: "ISO_B4" },
  { value: MEDIA_SIZE.GCP_MS_ISO_B5, label: "ISO_B5" },
  { value: MEDIA_SIZE.GCP_MS_241_2, label: '二等分' },
  { value: MEDIA_SIZE.GCP_MS_241_3, label: '三等分' },
];

export enum DUPLEX_SIZE {
  GCP_DP_NONE = "GCP_DP_NONE",
  GCP_DP_NOTUMBLE = "GCP_DP_NOTUMBLE",
  GCP_DP_TUMBLE = "GCP_DP_TUMBLE",
  FIT_TO_WIDTH = "FIT_TO_WIDTH",
  FIT_TO_HEIGHT = "FIT_TO_HEIGHT",
}

export const DUPLEX_SIZE_TRANSLATE = [
  { value: DUPLEX_SIZE.GCP_DP_NONE, label: "单面打印" },
  { value: DUPLEX_SIZE.GCP_DP_NOTUMBLE, label: "竖向双面打印" },
  { value: DUPLEX_SIZE.GCP_DP_TUMBLE, label: "横向双面打印" },
  { value: DUPLEX_SIZE.FIT_TO_WIDTH, label: "所有列打印在一页" },
  { value: DUPLEX_SIZE.FIT_TO_HEIGHT, label: "所有行打印在一页" },
];

export enum ODD_OR_EVEN {
  DEFAULT,
  ODD,
  EVEN
}

export const ODD_OR_EVEN_TRANSLATE = [
  { value: ODD_OR_EVEN.ODD, label: "奇数页" },
  { value: ODD_OR_EVEN.EVEN, label: "偶数页" },
];

export enum DM_ORIENTATION {
  DMORIENT_PORTRAIT = 1,
  DMORIENT_LANDSCAPE = 2,
}

export const DM_ORIENTATION_TRANSLATE = [
  { value: DM_ORIENTATION.DMORIENT_PORTRAIT, label: "纵向打印" },
  { value: DM_ORIENTATION.DMORIENT_LANDSCAPE, label: "横向打印" },
];

export enum STRETCH_MODE {
  WIDTH,
  HEIGHT,
  FIT,
}

export const STRETCH_MODE_TRANSLATE = [
  { value: STRETCH_MODE.WIDTH, label: "横向自适应" },
  { value: STRETCH_MODE.HEIGHT, label: "纵向自适应" },
  { value: STRETCH_MODE.FIT, label: "铺满纸张" },
];

export enum QUALITY_MODE {
  GCP_QM_DRAFT = "GCP_QM_DRAFT",
  GCP_QM_NORMAL = "GCP_QM_NORMAL",
  GCP_QM_HIGH = "GCP_QM_HIGH",
}

export const QUALITY_MODE_TRANSLATE = [
  { value: QUALITY_MODE.GCP_QM_DRAFT, label: "草稿" },
  { value: QUALITY_MODE.GCP_QM_NORMAL, label: "普通" },
  { value: QUALITY_MODE.GCP_QM_HIGH, label: "高质量" },
];

export enum FILE_STATUS {
  SUCESS,
  SIZE_LIMIT,
  TYPE_LIMIT,
  UPLOAD_FAIL,
  CONVERT_FAIL,
}