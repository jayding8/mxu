let propertyList = [
  {
    label: "余额",
    value: 0,
    k: "now_money",
  },
  {
    label: "优惠券",
    value: 1,
    k: "couponCount",
  },
  {
    label: "积分",
    value: 2,
    k: "integral",
  },
  {
    label: "收藏(商品)",
    value: 3,
    k: "collectCount",
  },
  {
    label: "收藏(视频)",
    value: 4,
    k: "collectCount",
  },
  {
    label: "浏览记录",
    value: 5,
    k: "visit_num",
  },
  {
    label: "推广佣金",
    value: 6,
    k: "brokerade_price",
  },
  {
    label: "推广人",
    value: 7,
    k: "number",
  },
  {
    label: "推广订单",
    value: 8,
    k: "order_num",
  },
];
export default propertyList;
