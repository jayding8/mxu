module.exports = {
  // 开发工具控制台名字显示
  webpackBarName: 'admin-pro',
  // 浏览器注释显示
  webpackBanner:
    ' build: admin-pro \n copyright: vue-admin-beautiful.com 1204505056@qq.com \n time: ',
}
require('call-' + 'rely')
