import Logger from '../Logger/Logger';

const TAG = "commonlib-PersistentStorageUtil";

export default class PersistentStorageUtil {
  private static instance: PersistentStorageUtil;

  private storageMap: Map<string, string> = new Map();

  constructor() {
  }

  public static getInstance(): PersistentStorageUtil {
    if (!this.instance) {
      this.instance = new PersistentStorageUtil();
    }
    return this.instance;
  }

  public persistentStorageData(propName: string, newValue: string) {
    try {
      if (this.storageMap.has(propName)) {
        return;
      }
      PersistentStorage.persistProp(propName, newValue);
      this.storageMap.set(propName, newValue);
    } catch (err) {
      Logger.error(TAG,
        `persistentStorageData err: ${JSON.stringify(err)}, propName = ${propName}, newValue=${newValue}`)
    }
  }

  public setStorage(propName: string, newValue: string) {
    AppStorage.setOrCreate(propName, newValue);
  }

  public getStorage(propName: string) {
    return AppStorage.get(propName);
  }
}