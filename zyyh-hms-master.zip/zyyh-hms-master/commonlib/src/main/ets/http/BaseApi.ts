import { BusinessError } from '@kit.BasicServicesKit';
import { rcp } from "@kit.RemoteCommunicationKit";
import Logger from '../Logger/Logger';

const TAG = "commonLib-BaseApi";

export default class BaseApi {
  protected host: string = "https://www.wtcloudbox.cn";
  protected path: string = "/app/api";
  protected version: string = "/v1";
  protected url: string = "";

  /**
   * 设置host，用于特殊请求场景
   *
   * @param {string} host 请求host，格式为 protocol://hostname[:port]/
   */
  public setHost(host): void {
    this.host = host;
  }

  public request() {

  }

  public get(url: string) {
    const session = rcp.createSession();

    session.get(url).then((rep: rcp.Response) => {
      console.info(`Response succeeded: ${rep}`);
    }).catch((err: BusinessError) => {
      console.error(`Response err: Code is ${err.code}, message is ${err.message}`);
    });
  }

  public post(url: string, data) {
    const session = rcp.createSession();

    Logger.info(TAG, `Request params: ${url}  data: ${JSON.stringify(data)}`);
    // session.close();
    return session.post(url, data);
  }

  public put(url: string, data) {
    const session = rcp.createSession();

    Logger.info(TAG, `Request params: ${url}  data: ${JSON.stringify(data)}`);
    // session.close();
    return session.put(url, data);
  }

  protected getQueryString(param: any) {
    let str = "";
    for (const key in param) {
      if (Object.prototype.hasOwnProperty.call(param, key)) {
        str += `${key}=${param[key]}&`;
      }
    }
    return encodeURI(str.replace(/&$/, ""));
  }
}
