export const SUCESS_CODE = 200;

// 用户登录信息
export const USER_INFO_KEY = "userInfo";

// 手机信息
export const MOBILE_INFO_KEY = "mobileInfo";

// 盒子信息
export const BOX_INFO_KEY = "boxInfo";

// 设备信息
export const PRINTER_INFO_KEY = "printerInfo";

// 打印机能力
export const PRINTER_ABILITY_KEY = "printerAbility";

// 打印机能力分组
export const PRINTER_ABILITY_GROUP_KEY = "printerAbilityGroup";

// 打印机进纸口
export const BIN_OPTION = 'bin_option';