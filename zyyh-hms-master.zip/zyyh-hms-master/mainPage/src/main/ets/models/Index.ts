export enum TAB_TYPE {
  HOME,
  RESOURCE,
  USER,
}

export interface TabItem {
  name: string;
  icon: string;
  selectedIcon: string;
  type: TAB_TYPE;
}