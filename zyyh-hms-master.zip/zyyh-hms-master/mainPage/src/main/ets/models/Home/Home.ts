export interface CommonResult<T> {
  code: number;
  msg: string;
  data: T;
}

// 查询设备状态：入参
export interface DeviceStatusParam {
  device_id: string;
}

// 查询设备状态：返回值
export interface DeviceStatusResult {
  dev_online: boolean;
  printer_connect: boolean;
}