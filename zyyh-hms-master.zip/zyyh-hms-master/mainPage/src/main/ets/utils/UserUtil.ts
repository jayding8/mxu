const PHONE_LEN = 11;
const MIN_PWD_LEN = 8;

class UserUtil {
  /**
   * 校验账号
   *
   * @param account 用户账号
   */
  public checkAccount(account: string): boolean {
    if (!account) {
      return false;
    }
    if (account.length !== PHONE_LEN) {
      return false;
    }
    return true;
  }

  /**
   * 校验密码
   *
   * @param pwd 用户密码
   */
  public checkPassword(pwd: string): boolean {
    if (!pwd) {
      return false;
    }
    if (pwd.length < MIN_PWD_LEN) {
      return false;
    }
    return true;
  }
}

export default new UserUtil();