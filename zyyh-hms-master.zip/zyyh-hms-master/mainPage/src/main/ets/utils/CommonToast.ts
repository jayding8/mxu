import { promptAction } from '@kit.ArkUI'
import { BusinessError } from '@kit.BasicServicesKit';
import { Logger } from '@ohos/commonlib';

const TAG = "MainPage-CommonToast";

class CommonToast {
  showToast(toastOptions: promptAction.ShowToastOptions, callback?: () => void) {
    const duration = toastOptions.duration ?? 2000;
    try {
      promptAction.showToast({
        message: toastOptions.message,
        duration,
      });
    } catch (error) {
      let message = (error as BusinessError).message
      let code = (error as BusinessError).code
      Logger.error(TAG, `showToast args error code is ${code}, message is ${message}`);
    }
    if (callback) {
      const timer = setTimeout(() => {
        callback();
        clearTimeout(timer)
      }, duration)
    }
  }
}

export default new CommonToast();